
// ===== DADOS ORIGINAIS (nomes fictícios; edite no menu Editor) =====
const SILABAS1=["Ro","Ma","Fe","Ca","Jo","Lu","Pa","Vi","Ri","Th","An","Be","Gu","Le","Da","Wa","Hu","Ed","Ni","Os"];
const SILABAS2=["drigo","theus","lipe","ique","ão","cas","ulo","tor","cardo","iago","dré","to","stavo","andro","vi","lter","go","son","colas","car"];
const SOBRE=["Silva","Souza","Lima","Costa","Rocha","Alves","Pinto","Mendes","Duarte","Nunes","Barros","Freitas","Lopes","Moura","Reis","Cunha","Matos","Farias"];
const LIGAS={"Brasil":[[["Flamengo","FLA","#c8102e","#111111"],["Palmeiras","PAL","#006437","#ffffff"],["Corinthians","COR","#111111","#ffffff"],["São Paulo","SÃP","#e30613","#111111"],["Santos","SAN","#ffffff","#111111"],["Fluminense","FLU","#7a0019","#00843d"],["Botafogo","BOT","#111111","#ffffff"],["Vasco da Gama","VDG","#111111","#ffffff"],["Grêmio","GRÊ","#0d80bf","#111111"],["Internacional","INT","#e30613","#ffffff"],["Atlético Mineiro","ATM","#111111","#ffffff"],["Cruzeiro","CRU","#0033a0","#ffffff"],["Bahia","BAH","#0033a0","#e30613"],["Vitória","VIT","#e30613","#111111"],["Fortaleza","FOR","#0033a0","#e30613"],["Ceará","CEA","#111111","#ffffff"],["Athletico Paranaense","ATP","#e30613","#111111"],["Coritiba","COR","#00843d","#ffffff"],["Sport Recife","SPR","#e30613","#111111"],["Goiás","GOI","#00843d","#ffffff"]],[["Avaí","AVA","#cd6133","#ffffff"],["Criciúma","CRI","#e74c3c","#111111"],["Chapecoense","CHA","#c0392b","#ffffff"],["Juventude","JUV","#d35400","#111111"],["Vila Nova","VIN","#d35400","#111111"],["Novorizontino","NOV","#cd6133","#ffffff"],["Mirassol","MIR","#8e44ad","#ffffff"],["Ponte Preta","POP","#e74c3c","#111111"],["Guarani","GUA","#8e44ad","#ffffff"],["Operário-PR","OPP","#cd6133","#ffffff"],["Paysandu","PAY","#1abc9c","#111111"],["Remo","REM","#2980b9","#ffffff"],["CRB","CRB","#b33939","#ffffff"],["Amazonas","AMA","#e74c3c","#111111"],["Botafogo-SP","BOS","#8e44ad","#ffffff"],["Ituano","ITU","#273c75","#ffffff"],["Brusque","BRU","#218c74","#ffffff"],["América-MG","AMM","#8e44ad","#ffffff"],["Atlético-GO","ATG","#0097e6","#ffffff"],["Cuiabá","CUI","#b33939","#ffffff"]],[["Ypiranga","YPI","#2980b9","#ffffff"],["Figueirense","FIG","#b33939","#ffffff"],["Londrina","LON","#cd6133","#ffffff"],["Volta Redonda","VOR","#16a085","#ffffff"],["Náutico","NÁU","#218c74","#ffffff"],["Santa Cruz","SAC","#d35400","#111111"],["Confiança","CON","#b33939","#ffffff"],["Botafogo-PB","BOP","#8e44ad","#ffffff"],["Ferroviária","FER","#8e44ad","#ffffff"],["Tombense","TOM","#273c75","#ffffff"],["Athletic-MG","ATM","#34495e","#ffffff"],["Aparecidense","APA","#8e44ad","#ffffff"],["São Bernardo","SÃB","#c0392b","#ffffff"],["Floresta","FLO","#2980b9","#ffffff"],["ABC","ABC","#1abc9c","#111111"],["Campinense","CAM","#16a085","#ffffff"],["Maringá","MAR","#e74c3c","#111111"],["Caxias","CAX","#b33939","#ffffff"],["Anápolis","ANÁ","#d35400","#111111"],["Manaus","MAN","#1abc9c","#111111"]]],"Inglaterra":[[["Arsenal","ARS","#ef0107","#ffffff"],["Aston Villa","ASV","#8e44ad","#ffffff"],["Bournemouth","BOU","#218c74","#ffffff"],["Brentford","BRE","#273c75","#ffffff"],["Brighton","BRI","#b33939","#ffffff"],["Chelsea","CHE","#034694","#ffffff"],["Crystal Palace","CRP","#f39c12","#111111"],["Everton","EVE","#16a085","#ffffff"],["Fulham","FUL","#16a085","#ffffff"],["Liverpool","LIV","#c8102e","#ffffff"],["Manchester City","MAC","#6cabdd","#ffffff"],["Manchester United","MAU","#da291c","#111111"],["Newcastle United","NEU","#e74c3c","#111111"],["Nottingham Forest","NOF","#273c75","#ffffff"],["Tottenham","TOT","#8e44ad","#ffffff"],["West Ham","WEH","#34495e","#ffffff"],["Wolverhampton","WOL","#c0392b","#ffffff"],["Leeds United","LEU","#16a085","#ffffff"],["Burnley","BUR","#0097e6","#ffffff"],["Sunderland","SUN","#d35400","#111111"]],[["Leicester City","LEC","#c0392b","#ffffff"],["Southampton","SOU","#8e44ad","#ffffff"],["Ipswich Town","IPT","#e74c3c","#111111"],["Norwich City","NOC","#e74c3c","#111111"],["West Bromwich","WEB","#e74c3c","#111111"],["Middlesbrough","MID","#16a085","#ffffff"],["Sheffield United","SHU","#e74c3c","#111111"],["Watford","WAT","#b33939","#ffffff"],["Coventry City","COC","#f39c12","#111111"],["Hull City","HUC","#0097e6","#ffffff"],["Stoke City","STC","#d35400","#111111"],["Swansea City","SWC","#f39c12","#111111"],["Bristol City","BRC","#0097e6","#ffffff"],["Cardiff City","CAC","#218c74","#ffffff"],["Blackburn Rovers","BLR","#16a085","#ffffff"],["Preston North End","PNE","#27ae60","#ffffff"],["Millwall","MIL","#8e44ad","#ffffff"],["Queens Park Rangers","QPR","#273c75","#ffffff"],["Sheffield Wednesday","SHW","#16a085","#ffffff"],["Derby County","DEC","#e74c3c","#111111"]],[["Birmingham City","BIC","#b33939","#ffffff"],["Wrexham","WRE","#16a085","#ffffff"],["Charlton Athletic","CHA","#8e44ad","#ffffff"],["Wigan Athletic","WIA","#218c74","#ffffff"],["Huddersfield Town","HUT","#e74c3c","#111111"],["Bolton Wanderers","BOW","#218c74","#ffffff"],["Reading","REA","#0097e6","#ffffff"],["Portsmouth","POR","#2980b9","#ffffff"],["Stockport County","STC","#34495e","#ffffff"],["Barnsley","BAR","#b33939","#ffffff"],["Peterborough United","PEU","#c0392b","#ffffff"],["Lincoln City","LIC","#27ae60","#ffffff"],["Blackpool","BLA","#c0392b","#ffffff"],["Rotherham United","ROU","#cd6133","#ffffff"],["Leyton Orient","LEO","#b33939","#ffffff"],["Wycombe Wanderers","WYW","#0097e6","#ffffff"],["Exeter City","EXC","#218c74","#ffffff"],["Burton Albion","BUA","#16a085","#ffffff"],["Mansfield Town","MAT","#d35400","#111111"],["Stevenage","STE","#d35400","#111111"]]],"Espanha":[[["Real Madrid","REM","#ffffff","#febe10"],["Barcelona","BAR","#a50044","#004d98"],["Atlético de Madrid","ADM","#cd6133","#ffffff"],["Sevilla","SEV","#cd6133","#ffffff"],["Real Betis","REB","#16a085","#ffffff"],["Real Sociedad","RES","#c0392b","#ffffff"],["Villarreal","VIL","#cd6133","#ffffff"],["Athletic Bilbao","ATB","#e74c3c","#111111"],["Valencia","VAL","#2980b9","#ffffff"],["Girona","GIR","#273c75","#ffffff"],["Osasuna","OSA","#218c74","#ffffff"],["Celta de Vigo","CDV","#218c74","#ffffff"],["Getafe","GET","#f39c12","#111111"],["Rayo Vallecano","RAV","#0097e6","#ffffff"],["Mallorca","MAL","#1abc9c","#111111"],["Alavés","ALA","#273c75","#ffffff"],["Las Palmas","LAP","#218c74","#ffffff"],["Espanyol","ESP","#1abc9c","#111111"],["Levante","LEV","#8e44ad","#ffffff"],["Elche","ELC","#cd6133","#ffffff"]],[["Leganés","LEG","#273c75","#ffffff"],["Real Valladolid","REV","#8e44ad","#ffffff"],["Granada","GRA","#2980b9","#ffffff"],["Almería","ALM","#e74c3c","#111111"],["Cádiz","CÁD","#b33939","#ffffff"],["Deportivo La Coruña","DLC","#d35400","#111111"],["Racing Santander","RAS","#f39c12","#111111"],["Sporting Gijón","SPG","#f39c12","#111111"],["Real Oviedo","REO","#cd6133","#ffffff"],["Zaragoza","ZAR","#8e44ad","#ffffff"],["Eibar","EIB","#c0392b","#ffffff"],["Málaga","MÁL","#c0392b","#ffffff"],["Burgos","BUR","#34495e","#ffffff"],["Mirandés","MIR","#1abc9c","#111111"],["Castellón","CAS","#34495e","#ffffff"],["Huesca","HUE","#e74c3c","#111111"],["Córdoba","CÓR","#cd6133","#ffffff"],["Albacete","ALB","#16a085","#ffffff"],["Racing Ferrol","RAF","#27ae60","#ffffff"],["Cartagena","CAR","#b33939","#ffffff"]],[["Real Murcia","REM","#c0392b","#ffffff"],["Tenerife","TEN","#34495e","#ffffff"],["Racing Ferrol B","RFB","#1abc9c","#111111"],["Ibiza","IBI","#f39c12","#111111"],["Lugo","LUG","#2980b9","#ffffff"],["Numancia","NUM","#8e44ad","#ffffff"],["Alcorcón","ALC","#16a085","#ffffff"],["Recreativo Huelva","REH","#27ae60","#ffffff"],["Sabadell","SAB","#b33939","#ffffff"],["Ponferradina","PON","#c0392b","#ffffff"],["Cultural Leonesa","CUL","#273c75","#ffffff"],["Villarreal B","VIB","#c0392b","#ffffff"],["Barcelona Atlètic","BAA","#e74c3c","#111111"],["Real Madrid Castilla","RMC","#27ae60","#ffffff"],["Atlético Sanluqueño","ATS","#c0392b","#ffffff"],["Algeciras","ALG","#b33939","#ffffff"],["Hércules","HÉR","#34495e","#ffffff"],["Amorebieta","AMO","#cd6133","#ffffff"],["Arenteiro","ARE","#16a085","#ffffff"],["Teruel","TER","#273c75","#ffffff"]]],"Itália":[[["Inter","INT","#0068a8","#111111"],["Milan","MIL","#fb090b","#111111"],["Juventus","JUV","#111111","#ffffff"],["Napoli","NAP","#27ae60","#ffffff"],["Roma","ROM","#8e44ad","#ffffff"],["Lazio","LAZ","#0097e6","#ffffff"],["Atalanta","ATA","#0097e6","#ffffff"],["Fiorentina","FIO","#273c75","#ffffff"],["Bologna","BOL","#8e44ad","#ffffff"],["Torino","TOR","#34495e","#ffffff"],["Genoa","GEN","#1abc9c","#111111"],["Udinese","UDI","#273c75","#ffffff"],["Cagliari","CAG","#cd6133","#ffffff"],["Verona","VER","#f39c12","#111111"],["Parma","PAR","#8e44ad","#ffffff"],["Lecce","LEC","#273c75","#ffffff"],["Como","COM","#d35400","#111111"],["Sassuolo","SAS","#e74c3c","#111111"],["Pisa","PIS","#0097e6","#ffffff"],["Cremonese","CRE","#d35400","#111111"]],[["Palermo","PAL","#34495e","#ffffff"],["Sampdoria","SAM","#f39c12","#111111"],["Venezia","VEN","#1abc9c","#111111"],["Spezia","SPE","#218c74","#ffffff"],["Bari","BAR","#218c74","#ffffff"],["Cesena","CES","#e74c3c","#111111"],["Modena","MOD","#34495e","#ffffff"],["Frosinone","FRO","#34495e","#ffffff"],["Empoli","EMP","#34495e","#ffffff"],["Monza","MON","#cd6133","#ffffff"],["Brescia","BRE","#2980b9","#ffffff"],["Catanzaro","CAT","#cd6133","#ffffff"],["Reggiana","REG","#16a085","#ffffff"],["Salernitana","SAL","#8e44ad","#ffffff"],["Cosenza","COS","#8e44ad","#ffffff"],["Sudtirol","SUD","#273c75","#ffffff"],["Juve Stabia","JUS","#b33939","#ffffff"],["Carrarese","CAR","#2980b9","#ffffff"],["Mantova","MAN","#2980b9","#ffffff"],["Cittadella","CIT","#d35400","#111111"]],[["Vicenza","VIC","#b33939","#ffffff"],["Padova","PAD","#b33939","#ffffff"],["Triestina","TRI","#273c75","#ffffff"],["Pescara","PES","#34495e","#ffffff"],["Ascoli","ASC","#cd6133","#ffffff"],["Perugia","PER","#1abc9c","#111111"],["Ternana","TER","#16a085","#ffffff"],["Avellino","AVE","#d35400","#111111"],["Benevento","BEN","#0097e6","#ffffff"],["Foggia","FOG","#16a085","#ffffff"],["Lecco","LEC","#cd6133","#ffffff"],["Catania","CAT","#c0392b","#ffffff"],["Arezzo","ARE","#16a085","#ffffff"],["Gubbio","GUB","#2980b9","#ffffff"],["Pontedera","PON","#8e44ad","#ffffff"],["Pianese","PIA","#27ae60","#ffffff"],["Torres","TOR","#34495e","#ffffff"],["Entella","ENT","#f39c12","#111111"],["Rimini","RIM","#b33939","#ffffff"],["Pergolettese","PER","#8e44ad","#ffffff"]]],"Alemanha":[[["Bayern de Munique","BDM","#dc052d","#ffffff"],["Borussia Dortmund","BOD","#fde100","#111111"],["RB Leipzig","RBL","#1abc9c","#111111"],["Bayer Leverkusen","BAL","#16a085","#ffffff"],["Eintracht Frankfurt","EIF","#34495e","#ffffff"],["Stuttgart","STU","#16a085","#ffffff"],["Wolfsburg","WOL","#cd6133","#ffffff"],["Borussia Mönchengladbach","BOM","#c0392b","#ffffff"],["Werder Bremen","WEB","#d35400","#111111"],["Freiburg","FRE","#0097e6","#ffffff"],["Hoffenheim","HOF","#218c74","#ffffff"],["Mainz 05","MA0","#34495e","#ffffff"],["Union Berlin","UNB","#34495e","#ffffff"],["Augsburg","AUG","#16a085","#ffffff"],["Heidenheim","HEI","#d35400","#111111"],["St. Pauli","STP","#b33939","#ffffff"],["Köln","KÖL","#16a085","#ffffff"],["Hamburgo","HAM","#e74c3c","#111111"]],[["Schalke 04","SC0","#2980b9","#ffffff"],["Hertha Berlin","HEB","#f39c12","#111111"],["Hannover 96","HA9","#0097e6","#ffffff"],["Fortuna Düsseldorf","FOD","#cd6133","#ffffff"],["Nürnberg","NÜR","#c0392b","#ffffff"],["Kaiserslautern","KAI","#27ae60","#ffffff"],["Karlsruhe","KAR","#b33939","#ffffff"],["Paderborn","PAD","#2980b9","#ffffff"],["Magdeburg","MAG","#16a085","#ffffff"],["Hansa Rostock","HAR","#27ae60","#ffffff"],["Holstein Kiel","HOK","#273c75","#ffffff"],["Darmstadt","DAR","#e74c3c","#111111"],["Greuther Fürth","GRF","#cd6133","#ffffff"],["Braunschweig","BRA","#c0392b","#ffffff"],["Elversberg","ELV","#b33939","#ffffff"],["Preußen Münster","PRM","#1abc9c","#111111"],["Bochum","BOC","#b33939","#ffffff"],["Arminia Bielefeld","ARB","#d35400","#111111"]],[["Dynamo Dresden","DYD","#2980b9","#ffffff"],["1860 Munique","18M","#cd6133","#ffffff"],["Duisburg","DUI","#f39c12","#111111"],["Waldhof Mannheim","WAM","#0097e6","#ffffff"],["Erzgebirge Aue","ERA","#f39c12","#111111"],["Viktoria Köln","VIK","#0097e6","#ffffff"],["Energie Cottbus","ENC","#8e44ad","#ffffff"],["Saarbrücken","SAA","#2980b9","#ffffff"],["Wehen Wiesbaden","WEW","#1abc9c","#111111"],["Rot-Weiss Essen","RWE","#0097e6","#ffffff"],["Ingolstadt","ING","#d35400","#111111"],["Hannover 96 II","H9I","#e74c3c","#111111"],["Alemannia Aachen","ALA","#e74c3c","#111111"],["Osnabrück","OSN","#b33939","#ffffff"],["Verl","VER","#27ae60","#ffffff"],["Hoffenheim II","HOI","#273c75","#ffffff"],["Ulm","ULM","#c0392b","#ffffff"],["Borussia Dortmund II","BDI","#f39c12","#111111"]]],"França":[[["Paris Saint-Germain","PSG","#004170","#da291c"],["Olympique de Marseille","ODM","#8e44ad","#ffffff"],["Olympique Lyonnais","OLL","#f39c12","#111111"],["Monaco","MON","#0097e6","#ffffff"],["Lille","LIL","#0097e6","#ffffff"],["Nice","NIC","#f39c12","#111111"],["Lens","LEN","#34495e","#ffffff"],["Rennes","REN","#e74c3c","#111111"],["Strasbourg","STR","#34495e","#ffffff"],["Nantes","NAN","#2980b9","#ffffff"],["Toulouse","TOU","#1abc9c","#111111"],["Montpellier","MON","#d35400","#111111"],["Reims","REI","#f39c12","#111111"],["Brest","BRE","#b33939","#ffffff"],["Auxerre","AUX","#e74c3c","#111111"],["Angers","ANG","#e74c3c","#111111"],["Le Havre","LEH","#8e44ad","#ffffff"],["Metz","MET","#cd6133","#ffffff"],["Lorient","LOR","#1abc9c","#111111"],["Paris FC","PAF","#d35400","#111111"]],[["Saint-Étienne","SAÉ","#273c75","#ffffff"],["Bordeaux","BOR","#273c75","#ffffff"],["Sochaux","SOC","#b33939","#ffffff"],["Guingamp","GUI","#c0392b","#ffffff"],["Caen","CAE","#b33939","#ffffff"],["Rodez","ROD","#e74c3c","#111111"],["Pau","PAU","#273c75","#ffffff"],["Amiens","AMI","#e74c3c","#111111"],["Troyes","TRO","#b33939","#ffffff"],["Grenoble","GRE","#f39c12","#111111"],["Laval","LAV","#e74c3c","#111111"],["Red Star","RES","#b33939","#ffffff"],["Dunkerque","DUN","#cd6133","#ffffff"],["Annecy","ANN","#27ae60","#ffffff"],["Clermont","CLE","#27ae60","#ffffff"],["Bastia","BAS","#cd6133","#ffffff"],["Martigues","MAR","#27ae60","#ffffff"],["Ajaccio","AJA","#d35400","#111111"],["Nancy","NAN","#218c74","#ffffff"],["Valenciennes","VAL","#34495e","#ffffff"]],[["Nîmes","NÎM","#0097e6","#ffffff"],["Dijon","DIJ","#8e44ad","#ffffff"],["Quevilly-Rouen","QUR","#27ae60","#ffffff"],["Le Mans","LEM","#d35400","#111111"],["Orléans","ORL","#34495e","#ffffff"],["Niort","NIO","#2980b9","#ffffff"],["Versailles","VER","#27ae60","#ffffff"],["Bourg-en-Bresse","BEB","#cd6133","#ffffff"],["Villefranche","VIL","#34495e","#ffffff"],["Concarneau","CON","#c0392b","#ffffff"],["Paris 13 Atletico","P1A","#34495e","#ffffff"],["Sedan","SED","#218c74","#ffffff"],["Cholet","CHO","#c0392b","#ffffff"],["Fleury","FLE","#1abc9c","#111111"],["Stade Briochin","STB","#273c75","#ffffff"],["Aubagne","AUB","#c0392b","#ffffff"],["Nancy B","NAB","#16a085","#ffffff"],["Chambly","CHA","#1abc9c","#111111"],["Avranches","AVR","#273c75","#ffffff"],["Béziers","BÉZ","#1abc9c","#111111"]]],"Portugal":[[["Benfica","BEN","#e30613","#ffffff"],["Porto","POR","#003893","#ffffff"],["Sporting CP","SPC","#00794d","#ffffff"],["Braga","BRA","#273c75","#ffffff"],["Vitória de Guimarães","VDG","#d35400","#111111"],["Famalicão","FAM","#c0392b","#ffffff"],["Moreirense","MOR","#34495e","#ffffff"],["Estoril","EST","#218c74","#ffffff"],["Gil Vicente","GIV","#b33939","#ffffff"],["Casa Pia","CAP","#cd6133","#ffffff"],["Rio Ave","RIA","#218c74","#ffffff"],["Arouca","ARO","#8e44ad","#ffffff"],["Santa Clara","SAC","#e74c3c","#111111"],["Nacional","NAC","#273c75","#ffffff"],["Farense","FAR","#b33939","#ffffff"],["Alverca","ALV","#8e44ad","#ffffff"],["Tondela","TON","#34495e","#ffffff"],["Estrela da Amadora","EDA","#34495e","#ffffff"]],[["Boavista","BOA","#c0392b","#ffffff"],["Marítimo","MAR","#0097e6","#ffffff"],["Belenenses","BEL","#218c74","#ffffff"],["Vizela","VIZ","#8e44ad","#ffffff"],["Paços de Ferreira","PDF","#b33939","#ffffff"],["Chaves","CHA","#f39c12","#111111"],["Portimonense","POR","#0097e6","#ffffff"],["Académica","ACA","#1abc9c","#111111"],["Leixões","LEI","#2980b9","#ffffff"],["Desportivo das Aves","DDA","#d35400","#111111"],["Penafiel","PEN","#218c74","#ffffff"],["Mafra","MAF","#16a085","#ffffff"],["Torreense","TOR","#2980b9","#ffffff"],["Feirense","FEI","#1abc9c","#111111"],["Oliveirense","OLI","#d35400","#111111"],["Académico de Viseu","ADV","#0097e6","#ffffff"],["Vilafranquense","VIL","#273c75","#ffffff"],["Lourosa","LOU","#34495e","#ffffff"]],[["Varzim","VAR","#0097e6","#ffffff"],["Trofense","TRO","#d35400","#111111"],["Felgueiras","FEL","#c0392b","#ffffff"],["Fafe","FAF","#218c74","#ffffff"],["Länk Vilaverdense","LÄV","#cd6133","#ffffff"],["Sporting da Covilhã","SDC","#218c74","#ffffff"],["Anadia","ANA","#1abc9c","#111111"],["Amora","AMO","#d35400","#111111"],["União de Leiria","UDL","#1abc9c","#111111"],["Marinhense","MAR","#8e44ad","#ffffff"],["Real SC","RES","#273c75","#ffffff"],["Sporting B","SPB","#cd6133","#ffffff"],["Benfica B","BEB","#34495e","#ffffff"],["Porto B","POB","#273c75","#ffffff"],["Braga B","BRB","#c0392b","#ffffff"],["Cova da Piedade","CDP","#d35400","#111111"],["Sacavenense","SAC","#c0392b","#ffffff"],["Atlético CP","ATC","#34495e","#ffffff"]]],"Holanda":[[["Ajax","AJA","#d2122e","#ffffff"],["PSV Eindhoven","PSE","#2980b9","#ffffff"],["Feyenoord","FEY","#273c75","#ffffff"],["AZ Alkmaar","AZA","#218c74","#ffffff"],["FC Twente","FCT","#1abc9c","#111111"],["FC Utrecht","FCU","#b33939","#ffffff"],["Sparta Roterdã","SPR","#27ae60","#ffffff"],["Go Ahead Eagles","GAE","#1abc9c","#111111"],["NEC Nijmegen","NEN","#f39c12","#111111"],["Heerenveen","HEE","#34495e","#ffffff"],["Fortuna Sittard","FOS","#e74c3c","#111111"],["PEC Zwolle","PEZ","#f39c12","#111111"],["Heracles","HER","#34495e","#ffffff"],["Groningen","GRO","#f39c12","#111111"],["Willem II","WII","#d35400","#111111"],["NAC Breda","NAB","#27ae60","#ffffff"],["Excelsior","EXC","#e74c3c","#111111"],["Telstar","TEL","#e74c3c","#111111"]],[["Roda JC","ROJ","#e74c3c","#111111"],["Cambuur","CAM","#b33939","#ffffff"],["Almere City","ALC","#1abc9c","#111111"],["De Graafschap","DEG","#b33939","#ffffff"],["Vitesse","VIT","#cd6133","#ffffff"],["ADO Den Haag","ADH","#8e44ad","#ffffff"],["Den Bosch","DEB","#0097e6","#ffffff"],["VVV-Venlo","VVV","#0097e6","#ffffff"],["MVV Maastricht","MVM","#f39c12","#111111"],["Helmond Sport","HES","#27ae60","#ffffff"],["Dordrecht","DOR","#1abc9c","#111111"],["Emmen","EMM","#273c75","#ffffff"],["FC Eindhoven","FCE","#27ae60","#ffffff"],["TOP Oss","TOO","#f39c12","#111111"],["Jong Ajax","JOA","#b33939","#ffffff"],["Jong PSV","JOP","#218c74","#ffffff"],["Jong AZ","JOA","#16a085","#ffffff"],["Jong Utrecht","JOU","#2980b9","#ffffff"]],[["Quick Boys","QUB","#c0392b","#ffffff"],["Katwijk","KAT","#27ae60","#ffffff"],["Spakenburg","SPA","#34495e","#ffffff"],["Koninklijke HFC","KOH","#b33939","#ffffff"],["Rijnsburgse Boys","RIB","#cd6133","#ffffff"],["Hoek","HOE","#2980b9","#ffffff"],["IJsselmeervogels","IJS","#cd6133","#ffffff"],["Excelsior Maassluis","EXM","#1abc9c","#111111"],["Ajax B","AJB","#e74c3c","#111111"],["Scheveningen","SCH","#cd6133","#ffffff"],["Barendrecht","BAR","#27ae60","#ffffff"],["Kozakken Boys","KOB","#1abc9c","#111111"],["Vitesse B","VIB","#b33939","#ffffff"],["Noordwijk","NOO","#34495e","#ffffff"],["Ajax A","AJA","#f39c12","#111111"],["Sparta B","SPB","#16a085","#ffffff"],["VVSB","VVS","#1abc9c","#111111"],["ADO B","ADB","#0097e6","#ffffff"]]],"Argentina":[[["Boca Juniors","BOJ","#0b3d91","#f5c542"],["River Plate","RIP","#ffffff","#e30613"],["Racing Club","RAC","#273c75","#ffffff"],["Independiente","IND","#0097e6","#ffffff"],["San Lorenzo","SAL","#c0392b","#ffffff"],["Estudiantes","EST","#2980b9","#ffffff"],["Vélez Sarsfield","VÉS","#f39c12","#111111"],["Lanús","LAN","#c0392b","#ffffff"],["Talleres","TAL","#d35400","#111111"],["Argentinos Juniors","ARJ","#34495e","#ffffff"],["Newell's Old Boys","NOB","#f39c12","#111111"],["Rosario Central","ROC","#b33939","#ffffff"],["Defensa y Justicia","DYJ","#cd6133","#ffffff"],["Huracán","HUR","#c0392b","#ffffff"],["Banfield","BAN","#218c74","#ffffff"],["Godoy Cruz","GOC","#218c74","#ffffff"],["Belgrano","BEL","#cd6133","#ffffff"],["Tigre","TIG","#f39c12","#111111"],["Platense","PLA","#d35400","#111111"],["Gimnasia La Plata","GLP","#cd6133","#ffffff"]],[["Atlético Tucumán","ATT","#b33939","#ffffff"],["Colón","COL","#273c75","#ffffff"],["Unión","UNI","#1abc9c","#111111"],["Quilmes","QUI","#8e44ad","#ffffff"],["Chacarita Juniors","CHJ","#27ae60","#ffffff"],["Nueva Chicago","NUC","#16a085","#ffffff"],["Ferro Carril Oeste","FCO","#16a085","#ffffff"],["Almagro","ALM","#1abc9c","#111111"],["Instituto","INS","#218c74","#ffffff"],["Güemes","GÜE","#8e44ad","#ffffff"],["Temperley","TEM","#16a085","#ffffff"],["Sarmiento","SAR","#e74c3c","#111111"],["Barracas Central","BAC","#8e44ad","#ffffff"],["Estudiantes de Río Cuarto","EDR","#c0392b","#ffffff"],["San Telmo","SAT","#d35400","#111111"],["Morón","MOR","#e74c3c","#111111"],["Deportivo Riestra","DER","#f39c12","#111111"],["Aldosivi","ALD","#f39c12","#111111"],["Patronato","PAT","#cd6133","#ffffff"],["Atlanta","ATL","#1abc9c","#111111"]],[["Deportivo Merlo","DEM","#218c74","#ffffff"],["Defensores de Belgrano","DDB","#b33939","#ffffff"],["Brown de Adrogué","BDA","#8e44ad","#ffffff"],["Talleres de Remedios","TDR","#b33939","#ffffff"],["Argentino de Quilmes","ADQ","#273c75","#ffffff"],["Midland","MID","#d35400","#111111"],["Excursionistas","EXC","#8e44ad","#ffffff"],["Villa Dálmine","VID","#cd6133","#ffffff"],["San Miguel","SAM","#1abc9c","#111111"],["Sacachispas","SAC","#0097e6","#ffffff"],["Tristán Suárez","TRS","#e74c3c","#111111"],["Deportivo Armenio","DEA","#27ae60","#ffffff"],["Acassuso","ACA","#16a085","#ffffff"],["Comunicaciones","COM","#34495e","#ffffff"],["Dock Sud","DOS","#273c75","#ffffff"],["Laferrere","LAF","#e74c3c","#111111"],["Flandria","FLA","#f39c12","#111111"],["Fénix","FÉN","#b33939","#ffffff"]]],"México":[[["América","AMÉ","#fdd116","#0a2a66"],["Guadalajara","GUA","#e30613","#ffffff"],["Cruz Azul","CRA","#27ae60","#ffffff"],["Pumas UNAM","PUU","#cd6133","#ffffff"],["Tigres UANL","TIU","#d35400","#111111"],["Monterrey","MON","#34495e","#ffffff"],["Toluca","TOL","#f39c12","#111111"],["Santos Laguna","SAL","#f39c12","#111111"],["Pachuca","PAC","#cd6133","#ffffff"],["León","LEÓ","#16a085","#ffffff"],["Atlas","ATL","#218c74","#ffffff"],["Necaxa","NEC","#218c74","#ffffff"],["Puebla","PUE","#cd6133","#ffffff"],["Tijuana","TIJ","#2980b9","#ffffff"],["Querétaro","QUE","#16a085","#ffffff"],["Mazatlán","MAZ","#e74c3c","#111111"],["Juárez","JUÁ","#34495e","#ffffff"],["Atlético San Luis","ASL","#218c74","#ffffff"]],[["Atlante","ATL","#d35400","#111111"],["Celaya","CEL","#27ae60","#ffffff"],["Tapatío","TAP","#c0392b","#ffffff"],["Leones Negros","LEN","#8e44ad","#ffffff"],["Cancún","CAN","#f39c12","#111111"],["Tepatitlán","TEP","#c0392b","#ffffff"],["Correcaminos","COR","#d35400","#111111"],["Dorados","DOR","#34495e","#ffffff"],["Venados","VEN","#f39c12","#111111"],["Morelia","MOR","#8e44ad","#ffffff"],["Alebrijes de Oaxaca","ADO","#b33939","#ffffff"],["Zacatepec","ZAC","#cd6133","#ffffff"],["Mineros de Zacatecas","MDZ","#2980b9","#ffffff"],["Tlaxcala","TLA","#e74c3c","#111111"],["Cimarrones","CIM","#0097e6","#ffffff"],["Pumas Tabasco","PUT","#16a085","#ffffff"],["Irapuato","IRA","#e74c3c","#111111"],["Raya2","RAY","#34495e","#ffffff"]],[["Pioneros","PIO","#27ae60","#ffffff"],["Tuxtla","TUX","#16a085","#ffffff"],["Cafetaleros","CAF","#273c75","#ffffff"],["Inter Playa del Carmen","IPD","#d35400","#111111"],["Colima","COL","#2980b9","#ffffff"],["Durango","DUR","#cd6133","#ffffff"],["Santos B","SAB","#c0392b","#ffffff"],["Chivas B","CHB","#2980b9","#ffffff"],["Atlas B","ATB","#f39c12","#111111"],["Toluca B","TOB","#2980b9","#ffffff"],["Pachuca B","PAB","#16a085","#ffffff"],["León B","LEB","#b33939","#ffffff"],["América B","AMB","#27ae60","#ffffff"],["Cruz Azul B","CAB","#273c75","#ffffff"],["Tigres B","TIB","#e74c3c","#111111"],["Monterrey B","MOB","#cd6133","#ffffff"],["Necaxa B","NEB","#27ae60","#ffffff"],["Puebla B","PUB","#f39c12","#111111"]]],"Estados Unidos":[[["Inter Miami","INM","#b33939","#ffffff"],["LA Galaxy","LAG","#c0392b","#ffffff"],["LAFC","LAF","#cd6133","#ffffff"],["Seattle Sounders","SES","#273c75","#ffffff"],["Portland Timbers","POT","#e74c3c","#111111"],["Atlanta United","ATU","#cd6133","#ffffff"],["New York Red Bulls","NYR","#1abc9c","#111111"],["New York City FC","NYC","#c0392b","#ffffff"],["Philadelphia Union","PHU","#8e44ad","#ffffff"],["Columbus Crew","COC","#f39c12","#111111"],["Orlando City","ORC","#27ae60","#ffffff"],["Austin FC","AUF","#273c75","#ffffff"],["FC Dallas","FCD","#1abc9c","#111111"],["Houston Dynamo","HOD","#e74c3c","#111111"],["Sporting Kansas City","SKC","#1abc9c","#111111"],["Minnesota United","MIU","#273c75","#ffffff"],["Real Salt Lake","RSL","#b33939","#ffffff"],["Colorado Rapids","COR","#0097e6","#ffffff"]],[["Louisville City","LOC","#27ae60","#ffffff"],["Charleston Battery","CHB","#f39c12","#111111"],["Phoenix Rising","PHR","#16a085","#ffffff"],["Sacramento Republic","SAR","#1abc9c","#111111"],["San Antonio FC","SAF","#0097e6","#ffffff"],["Tampa Bay Rowdies","TBR","#8e44ad","#ffffff"],["Indy Eleven","INE","#cd6133","#ffffff"],["Detroit City","DEC","#e74c3c","#111111"],["Pittsburgh Riverhounds","PIR","#0097e6","#ffffff"],["Rhode Island FC","RIF","#27ae60","#ffffff"],["Birmingham Legion","BIL","#e74c3c","#111111"],["Memphis 901","ME9","#2980b9","#ffffff"],["Hartford Athletic","HAA","#8e44ad","#ffffff"],["Oakland Roots","OAR","#f39c12","#111111"],["El Paso Locomotive","EPL","#f39c12","#111111"],["Orange County SC","OCS","#34495e","#ffffff"],["Miami FC","MIF","#34495e","#ffffff"],["Las Vegas Lights","LVL","#27ae60","#ffffff"]],[["Union Omaha","UNO","#cd6133","#ffffff"],["Greenville Triumph","GRT","#e74c3c","#111111"],["Chattanooga Red Wolves","CRW","#e74c3c","#111111"],["Richmond Kickers","RIK","#2980b9","#ffffff"],["Spokane Velocity","SPV","#2980b9","#ffffff"],["Northern Colorado Hailstorm","NCH","#16a085","#ffffff"],["Westchester SC","WES","#16a085","#ffffff"],["Lexington SC","LES","#0097e6","#ffffff"],["One Knoxville","ONK","#16a085","#ffffff"],["Forward Madison","FOM","#2980b9","#ffffff"],["South Georgia Tormenta","SGT","#b33939","#ffffff"],["Charlotte Independence","CHI","#c0392b","#ffffff"],["FC Naples","FCN","#218c74","#ffffff"],["Central Valley Fuego","CVF","#cd6133","#ffffff"],["Texoma FC","TEF","#2980b9","#ffffff"],["Portland Hearts of Pine","PHO","#8e44ad","#ffffff"],["AC Boise","ACB","#16a085","#ffffff"],["Sarasota Paradise","SAP","#e74c3c","#111111"]]],"Japão":[[["Vissel Kobe","VIK","#8e44ad","#ffffff"],["Yokohama F. Marinos","YFM","#27ae60","#ffffff"],["Kawasaki Frontale","KAF","#8e44ad","#ffffff"],["Urawa Red Diamonds","URD","#f39c12","#111111"],["Kashima Antlers","KAA","#b33939","#ffffff"],["Gamba Osaka","GAO","#f39c12","#111111"],["Cerezo Osaka","CEO","#27ae60","#ffffff"],["Sanfrecce Hiroshima","SAH","#8e44ad","#ffffff"],["Nagoya Grampus","NAG","#34495e","#ffffff"],["FC Tokyo","FCT","#c0392b","#ffffff"],["Kashiwa Reysol","KAR","#16a085","#ffffff"],["Avispa Fukuoka","AVF","#f39c12","#111111"],["Machida Zelvia","MAZ","#34495e","#ffffff"],["Shimizu S-Pulse","SSP","#b33939","#ffffff"],["Albirex Niigata","ALN","#8e44ad","#ffffff"],["Kyoto Sanga","KYS","#16a085","#ffffff"],["Tokyo Verdy","TOV","#2980b9","#ffffff"],["Fagiano Okayama","FAO","#27ae60","#ffffff"],["Sagan Tosu","SAT","#f39c12","#111111"],["Shonan Bellmare","SHB","#0097e6","#ffffff"]],[["Júbilo Iwata","JÚI","#cd6133","#ffffff"],["Consadole Sapporo","COS","#8e44ad","#ffffff"],["Vegalta Sendai","VES","#16a085","#ffffff"],["Yokohama FC","YOF","#2980b9","#ffffff"],["Montedio Yamagata","MOY","#2980b9","#ffffff"],["Ventforet Kofu","VEK","#27ae60","#ffffff"],["Omiya Ardija","OMA","#218c74","#ffffff"],["JEF United Chiba","JUC","#27ae60","#ffffff"],["Blaublitz Akita","BLA","#27ae60","#ffffff"],["Tochigi SC","TOS","#27ae60","#ffffff"],["Mito HollyHock","MIH","#0097e6","#ffffff"],["Thespa Gunma","THG","#0097e6","#ffffff"],["Fujieda MYFC","FUM","#8e44ad","#ffffff"],["Ehime FC","EHF","#b33939","#ffffff"],["Tokushima Vortis","TOV","#218c74","#ffffff"],["V-Varen Nagasaki","VVN","#218c74","#ffffff"],["Roasso Kumamoto","ROK","#e74c3c","#111111"],["Oita Trinita","OIT","#1abc9c","#111111"],["Renofa Yamaguchi","REY","#d35400","#111111"],["Iwaki FC","IWF","#2980b9","#ffffff"]],[["Kataller Toyama","KAT","#27ae60","#ffffff"],["Gainare Tottori","GAT","#16a085","#ffffff"],["Kamatamare Sanuki","KAS","#218c74","#ffffff"],["Zweigen Kanazawa","ZWK","#b33939","#ffffff"],["Matsumoto Yamaga","MAY","#0097e6","#ffffff"],["Nagano Parceiro","NAP","#c0392b","#ffffff"],["Iwate Grulla","IWG","#b33939","#ffffff"],["Fukushima United","FUU","#d35400","#111111"],["Azul Claro Numazu","ACN","#8e44ad","#ffffff"],["Vanraure Hachinohe","VAH","#218c74","#ffffff"],["FC Imabari","FCI","#27ae60","#ffffff"],["Giravanz Kitakyushu","GIK","#b33939","#ffffff"],["SC Sagamihara","SCS","#0097e6","#ffffff"],["Tegevajaro Miyazaki","TEM","#0097e6","#ffffff"],["Kagoshima United","KAU","#1abc9c","#111111"],["FC Gifu","FCG","#f39c12","#111111"],["Nara Club","NAC","#27ae60","#ffffff"],["Ryukyu","RYU","#27ae60","#ffffff"]]],"Turquia":[[["Galatasaray","GAL","#e30613","#fdb913"],["Fenerbahçe","FEN","#fdd116","#0a2a66"],["Beşiktaş","BEŞ","#b33939","#ffffff"],["Trabzonspor","TRA","#27ae60","#ffffff"],["Başakşehir","BAŞ","#cd6133","#ffffff"],["Adana Demirspor","ADD","#16a085","#ffffff"],["Antalyaspor","ANT","#218c74","#ffffff"],["Konyaspor","KON","#b33939","#ffffff"],["Sivasspor","SIV","#f39c12","#111111"],["Kayserispor","KAY","#34495e","#ffffff"],["Alanyaspor","ALA","#8e44ad","#ffffff"],["Gaziantep FK","GAF","#27ae60","#ffffff"],["Rizespor","RIZ","#e74c3c","#111111"],["Samsunspor","SAM","#b33939","#ffffff"],["Hatayspor","HAT","#218c74","#ffffff"],["Kasımpaşa","KAS","#16a085","#ffffff"],["Eyüpspor","EYÜ","#f39c12","#111111"],["Göztepe","GÖZ","#27ae60","#ffffff"]],[["Bursaspor","BUR","#0097e6","#ffffff"],["Altay","ALT","#2980b9","#ffffff"],["Ankaragücü","ANK","#218c74","#ffffff"],["Karagümrük","KAR","#16a085","#ffffff"],["Bodrum","BOD","#b33939","#ffffff"],["Pendikspor","PEN","#8e44ad","#ffffff"],["Giresunspor","GIR","#d35400","#111111"],["Boluspor","BOL","#2980b9","#ffffff"],["Manisa","MAN","#2980b9","#ffffff"],["Çorum","ÇOR","#27ae60","#ffffff"],["Sakaryaspor","SAK","#8e44ad","#ffffff"],["Erzurumspor","ERZ","#2980b9","#ffffff"],["Keçiörengücü","KEÇ","#16a085","#ffffff"],["Ümraniyespor","ÜMR","#1abc9c","#111111"],["Şanlıurfaspor","ŞAN","#2980b9","#ffffff"],["Istanbulspor","IST","#273c75","#ffffff"],["Adanaspor","ADA","#2980b9","#ffffff"],["Tuzlaspor","TUZ","#c0392b","#ffffff"]],[["Eskişehirspor","ESK","#c0392b","#ffffff"],["Denizlispor","DEN","#0097e6","#ffffff"],["Elazığspor","ELA","#16a085","#ffffff"],["Sarıyer","SAR","#cd6133","#ffffff"],["Bandırmaspor","BAN","#2980b9","#ffffff"],["Menemenspor","MEN","#8e44ad","#ffffff"],["Altınordu","ALT","#1abc9c","#111111"],["Kocaelispor","KOC","#0097e6","#ffffff"],["Amed","AME","#b33939","#ffffff"],["Isparta 32","IS3","#c0392b","#ffffff"],["Karaman","KAR","#273c75","#ffffff"],["Ankara Demirspor","AND","#273c75","#ffffff"],["Fethiyespor","FET","#e74c3c","#111111"],["Diyarbekirspor","DIY","#c0392b","#ffffff"],["Niğde Anadolu","NIA","#2980b9","#ffffff"],["Serik","SER","#27ae60","#ffffff"],["Yeni Malatyaspor","YEM","#2980b9","#ffffff"],["Kırklarelispor","KIR","#27ae60","#ffffff"]]],"Bélgica":[[["Club Brugge","CLB","#34495e","#ffffff"],["Anderlecht","AND","#34495e","#ffffff"],["Union Saint-Gilloise","USG","#0097e6","#ffffff"],["Genk","GEN","#218c74","#ffffff"],["Antwerp","ANT","#16a085","#ffffff"],["Gent","GEN","#34495e","#ffffff"],["Standard de Liège","SDL","#d35400","#111111"],["Cercle Brugge","CEB","#f39c12","#111111"],["Mechelen","MEC","#cd6133","#ffffff"],["Westerlo","WES","#1abc9c","#111111"],["Charleroi","CHA","#e74c3c","#111111"],["OH Leuven","OHL","#218c74","#ffffff"],["Sint-Truiden","SIT","#b33939","#ffffff"],["Zulte Waregem","ZUW","#34495e","#ffffff"],["Dender","DEN","#c0392b","#ffffff"],["Kortrijk","KOR","#8e44ad","#ffffff"]],[["Beerschot","BEE","#c0392b","#ffffff"],["Lommel","LOM","#34495e","#ffffff"],["Lokeren","LOK","#cd6133","#ffffff"],["RWDM","RWD","#1abc9c","#111111"],["Seraing","SER","#27ae60","#ffffff"],["Eupen","EUP","#cd6133","#ffffff"],["Beveren","BEV","#c0392b","#ffffff"],["Patro Eisden","PAE","#27ae60","#ffffff"],["Francs Borains","FRB","#1abc9c","#111111"],["Club NXT","CLN","#d35400","#111111"],["Lierse","LIE","#27ae60","#ffffff"],["Anderlecht B","ANB","#2980b9","#ffffff"],["Waasland-Beveren","WAB","#16a085","#ffffff"],["Roeselare","ROE","#273c75","#ffffff"],["Dessel","DES","#1abc9c","#111111"],["Virton","VIR","#e74c3c","#111111"]],[["Mons","MON","#2980b9","#ffffff"],["Knokke","KNO","#2980b9","#ffffff"],["Tubize","TUB","#d35400","#111111"],["Olympic Charleroi","OLC","#c0392b","#ffffff"],["Rupel Boom","RUB","#b33939","#ffffff"],["Heist","HEI","#b33939","#ffffff"],["Oostende","OOS","#cd6133","#ffffff"],["Hoogstraten","HOO","#8e44ad","#ffffff"],["Thes Sport","THS","#16a085","#ffffff"],["Union SG B","USB","#1abc9c","#111111"],["Cercle B","CEB","#f39c12","#111111"],["Gent B","GEB","#b33939","#ffffff"],["Genk B","GEB","#218c74","#ffffff"],["Standard B","STB","#273c75","#ffffff"],["Dender B","DEB","#2980b9","#ffffff"],["Aalst","AAL","#34495e","#ffffff"]]],"Escócia":[[["Celtic","CEL","#00843d","#ffffff"],["Rangers","RAN","#1b458f","#ffffff"],["Hearts","HEA","#34495e","#ffffff"],["Hibernian","HIB","#d35400","#111111"],["Aberdeen","ABE","#c0392b","#ffffff"],["Dundee United","DUU","#218c74","#ffffff"],["Motherwell","MOT","#218c74","#ffffff"],["Kilmarnock","KIL","#16a085","#ffffff"],["St Mirren","STM","#b33939","#ffffff"],["Ross County","ROC","#cd6133","#ffffff"],["St Johnstone","STJ","#218c74","#ffffff"],["Dundee","DUN","#2980b9","#ffffff"]],[["Livingston","LIV","#f39c12","#111111"],["Partick Thistle","PAT","#16a085","#ffffff"],["Raith Rovers","RAR","#34495e","#ffffff"],["Ayr United","AYU","#1abc9c","#111111"],["Falkirk","FAL","#34495e","#ffffff"],["Queen's Park","QUP","#8e44ad","#ffffff"],["Greenock Morton","GRM","#34495e","#ffffff"],["Hamilton Academical","HAA","#cd6133","#ffffff"],["Airdrieonians","AIR","#cd6133","#ffffff"],["Arbroath","ARB","#27ae60","#ffffff"]],[["Dunfermline","DUN","#b33939","#ffffff"],["Inverness","INV","#c0392b","#ffffff"],["Cove Rangers","COR","#27ae60","#ffffff"],["Peterhead","PET","#cd6133","#ffffff"],["Alloa","ALL","#d35400","#111111"],["Stenhousemuir","STE","#218c74","#ffffff"],["Kelty Hearts","KEH","#27ae60","#ffffff"],["Montrose","MON","#16a085","#ffffff"],["Clyde","CLY","#34495e","#ffffff"],["Stirling Albion","STA","#2980b9","#ffffff"]]],"Rússia":[[["Zenit","ZEN","#1abc9c","#111111"],["Spartak Moscou","SPM","#2980b9","#ffffff"],["CSKA Moscou","CSM","#8e44ad","#ffffff"],["Lokomotiv Moscou","LOM","#b33939","#ffffff"],["Dínamo Moscou","DÍM","#16a085","#ffffff"],["Krasnodar","KRA","#e74c3c","#111111"],["Rubin Kazan","RUK","#273c75","#ffffff"],["Akhmat Grozny","AKG","#16a085","#ffffff"],["Rostov","ROS","#d35400","#111111"],["Krylya Sovetov","KRS","#8e44ad","#ffffff"],["Orenburg","ORE","#16a085","#ffffff"],["Pari Nizhny Novgorod","PNN","#8e44ad","#ffffff"],["Sochi","SOC","#27ae60","#ffffff"],["Baltika","BAL","#2980b9","#ffffff"],["Akron Tolyatti","AKT","#16a085","#ffffff"],["Dínamo Makhachkala","DÍM","#cd6133","#ffffff"]],[["Torpedo Moscou","TOM","#34495e","#ffffff"],["Shinnik Yaroslavl","SHY","#2980b9","#ffffff"],["Fakel Voronezh","FAV","#1abc9c","#111111"],["Khimki","KHI","#273c75","#ffffff"],["Ural","URA","#27ae60","#ffffff"],["Neftekhimik","NEF","#34495e","#ffffff"],["Chayka","CHA","#218c74","#ffffff"],["Tekstilshchik","TEK","#d35400","#111111"],["Spartak Kostroma","SPK","#8e44ad","#ffffff"],["Chertanovo","CHE","#c0392b","#ffffff"],["Yenisey","YEN","#0097e6","#ffffff"],["SKA-Khabarovsk","SKK","#b33939","#ffffff"],["Volga","VOL","#cd6133","#ffffff"],["Sokol Saratov","SOS","#34495e","#ffffff"],["Alania","ALA","#16a085","#ffffff"],["Kuban","KUB","#27ae60","#ffffff"]],[["Torpedo Vladimir","TOV","#8e44ad","#ffffff"],["Zenit-2","ZE2","#34495e","#ffffff"],["Lokomotiv-2","LO2","#27ae60","#ffffff"],["Dinamo-2","DI2","#34495e","#ffffff"],["Rubin-2","RU2","#8e44ad","#ffffff"],["Spartak-2","SP2","#27ae60","#ffffff"],["CSKA-2","CS2","#b33939","#ffffff"],["Krasnodar-2","KR2","#c0392b","#ffffff"],["Rostov-2","RO2","#b33939","#ffffff"],["Akhmat-2","AK2","#e74c3c","#111111"],["Ural-2","UR2","#0097e6","#ffffff"],["Kaluga","KAL","#f39c12","#111111"],["Lada","LAD","#218c74","#ffffff"],["Orel","ORE","#34495e","#ffffff"],["Zvezda","ZVE","#34495e","#ffffff"],["Mashuk","MAS","#b33939","#ffffff"]]],"Colômbia":[[["Atlético Nacional","ATN","#c0392b","#ffffff"],["Millonarios","MIL","#1abc9c","#111111"],["Junior","JUN","#b33939","#ffffff"],["América de Cali","ADC","#b33939","#ffffff"],["Deportivo Cali","DEC","#0097e6","#ffffff"],["Independiente Santa Fe","ISF","#8e44ad","#ffffff"],["Once Caldas","ONC","#27ae60","#ffffff"],["Tolima","TOL","#c0392b","#ffffff"],["Medellín","MED","#34495e","#ffffff"],["Bucaramanga","BUC","#b33939","#ffffff"],["Pasto","PAS","#16a085","#ffffff"],["Águilas Doradas","ÁGD","#16a085","#ffffff"],["Alianza","ALI","#d35400","#111111"],["La Equidad","LAE","#16a085","#ffffff"],["Envigado","ENV","#e74c3c","#111111"],["Jaguares","JAG","#f39c12","#111111"],["Fortaleza CEIF","FOC","#e74c3c","#111111"],["Llaneros","LLA","#c0392b","#ffffff"]],[["Cúcuta Deportivo","CÚD","#27ae60","#ffffff"],["Atlético Huila","ATH","#2980b9","#ffffff"],["Boyacá Chicó","BOC","#f39c12","#111111"],["Patriotas","PAT","#e74c3c","#111111"],["Real Cartagena","REC","#8e44ad","#ffffff"],["Unión Magdalena","UNM","#d35400","#111111"],["Barranquilla FC","BAF","#27ae60","#ffffff"],["Deportivo Pereira","DEP","#e74c3c","#111111"],["Atlético Bucaramanga B","ABB","#8e44ad","#ffffff"],["Orsomarso","ORS","#8e44ad","#ffffff"],["Tigres","TIG","#34495e","#ffffff"],["Llaneros B","LLB","#1abc9c","#111111"],["Real Santander","RES","#d35400","#111111"],["Cortuluá","COR","#2980b9","#ffffff"],["Valledupar","VAL","#16a085","#ffffff"],["Bogotá FC","BOF","#1abc9c","#111111"],["Internacional de Palmira","IDP","#16a085","#ffffff"],["Real Soacha","RES","#2980b9","#ffffff"]],[["Sporting Barranquilla","SPB","#e74c3c","#111111"],["Deportes Quindío","DEQ","#27ae60","#ffffff"],["Girardot","GIR","#1abc9c","#111111"],["Libertad","LIB","#8e44ad","#ffffff"],["Fortaleza B","FOB","#d35400","#111111"],["Atlético Nacional B","ANB","#2980b9","#ffffff"],["Medellín B","MEB","#8e44ad","#ffffff"],["Cali B","CAB","#cd6133","#ffffff"],["Santa Fe B","SFB","#8e44ad","#ffffff"],["Millonarios B","MIB","#8e44ad","#ffffff"],["Junior B","JUB","#27ae60","#ffffff"],["Tolima B","TOB","#2980b9","#ffffff"],["Once Caldas B","OCB","#27ae60","#ffffff"],["Pasto B","PAB","#0097e6","#ffffff"],["Alianza B","ALB","#8e44ad","#ffffff"],["Equidad B","EQB","#34495e","#ffffff"],["Envigado B","ENB","#c0392b","#ffffff"],["Águilas B","ÁGB","#f39c12","#111111"]]],"Uruguai":[[["Peñarol","PEÑ","#cd6133","#ffffff"],["Nacional","NAC","#273c75","#ffffff"],["Defensor Sporting","DES","#16a085","#ffffff"],["Liverpool","LIV","#c8102e","#ffffff"],["Danubio","DAN","#d35400","#111111"],["Montevideo Wanderers","MOW","#218c74","#ffffff"],["River Plate (URU)","RP(","#1abc9c","#111111"],["Racing (URU)","RA(","#c0392b","#ffffff"],["Cerro Largo","CEL","#0097e6","#ffffff"],["Boston River","BOR","#27ae60","#ffffff"],["Plaza Colonia","PLC","#0097e6","#ffffff"],["Progreso","PRO","#1abc9c","#111111"],["Juventud","JUV","#34495e","#ffffff"],["Cerro","CER","#27ae60","#ffffff"],["Miramar Misiones","MIM","#8e44ad","#ffffff"],["Albion","ALB","#273c75","#ffffff"]],[["Rentistas","REN","#cd6133","#ffffff"],["Villa Española","VIE","#273c75","#ffffff"],["Sud América","SUA","#27ae60","#ffffff"],["Fénix","FÉN","#b33939","#ffffff"],["Central Español","CEE","#1abc9c","#111111"],["Torque","TOR","#e74c3c","#111111"],["Atenas","ATE","#34495e","#ffffff"],["Rampla Juniors","RAJ","#e74c3c","#111111"],["Deportivo Maldonado","DEM","#b33939","#ffffff"],["Oriental","ORI","#b33939","#ffffff"],["Uruguay Montevideo","URM","#1abc9c","#111111"],["Cooper","COO","#d35400","#111111"],["Ferro Carril","FEC","#d35400","#111111"],["Colón","COL","#273c75","#ffffff"],["Tacuarembó","TAC","#218c74","#ffffff"],["Artigas","ART","#c0392b","#ffffff"]],[["Nacional B","NAB","#34495e","#ffffff"],["Peñarol B","PEB","#f39c12","#111111"],["Defensor B","DEB","#e74c3c","#111111"],["Danubio B","DAB","#16a085","#ffffff"],["Liverpool B","LIB","#16a085","#ffffff"],["Wanderers B","WAB","#0097e6","#ffffff"],["Cerro B","CEB","#34495e","#ffffff"],["Racing B","RAB","#b33939","#ffffff"],["Progreso B","PRB","#2980b9","#ffffff"],["Juventud B","JUB","#b33939","#ffffff"],["Boston River B","BRB","#16a085","#ffffff"],["Plaza Colonia B","PCB","#b33939","#ffffff"],["Albion B","ALB","#cd6133","#ffffff"],["Cerro Largo B","CLB","#27ae60","#ffffff"],["Miramar B","MIB","#d35400","#111111"],["River B","RIB","#d35400","#111111"]]],"Chile":[[["Colo-Colo","COC","#e74c3c","#111111"],["Universidad de Chile","UDC","#273c75","#ffffff"],["Universidad Católica","UNC","#8e44ad","#ffffff"],["Cobresal","COB","#27ae60","#ffffff"],["Huachipato","HUA","#cd6133","#ffffff"],["Palestino","PAL","#16a085","#ffffff"],["Unión Española","UNE","#218c74","#ffffff"],["Audax Italiano","AUI","#2980b9","#ffffff"],["Everton","EVE","#16a085","#ffffff"],["O'Higgins","O'H","#8e44ad","#ffffff"],["Coquimbo Unido","COU","#218c74","#ffffff"],["Ñublense","ÑUB","#8e44ad","#ffffff"],["Deportes Iquique","DEI","#34495e","#ffffff"],["Deportes La Serena","DLS","#b33939","#ffffff"],["Cobreloa","COB","#f39c12","#111111"],["Unión La Calera","ULC","#273c75","#ffffff"]],[["Santiago Wanderers","SAW","#8e44ad","#ffffff"],["Deportes Temuco","DET","#2980b9","#ffffff"],["Magallanes","MAG","#34495e","#ffffff"],["Rangers","RAN","#1b458f","#ffffff"],["Deportes Antofagasta","DEA","#b33939","#ffffff"],["San Luis","SAL","#e74c3c","#111111"],["Curicó Unido","CUU","#f39c12","#111111"],["Deportes Copiapó","DEC","#8e44ad","#ffffff"],["Santiago Morning","SAM","#2980b9","#ffffff"],["San Marcos de Arica","SMD","#1abc9c","#111111"],["Puerto Montt","PUM","#218c74","#ffffff"],["Deportes Recoleta","DER","#2980b9","#ffffff"],["Barnechea","BAR","#273c75","#ffffff"],["Deportes Concepción","DEC","#2980b9","#ffffff"],["Cobreloa B","COB","#f39c12","#111111"],["Colchagua","COL","#0097e6","#ffffff"]],[["Lota Schwager","LOS","#d35400","#111111"],["Fernández Vial","FEV","#34495e","#ffffff"],["Trasandino","TRA","#0097e6","#ffffff"],["Provincial Osorno","PRO","#e74c3c","#111111"],["Naval","NAV","#8e44ad","#ffffff"],["Deportes Valdivia","DEV","#e74c3c","#111111"],["Independiente de Cauquenes","IDC","#16a085","#ffffff"],["Iberia","IBE","#1abc9c","#111111"],["Municipal Mejillones","MUM","#27ae60","#ffffff"],["San Antonio Unido","SAU","#218c74","#ffffff"],["Brujas de Salamanca","BDS","#8e44ad","#ffffff"],["Deportes Linares","DEL","#d35400","#111111"],["Real San Joaquín","RSJ","#27ae60","#ffffff"],["Comunal Cabrero","COC","#cd6133","#ffffff"],["Unión San Felipe","USF","#c0392b","#ffffff"],["Deportes Limache","DEL","#e74c3c","#111111"]]],"Arábia Saudita":[[["Al-Hilal","ALH","#0033a0","#ffffff"],["Al-Nassr","ALN","#fdd116","#0a2a66"],["Al-Ittihad","ALI","#d35400","#111111"],["Al-Ahli","ALA","#d35400","#111111"],["Al-Shabab","ALS","#c0392b","#ffffff"],["Al-Ettifaq","ALE","#273c75","#ffffff"],["Al-Taawoun","ALT","#27ae60","#ffffff"],["Al-Fateh","ALF","#1abc9c","#111111"],["Al-Fayha","ALF","#cd6133","#ffffff"],["Al-Raed","ALR","#b33939","#ffffff"],["Damac","DAM","#34495e","#ffffff"],["Al-Khaleej","ALK","#273c75","#ffffff"],["Al-Okhdood","ALO","#16a085","#ffffff"],["Al-Riyadh","ALR","#8e44ad","#ffffff"],["Al-Kholood","ALK","#cd6133","#ffffff"],["Al-Qadsiah","ALQ","#e74c3c","#111111"],["Al-Orobah","ALO","#218c74","#ffffff"],["Al-Najma","ALN","#273c75","#ffffff"]],[["Al-Wehda","ALW","#34495e","#ffffff"],["Abha","ABH","#d35400","#111111"],["Al-Hazem","ALH","#218c74","#ffffff"],["Al-Tai","ALT","#cd6133","#ffffff"],["Al-Batin","ALB","#b33939","#ffffff"],["Al-Adalah","ALA","#cd6133","#ffffff"],["Al-Faisaly","ALF","#cd6133","#ffffff"],["Al-Jabalain","ALJ","#218c74","#ffffff"],["Al-Zulfi","ALZ","#e74c3c","#111111"],["Al-Arabi","ALA","#2980b9","#ffffff"],["Al-Anwar","ALA","#27ae60","#ffffff"],["Al-Bukiryah","ALB","#c0392b","#ffffff"],["Al-Jandal","ALJ","#e74c3c","#111111"],["Al-Diriyah","ALD","#27ae60","#ffffff"],["Al-Qaisumah","ALQ","#34495e","#ffffff"],["Al-Washm","ALW","#0097e6","#ffffff"],["Al-Ula","ALU","#cd6133","#ffffff"],["Al-Akhdoud","ALA","#1abc9c","#111111"]],[["Al-Sahel","ALS","#218c74","#ffffff"],["Al-Ain","ALA","#8e44ad","#ffffff"],["Al-Ghottah","ALG","#cd6133","#ffffff"],["Al-Nojoom","ALN","#16a085","#ffffff"],["Al-Sharq","ALS","#e74c3c","#111111"],["Al-Majd","ALM","#b33939","#ffffff"],["Al-Thoqbah","ALT","#e74c3c","#111111"],["Al-Rawdhah","ALR","#f39c12","#111111"],["Al-Mujazzal","ALM","#f39c12","#111111"],["Al-Safa","ALS","#34495e","#ffffff"],["Al-Khaldi","ALK","#d35400","#111111"],["Al-Dahab","ALD","#27ae60","#ffffff"],["Al-Shoulla","ALS","#cd6133","#ffffff"],["Al-Tuhami","ALT","#d35400","#111111"],["Al-Hamadah","ALH","#0097e6","#ffffff"],["Al-Orubah B","AOB","#16a085","#ffffff"],["Al-Faisaly B","AFB","#8e44ad","#ffffff"],["Al-Taawoun B","ATB","#273c75","#ffffff"]]]};
const LIGANOME={Brasil:['Brasileirão Série A','Brasileirão Série B','Brasileirão Série C'],Inglaterra:['Premier League','Championship','League One'],Espanha:['La Liga','Segunda División','Primera Federación'],Itália:['Serie A','Serie B','Serie C'],Alemanha:['Bundesliga','2. Bundesliga','3. Liga'],França:['Ligue 1','Ligue 2','National'],Portugal:['Primeira Liga','Liga Portugal 2','Liga 3'],Holanda:['Eredivisie','Eerste Divisie','Tweede Divisie'],Argentina:['Liga Profesional','Primera Nacional','Primera B'],México:['Liga MX','Liga de Expansión','Liga Premier'],'Estados Unidos':['MLS','USL Championship','USL League One'],Japão:['J1 League','J2 League','J3 League'],Turquia:['Süper Lig','1. Lig','2. Lig'],Bélgica:['Pro League','Challenger Pro League','Division 2'],Escócia:['Premiership','Championship','League One'],Rússia:['Premier Liga','FNL','Segunda Liga'],Colômbia:['Liga BetPlay','Torneo BetPlay','Torneo Aficionado'],Uruguai:['Primera División','Segunda División','Divisional C'],Chile:['Primera División','Primera B','Segunda División'],'Arábia Saudita':['Saudi Pro League','Primeira Divisão','Segunda Divisão']};

const POS=["GOL","ZAG","ZAG","LD","LE","VOL","MEI","MEI","ATA","ATA","PE"];
const FORMSLOT={"4-4-2":[["GOL",50,93],["LE",14.0,75],["ZAG",38.0,75],["ZAG",62.0,75],["LD",86.0,75],["PE",14.0,47],["MEI",38.0,47],["MEI",62.0,47],["PE",86.0,47],["ATA",34,20],["ATA",66,20]],"4-4-2 Losango":[["GOL",50,93],["LE",14.0,75],["ZAG",38.0,75],["ZAG",62.0,75],["LD",86.0,75],["VOL",50,62],["MEI",24,47],["MEI",76,47],["MEI",50,34],["ATA",36,19],["ATA",64,19]],"4-4-2 Ofensiva":[["GOL",50,93],["LE",14.0,76],["ZAG",38.0,76],["ZAG",62.0,76],["LD",86.0,76],["VOL",38,55],["MEI",62,55],["PE",12,38],["PE",88,38],["ATA",36,19],["ATA",64,19]],"4-3-3":[["GOL",50,93],["LE",14.0,75],["ZAG",38.0,75],["ZAG",62.0,75],["LD",86.0,75],["MEI",14.0,49],["VOL",50.0,49],["MEI",86.0,49],["PE",16,21],["ATA",50,21],["PE",84,21]],"4-3-3 Ofensiva":[["GOL",50,93],["LE",14.0,76],["ZAG",38.0,76],["ZAG",62.0,76],["LD",86.0,76],["VOL",50,58],["MEI",30,44],["MEI",70,44],["PE",14,20],["ATA",50,20],["PE",86,20]],"4-2-3-1":[["GOL",50,93],["LE",14.0,75],["ZAG",38.0,75],["ZAG",62.0,75],["LD",86.0,75],["VOL",38,60],["VOL",62,60],["PE",16,40],["MEI",50,40],["PE",84,40],["ATA",50,19]],"4-1-4-1":[["GOL",50,93],["LE",14.0,75],["ZAG",38.0,75],["ZAG",62.0,75],["LD",86.0,75],["VOL",50,62],["PE",12,45],["MEI",38,45],["MEI",62,45],["PE",88,45],["ATA",50,19]],"4-5-1":[["GOL",50,93],["LE",14.0,75],["ZAG",38.0,75],["ZAG",62.0,75],["LD",86.0,75],["PE",10,47],["MEI",30,47],["VOL",50,47],["MEI",70,47],["PE",90,47],["ATA",50,20]],"4-3-2-1":[["GOL",50,93],["LE",14.0,75],["ZAG",38.0,75],["ZAG",62.0,75],["LD",86.0,75],["MEI",28,55],["VOL",50,55],["MEI",72,55],["MEI",34,37],["MEI",66,37],["ATA",50,19]],"4-2-2-2":[["GOL",50,93],["LE",14.0,75],["ZAG",38.0,75],["ZAG",62.0,75],["LD",86.0,75],["VOL",38,60],["VOL",62,60],["MEI",22,40],["MEI",78,40],["ATA",36,19],["ATA",64,19]],"3-5-2":[["GOL",50,93],["ZAG",24,76],["ZAG",50,76],["ZAG",76,76],["LE",9,52],["MEI",30,49],["VOL",50,57],["MEI",70,49],["LD",91,52],["ATA",36,20],["ATA",64,20]],"3-4-3":[["GOL",50,93],["ZAG",24,76],["ZAG",50,76],["ZAG",76,76],["LE",10,52],["VOL",38,52],["VOL",62,52],["LD",90,52],["PE",18,21],["ATA",50,21],["PE",82,21]],"3-4-1-2":[["GOL",50,93],["ZAG",24,76],["ZAG",50,76],["ZAG",76,76],["LE",10,54],["VOL",38,54],["VOL",62,54],["LD",90,54],["MEI",50,37],["ATA",36,19],["ATA",64,19]],"3-4-2-1":[["GOL",50,93],["ZAG",24,76],["ZAG",50,76],["ZAG",76,76],["LE",10,56],["VOL",38,56],["VOL",62,56],["LD",90,56],["MEI",32,37],["MEI",68,37],["ATA",50,19]],"5-3-2":[["GOL",50,93],["LE",9,68],["ZAG",30,76],["ZAG",50,78],["ZAG",70,76],["LD",91,68],["MEI",26,49],["VOL",50,49],["MEI",74,49],["ATA",36,20],["ATA",64,20]],"5-4-1":[["GOL",50,93],["LE",9,68],["ZAG",30,76],["ZAG",50,78],["ZAG",70,76],["LD",91,68],["PE",14,46],["MEI",38,46],["MEI",62,46],["PE",86,46],["ATA",50,20]],"5-2-3":[["GOL",50,93],["LE",9,68],["ZAG",30,76],["ZAG",50,78],["ZAG",70,76],["LD",91,68],["VOL",38,52],["VOL",62,52],["PE",18,22],["ATA",50,22],["PE",82,22]],"4-4-1-1":[["GOL",50,93],["LE",14.0,75],["ZAG",38.0,75],["ZAG",62.0,75],["LD",86.0,75],["PE",12,49],["MEI",38,49],["MEI",62,49],["PE",88,49],["MEI",50,34],["ATA",50,18]],"4-1-3-2":[["GOL",50,93],["LE",14.0,75],["ZAG",38.0,75],["ZAG",62.0,75],["LD",86.0,75],["VOL",50,62],["MEI",22,44],["MEI",50,44],["MEI",78,44],["ATA",36,19],["ATA",64,19]],"3-3-4":[["GOL",50,93],["ZAG",24,76],["ZAG",50,76],["ZAG",76,76],["MEI",26,54],["VOL",50,54],["MEI",74,54],["PE",10,22],["ATA",38,22],["ATA",62,22],["PE",90,22]],"4-6-0":[["GOL",50,93],["LE",14.0,75],["ZAG",38.0,75],["ZAG",62.0,75],["LD",86.0,75],["VOL",38,58],["VOL",62,58],["PE",12,37],["MEI",38,37],["MEI",62,37],["PE",88,37]]};

const ROLE_GRUPO={GOL:"GOL",ZAG:"DEF",LD:"DEF",LE:"DEF",VOL:"MEI",MEI:"MEI",PE:"MEI",ATA:"ATA"};
const FORM={};Object.keys(FORMSLOT).forEach(k=>{const c={GOL:0,DEF:0,MEI:0,ATA:0};FORMSLOT[k].forEach(s=>c[ROLE_GRUPO[s[0]]]++);FORM[k]=[c.GOL,c.DEF,c.MEI,c.ATA]});
// afinidade entre a posição do jogador e o papel do slot (maior = melhor encaixe)
const AFIN={
 GOL:{GOL:10},
 ZAG:{ZAG:10,LD:5,LE:5,VOL:5,MEI:2,PE:1,ATA:0},
 LD:{LD:10,LE:7,ZAG:5,PE:5,VOL:3,MEI:3,ATA:1},
 LE:{LE:10,LD:7,ZAG:5,PE:5,VOL:3,MEI:3,ATA:1},
 VOL:{VOL:10,MEI:7,ZAG:5,LD:3,LE:3,PE:2,ATA:1},
 MEI:{MEI:10,VOL:7,PE:6,ATA:4,LD:3,LE:3,ZAG:2},
 PE:{PE:10,MEI:6,ATA:6,LD:5,LE:5,VOL:2},
 ATA:{ATA:10,PE:6,MEI:4,VOL:1}
};
const af=(pos,role)=>((AFIN[pos]||{})[role])||0;

// ================= FASE 0 · NÚCLEO DETERMINÍSTICO (RNG) =================
// Um único ponto de aleatoriedade do jogo. Fora de uma simulação, R() é idêntico a
// Math.random() — o jogador não sente nenhuma diferença. Dentro de comSeed(), R() passa
// a ser um gerador SEMEADO: mesma semente = mesmo resultado, em qualquer máquina.
// É a base do multiplayer (todos os clientes chegam ao mesmo placar) e da verificação
// por hash na Fase 7. Nada aqui altera o comportamento single-player existente.
let RNG_CTX=null;                     // gerador ativo (null = aleatório real do navegador)
let RNG_NOME="";                      // rótulo da semente ativa (debug)
let RNG_USOS=0;                       // quantas chamadas R() ocorreram no contexto
function R(){RNG_USOS++;return RNG_CTX?RNG_CTX():Math.random()}
function comSeed(seedTxt,fn){         // executa fn com RNG semeado e restaura o estado anterior
  const ctxA=RNG_CTX,nomeA=RNG_NOME,usosA=RNG_USOS;
  const seed=(typeof seedTxt==="number")?seedTxt:semente(String(seedTxt==null?"":seedTxt));
  RNG_CTX=rngSeed(seed);RNG_NOME=String(seedTxt);RNG_USOS=0;
  try{return fn()}finally{RNG_CTX=ctxA;RNG_NOME=nomeA;RNG_USOS=usosA}
}
function Rembaralha(arr){             // Fisher-Yates determinístico (substitui sort(random-.5))
  const a=arr.slice();
  for(let i=a.length-1;i>0;i--){const j=Math.floor(R()*(i+1));const t=a[i];a[i]=a[j];a[j]=t}
  return a;
}
function Rchance(p){return R()<p}
function seedDe(tag){return semente(String(tag)+"|"+((S&&S.seed)!=null?S.seed:0)+"|"+((S&&S.temp)||1)+"|"+((S&&S.rodada)||0))}
const rnd=(a,b)=>Math.floor(R()*(b-a+1))+a;
const pick=a=>a[rnd(0,a.length-1)];
let S=null;


// ===== BASE DE DADOS REALISTA v2 (2.0.0-alpha) =====
// Módulo separado e versionado: clube = país, liga, estádio, cores, uniformes 1/2/3, escudo.
// Jogador = nome real, posição real, ano de nascimento (idade calculada), nacionalidade, força.
const DB_VER="2.0.0-alpha";
const EST_EXTRA={
"Real Madrid":["Santiago Bernabéu",81044],"Barcelona":["Spotify Camp Nou",99354],"Atlético de Madrid":["Riyadh Air Metropolitano",68456],
"Sevilla":["Ramón Sánchez-Pizjuán",43883],"Real Betis":["Benito Villamarín",60721],"Valencia":["Mestalla",48600],
"Athletic Bilbao":["San Mamés",53289],"Real Sociedad":["Reale Arena",39500],"Villarreal":["La Cerámica",23008],
"Arsenal":["Emirates Stadium",60704],"Chelsea":["Stamford Bridge",40343],"Liverpool":["Anfield",61276],
"Manchester City":["Etihad Stadium",53400],"Manchester United":["Old Trafford",74310],"Tottenham":["Tottenham Hotspur Stadium",62850],
"Newcastle United":["St James' Park",52305],"Aston Villa":["Villa Park",42657],"Everton":["Hill Dickinson Stadium",52888],
"West Ham":["London Stadium",62500],"Inter":["San Siro",75817],"Milan":["San Siro",75817],"Juventus":["Allianz Stadium",41507],
"Napoli":["Diego Armando Maradona",54726],"Roma":["Stadio Olimpico",70634],"Lazio":["Stadio Olimpico",70634],
"Bayern de Munique":["Allianz Arena",75024],"Borussia Dortmund":["Signal Iduna Park",81365],"RB Leipzig":["Red Bull Arena",47069],
"Bayer Leverkusen":["BayArena",30210],"Eintracht Frankfurt":["Deutsche Bank Park",58000],
"Paris Saint-Germain":["Parc des Princes",47929],"Olympique de Marseille":["Orange Vélodrome",67394],
"Olympique Lyonnais":["Groupama Stadium",59186],"Monaco":["Stade Louis II",18523],"Lille":["Stade Pierre-Mauroy",50186],
"Benfica":["Estádio da Luz",64642],"Porto":["Estádio do Dragão",50033],"Sporting CP":["Estádio José Alvalade",50095],
"Ajax":["Johan Cruijff ArenA",55865],"PSV Eindhoven":["Philips Stadion",35000],"Feyenoord":["De Kuip",51117],
"Boca Juniors":["La Bombonera",54000],"River Plate":["Monumental",83214],"Racing Club":["El Cilindro",55000],
"Independiente":["Libertadores de América",48069],"América":["Estadio Azteca",87523],"Guadalajara":["Estadio Akron",46232],
"Inter Miami":["Chase Stadium",21550],"LA Galaxy":["Dignity Health Sports Park",27000],"LAFC":["BMO Stadium",22000],
"Al Hilal":["Kingdom Arena",25000],"Al Nassr":["Al-Awwal Park",25000],"Flamengo":["Maracanã",78838]
};
// estádios extras são consultados por fallback em arenaDe (evita TDZ de ESTREAL)

// Uniformes: [principal, reserva, terceiro] — cor1, cor2, padrão (listras|solida|metade|faixa)
const KITS_REAL={
"Flamengo":[["#c8102e","#111111","listras"],["#ffffff","#111111","solida"],["#0b0b0b","#c8102e","listras"]],
"Palmeiras":[["#006437","#ffffff","solida"],["#ffffff","#006437","solida"],["#0b2a1d","#c9a227","faixa"]],
"Corinthians":[["#ffffff","#111111","solida"],["#111111","#ffffff","solida"],["#f5c542","#111111","faixa"]],
"São Paulo":[["#ffffff","#e30613","faixa"],["#111111","#e30613","faixa"],["#e30613","#111111","listras"]],
"Santos":[["#ffffff","#111111","solida"],["#111111","#ffffff","listras"],["#c9a227","#111111","faixa"]],
"Fluminense":[["#7a0019","#00843d","listras"],["#ffffff","#7a0019","solida"],["#0b3d2a","#c9a227","faixa"]],
"Botafogo":[["#111111","#ffffff","listras"],["#ffffff","#111111","listras"],["#c8102e","#111111","solida"]],
"Vasco da Gama":[["#111111","#ffffff","faixa"],["#ffffff","#111111","solida"],["#5b2c6f","#111111","solida"]],
"Grêmio":[["#0d80bf","#111111","listras"],["#ffffff","#0d80bf","solida"],["#111111","#c9a227","faixa"]],
"Internacional":[["#e30613","#ffffff","solida"],["#ffffff","#e30613","solida"],["#111111","#e30613","listras"]],
"Atlético Mineiro":[["#111111","#ffffff","listras"],["#ffffff","#111111","listras"],["#c9a227","#111111","faixa"]],
"Cruzeiro":[["#0033a0","#ffffff","solida"],["#ffffff","#0033a0","solida"],["#0b1e3a","#c9a227","faixa"]],
"Bahia":[["#0033a0","#e30613","faixa"],["#ffffff","#0033a0","solida"],["#e30613","#111111","listras"]],
"Vitória":[["#e30613","#111111","listras"],["#ffffff","#e30613","solida"],["#111111","#e30613","faixa"]],
"Fortaleza":[["#0033a0","#e30613","listras"],["#ffffff","#0033a0","solida"],["#111111","#0033a0","faixa"]],
"Ceará":[["#111111","#ffffff","listras"],["#ffffff","#111111","listras"],["#c8102e","#111111","solida"]],
"Athletico Paranaense":[["#e30613","#111111","listras"],["#111111","#e30613","listras"],["#ffffff","#e30613","solida"]],
"Coritiba":[["#00843d","#ffffff","listras"],["#ffffff","#00843d","solida"],["#111111","#00843d","faixa"]],
"Sport Recife":[["#e30613","#111111","listras"],["#111111","#e30613","faixa"],["#ffffff","#e30613","solida"]],
"Goiás":[["#00843d","#ffffff","listras"],["#ffffff","#00843d","solida"],["#111111","#00843d","faixa"]],
"Real Madrid":[["#ffffff","#febe10","solida"],["#111111","#febe10","solida"],["#0a1a3a","#febe10","faixa"]],
"Barcelona":[["#a50044","#004d98","listras"],["#f2e8d5","#a50044","solida"],["#0b2f6b","#a50044","faixa"]],
"Atlético de Madrid":[["#cd6133","#ffffff","listras"],["#111111","#cd6133","solida"],["#1b3a5c","#cd6133","faixa"]],
"Liverpool":[["#c8102e","#ffffff","solida"],["#0e3a4f","#ffffff","solida"],["#f2f2f2","#c8102e","faixa"]],
"Manchester City":[["#6cabdd","#ffffff","solida"],["#0b1e3a","#6cabdd","solida"],["#f5c542","#6cabdd","faixa"]],
"Manchester United":[["#da291c","#ffffff","solida"],["#111111","#da291c","solida"],["#f5e6c8","#da291c","faixa"]],
"Arsenal":[["#ef0107","#ffffff","solida"],["#f5e6a8","#111111","solida"],["#0b1e3a","#ef0107","faixa"]],
"Chelsea":[["#034694","#ffffff","solida"],["#f2f2f2","#034694","solida"],["#111111","#034694","faixa"]],
"Bayern de Munique":[["#dc052d","#ffffff","solida"],["#111111","#dc052d","solida"],["#f2e8d5","#dc052d","faixa"]],
"Borussia Dortmund":[["#fde100","#111111","solida"],["#111111","#fde100","solida"],["#2b2b2b","#fde100","faixa"]],
"Juventus":[["#111111","#ffffff","listras"],["#ffffff","#111111","solida"],["#1b3a5c","#c9a227","faixa"]],
"Inter":[["#0068a8","#111111","listras"],["#ffffff","#0068a8","solida"],["#111111","#c9a227","faixa"]],
"Milan":[["#fb090b","#111111","listras"],["#ffffff","#fb090b","solida"],["#111111","#fb090b","faixa"]],
"Napoli":[["#27ae60","#ffffff","solida"],["#ffffff","#27ae60","solida"],["#0b3d6b","#27ae60","faixa"]],
"Paris Saint-Germain":[["#004170","#da291c","faixa"],["#ffffff","#004170","solida"],["#111111","#da291c","solida"]],
"Benfica":[["#e30613","#ffffff","solida"],["#ffffff","#e30613","solida"],["#111111","#e30613","faixa"]],
"Porto":[["#003893","#ffffff","listras"],["#ffffff","#003893","solida"],["#0b1e3a","#c9a227","faixa"]],
"Sporting CP":[["#00794d","#ffffff","listras"],["#ffffff","#00794d","solida"],["#111111","#00794d","faixa"]],
"Ajax":[["#d2122e","#ffffff","faixa"],["#111111","#d2122e","solida"],["#f2e8d5","#d2122e","faixa"]],
"Boca Juniors":[["#0b3d91","#f5c542","faixa"],["#f5c542","#0b3d91","solida"],["#111111","#0b3d91","faixa"]],
"River Plate":[["#ffffff","#e30613","faixa"],["#111111","#e30613","solida"],["#e30613","#111111","faixa"]]
};

// Elencos reais: [nome, posição, ano de nascimento, nacionalidade, força]
const JOG_REAL={
"Flamengo":[
["Agustín Rossi","GOL",1995,"Argentina",82],["Matheus Cunha","GOL",1991,"Brasil",76],
["Guillermo Varela","LD",1993,"Uruguai",78],["Léo Pereira","ZAG",1996,"Brasil",81],
["Léo Ortiz","ZAG",1996,"Brasil",82],["Danilo","ZAG",1991,"Brasil",80],
["Alex Sandro","LE",1991,"Brasil",79],["Ayrton Lucas","LE",1997,"Brasil",80],
["Erick Pulgar","VOL",1994,"Chile",80],["Jorginho","VOL",1991,"Itália",82],
["Gerson","MEI",1997,"Brasil",83],["Giorgian De Arrascaeta","MEI",1994,"Uruguai",85],
["Saúl Ñíguez","MEI",1994,"Espanha",79],["Luiz Araújo","PE",1996,"Brasil",80],
["Michael","PE",1996,"Brasil",79],["Gonzalo Plata","PE",2000,"Equador",79],
["Bruno Henrique","ATA",1990,"Brasil",81],["Pedro","ATA",1997,"Brasil",84]
],
"Palmeiras":[
["Weverton","GOL",1987,"Brasil",80],["Marcelo Lomba","GOL",1986,"Brasil",72],
["Mayke","LD",1992,"Brasil",77],["Agustín Giay","LD",2003,"Argentina",75],
["Gustavo Gómez","ZAG",1993,"Paraguai",83],["Murilo","ZAG",1997,"Brasil",79],
["Bruno Fuchs","ZAG",1999,"Brasil",76],["Joaquín Piquerez","LE",1998,"Uruguai",79],
["Aníbal Moreno","VOL",1999,"Argentina",80],["Richard Ríos","VOL",2000,"Colômbia",79],
["Allan","VOL",1997,"Brasil",76],["Raphael Veiga","MEI",1995,"Brasil",81],
["Maurício","MEI",1996,"Brasil",77],["Felipe Anderson","PE",1993,"Brasil",78],
["Vitor Roque","ATA",2005,"Brasil",80],["Flaco López","ATA",2000,"Argentina",80],
["Paulinho","ATA",2000,"Brasil",79],["Estêvão","PE",2007,"Brasil",81]
],
"Corinthians":[
["Hugo Souza","GOL",1999,"Brasil",78],["Matheus Donelli","GOL",2002,"Brasil",71],
["Matheuzinho","LD",2000,"Brasil",76],["Fagner","LD",1989,"Brasil",72],
["André Ramalho","ZAG",1992,"Brasil",76],["Cacá","ZAG",1999,"Brasil",75],
["Félix Torres","ZAG",1997,"Equador",76],["Hugo","LE",1997,"Brasil",73],
["José Martínez","VOL",1994,"Venezuela",77],["Maycon","VOL",1997,"Brasil",76],
["Raniele","VOL",1997,"Brasil",75],["Rodrigo Garro","MEI",1997,"Argentina",81],
["Breno Bidon","MEI",2005,"Brasil",75],["Memphis Depay","ATA",1994,"Holanda",83],
["Yuri Alberto","ATA",2001,"Brasil",80],["Ángel Romero","ATA",1992,"Paraguai",77],
["Talles Magno","PE",2002,"Brasil",75]
],
"São Paulo":[
["Rafael","GOL",1989,"Brasil",78],["Jandrei","GOL",1993,"Brasil",71],
["Rafinha","LD",1985,"Brasil",72],["Robert Arboleda","ZAG",1991,"Equador",77],
["Alan Franco","ZAG",1996,"Argentina",76],["Sabino","ZAG",1996,"Brasil",74],
["Wendell","LE",1993,"Brasil",76],["Enzo Díaz","LE",1995,"Argentina",74],
["Damián Bobadilla","VOL",1997,"Paraguai",75],["Luiz Gustavo","VOL",1987,"Brasil",74],
["Alisson","MEI",1993,"Brasil",76],["Oscar","MEI",1991,"Brasil",82],
["Lucas Moura","PE",1992,"Brasil",80],["Ferreirinha","PE",1998,"Brasil",77],
["Jonathan Calleri","ATA",1993,"Argentina",81],["Luciano","ATA",1993,"Brasil",78]
],
"Real Madrid":[
["Thibaut Courtois","GOL",1992,"Bélgica",89],["Andriy Lunin","GOL",1999,"Ucrânia",79],
["Trent Alexander-Arnold","LD",1998,"Inglaterra",85],["Dani Carvajal","LD",1992,"Espanha",82],
["Éder Militão","ZAG",1998,"Brasil",84],["Antonio Rüdiger","ZAG",1993,"Alemanha",85],
["Dean Huijsen","ZAG",2005,"Espanha",80],["Fran García","LE",1999,"Espanha",78],
["Aurélien Tchouaméni","VOL",2000,"França",84],["Federico Valverde","MEI",1998,"Uruguai",87],
["Jude Bellingham","MEI",2003,"Inglaterra",89],["Arda Güler","MEI",2005,"Turquia",82],
["Vinícius Júnior","PE",2000,"Brasil",90],["Rodrygo","PE",2001,"Brasil",85],
["Kylian Mbappé","ATA",1998,"França",91]
],
"Barcelona":[
["Joan García","GOL",2001,"Espanha",82],["Wojciech Szczęsny","GOL",1990,"Polônia",79],
["Jules Koundé","LD",1998,"França",85],["Pau Cubarsí","ZAG",2007,"Espanha",83],
["Ronald Araújo","ZAG",1999,"Uruguai",83],["Alejandro Balde","LE",2003,"Espanha",81],
["Pedri","MEI",2002,"Espanha",88],["Frenkie de Jong","VOL",1997,"Holanda",84],
["Gavi","MEI",2004,"Espanha",82],["Dani Olmo","MEI",1998,"Espanha",83],
["Lamine Yamal","PE",2007,"Espanha",89],["Raphinha","PE",1996,"Brasil",86],
["Robert Lewandowski","ATA",1988,"Polônia",85],["Ferran Torres","ATA",2000,"Espanha",82]
],
"Liverpool":[
["Alisson","GOL",1992,"Brasil",88],["Jeremie Frimpong","LD",2000,"Holanda",81],
["Virgil van Dijk","ZAG",1991,"Holanda",88],["Ibrahima Konaté","ZAG",1999,"França",84],
["Milos Kerkez","LE",2003,"Hungria",79],["Ryan Gravenberch","VOL",2002,"Holanda",84],
["Alexis Mac Allister","MEI",1998,"Argentina",85],["Dominik Szoboszlai","MEI",2000,"Hungria",83],
["Florian Wirtz","MEI",2003,"Alemanha",87],["Mohamed Salah","PE",1992,"Egito",89],
["Cody Gakpo","PE",1999,"Holanda",83],["Hugo Ekitiké","ATA",2002,"França",83]
],
"Manchester City":[
["Gianluigi Donnarumma","GOL",1999,"Itália",87],["Matheus Nunes","LD",1998,"Portugal",79],
["Rúben Dias","ZAG",1997,"Portugal",86],["Joško Gvardiol","ZAG",2002,"Croácia",84],
["Josko Nunes","LE",1999,"Portugal",76],["Rodri","VOL",1996,"Espanha",89],
["Bernardo Silva","MEI",1994,"Portugal",85],["Phil Foden","MEI",2000,"Inglaterra",85],
["Tijjani Reijnders","MEI",1998,"Holanda",82],["Jérémy Doku","PE",2002,"Bélgica",83],
["Savinho","PE",2004,"Brasil",81],["Erling Haaland","ATA",2000,"Noruega",91]
],
"Bayern de Munique":[
["Manuel Neuer","GOL",1986,"Alemanha",86],["Konrad Laimer","LD",1997,"Áustria",80],
["Dayot Upamecano","ZAG",1998,"França",84],["Jonathan Tah","ZAG",1996,"Alemanha",83],
["Alphonso Davies","LE",2000,"Canadá",83],["Joshua Kimmich","VOL",1995,"Alemanha",86],
["Leon Goretzka","MEI",1995,"Alemanha",81],["Jamal Musiala","MEI",2003,"Alemanha",87],
["Michael Olise","PE",2001,"França",85],["Luis Díaz","PE",1997,"Colômbia",85],
["Harry Kane","ATA",1993,"Inglaterra",90]
]
};

function kitDe(c,kit){
  const K=KITS_REAL[c&&c.nome]||[];
  const i=Math.max(0,Math.min(2,(kit||(c&&c.kit)||1)-1));
  const k=K[i]||[c&&c.cor,c&&c.cor2||"#ffffff","listras"];
  return {c1:k[0]||"#666",c2:k[1]||"#ffffff",pat:k[2]||"listras",n:["Principal","Reserva","Terceiro"][i],i:i+1};
}
function realizaElenco(c){
  const arr=JOG_REAL[c&&c.nome];if(!arr||!arr.length)return false;
  const ant=c.elenco||[];
  const rg=rngClube("real|"+c.nome+"|"+(S&&S.seed!=null?S.seed:0));
  const mk=mkDaChave((S?S.pais:"Brasil")+"|"+(S?S.div:0)+"|0");
  const out=arr.map(function(r){
    const j=criaJogadorFixo(r[1],r[4],rg,null,r[2],r[3]);
    j.nome=r[0];j.real=true;j.nac=r[3]||"";
    j.val=valorDe(j.f,j.idade,j.pot,mk);j.sal=salarioDe(j.f,mk);
    return j;
  });
  let i=0;
  while(out.length<22&&i<ant.length){const g=ant[i++];g.real=false;out.push(g)}
  c.elenco=out.slice(0,30);
  try{atribuiNumeros(c)}catch(e){}
  return true;
}
function dbStats(){
  let reais=0,kit=0,est=0,tot=0;
  if(S)S.clubes.forEach(function(c){tot++;if(JOG_REAL[c.nome])reais++;if(KITS_REAL[c.nome])kit++;if(ESTREAL[c.nome])est++});
  return {reais:reais,kit:kit,est:est,tot:tot,jog:Object.keys(JOG_REAL).length};
}

function nomeJog(){return pick(SILABAS1)+pick(SILABAS2)+" "+pick(SOBRE)}
function novoJog(pos,base,rgOpt){ // jogador de reposição (jovem da base) — determinístico a partir de um contador salvo no jogo
  S.contRepos=(S.contRepos||0)+1;
  const rg=rgOpt||rngClube("repos|"+S.contRepos);
  const j=criaJogadorFixo(pos,Math.max(18,base+Math.floor(rg()*7)-3),rg,17+Math.floor(rg()*3));
  return j;
}
function criaElenco(base){return POS22.map(x=>novoJog(x,base))}
function novoJogo(pais,div,idx,treinador){
  const lista=LIGAS[pais][div];
  const clubes=lista.map((c,i)=>({id:i,nome:c[0],sig:c[1],cor:c[2],cor2:c[3],escudo:null,forca:50,caixa:(i===idx?15000000:rnd(2,10)*1000000/(1+div*0.8)),
    elenco:[],pts:0,j:0,v:0,e:0,d:0,gp:0,gc:0}));
  const seed=novaSemente();
  const n=clubes.length;
  S={seed,treinador,pais,div,meu:idx,clubes,rodada:0,temp:1,form:"4-4-2",tatica:"Equilibrada",marc:"Leve",conc:"Pelo meio",subs:0,props:[],log:[],mercado:[],aba:"home",fixt:fixtures(n%2?n+1:n,n),hist:[],_v:SAVE_VER,ing:15000/(1+div*.6)};
  S.clubes.forEach((c,i)=>{const pk=picoDe(S.pais,S.div)-Math.floor(rngClube(S.pais+'|'+S.div+'|p|'+i)()*8);c.elenco=geraElencoFixo(S.pais+'|'+S.div+'|'+i,pk);c.forca=forcaMedia(c)});
  S.clubes.forEach(function(c){c.pais=S.pais;c.div=S.div;c.liga=(LIGANOME[S.pais]||[])[S.div]||"";c.kit=1;c.est=null;try{est(c)}catch(e){}try{dbAplicaClube(c)}catch(e){}try{if(realizaElenco(c))c.forca=forcaMedia(c)}catch(e){}});
  S.clubes.forEach(c=>auto(c));
  garanteDivAtual();
  S.emp=[];S.aux=null;S.rankModo='clubes';geraMercado();garanteTec();try{clInicia()}catch(e){S.cl=null}try{lbInicia()}catch(e){S.lb=null}try{elInicia()}catch(e){S.el=null}try{saInicia()}catch(e){S.sa=null}try{cnInicia()}catch(e){S.cn=null}try{agendaMonta()}catch(e){S.agenda=null;S.dia=0}try{geraObjetivo()}catch(e){}save();
}
function fixtures(nn,real){ // round robin (nn par; índices >= real são folga)
  real=real||nn;
  let t=[...Array(nn).keys()],R=[];
  for(let r=0;r<nn-1;r++){let m=[];for(let i=0;i<nn/2;i++){const a=t[i],b=t[nn-1-i];if(a<real&&b<real)m.push([a,b])}R.push(m);t.splice(1,0,t.pop())}
  return R.concat(R.map(r=>r.map(([a,b])=>[b,a])));
}
function auto(c,manterPos){ // escala automaticamente por slot da formação
  try{if(c.elenco.some(j=>j.num==null))atribuiNumeros(c)}catch(e){}
  const antes={};c.elenco.forEach(j=>{if(j.tit&&j.px!=null)antes[j.id]=[j.px,j.py,j._g]});
  const form=c.form||"4-4-2";
  const slots=FORMSLOT[form]||FORMSLOT["4-4-2"];
  c.elenco.forEach(j=>{j.tit=false;j.px=null;j.py=null;j._g=null;j._slot=null});
  const nExp=c.elenco.filter(j=>j.expulso).length;
  const livres=()=>c.elenco.filter(j=>!j.tit&&j.lesao<=0&&!j.expulso&&!(j.suspenso>0));
  // slots mais restritos primeiro: GOL, depois os demais
  const ordem=slots.map((sl,i)=>i).sort((i,k)=>(slots[i][0]==="GOL"?-1:0)-(slots[k][0]==="GOL"?-1:0));
  ordem.forEach(i=>{
    const [role,x,y]=slots[i];
    const cand=livres().filter(j=>role==="GOL"?j.pos==="GOL":j.pos!=="GOL")
      .map(j=>({j,sc:af(j.pos,role)*100+fe(j)}))
      .filter(o=>role==="GOL"?true:af(o.j.pos,role)>0||true)
      .sort((p,q)=>q.sc-p.sc);
    if(c.elenco.filter(x=>x.tit).length>=11-nExp)return;      // expulsos não são repostos
    const m=cand[0];if(!m)return;
    m.j.tit=true;m.j.px=x;m.j.py=y;m.j._g=ROLE_GRUPO[role];m.j._slot=i;m.j._role=role;
  });
  if(manterPos)c.elenco.forEach(j=>{if(j.tit&&antes[j.id]){j.px=antes[j.id][0];j.py=antes[j.id][1];j._g=antes[j.id][2]}});
}
function fe(j){const e=j.en==null?100:j.en;const base=j.f+bonusEstrela(j)+habBonus(j)*1.5;return base*(0.7+0.3*e/100)*efPos(j)}
function forcaTime(c,tat){
  const t=c.elenco.filter(j=>j.tit);
  if(!t.length)return 40;
  let m=t.reduce((s,j)=>s+fe(j),0)/t.length;if(c.id===S.meu&&S.aux)m+=S.aux.hab/60;
  if(c.id===S.meu||c.hum)m*=fatorEntrosMoral(c);                                    // v58: entrosamento e moral do SEU time
  if(tat==="Ofensiva")m+=1;if(tat==="Defensiva")m-=1;if(tat==="Contra-ataque")m-=.3;
  return m;
}
function simula(a,b,meuA,meuB){
  const TA_=TTc(a),TB_=TTc(b);meuA=meuA||ehHc(a);meuB=meuB||ehHc(b);const fa=forcaTime(a,meuA?TA_.tatica:"Equilibrada")+3,fb=forcaTime(b,meuB?TB_.tatica:"Equilibrada");
  const of=(t,x)=>t==="Ofensiva"?1.25:t==="Defensiva"?.8:1;
  let ma=Math.max(.2,(fa-fb)/22+1.35)*(meuA?of(TA_.tatica):1)*(meuB&&TB_.tatica==="Defensiva"?.85:1);
  let mb=Math.max(.2,(fb-fa)/22+1.0)*(meuB?of(TB_.tatica):1)*(meuA&&TA_.tatica==="Defensiva"?.85:1);
  const pois=l=>{let L=Math.exp(-l),k=0,p=1;do{k++;p*=R()}while(p>L);return k-1};
  const ga=pois(ma),gb=pois(mb);
  const marca=(c,g)=>{const at=c.elenco.filter(j=>j.tit&&j.pos!=="GOL");const ev=[];for(let i=0;i<g;i++){const w=at.map(j=>j.pos==="ATA"?5:j.pos==="MEI"||j.pos==="PE"?2.5:j.pos==="VOL"?1:.4);let s=w.reduce((x,y)=>x+y,0),r=R()*s,k=0;while(r>w[k]){r-=w[k];k++}at[k].gols++;ev.push(at[k].nome)}return ev};
  const ea=marca(a,ga),eb=marca(b,gb);
  return{ga,gb,ea,eb};
}
function aplica(a,b,r){
  a.j++;b.j++;a.gp+=r.ga;a.gc+=r.gb;b.gp+=r.gb;b.gc+=r.ga;
  if(r.ga>r.gb){a.v++;b.d++;a.pts+=3}else if(r.ga<r.gb){b.v++;a.d++;b.pts+=3}else{a.e++;b.e++;a.pts++;b.pts++}
}
function fimTemporada(){
  const t=tabela();
  // (S.tabFinal é calculado depois, junto do acesso/rebaixamento, para sempre representar a 1ª divisão)
  S.hist.push({temp:S.temp,campeao:t[0].nome,meu:t.findIndex(c=>c.id===S.meu)+1});garanteTec();if(t[0].tec)t[0].tec.tit=(t[0].tec.tit||0)+1;S.clubes.forEach(c=>{if(c.tec&&!c.tec.meu)c.tec.hab=Math.max(30,Math.min(95,c.tec.hab+rnd(-3,3)))});
  try{avancaMundo(S.fixt.length,S.fixt.length)}catch(e){}
  const avisoEstrela=fechaArtilharia();
  let estrelasMundo=[];try{estrelasMundo=fechaArtilhariaMundo()}catch(e){estrelasMundo=[]}
  let premiosInd=null;try{premiosInd=fechaPremiosIndividuais()}catch(e){premiosInd=null}S._premiosInd=premiosInd;
  let movsMundo=[];try{movsMundo=acessoRebaixamentoMundo()}catch(e){movsMundo=[]}
  try{fechaCopasMundo()}catch(e){}
  const tabelaNomes=t.map(c=>c.nome);
  try{registraTitulosTemporada(t[0].nome)}catch(e){}
  try{mundialJogaTudo()}catch(e){}
  const meuNome=S.clubes[S.meu].nome,divAntes=S.div,posFinal=t.findIndex(c=>c.id===S.meu)+1;
  let eventosTecFim=[];try{eventosTecFim=janelaTecnicosFim()||[]}catch(e){}
  try{premiosFimTemporada(posFinal,t.length,meuNome)}catch(e){}
  try{S._objFim=fechaObjetivo(posFinal)}catch(e){S._objFim=null}
  S._mundOk=false;S.temp++;S.rodada=0;S.agenda=null;S.dia=0;S.cl=null;S.lb=null;S.cn=null;S.el=null;S.sa=null;S.extras=0;
  let movs=[];try{movs=aplicaAcessoRebaixamento(tabelaNomes)}catch(e){movs=[]}
  const meuMov=movs.find(m=>m.nome===meuNome);
  if(meuMov){try{reconstroiMinhaLiga(meuMov.para,meuNome)}catch(e){}}
  else if(movs.length){try{reconstroiMinhaLiga(S.div,meuNome)}catch(e){}}
  S.clubes.forEach((c,ci)=>{c.pts=c.j=c.v=c.e=c.d=c.gp=c.gc=0;evoluiElenco(c,'liga|'+ci);
    while(c.elenco.length<20)c.elenco.push(novoJog(pick(POS),c.forca-6))});
  evoluiMundoTodo();
  try{S.ligas={};garanteLigasVivas()}catch(e){}
  let novosBase=[];try{novosBase=geraBaseClube(S.clubes[S.meu])}catch(e){}
  S.clubes.forEach(cc=>{if(cc.id!==S.meu){try{geraBaseClube(cc);const b=cc.base||[];b.filter(x=>x.idade>=17||R()<.5).slice(0,2).forEach(x=>{if(cc.elenco.length<MAX_ELENCO){delete x.nBase;cc.elenco.push(x);cc.base=cc.base.filter(y=>y.id!==x.id)}})}catch(e){}}});   // IA promove sozinha 1–2 garotos por ano
  resolveEmprestimos();clMontaTemporada();lbMontaTemporada();try{elInicia()}catch(e){S.el=null}try{saInicia()}catch(e){S.sa=null}try{cnInicia()}catch(e){S.cn=null}try{agendaMonta()}catch(e){S.agenda=null;S.dia=0}try{(S.pedidosSaida||[]).forEach(p=>{const j=meuReal().elenco.find(x=>x.id===p.jid);if(j)j.mor=Math.max(15,moralJ(j)-5)});S.pedidosSaida=[]}catch(e){}
  let renovAuto={renov:[],ficou:[]};try{renovAuto=renovaAutomatico()}catch(e){}S._renovAuto=renovAuto;let saidos=[];try{saidos=eu0Saidos()}catch(e){}vencerContratos();try{limitaElenco32()}catch(e){}try{geraLivres(saidos)}catch(e){}try{geraObjetivo()}catch(e){}try{patrocinioFimTemporada(posFinal)}catch(e){}S.fixt=fixtures(S.clubes.length%2?S.clubes.length+1:S.clubes.length,S.clubes.length);geraMercado();save();render();
  const subiu=meuMov&&meuMov.para<meuMov.de,desceu=meuMov&&meuMov.para>meuMov.de;
  const txtMov=subiu?`\n\n⬆️ ACESSO! O ${meuNome} subiu para a ${LIGANOME[S.pais][S.div]}.`:desceu?`\n\n⬇️ REBAIXAMENTO. O ${meuNome} caiu para a ${LIGANOME[S.pais][S.div]}.`:"";
  const listaMov=movs.length?`\n\nSobem e caem na sua liga:\n`+movs.filter(m=>m.de===divAntes||m.para===divAntes).map(m=>`${m.para<m.de?"⬆️":"⬇️"} ${m.nome}`).join("\n"):"";
  aviso("Temporada encerrada! Você ficou em "+posFinal+"º. Campeão: "+S.hist[S.hist.length-1].campeao+txtMov+(avisoEstrela?"\n\n"+avisoEstrela:"")+listaMov+(movsMundo.length?"\n\nAcessos pelo mundo: "+movsMundo.filter(m=>m.para<m.de&&m.de===1).slice(0,6).map(m=>m.nome+" ("+m.pais+")").join(", "):"")+(estrelasMundo.length?"\n\nNovas estrelas pelo mundo:\n"+estrelasMundo.slice(0,8).map(e=>(e.nivel===2?"🔴★ ":"🟡★ ")+e.nome+" ("+e.clube+", "+e.liga+")").join("\n"):""),mostraTecPendente);
}
function tabela(){return [...S.clubes].sort((a,b)=>b.pts-a.pts||(b.gp-b.gc)-(a.gp-a.gc)||b.gp-a.gp)}
function geraMercado(){
  const rg=rngClube("mercado|"+S.temp+"|"+(S.contMerc=(S.contMerc||0)+1));
  const outros=S.clubes.filter(c=>c.id!==S.meu);
  const lista=[];
  // 1) jogadores da minha liga
  for(let t=0;t<200&&lista.length<12;t++){
    const c=outros[Math.floor(rg()*outros.length)],j=c.elenco[Math.floor(rg()*c.elenco.length)];
    if(!j||j.emprestado||lista.some(x=>x.id===j.id))continue;
    if(j.f>=picoDe(S.pais,S.div)-2)continue;               // craques do clube não ficam "à venda"
    lista.push({t:"liga",id:j.id,clubeId:c.id});
  }
  // 2) jogadores de OUTROS países e divisões (o mundo todo)
  const paises=Object.keys(LIGAS).filter(p=>p!==S.pais);
  for(let t=0,n=0;t<400&&n<22;t++){
    const pa=paises[Math.floor(rg()*paises.length)];
    const rd=rg();const dv=Math.min(LIGAS[pa].length-1,rd<.6?0:rd<.9?1:2);          // 60% 1ª div. · 30% 2ª · 10% 3ª
    const cl=clubesNaDivisao(pa,dv);if(!cl.length)continue;
    const nm=cl[Math.floor(rg()*cl.length)][0];const ch=chaveFixa(pa,nm);if(!ch)continue;
    const c=clubeMundo(pa,ch.div,ch.idx);if(!c||!c.elenco)continue;
    const j=c.elenco[Math.floor(rg()*c.elenco.length)];
    if(!j||j.emprestado||lista.some(x=>x.id===j.id))continue;
    if(j.f>=picoDe(pa,ch.div)-1)continue;                   // peça-chave não vai ao mercado
    lista.push({t:"mundo",pais:pa,div:ch.div,idx:ch.idx,id:j.id});n++;
  }
  // 3) jogadores RAROS: força alta para uma liga fraca, jovens, preço com desconto de descoberta
  const fracas=["Brasil","Argentina","Colômbia","Chile","Uruguai","México","Estados Unidos","Japão","Arábia Saudita"];
  const POSR=["ATA","PE","MEI","VOL","ZAG","LD","LE","GOL"];
  for(let n=0;n<6;n++){
    const pa=fracas[Math.floor(rg()*fracas.length)],pos=POSR[Math.floor(rg()*POSR.length)];
    const f=48+Math.floor(rg()*9);                          // F48–F56
    const idade=19+Math.floor(rg()*6);                      // 19–24 anos
    const j=criaJogadorFixo(pos,f,rg,idade);
    j.pot=Math.min(100,Math.max(j.pot,f+4+Math.floor(rg()*10)));
    const clubes=clubesNaDivisao(pa,0);const origem=clubes.length?clubes[Math.floor(rg()*clubes.length)]:null;
    j.mk=fatorMercado(pa,0);j.raro=true;j.origem=origem?origem[0]:pa;j.paisOrigem=pa;
    j.val=valorDe(j.f,j.idade,j.pot,1)*0.6;                 // desconto de descoberta (≈ R$ 7–10 mi para F50)
    j.val=Math.round(j.val/10000)*10000;j.sal=salarioDe(j.f,.6);
    lista.push({t:"raro",j});
  }
  S.mercado=lista;
}
const $=n=>n.toLocaleString("pt-BR");
const R$=v=>"R$ "+(Math.abs(v)>=1e6?(v/1e6).toFixed(2)+" mi":Math.abs(v)>=1e3?(v/1e3).toFixed(0)+" mil":v);


// ===== BASE DE DADOS DOS CLUBES · v1 (Clubes_Atualizados_v1) =====
// Estrutura pedida na especificação, adicionada AO LADO dos campos existentes:
// {id, nome, nomeCurto, nomeOficial, nomeInternacional, pais, liga, logo,
//  uniformeCasa, uniformeFora, uniformeTerceiro, estadio, reputacao, orcamento}
// 'nome' e 'id' NUNCA são alterados: saves, elencos, histórico, fama e transferências continuam resolvendo pelo mesmo nome.
const CLUBE_DB_VER="Clubes_Atualizados_v1";
const CLUBE_DB={
// ---------- BRASIL · Série A (nomes oficiais conferidos na Wikipédia) ----------
"Flamengo":{of:"Clube de Regatas do Flamengo",cur:"Flamengo",int:"Flamengo",pais:"Brasil",liga:"Brasileirão Série A",rep:3,orc:180000000,
 logo:"https://thumb.wikimedia.org/wikipedia/commons/thumb/9/96/Clube_de_Regatas_do_Flamengo_logo.svg/langpt-330px-Clube_de_Regatas_do_Flamengo_logo.svg.png",est:["Maracanã",78838],fonte:"pt.wikipedia"},
"Palmeiras":{of:"Sociedade Esportiva Palmeiras",cur:"Palmeiras",int:"Palmeiras",pais:"Brasil",liga:"Brasileirão Série A",rep:3,orc:170000000,
 logo:"https://thumb.wikimedia.org/wikipedia/commons/thumb/6/68/Sociedade_Esportiva_Palmeiras_logo_%281_red_star%29.svg/langpt-330px-Sociedade_Esportiva_Palmeiras_logo_%281_red_star%29.svg.png",est:["Allianz Parque",43713],fonte:"pt.wikipedia"},
"Corinthians":{of:"Sport Club Corinthians Paulista",cur:"Corinthians",int:"Corinthians",pais:"Brasil",liga:"Brasileirão Série A",rep:3,orc:160000000,
 logo:"https://thumb.wikimedia.org/wikipedia/pt/thumb/b/b4/Corinthians_simbolo.png/330px-Corinthians_simbolo.png",est:["Neo Química Arena",49205],fonte:"pt.wikipedia"},
"São Paulo":{of:"São Paulo Futebol Clube",cur:"São Paulo",int:"São Paulo",pais:"Brasil",liga:"Brasileirão Série A",rep:3,orc:150000000,
 logo:"https://thumb.wikimedia.org/wikipedia/commons/thumb/f/f4/S%C3%A3o_Paulo_Futebol_Clube_logo_%282022%29.svg/langpt-330px-S%C3%A3o_Paulo_Futebol_Clube_logo_%282022%29.svg.png",est:["Morumbi",66795],fonte:"pt.wikipedia"},
"Santos":{of:"Santos Futebol Clube",cur:"Santos",int:"Santos",pais:"Brasil",liga:"Brasileirão Série A",rep:3,orc:90000000,
 logo:"https://thumb.wikimedia.org/wikipedia/commons/thumb/0/0e/Santos_Futebol_Clube_logo_%28with_stars_and_crown%29.png/330px-Santos_Futebol_Clube_logo_%28with_stars_and_crown%29.png",est:["Vila Belmiro",16068],fonte:"pt.wikipedia"},
"Fluminense":{of:"Fluminense Football Club",cur:"Fluminense",int:"Fluminense",pais:"Brasil",liga:"Brasileirão Série A",rep:3,orc:110000000,
 logo:"https://thumb.wikimedia.org/wikipedia/commons/thumb/1/12/Fluminense_Football_Club.svg/langpt-330px-Fluminense_Football_Club.svg.png",est:["Maracanã",78838],fonte:"pt.wikipedia"},
"Botafogo":{of:"Botafogo de Futebol e Regatas",cur:"Botafogo",int:"Botafogo",pais:"Brasil",liga:"Brasileirão Série A",rep:3,orc:120000000,
 logo:"https://thumb.wikimedia.org/wikipedia/commons/thumb/5/52/Botafogo_de_Futebol_e_Regatas_logo.svg/langpt-330px-Botafogo_de_Futebol_e_Regatas_logo.svg.png",est:["Nilton Santos",44661],fonte:"pt.wikipedia"},
"Vasco da Gama":{of:"Club de Regatas Vasco da Gama",cur:"Vasco",int:"Vasco da Gama",pais:"Brasil",liga:"Brasileirão Série A",rep:2,orc:80000000,
 logo:"https://thumb.wikimedia.org/wikipedia/pt/thumb/8/8b/EscudoDoVascoDaGama.svg/langpt-330px-EscudoDoVascoDaGama.svg.png",est:["São Januário",21880],fonte:"pt.wikipedia"},
"Grêmio":{of:"Grêmio Foot-Ball Porto Alegrense",cur:"Grêmio",int:"Grêmio",pais:"Brasil",liga:"Brasileirão Série A",rep:3,orc:85000000,
 logo:"https://thumb.wikimedia.org/wikipedia/commons/thumb/0/08/Gremio_logo.svg/langpt-330px-Gremio_logo.svg.png",est:["Arena do Grêmio",57387],fonte:"pt.wikipedia"},
// ---------- EUROPA (nomes oficiais conferidos na Wikipédia em inglês) ----------
"Real Madrid":{of:"Real Madrid Club de Fútbol",cur:"Real Madrid",int:"Real Madrid",pais:"Espanha",liga:"La Liga",rep:3,orc:420000000,
 logo:"https://thumb.wikimedia.org/wikipedia/en/thumb/5/56/Real_Madrid_CF.svg/330px-Real_Madrid_CF.svg.png",est:["Santiago Bernabéu",81044],fonte:"en.wikipedia"},
"Barcelona":{of:"Futbol Club Barcelona",cur:"Barcelona",int:"FC Barcelona",pais:"Espanha",liga:"La Liga",rep:3,orc:400000000,
 logo:"https://thumb.wikimedia.org/wikipedia/en/thumb/4/47/FC_Barcelona_%28crest%29.svg/330px-FC_Barcelona_%28crest%29.svg.png",est:["Spotify Camp Nou",99354],fonte:"en.wikipedia"},
"Atlético de Madrid":{of:"Club Atlético de Madrid",cur:"Atlético",int:"Atlético de Madrid",pais:"Espanha",liga:"La Liga",rep:3,orc:180000000,
 logo:null,est:["Riyadh Air Metropolitano",68456],fonte:"en.wikipedia"},
"Liverpool":{of:"Liverpool Football Club",cur:"Liverpool",int:"Liverpool",pais:"Inglaterra",liga:"Premier League",rep:3,orc:380000000,
 logo:"https://thumb.wikimedia.org/wikipedia/en/thumb/0/0c/Liverpool_FC.svg/330px-Liverpool_FC.svg.png",est:["Anfield",61276],fonte:"en.wikipedia"},
"Manchester City":{of:"Manchester City Football Club",cur:"Man City",int:"Manchester City",pais:"Inglaterra",liga:"Premier League",rep:3,orc:450000000,
 logo:"https://thumb.wikimedia.org/wikipedia/en/thumb/e/eb/Manchester_City_FC_badge.svg/330px-Manchester_City_FC_badge.svg.png",est:["Etihad Stadium",53400],fonte:"en.wikipedia"},
"Manchester United":{of:"Manchester United Football Club",cur:"Man United",int:"Manchester United",pais:"Inglaterra",liga:"Premier League",rep:3,orc:400000000,
 logo:null,est:["Old Trafford",74310],fonte:"en.wikipedia"},
"Paris Saint-Germain":{of:"Paris Saint-Germain Football Club",cur:"PSG",int:"Paris Saint-Germain",pais:"França",liga:"Ligue 1",rep:3,orc:430000000,
 logo:"https://thumb.wikimedia.org/wikipedia/en/thumb/a/a7/Paris_Saint-Germain_F.C..svg/330px-Paris_Saint-Germain_F.C..svg.png",est:["Parc des Princes",47929],fonte:"en.wikipedia"},
"Inter":{of:"Football Club Internazionale Milano",cur:"Inter",int:"Inter Milan",pais:"Itália",liga:"Serie A",rep:3,orc:220000000,
 logo:"https://thumb.wikimedia.org/wikipedia/commons/thumb/0/05/FC_Internazionale_Milano_2021.svg/330px-FC_Internazionale_Milano_2021.svg.png",est:["San Siro",75817],fonte:"en.wikipedia"},
"Milan":{of:"Associazione Calcio Milan",cur:"Milan",int:"AC Milan",pais:"Itália",liga:"Serie A",rep:3,orc:200000000,
 logo:"https://thumb.wikimedia.org/wikipedia/commons/thumb/d/d0/Logo_of_AC_Milan.svg/330px-Logo_of_AC_Milan.svg.png",est:["San Siro",75817],fonte:"en.wikipedia"},
"Juventus":{of:"Juventus Football Club",cur:"Juventus",int:"Juventus",pais:"Itália",liga:"Serie A",rep:3,orc:210000000,
 logo:"https://thumb.wikimedia.org/wikipedia/commons/thumb/e/ed/Juventus_FC_-_logo_black_%28Italy%2C_2020%29.svg/330px-Juventus_FC_-_logo_black_%28Italy%2C_2020%29.svg.png",est:["Allianz Stadium",41507],fonte:"en.wikipedia"},
"Napoli":{of:"Società Sportiva Calcio Napoli",cur:"Napoli",int:"Napoli",pais:"Itália",liga:"Serie A",rep:2,orc:130000000,
 logo:null,est:["Diego Armando Maradona",54726],fonte:"en.wikipedia"},
"Bayern de Munique":{of:"Fußball-Club Bayern München e. V.",cur:"Bayern",int:"Bayern München",pais:"Alemanha",liga:"Bundesliga",rep:3,orc:390000000,
 logo:"https://thumb.wikimedia.org/wikipedia/commons/thumb/8/8d/FC_Bayern_M%C3%BCnchen_logo_%282024%29.svg/330px-FC_Bayern_M%C3%BCnchen_logo_%282024%29.svg.png",est:["Allianz Arena",75024],fonte:"en.wikipedia"},
"Borussia Dortmund":{of:"Ballspielverein Borussia 09 e. V. Dortmund",cur:"Dortmund",int:"Borussia Dortmund",pais:"Alemanha",liga:"Bundesliga",rep:3,orc:190000000,
 logo:null,est:["Signal Iduna Park",81365],fonte:"en.wikipedia"},
"Benfica":{of:"Sport Lisboa e Benfica",cur:"Benfica",int:"Benfica",pais:"Portugal",liga:"Primeira Liga",rep:2,orc:90000000,
 logo:null,est:["Estádio da Luz",64642],fonte:"en.wikipedia"},
"Porto":{of:"Futebol Clube do Porto",cur:"Porto",int:"FC Porto",pais:"Portugal",liga:"Primeira Liga",rep:2,orc:85000000,
 logo:null,est:["Estádio do Dragão",50033],fonte:"en.wikipedia"},
"Sporting CP":{of:"Sporting Clube de Portugal",cur:"Sporting",int:"Sporting CP",pais:"Portugal",liga:"Primeira Liga",rep:2,orc:88000000,
 logo:null,est:["Estádio José Alvalade",50095],fonte:"en.wikipedia"},
"Ajax":{of:"Amsterdamsche Football Club Ajax",cur:"Ajax",int:"Ajax",pais:"Holanda",liga:"Eredivisie",rep:2,orc:75000000,
 logo:null,est:["Johan Cruijff ArenA",55865],fonte:"en.wikipedia"},
"West Ham":{of:"West Ham United Football Club",cur:"West Ham",int:"West Ham United",pais:"Inglaterra",liga:"Premier League",rep:2,orc:150000000,
 logo:null,est:["London Stadium",62500],fonte:"premierleague"},
"Everton":{of:"Everton Football Club",cur:"Everton",int:"Everton",pais:"Inglaterra",liga:"Premier League",rep:2,orc:120000000,
 logo:null,est:["Hill Dickinson Stadium",52769],fonte:"premierleague"}
};
function fmtKit(k){return (k[0]||"#666")+"|"+(k[1]||"#ffffff")+"|"+(k[2]||"listras")}
function kitArr(c,n){const d=CLUBE_DB[c&&c.nome];const a=d&&d.kits?d.kits[n-1]:null;return a||null}
function dbClube(c){return c?(CLUBE_DB[c.nome]||null):null}
// Escreve o schema completo no objeto do clube, sem tocar em id/nome/sig/cor/forca/elenco.
function dbAplicaClube(c){
  if(!c)return false;const d=CLUBE_DB[c.nome];
  const km=KITS_REAL[c.nome];
  if(d){
    c.nomeOficial=d.of;c.nomeCurto=d.cur;c.nomeInternacional=d.int;
    c.pais=juntaPais(c.pais,d.pais);c.liga=c.liga||d.liga;
    c.logo=d.logo||null;
    if(d.est){c.estadio={nome:d.est[0],capacidade:d.est[1],real:true};
      c.est=c.est||{};if(!c.est.nome||c.est.nome.indexOf("Estádio ")!==0)c.est.nome=d.est[0];
      if(!c.est.base||c.est.base===0)c.est.base=d.est[1];}
    c.reputacao=d.rep||reputacaoDe(c.nome);
    c.orcamento=d.orc||Math.round((c.forca||50)*2200000);
    c.dbFonte=d.fonte||null;
  }else{
    c.nomeOficial=c.nomeOficial||c.nome;c.nomeCurto=c.nomeCurto||c.nome;
    c.nomeInternacional=c.nomeInternacional||c.nome;c.logo=c.logo||null;
    c.reputacao=c.reputacao||reputacaoDe(c.nome);
    c.orcamento=c.orcamento||Math.round((c.forca||50)*1600000);
    // sem entrada verificada: mantém o estádio que o jogo já tinha (real quando existe em ESTREAL)
    if(!c.estadio){var a=arenaDe(c);c.estadio={nome:(c.est&&c.est.nome)||a.nome,capacidade:Math.round((c.est&&c.est.base)||a.cap),real:!!a.real}}
  }
  if(km){c.uniformeCasa=fmtKit(km[0]);c.uniformeFora=fmtKit(km[1]);c.uniformeTerceiro=fmtKit(km[2]||km[1])}
  else{c.uniformeCasa=fmtKit([c.cor,c.cor2,"listras"]);c.uniformeFora=fmtKit([c.cor2||"#ffffff",c.cor,"solida"]);c.uniformeTerceiro=fmtKit([c.cor,c.cor2,"faixa"])}
  return !!d;
}
function juntaPais(a,b){return a||b||""}
function reputacaoDe(nome){
  try{if(typeof FAMA_MUNDIAL!=="undefined"&&FAMA_MUNDIAL.indexOf(nome)>=0)return 3;
      if(typeof FAMA_CONTINENTAL!=="undefined"&&FAMA_CONTINENTAL.indexOf(nome)>=0)return 2;}catch(e){}
  return 1;
}
function dbAplicaTodos(){let n=0;(S&&S.clubes||[]).forEach(function(c){try{if(dbAplicaClube(c))n++}catch(e){}});return n}
function dbMigraSave(){ // saves antigos: preenche os campos novos sem alterar nada existente
  if(!S||!S.clubes)return 0;let n=0;
  S.clubes.forEach(function(c){
    if(c.uniformeCasa==null||c.nomeOficial==null){try{dbAplicaClube(c);n++}catch(e){}}
  });
  if(typeof KITS_REAL!=="undefined")S.clubes.forEach(function(c){if(KITS_REAL[c.nome]&&c.kit==null)c.kit=1});
  return n;
}

// ===== SALVAMENTO EM 3 SLOTS =====
const SLOT_KEYS=["manager_slot1","manager_slot2","manager_slot3"];
const SAVE_VER=2;   // FASE 0: schema versionado (1 = saves antigos sem _v · 2 = com _v + migração)
// v55: o jogo se chama "Manager". Os saves da época "Mister Treinador" são COPIADOS para as chaves novas na 1ª abertura (os antigos ficam intactos).
try{["slot1","slot2","slot3"].forEach((k,i)=>{const velho=localStorage.getItem("mistertreinador_"+k);if(velho&&!localStorage.getItem(SLOT_KEYS[i]))localStorage.setItem(SLOT_KEYS[i],velho)})}catch(e){}
let SLOT_ATUAL=null;                                     // 0,1,2 ou null (jogo ainda não salvo em nenhum slot)
function lerSlot(i){try{const r=localStorage.getItem(SLOT_KEYS[i]);return r?JSON.parse(r):null}catch(e){return null}}
function infoSlot(i){
  const d=lerSlot(i);if(!d)return null;
  const eu=d.clubes&&d.clubes[d.meu];
  return{tecnico:d.treinador||"—",clube:eu?eu.nome:"—",pais:d.pais||"",temp:d.temp||1,dia:d.dia||0,total:d.agenda?d.agenda.length:0,quando:d._salvoEm||""};
}
function serializaJogo(){ // cópia segura do estado atual (universo real, sem partida em andamento)
  const c=Object.assign({},S);
  c._v=SAVE_VER;                       // FASE 0: a versão do schema vai DENTRO do arquivo
  delete c._soTick;delete c.resultados;delete c._clPre;delete c._lbPre;delete c._cnPre;delete c._mem;delete c._prog;delete c._resBusca;
  if(c.copasMundo){const nc={};Object.keys(c.copasMundo).forEach(k=>{const x=c.copasMundo[k];nc[k]={temp:x.temp,vivos:x.vivos,fase:x.fase,total:x.total,campeao:x.campeao,hist:(x.hist||[])}});c.copasMundo=nc}
  if(c.ligas){c.ligas=ligasParaSave(c.ligas)}
  if(c.ext){const so={};Object.keys(c.ext).forEach(k=>{const x=c.ext[k];if(x&&(x.mexido||x.gen))so[k]=x});c.ext=so}
  // sincroniza o estado compacto de todos os clubes montados nesta sessão (força, idade, artilharia)
  if(S._mem&&S.mundo)Object.keys(S._mem).forEach(k=>{const x=S._mem[k];if(x&&x.compacto&&S.mundo[k])S.mundo[k].c=compactaElencoComGen(x.elenco,S.mundo[k].c)});
  let ids=null;
  if(c._clbak){c.clubes=c._clbak.clubes;c.meu=c._clbak.meu;c.fixt=c._clbak.fixt;c.rodada=c._clbak.rodada;ids=c._clbak.ids}
  delete c._clbak;delete c.clAoVivo;
  if(c.live){c.live=null;if(c.aba==='live')c.aba='home'}
  if(c.aba==='pos')c.aba='home';
  const mapaId=ids?new Map(c.clubes.map((cl,i)=>[cl,ids[i]])):null;
  return JSON.stringify(c,function(k,v){
    if(k==="_clube")return undefined;
    if(k==="id"&&mapaId&&mapaId.has(this))return mapaId.get(this);
    return v;
  });
}
function gravaSlot(i,silencioso){
  if(!S)return false;
  try{
    S._salvoEm=new Date().toLocaleString("pt-BR",{day:"2-digit",month:"2-digit",hour:"2-digit",minute:"2-digit"});
    const txt=serializaJogo();
    S._tamSave=Math.round(txt.length/1024);                           // KB, para a tela de saves
    localStorage.setItem(SLOT_KEYS[i],txt);
    SLOT_ATUAL=i;S._slot=i;S._falhaSave=0;
    if(!silencioso)toast("💾 Jogo salvo no slot "+(i+1)+" ("+S._tamSave+" KB)");
    return true;
  }catch(e){
    // NUNCA silencioso quando falha: o jogador precisa saber que o progresso não foi gravado
    S._falhaSave=(S._falhaSave||0)+1;
    if(!silencioso||S._falhaSave===1||S._falhaSave%10===0){
      aviso("⚠️ NÃO foi possível salvar (armazenamento do navegador cheio ou bloqueado).\nSeu progresso desde o último salvamento NÃO está gravado.\nApague um save que você não usa (tela inicial) e toque em 💾 de novo.");
    }
    return false;
  }
}
function save(){ // autosave: grava no slot atual (se houver)
  if(!S)return;
  if(SLOT_ATUAL!=null)gravaSlot(SLOT_ATUAL,true);
}
function load(){} // mantido por compatibilidade: a tela inicial carrega por slot
function carregaSlot(i){
  const d=lerSlot(i);if(!d)return aviso("Este slot está vazio.");
  S=d;SLOT_ATUAL=i;S._slot=i;S._mem={};
  if(!S.pais||S.div==null){S=null;SLOT_ATUAL=null;return aviso("Este save é de uma versão antiga e não pode ser carregado.")}
  const _vAntes=(S._v==null?1:S._v);                 // FASE 0: lê a versão ANTES de migrar
  try{ligasDoSave(S.ligas)}catch(e){}
  migraJogo();garante();try{migraSaveVersao(_vAntes)}catch(e){console.warn("migração de save falhou",e)}
  S.live=null;S.extras=0;
  ['cl','lb','cn','el','sa'].forEach(k=>{if(S[k])S[k].jogouHoje=false});
  delete S._clbak;delete S.clAoVivo;if(S.aba==='live'||S.aba==='pos')S.aba='home';
  telaTitulo=false;try{dbMigraSave()}catch(e){};render();toast("Jogo carregado");
  if(!S.mundoCongelado)setTimeout(()=>{try{congelaMundoEmLotes()}catch(e){}},2000);
}
function apagaSlot(i){confirma("Apagar o jogo do slot "+(i+1)+"? Isso não pode ser desfeito.",()=>{localStorage.removeItem(SLOT_KEYS[i]);if(SLOT_ATUAL===i)SLOT_ATUAL=null;render()})}
function salvarAgora(){ // botão do disquete
  if(!S)return;
  if(S.live)return aviso("Termine ou pause a partida antes de salvar. (O jogo é salvo automaticamente ao fim de cada partida.)");
  if(SLOT_ATUAL!=null){gravaSlot(SLOT_ATUAL);return}
  escolheSlotParaSalvar();
}
function escolheSlotParaSalvar(){
  let h=`<h3>💾 Salvar jogo</h3><div class="mu" style="font-size:12px;margin:4px 0 10px">Escolha o slot. Slots ocupados serão sobrescritos.</div>`;
  for(let i=0;i<3;i++){
    const inf=infoSlot(i);
    h+=`<div class="clube" onclick="fechaDlg();gravaSlot(${i});render()"><span><b>Slot ${i+1}</b><br><small class="mu">${inf?`${inf.tecnico} · ${inf.clube} · Temp. ${inf.temp}`:'vazio'}</small></span><span class="tag">${inf?inf.quando:'novo'}</span></div>`;
  }
  h+=`<button class="s big" onclick="fechaDlg()">Cancelar</button>`;
  modal(h);
}



function crestSVG(c,sz){ // escudo procedural (fallback quando não há imagem real)
  sz=sz||18;const a=(c&&c.cor)||"#666",b=(c&&c.cor2)||"#fff";
  return `<svg width="${sz}" height="${sz}" viewBox="0 0 24 24" style="vertical-align:middle"><path d="M3 2h18v10c0 5-4 8-9 10C7 20 3 17 3 12z" fill="${a}" stroke="#fff" stroke-width="1.2"/><path d="M3 2h9v20C7 20 3 17 3 12z" fill="${b}" opacity=".85"/><circle cx="12" cy="10" r="3" fill="#fff" opacity=".9"/></svg>`;
}
function escudo(c,sz){sz=sz||18;
  if(!c)return crestSVG(c,sz);
  const url=c.logo||c.esc||c.escudo;           // logo real (base de dados) · URL manual · upload em base64
  if(!url)return crestSVG(c,sz);
  return `<span style="position:relative;display:inline-block;width:${sz}px;height:${sz}px;vertical-align:middle;line-height:0">`
    +`<span style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center">${crestSVG(c,Math.round(sz*.94))}</span>`
    +`<img src="${url}" alt="" loading="lazy" style="position:absolute;inset:0;width:100%;height:100%;object-fit:contain;object-position:center" onerror="this.remove()"></span>`;
}
function setEscudo(i,inp){const f=inp.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{const cv=document.createElement("canvas");cv.width=cv.height=96;const x=cv.getContext("2d");const k=Math.min(96/im.width,96/im.height);x.drawImage(im,(96-im.width*k)/2,(96-im.height*k)/2,im.width*k,im.height*k);S.clubes[i].escudo=cv.toDataURL("image/png");save();render()};im.src=r.result};r.readAsDataURL(f)}

function fazSub(){
  const eu=S.clubes[S.meu];
  const a=eu.elenco.find(j=>j.id===document.getElementById("ss").value),b=eu.elenco.find(j=>j.id===document.getElementById("se").value);
  if(!a||!b)return;
  if(!aptoParaJogar(b))return aviso(b.nome+" não pode jogar: "+motivoInapto(b)+".");
  a.tit=false;b.tit=true;S.subs++;
  const jg=S.live.jogos.find(x=>x.a===S.meu||x.b===S.meu);
  jg.ev.push({m:S.live.min,t:"s",lado:jg.a===S.meu?"a":"b",n:b.nome+" ↔ "+a.nome});
  jg.subs.push({m:S.live.min,lado:jg.a===S.meu?"a":"b",entra:b.id,sai:a.id,en:b.nome,sn:a.nome,ep:b.pos});
  document.getElementById("modalsub").remove();render();
}


// ===== DIÁLOGOS (substituem alert/confirm/prompt) =====
function modal(html){
  let m=document.getElementById("dlg");if(m)m.remove();
  m=document.createElement("div");m.id="dlg";
  m.style.cssText="position:fixed;inset:0;background:#000b;z-index:999;overflow:auto;padding:16px;display:flex;align-items:flex-start;justify-content:center";
  m.innerHTML=`<div class="card" style="width:100%;max-width:420px;margin-top:40px">${html}</div>`;
  document.body.appendChild(m);return m;
}
function fechaDlg(){const m=document.getElementById("dlg");if(m)m.remove()}
function aviso(txt,cb){window._cb=()=>{fechaDlg();cb&&cb()};modal(`<div style="white-space:pre-line;margin-bottom:12px">${txt}</div><button class="big" onclick="window._cb()">OK</button>`)}
function confirma(txt,cb){window._ok=()=>{fechaDlg();cb()};modal(`<div style="white-space:pre-line;margin-bottom:12px">${txt}</div><div class="row"><button class="s" onclick="fechaDlg()">Cancelar</button><button onclick="window._ok()">Confirmar</button></div>`)}
function pergunta(txt,padrao,cb){window._ok=()=>{const v=document.getElementById("dlgin").value;fechaDlg();cb(v)};modal(`<div style="white-space:pre-line;margin-bottom:10px">${txt}</div><input id="dlgin" type="number" inputmode="decimal" value="${padrao}"><div class="row" style="margin-top:12px"><button class="s" onclick="fechaDlg()">Cancelar</button><button onclick="window._ok()">OK</button></div>`)}
// ===== TRANSFERÊNCIAS =====
function garante(){garanteTec&&garanteTec();if(S&&!S.cl&&!S.live){try{clInicia()}catch(e){}}if(S&&!S.lb&&!S.live){try{lbInicia()}catch(e){}}if(S&&!S.cn&&!S.live){try{cnInicia()}catch(e){}}if(S&&!S.el&&!S.live){try{elInicia()}catch(e){}}if(S&&!S.agenda&&!S.live){try{agendaMonta()}catch(e){}}if(S&&!S.sa&&!S.live){try{saInicia()}catch(e){}}if(S&&S.clubes)S.clubes.forEach(c=>{est(c)});if(S&&!S.forma)S.forma=[]; // compatibilidade com saves antigos
  if(!S.props)S.props=[];
  S.clubes.forEach(c=>c.elenco.forEach(j=>{if(j.ct==null)j.ct=rnd(1,4);if(j.hum==null)j.hum=rnd(30,70);if(j.en==null)j.en=100}));

}
function geraPropostas(){
  garante();
  const eu=S.clubes[S.meu];
  S.props=S.props.filter(p=>eu.elenco.find(j=>j.id===p.jid)).slice(-5);
  if(R()<.45&&eu.elenco.length>17){
    const j=pick([...eu.elenco].filter(x=>!x.emprestado).sort((a,b)=>b.f-a.f).slice(0,10));if(!j)return;
    if(S.props.find(p=>p.jid===j.id))return;
    const c=pick(S.clubes.filter(c=>c.id!==S.meu));
    S.props.push({jid:j.id,nome:j.nome,clube:c.id,valor:Math.round(j.val*rnd(75,140)/100)});
  }
}
function aceitaProp(i){
  const eu=S.clubes[S.meu],p=S.props[i],j=eu.elenco.find(x=>x.id===p.jid);
  if(!j)return;
  if(eu.elenco.length<=16)return aviso("Elenco mínimo: 16 jogadores.");
  const c=S.clubes[p.clube];
  const resc=rescisaoDe(j,p.valor);eu.caixa+=p.valor-resc;finRec('Venda de jogadores',p.valor);finDesp('Rescisões',resc);eu.elenco=eu.elenco.filter(x=>x.id!==j.id);j.tit=false;j.gols=0;c.elenco.push(j);
  S.props.splice(i,1);auto(eu);save();render();
}
function recusaProp(i){S.props.splice(i,1);save();render()}
function contraProp(i){
  const p=S.props[i],eu=S.clubes[S.meu],j=eu.elenco.find(x=>x.id===p.jid);if(!j)return;
  pergunta(`Contraproposta por ${j.nome} (em mil R$).\nOferta atual: ${Math.round(p.valor/1000)} mil · Mercado: ${Math.round(j.val/1000)} mil`,Math.round(p.valor*1.15/1000),v=>{
    const alvo=parseFloat(v)*1000;if(!alvo)return;
    const lim=j.val*1.25;
    if(alvo<=lim&&R()<Math.max(.1,1-(alvo-p.valor)/(p.valor*.5+1))){p.valor=alvo;save();aviso("O clube aceitou a contraproposta! Confirme a venda.",render)}
    else{S.props.splice(i,1);save();aviso("O clube recusou e retirou a oferta.",render)}
  });
}
function renova(id){
  const eu=S.clubes[S.meu],j=eu.elenco.find(x=>x.id===id);
  if(j&&j.emprestado)return aviso(j.nome+" é emprestado: o contrato é do "+(j.donoNome||"clube dono")+".");
  pergunta(`Renovar ${j.nome}. Quantos anos (1 a 5)?`,2,x=>{
    const a=parseInt(x);if(!a||a<1||a>5)return;
    const aumento=1+(5-Math.min(j.hum,50)/10)*0.04+a*0.02;
    const novo=Math.round(j.sal*aumento*1000);
    if(moralJ(j)<25){return aviso(j.nome+" está descontente (moral "+Math.round(moralJ(j))+") e recusou renovar.")}
    if(R()<(j.hum>25?.85:.5))confirma(`${j.nome} aceita renovar por ${a} ano(s).\nNovo salário: ${R$(novo)}/mês`,()=>{j.ct=a;j.sal=novo/1000;save();render()});
    else aviso(j.nome+" recusou renovar.");
  });
}
function vencerContratos(){ // chamado no fim da temporada
  const eu=S.clubes[S.meu],saiu=[];
  S.clubes.forEach(c=>{c.elenco.forEach(j=>{j.ct=(j.ct||1)-1});
    if(c.id===S.meu){const v=c.elenco.filter(j=>j.ct<=0&&!j.emprestado);v.forEach(j=>saiu.push(j.nome));c.elenco=c.elenco.filter(j=>j.ct>0||j.emprestado);}
    else c.elenco.forEach(j=>{if(j.ct<=0)j.ct=rnd(1,4)});
  });
  while(eu.elenco.length<16){const j=novoJog(pick(POS),eu.forca-8);j.ct=2;eu.elenco.push(j)}
  auto(eu);
  if(saiu.length)setTimeout(()=>aviso("Contratos vencidos (saíram de graça): "+saiu.join(", ")),300);
}

// ===== PÓS-JOGO =====
function media_ref(){try{return forcaMedia(S.clubes[S.meu])}catch(e){return 40}}
function nota(j,g,golsPro,golsContra,gols,cart){
  let n=6+(j.f-(media_ref()))/18+rnd(-6,6)/10;
  n+=gols*1.1;
  if(cart>0)n-=.4;
  if(j.pos==="GOL")n+=(golsContra===0?.9:-golsContra*.4);
  else if(["ZAG","LD","LE"].includes(j.pos))n+=(golsContra===0?.5:-golsContra*.15);
  n+=(g>0?.3:g<0?-.3:0);
  return Math.max(2,Math.min(10,Math.round(n*10)/10));
}
function posJogo(j){
  const A=S.clubes[j.a],B=S.clubes[j.b];
  const res=j.ga>j.gb?1:j.ga<j.gb?-1:0;
  const lado=(C,ids,l,pro,contra,rs)=>{
    const sub=j.subs.filter(x=>x.lado===l);
    const entraram=sub.map(x=>x.entra);
    const lista=[...ids,...entraram].map(id=>{
      const jg=C.elenco.find(x=>x.id===id)||{nome:"?",pos:"?",f:50};
      const gols=j.ev.filter(e=>e.t==="g"&&e.jid===id).length;
      const cs=j.ev.filter(e=>e.t==="c"&&e.jid===id);
      return{id,nome:jg.nome,pos:jg.pos,gols,cart:cs.length,vm:cs.some(c=>c.verm)||cs.length>=2,nota:nota(jg,rs,pro,contra,gols,cs.length),ent:entraram.includes(id)};
    });
    return{lista,sub};
  };
  const stF=Object.assign({},j.st);if(stF.pm!=null){stF.pa=Math.max(0,Math.min(100,Math.round(stF.pm/90*100)))}
  const cab=c=>({nome:c.nome,sig:c.sig,cor:c.cor,cor2:c.cor2,escudo:c.escudo||null});
  return{cabA:cab(A),cabB:cab(B),est:j.est,pub:j.pub,renda:j.renda,clima:j.clima,gramado:j.gramado,a:j.a,b:j.b,ga:j.ga,gb:j.gb,ev:j.ev,st:stF,
    A:lado(A,j.inicio.a,"a",j.ga,j.gb,res),B:lado(B,j.inicio.b,"b",j.gb,j.ga,-res)};
}
function listaLateral(){
  const R=S.resultados;if(!R)return"<div class='lat'><div class='corpo' style='padding:10px;font-size:12px'>Sem resultados de outras ligas.</div></div>";
  const pa=S.filtroPais||R.pais;
  const dados=R.dados[pa]||[];
  const cb=c=>`<span style="display:inline-block;width:10px;height:10px;border-radius:2px;background:${c||'#888'};border:1px solid #0004"></span>`;
  let h=`<div class="lat"><select onchange="S.filtroPais=this.value;render()">${Object.keys(R.dados).map(p=>`<option ${p===pa?'selected':''}>${p}</option>`).join("")}</select><div class="corpo">`;
  dados.forEach((d,i)=>{
    h+=`<div class="dvh">${i+1}ª divisão</div>`;
    d.jogos.forEach(g=>{h+=`<div class="rj ${g.meu?'meu':''}"><div class="t">${cb(g.ca)} ${g.a}</div><div class="p">${g.ga}x${g.gb}</div><div class="t b">${cb(g.cb)} ${g.b}</div></div>`});
  });
  return h+`</div></div>`;
}
function abaPos(){
  const r=S.pos;if(!r)return"<div class='card'>Sem partida recente.</div>";
  const A=r.cabA||S.clubes[r.a],B=r.cabB||S.clubes[r.b];
  const nm=(i)=>{const x=S.clubes.flatMap(c=>c.elenco).find(z=>z.id===i);return x||(S._clbak?S._clbak.clubes.flatMap(c=>c.elenco).find(z=>z.id===i):null)};
  const nn=(e)=>{const x=nm(e.jid);return x?x.nome:e.n};
  const corN=n=>n>=7.5?'o':n>=5.5?'m':'f';
  const abrev={GOL:"G",ZAG:"Z",LD:"L",LE:"L",VOL:"M",MEI:"M",PE:"A",ATA:"A"};
  const col=(C,d,l)=>`<div class="tm"><div class="h">${escudo(C,14)} ${C.nome}</div>
    ${d.lista.map(x=>{const em=r.ev.filter(e=>e.t==="g"&&e.jid===x.id).length;
      return `<div class="r"><span>${abrev[x.pos]||x.pos[0]} - ${x.nome.split(" ").length>1?x.nome.split(" ")[0][0]+". "+x.nome.split(" ").slice(-1)[0]:x.nome}${x.gols?' ⚽'.repeat(Math.min(x.gols,3)):''}${x.vm?' 🟥':x.cart?' 🟨':''}${x.ent?' 🔼':''}</span><span class="nt ${corN(x.nota)}">${x.nota.toFixed(1).replace('.0','').replace('.',',')}</span></div>`}).join("")}
    ${d.sub.length?`<div class="r" style="color:#9fd0b2;font-size:11px"><span>Substituições: ${d.sub.map(x=>x.sn.split(" ").slice(-1)[0]+" → "+x.en.split(" ").slice(-1)[0]+" "+x.m+"'").join(" · ")}</span></div>`:''}</div>`;
  const gols=r.ev.filter(e=>e.t==="g"),cards=r.ev.filter(e=>e.t==="c");
  const st=r.st,pa=Math.round(st.pa);
  const comp=r.tituloCompleto||`${LIGANOME[S.pais][S.div]} · ${r.rodadaTxt||(S.rodada)+"ª rodada"}`;
  return `<div class="pj">${listaLateral()}
   <div class="painelJ">
    <div class="pjh"><div class="tt">${comp}</div>
     <div class="pl3"><div style="text-align:right">${escudo(A,38)}</div><div class="big3">${r.ga} <span style="opacity:.7">x</span> ${r.gb}</div><div style="text-align:left">${escudo(B,38)}</div></div></div>
    <div class="pjc">
     ${col(A,r.A,"a")}
     <div class="cen">
       <div class="box"><div style="font-weight:800;color:#ffd45e">${icoEstadio(14)} ${r.est}</div>${r.clima?`<div>${CLIMAS[r.clima].ic} ${CLIMAS[r.clima].n} · 🌱 ${rotuloGramado(r.gramado)}</div>`:''}<div>👥 ${r.pub.toLocaleString("pt-BR")} pagantes</div><div style="color:#7dff9a">💲 ${R$(r.renda)}</div></div>
       <div class="box"><h5>⚽ GOLS</h5>${gols.length?gols.map(e=>`<div>${e.m}' ${nn(e)} <span class="mu">(${e.lado==='a'?A.sig:B.sig})</span>${e.ass?` <small class="mu">ass. ${nm(e.assId)?nm(e.assId).nome.split(" ").slice(-1)[0]:e.ass.split(" ").slice(-1)[0]}</small>`:(e.pen?' <small class="mu">pênalti</small>':e.falta?' <small class="mu">falta</small>':'')}</div>`).join(""):'<div class="mu">Sem gols</div>'}</div>
       <div class="box"><h5>Cartões</h5>${cards.length?cards.map(e=>`<div>${e.verm?'🟥':'🟨'} ${e.m}' ${nn(e)} <span class="mu">(${e.lado==='a'?A.sig:B.sig})</span></div>`).join(""):'<div class="mu">Sem cartões</div>'}</div>
       <div class="box"><h5 style="text-align:center">Estatísticas</h5>
        <div class="posseB"><div class="pbA" style="width:${pa}%;background:${A.cor==='#ffffff'?'#e9eef0':A.cor}"><b>${pa}%</b></div><div class="pbB" style="width:${100-pa}%;background:${B.cor==='#ffffff'?'#e9eef0':B.cor}"><b>${100-pa}%</b></div></div>
        <div class="posseT">Posse de bola${Math.abs(pa-50)>=8?` · <b>${pa>50?A.sig||A.nome:B.sig||B.nome}</b> dominou`:' · jogo equilibrado'}</div>
        <div class="est2">
        <b>${st.fa}</b><span>Finalizações</span><b>${st.fb}</b>
        <b>${st.ga_}</b><span>No gol</span><b>${st.gb_}</b>
        <b>${st.da}</b><span>Roubadas de bola</span><b>${st.db}</b>
        <b>${st.pea}</b><span>Passes errados</span><b>${st.peb}</b>
       </div></div>
     </div>
     ${col(B,r.B,"b")}
    </div>
    ${(()=>{const av=(S.pos&&S.pos.ganhos)||[];return av.length?`<div class="box" style="margin:8px"><h5>📈 Subiram de força neste jogo</h5>${av.map(t=>`<div style="font-size:12px">${t}</div>`).join("")}</div>`:''})()}
    <button class="big" onclick="S.aba='home';render()">Continuar</button>
   </div></div>`;
}

// ===== ESTÁDIO / BANCO / TÉCNICOS / RANKINGS =====
const ESTREAL={"Flamengo":["Maracanã",78838],"Palmeiras":["Allianz Parque",43713],"Corinthians":["Neo Química Arena",49205],"São Paulo":["Morumbi",66795],"Santos":["Vila Belmiro",16068],"Fluminense":["Maracanã",78838],"Botafogo":["Nilton Santos",44661],"Vasco da Gama":["São Januário",21880],"Grêmio":["Arena do Grêmio",55662],"Internacional":["Beira-Rio",50128],"Atlético Mineiro":["Arena MRV",46000],"Cruzeiro":["Mineirão",61846],"Bahia":["Arena Fonte Nova",50025],"Vitória":["Barradão",34535],"Fortaleza":["Castelão",63903],"Ceará":["Castelão",63903],"Athletico Paranaense":["Ligga Arena",42372],"Coritiba":["Couto Pereira",40502],"Sport Recife":["Ilha do Retiro",26418],"Goiás":["Serrinha",12500],"Avaí":["Ressacada",17826],"Criciúma":["Heriberto Hülse",19300],"Chapecoense":["Arena Condá",22600],"Juventude":["Alfredo Jaconi",19924],"Vila Nova":["OBA",11788],"Novorizontino":["Jorge Ismael de Biasi",16000],"Mirassol":["Maião",15000],"Ponte Preta":["Moisés Lucarelli",19728],"Guarani":["Brinco de Ouro",29130],"Operário-PR":["Germano Krüger",10000],"Paysandu":["Mangueirão",53635],"Remo":["Baenão",15000],"CRB":["Rei Pelé",17126],"Amazonas":["Carlos Zamith",10000],"Botafogo-SP":["Santa Cruz",29292],"Ituano":["Novelli Júnior",18000],"Brusque":["Augusto Bauer",5000],"América-MG":["Independência",23018],"Atlético-GO":["Antônio Accioly",12500],"Cuiabá":["Arena Pantanal",44000],"Ypiranga":["Colosso da Lagoa",8000],"Figueirense":["Orlando Scarpelli",19584],"Londrina":["Estádio do Café",30000],"Volta Redonda":["Raulino de Oliveira",20255],"Náutico":["Aflitos",19800],"Santa Cruz":["Arruda",60044],"Confiança":["Batistão",15575],"Botafogo-PB":["Almeidão",19000],"Ferroviária":["Fonte Luminosa",21000],"Tombense":["Soares de Azevedo",5000],"Athletic-MG":["Joaquim Portugal",5000],"Aparecidense":["Annibal Batista de Toledo",5000],"São Bernardo":["Primeiro de Maio",15000],"Floresta":["Plácido Aderaldo Castelo",63903],"ABC":["Frasqueirão",18000],"Campinense":["Amigão",35000],"Maringá":["Willie Davids",21000],"Caxias":["Centenário",22132],"Anápolis":["Jonas Duarte",15000],"Manaus":["Arena da Amazônia",44000],"Arsenal":["Emirates Stadium",60704],"Aston Villa":["Villa Park",42682],"Bournemouth":["Vitality Stadium",11307],"Brentford":["Gtech Community Stadium",17250],"Brighton":["Amex Stadium",31800],"Chelsea":["Stamford Bridge",40341],"Crystal Palace":["Selhurst Park",25486],"Everton":["Goodison Park",39414],"Fulham":["Craven Cottage",29589],"Liverpool":["Anfield",61276],"Manchester City":["Etihad Stadium",53400],"Manchester United":["Old Trafford",74310],"Newcastle United":["St James' Park",52305],"Nottingham Forest":["City Ground",30445],"Tottenham":["Tottenham Hotspur Stadium",62850],"West Ham":["London Stadium",62500],"Wolverhampton":["Molineux",31750],"Leeds United":["Elland Road",37645],"Burnley":["Turf Moor",21944],"Sunderland":["Stadium of Light",49000],"Leicester City":["King Power Stadium",32312],"Southampton":["St Mary's",32384],"Ipswich Town":["Portman Road",29813],"Norwich City":["Carrow Road",27244],"West Bromwich":["The Hawthorns",26850],"Middlesbrough":["Riverside Stadium",34000],"Sheffield United":["Bramall Lane",32050],"Watford":["Vicarage Road",22200],"Coventry City":["Coventry Building Society Arena",32609],"Hull City":["MKM Stadium",25586],"Stoke City":["bet365 Stadium",30089],"Swansea City":["Swansea.com Stadium",21088],"Bristol City":["Ashton Gate",27000],"Cardiff City":["Cardiff City Stadium",33280],"Blackburn Rovers":["Ewood Park",31367],"Preston North End":["Deepdale",23404],"Millwall":["The Den",20146],"Queens Park Rangers":["Loftus Road",18439],"Sheffield Wednesday":["Hillsborough",39732],"Derby County":["Pride Park",33597],"Birmingham City":["St Andrew's",29409],"Wrexham":["Racecourse Ground",13341],"Charlton Athletic":["The Valley",27111],"Wigan Athletic":["DW Stadium",25138],"Huddersfield Town":["John Smith's Stadium",24121],"Bolton Wanderers":["Toughsheet Stadium",28723],"Reading":["Select Car Leasing Stadium",24161],"Portsmouth":["Fratton Park",20899],"Real Madrid":["Santiago Bernabéu",83186],"Barcelona":["Spotify Camp Nou",99354],"Atlético de Madrid":["Metropolitano",70460],"Sevilla":["Ramón Sánchez-Pizjuán",43883],"Real Betis":["Benito Villamarín",60721],"Real Sociedad":["Reale Arena",39500],"Villarreal":["La Cerámica",23500],"Athletic Bilbao":["San Mamés",53289],"Valencia":["Mestalla",49430],"Girona":["Montilivi",14624],"Osasuna":["El Sadar",23576],"Celta de Vigo":["Balaídos",24791],"Getafe":["Coliseum",16500],"Rayo Vallecano":["Vallecas",14708],"Mallorca":["Son Moix",23142],"Alavés":["Mendizorroza",19840],"Las Palmas":["Gran Canaria",32392],"Espanyol":["RCDE Stadium",40000],"Levante":["Ciutat de València",26354],"Elche":["Martínez Valero",33732],"Inter":["San Siro",75923],"Milan":["San Siro",75923],"Juventus":["Allianz Stadium",41507],"Napoli":["Diego Armando Maradona",54726],"Roma":["Olimpico",70634],"Lazio":["Olimpico",70634],"Atalanta":["Gewiss Stadium",24950],"Fiorentina":["Artemio Franchi",43147],"Bologna":["Renato Dall'Ara",36462],"Torino":["Olimpico Grande Torino",27958],"Genoa":["Luigi Ferraris",36599],"Udinese":["Bluenergy Stadium",25144],"Cagliari":["Unipol Domus",16416],"Verona":["Bentegodi",39211],"Parma":["Ennio Tardini",27906],"Lecce":["Via del Mare",31533],"Como":["Giuseppe Sinigaglia",13602],"Sassuolo":["Mapei Stadium",21584],"Pisa":["Arena Garibaldi",10000],"Cremonese":["Zini",16003],"Bayern de Munique":["Allianz Arena",75024],"Borussia Dortmund":["Signal Iduna Park",81365],"RB Leipzig":["Red Bull Arena",47069],"Bayer Leverkusen":["BayArena",30210],"Eintracht Frankfurt":["Deutsche Bank Park",58000],"Stuttgart":["MHPArena",60449],"Wolfsburg":["Volkswagen Arena",30000],"Borussia Mönchengladbach":["Borussia-Park",54057],"Werder Bremen":["Weserstadion",42100],"Freiburg":["Europa-Park Stadion",34700],"Hoffenheim":["PreZero Arena",30150],"Mainz 05":["Mewa Arena",33305],"Union Berlin":["An der Alten Försterei",22012],"Augsburg":["WWK Arena",30660],"Heidenheim":["Voith-Arena",15000],"St. Pauli":["Millerntor",29546],"Köln":["RheinEnergieStadion",50000],"Hamburgo":["Volksparkstadion",57000],"Schalke 04":["Veltins-Arena",62271],"Hertha Berlin":["Olympiastadion",74475],"Paris Saint-Germain":["Parc des Princes",47929],"Olympique de Marseille":["Vélodrome",67394],"Olympique Lyonnais":["Groupama Stadium",59186],"Monaco":["Louis II",18523],"Lille":["Pierre-Mauroy",50157],"Nice":["Allianz Riviera",35624],"Lens":["Bollaert-Delelis",38223],"Rennes":["Roazhon Park",29778],"Strasbourg":["La Meinau",26109],"Nantes":["La Beaujoire",35322],"Toulouse":["Stadium de Toulouse",33150],"Montpellier":["La Mosson",32900],"Reims":["Auguste-Delaune",21684],"Brest":["Francis-Le Blé",15931],"Auxerre":["Abbé-Deschamps",18541],"Angers":["Raymond-Kopa",17048],"Le Havre":["Océane",25178],"Metz":["Saint-Symphorien",30000],"Lorient":["Moustoir",18110],"Saint-Étienne":["Geoffroy-Guichard",41965],"Benfica":["Estádio da Luz",64642],"Porto":["Estádio do Dragão",50033],"Sporting CP":["José Alvalade",50095],"Braga":["Pedreira",30286],"Vitória de Guimarães":["D. Afonso Henriques",30008],"Famalicão":["Municipal 22 de Junho",5307],"Boavista":["Bessa",28263],"Marítimo":["Barreiros",10932],"Ajax":["Johan Cruyff Arena",54990],"PSV Eindhoven":["Philips Stadion",35000],"Feyenoord":["De Kuip",51117],"AZ Alkmaar":["AFAS Stadion",19478],"FC Twente":["De Grolsch Veste",30205],"FC Utrecht":["Galgenwaard",23750],"Sparta Roterdã":["Het Kasteel",11026],"Heerenveen":["Abe Lenstra",27224],"Boca Juniors":["La Bombonera",54000],"River Plate":["Monumental",84567],"Racing Club":["Presidente Perón",51389],"Independiente":["Libertadores de América",52364],"San Lorenzo":["Nuevo Gasómetro",47964],"Estudiantes":["Jorge Luis Hirschi",30000],"Vélez Sarsfield":["José Amalfitani",49540],"Lanús":["Ciudad de Lanús",47027],"Talleres":["Mario Alberto Kempes",57000],"Argentinos Juniors":["Diego Armando Maradona",26000],"Newell's Old Boys":["Marcelo Bielsa",42000],"Rosario Central":["Gigante de Arroyito",41654],"América":["Estadio Azteca",87523],"Guadalajara":["Akron",48071],"Cruz Azul":["Ciudad de los Deportes",33000],"Pumas UNAM":["Olímpico Universitario",48297],"Tigres UANL":["Universitario",41886],"Monterrey":["BBVA",51000],"Toluca":["Nemesio Díez",30000],"Santos Laguna":["Corona",30000],"Inter Miami":["Chase Stadium",21000],"LA Galaxy":["Dignity Health Sports Park",27000],"LAFC":["BMO Stadium",22000],"Seattle Sounders":["Lumen Field",37722],"Atlanta United":["Mercedes-Benz Stadium",42500],"New York City FC":["Yankee Stadium",28000],"Vissel Kobe":["Noevir Stadium",30132],"Yokohama F. Marinos":["Nissan Stadium",72327],"Kawasaki Frontale":["Todoroki",26827],"Urawa Red Diamonds":["Saitama Stadium 2002",63700],"Kashima Antlers":["Kashima Soccer Stadium",40728],"Gamba Osaka":["Panasonic Stadium Suita",39694],"Galatasaray":["RAMS Park",52223],"Fenerbahçe":["Şükrü Saracoğlu",47834],"Beşiktaş":["Tüpraş Stadyumu",42590],"Trabzonspor":["Papara Park",40782],"Club Brugge":["Jan Breydel",29062],"Anderlecht":["Lotto Park",21500],"Union Saint-Gilloise":["Joseph Marien",9400],"Genk":["Cegeka Arena",23718],"Celtic":["Celtic Park",60411],"Rangers":["Ibrox",50817],"Hearts":["Tynecastle",19852],"Hibernian":["Easter Road",20421],"Aberdeen":["Pittodrie",20866],"Zenit":["Gazprom Arena",67800],"Spartak Moscou":["Otkritie Arena",45360],"CSKA Moscou":["VEB Arena",30457],"Lokomotiv Moscou":["RZD Arena",27320],"Dínamo Moscou":["VTB Arena",26319],"Atlético Nacional":["Atanasio Girardot",45000],"Millonarios":["El Campín",36343],"Junior":["Metropolitano Roberto Meléndez",46692],"América de Cali":["Pascual Guerrero",35405],"Deportivo Cali":["Deportivo Cali",52000],"Peñarol":["Campeón del Siglo",40000],"Nacional":["Gran Parque Central",27000],"Colo-Colo":["Monumental David Arellano",47347],"Universidad de Chile":["Nacional",48665],"Universidad Católica":["San Carlos de Apoquindo",14118],"Al-Hilal":["Kingdom Arena",60000],"Al-Nassr":["Al-Awwal Park",25000],"Al-Ittihad":["Al-Inma",62345],"Al-Ahli":["Al-Inma",62345]};

function arenaDe(c){ // nome e capacidade reais quando houver
  const r=ESTREAL[c.nome]||EST_EXTRA[c.nome];
  if(r)return{nome:r[0],cap:r[1],real:true};
  const n=c.nome.replace(/^(Club|FC|SC|AC|CD|CA)\s+/,"");
  return{nome:"Estádio "+n.split(" ")[0],cap:Math.round(6000+c.forca*220),real:false};
}
const NIVEIS_EST=[
 {n:"Estádio simples",cap:8000,custo:0},{n:"Arquibancadas modernizadas",cap:16000,custo:3000000},
 {n:"Estádio com cobertura",cap:26000,custo:7000000},{n:"Arena moderna",cap:38000,custo:15000000},
 {n:"Super arena",cap:52000,custo:30000000},{n:"Estádio de elite",cap:70000,custo:60000000}];
function est(c){if(!c.est){const a=arenaDe(c);c.est={nivel:0,preco:Math.round(20+Math.max(0,Math.min(60,c.forca-20))*0.9),conforto:0,base:a.cap,nome:a.nome}}if(!c.est.base){const a=arenaDe(c);c.est.base=a.cap;c.est.nome=a.nome}return c.est}
function capEst(c){const e=est(c);return Math.round(e.base*(1+e.nivel*0.18))}
function pubJogo(c,adversario){ // público de um jogo em casa
  const e=est(c),cap=capEst(c);
  const t=tabela(),pos=t.findIndex(x=>x.id===c.id)+1;
  const torc=(c.id===S.meu?(S.tor==null?70:S.tor):60)/100;
  const ff=fatorFamaPublico(c.nome);
  const n=S.clubes.length||20;
  const momento=pos<=3?.14:pos<=6?.08:pos<=n*.5?0:pos<=n*.75?-.08:-.16;      // time bem enche, time mal esvazia
  const base=(0.40+0.45*torc+momento)*ff;
  const grande=(adversario&&(nivelFama(adversario.nome)>=1||adversario.forca>72))?.06:0;
  const demanda=cap*Math.max(.12,base+grande)*(1+e.conforto*.04)*(1-(e.preco-40)/220);
  return Math.max(500,Math.min(cap,Math.round(demanda*rnd(92,108)/100)));
}
function abaEst(){
  const eu=S.clubes[S.meu],e=est(eu),nv=NIVEIS_EST[e.nivel],prox=NIVEIS_EST[e.nivel+1];
  const cap=capEst(eu);
  let h=topoAba("🏛",e.nome,nv.n,[[cap.toLocaleString("pt-BR"),"Capacidade"],[e.conforto+"/5","Conforto"],["R$ "+e.preco,"Ingresso"]]);
  h+=`<div class="card">${linhaInfo("Renda estimada (jogo cheio)",R$(cap*e.preco),"g")}${linhaInfo("Público médio esperado",Math.round(pubJogo(eu,null)).toLocaleString("pt-BR"))}${linhaInfo("Fama do clube",iconeFama(eu.nome)+" "+nomeFama(eu.nome))}</div>`;
  h+=`<div class="card"><div class="tag">Preço do ingresso</div><input type="range" min="10" max="150" step="5" value="${e.preco}" oninput="est(S.clubes[S.meu]).preco=+this.value;this.nextElementSibling.textContent='R$ '+this.value" onchange="save();render()" style="width:100%;margin-top:8px"><b style="font-size:18px">R$ ${e.preco}</b>
  <small class="mu" style="display:block">Ingresso caro rende mais por torcedor, mas afasta o público. Time mal na tabela esvazia o estádio.</small></div>`;
  if(S.gramado==null)S.gramado=62;
  h+=`<div class="card"><div class="tag" style="margin-bottom:6px">🌱 Gramado</div>${linhaInfo("Estado do gramado",Math.round(S.gramado)+" · "+rotuloGramado(S.gramado))}<div class="vb"><i style="width:${Math.round(S.gramado)}%;background:${S.gramado>=85?'#3ddc84':S.gramado>=60?'#9be15d':S.gramado>=35?'#f5c542':'#ff5d5d'}"></i><b>${Math.round(S.gramado)}%</b></div>
    <small class="mu" style="display:block;margin:6px 0">Estraga com os jogos em casa (e mais com chuva) e se recupera aos poucos. Gramado ruim aumenta lesões; péssimo também derruba a precisão dos chutes.</small>
    <button class="sm" onclick="gramadoMelhora()">🔧 Reformar o gramado (+12)</button></div>`;
  h+=`<div class="card"><div class="tag" style="margin-bottom:6px">Melhorias</div>`;
  if(prox)h+=`<div class="upL"><div><b>Ampliar: ${prox.n}</b><small>Capacidade ${Math.round(e.base*(1+(e.nivel+1)*0.18)).toLocaleString("pt-BR")}</small></div><button class="sm" onclick="melhoraEst('nivel')">${R$(prox.custo)}</button></div>`;
  else h+=`<div class="mu" style="padding:6px 0">Estádio no nível máximo.</div>`;
  const cc=1500000*(e.conforto+1);
  h+=e.conforto<5?`<div class="upL"><div><b>Conforto e serviços</b><small>Mais público e renda (+4% por nível)</small></div><button class="sm" onclick="melhoraEst('conforto')">${R$(cc)}</button></div>`:'<div class="mu" style="padding:6px 0">Conforto no máximo.</div>';
  return h+`</div>`;
}
function melhoraEst(t){
  const eu=S.clubes[S.meu],e=est(eu);
  const custo=t==='nivel'?NIVEIS_EST[e.nivel+1].custo:1500000*(e.conforto+1);
  if(eu.caixa<custo)return aviso("Caixa insuficiente para a obra.");
  confirma(`Investir ${R$(custo)} nesta melhoria?`,()=>{eu.caixa-=custo;finDesp('Estádio (obras)',custo);if(t==='nivel')e.nivel++;else e.conforto++;save();render()});
}
// Banco
function abaBanco(){
  const eu=S.clubes[S.meu];if(!S.emp)S.emp=[];
  const div=S.emp.reduce((q,x)=>q+x.resta,0);
  const lim=Math.max(5000000,Math.round(eu.forca*300000))-div;
  let h=topoAba("🏦","Banco","Empréstimos e dívidas do clube",[[R$(eu.caixa),"Caixa"],[R$(div),"Dívida"],[R$(Math.max(0,lim)),"Crédito"]]);
  h+=`<div class="card">${linhaInfo("Juros",(taxa()*100).toFixed(1)+"% ao mês")}<div class="tag" style="margin:10px 0 6px">Pedir empréstimo</div><div class="chipL"><button onclick="pedeEmp(1000000)">R$ 1 mi</button><button onclick="pedeEmp(3000000)">R$ 3 mi</button><button onclick="pedeEmp(5000000)">R$ 5 mi</button><button onclick="pedeEmp(10000000)">R$ 10 mi</button></div><small class="mu" style="display:block;margin-top:6px">Pago em parcelas a cada rodada. Confiança baixa da diretoria aumenta os juros.</small></div>`;
  if(S.emp.length){h+=`<div class="card"><div class="tag" style="margin-bottom:6px">Empréstimos ativos</div>`;S.emp.forEach((x,i)=>{h+=`<div class="upL"><div><b>${R$(x.valor)}</b><small>${x.parc} parcelas · falta ${R$(x.resta)} · parcela ${R$(x.pmt)}</small></div><button class="sm s" onclick="quitaEmp(${i})">Quitar</button></div>`});h+=`</div>`}
  return h;
}
function taxa(){const d=S.dir==null?70:S.dir;return d>=60?.012:d>=35?.02:.035}
function pedeEmp(v){
  const eu=S.clubes[S.meu];if(!S.emp)S.emp=[];
  const div=S.emp.reduce((q,x)=>q+x.resta,0),lim=Math.max(5000000,Math.round(eu.forca*300000))-div;
  if(v>lim)return aviso("O banco não libera esse valor. Crédito disponível: "+R$(Math.max(0,lim)));
  const n=Math.max(10,Math.round(S.fixt.length/2)),tx=taxa();
  const total=v*(1+tx*n),pmt=Math.round(total/n);
  confirma(`Receber ${R$(v)}?\nPagar ${n} parcelas de ${R$(pmt)} (total ${R$(Math.round(total))}).`,()=>{eu.caixa+=v;finRec('Empréstimo bancário',v);S.emp.push({valor:v,parc:n,pmt,resta:pmt*n});save();render()});
}
function quitaEmp(i){const eu=S.clubes[S.meu],x=S.emp[i];
  const v=Math.round(x.resta*.92);
  if(eu.caixa<v)return aviso("Caixa insuficiente. Para quitar: "+R$(v));
  confirma(`Quitar por ${R$(v)} (desconto por pagamento antecipado)?`,()=>{eu.caixa-=v;finDesp('Empréstimo bancário (quitação)',v);S.emp.splice(i,1);save();render()})}
function cobraParcelas(){ // chamado a cada rodada
  if(!S.emp||!S.emp.length)return 0;const eu=S.clubes[S.meu];let tot=0;
  S.emp.forEach(x=>{eu.caixa-=x.pmt;tot+=x.pmt;x.resta-=x.pmt;x.parc--});try{finDesp('Parcelas do banco',tot)}catch(e){}
  S.emp=S.emp.filter(x=>x.parc>0);
  if(eu.caixa<0&&S.dir!=null)S.dir=Math.max(5,S.dir-4);
  return tot;
}
// Técnicos
const NOMES_T=["Carlos","Luís","Marcos","Renato","Abel","Tite","Jorge","Fábio","Dorival","Roger","Cuca","Mano","Vanderlei","Sérgio","Paulo","Antônio","Oswaldo","Eduardo","Gilson","Rodrigo"];
const SOB_T=["Almeida","Ferraz","Menezes","Quintela","Sampaio","Bragança","Teles","Carvalho","Brandão","Nogueira","Peixoto","Valente","Zanetti","Moraes","Bittencourt","Neves","Camargo","Linhares","Prado","Siqueira"];
function geraTec(forca){const h=Math.max(30,Math.min(95,forca+rnd(-12,15)));return{id:R().toString(36).slice(2),nome:pick(NOMES_T)+" "+pick(SOB_T),hab:h,tit:rnd(0,12),sal:Math.round(h*h/40*1000),idade:rnd(35,68)}}
function garanteTec(){
  if(!S||!S.clubes)return;
  S.clubes.forEach(c=>{if(!c.tec)c.tec=geraTec(c.forca)});
  S.clubes.forEach(c=>{if(c.tec&&c.tec.meu&&c.id!==S.meu)c.tec=geraTec(c.forca)});
  if(!S.tecLivres||!S.tecLivres.length){S.tecLivres=[];for(let i=0;i<8;i++)S.tecLivres.push(geraTec(rnd(50,85)))}
  const eu=S.clubes[S.meu];
  if(!eu.tec||!eu.tec.meu){const hab=eu.tec&&eu.tec.hab?Math.min(eu.tec.hab,60):50;eu.tec={id:"eu",nome:S.treinador,hab:hab,tit:0,sal:0,idade:40,meu:true}}
}
function abaTec(){
  garanteTec();const eu=S.clubes[S.meu];
  let h=topoAba("👔",eu.tec.nome,"Seu perfil de treinador",[[Math.round(eu.tec.hab),"Habilidade"],[eu.tec.tit,"Títulos"],[S.aux?S.aux.hab:"—","Auxiliar"]]);
  h+=`<div class="card"><div class="tag" style="margin-bottom:6px">Assumir outro clube</div><small class="mu">Você pode propor assumir um clube do seu nível ou melhor. Sua reputação decide.</small><div class="tbL">`;
  S.clubes.filter(c=>c.id!==S.meu).sort((a,b)=>b.forca-a.forca).forEach(c=>{h+=`<div class="tbR"><span class="tbN">${escudo(c,16)}<span><b>${c.nome}</b><small>${c.tec.nome} · H ${c.tec.hab}</small></span></span><button class="sm s" onclick="propoeClube(${c.id})">Assumir</button></div>`});
  h+=`</div></div><div class="card"><div class="tag" style="margin-bottom:6px">Técnicos livres</div><small class="mu">Contrate um auxiliar: aumenta a força do time em campo.</small><div class="tbL">`;
  S.tecLivres.forEach((t,i)=>{h+=`<div class="tbR"><span class="tbN"><span><b>${t.nome}</b><small>Habilidade ${t.hab} · ${R$(t.sal)}</small></span></span><button class="sm" onclick="contrataAux(${i})">Contratar</button></div>`});
  h+=`</div>${S.aux?`<div class="tag" style="margin-top:8px">Auxiliar atual: ${S.aux.nome} (H ${S.aux.hab})</div>`:''}</div>`;
  return h;
}
function contrataAux(i){const eu=S.clubes[S.meu],t=S.tecLivres[i];
  if(eu.caixa<t.sal*3)return aviso("Caixa insuficiente (3 meses de salário).");
  confirma(`Contratar ${t.nome} (H ${t.hab}) por ${R$(t.sal)}/mês?`,()=>{eu.caixa-=t.sal*3;finDesp('Auxiliar técnico',t.sal*3);if(S.aux)S.tecLivres.push(S.aux);S.aux=t;S.tecLivres.splice(i,1);save();render()})}
function propoeClube(id){
  const c=S.clubes[id],eu=S.clubes[S.meu];
  const rep=reputacao();
  const dif=c.forca-eu.forca;
  const chance=Math.max(.03,Math.min(.9,.5+(rep-c.forca)/60-(dif>0?dif/40:0)));
  confirma(`Pedir para treinar ${c.nome}?\nChance estimada: ${Math.round(chance*100)}%\nVocê deixa o ${eu.nome}.`,()=>{
    if(R()>chance)return aviso(`${c.nome} recusou sua proposta.`);
    const velho=eu,hab=eu.tec.hab,tit=eu.tec.tit;const tecDoAlvo=c.tec?c.tec.nome:"—";velho.tec=geraTec(velho.forca);
    try{regTec("fim",S.treinador,velho.tec.nome,velho.nome,S.pais,"Você pediu para sair");regTec("fim",tecDoAlvo,S.treinador,c.nome,S.pais,"Você assumiu o clube")}catch(e){}
    S.meu=id;S.dir=70;S.tor=70;S.cap=null;S.selId=null;S.emp=[];S.homeAba="jogar";
    S.clubes[id].tec={id:"eu",nome:S.treinador,hab:hab,tit:tit,sal:0,idade:40,meu:true};
    garanteTec();save();aviso(`Você agora é o técnico do ${c.nome}!`,render);
  });
}
function reputacao(){ // 0-100
  const eu=S.clubes[S.meu];const t=tabela(),pos=t.findIndex(c=>c.id===S.meu)+1;
  const bonus=(eu.tec?eu.tec.tit:0)*2+S.hist.filter(h=>h.meu<=3).length*3;
  return Math.max(10,Math.min(100,Math.round(eu.forca*.9+10+(S.clubes.length-pos)*1.2+bonus)));
}
// Rankings
function abaRank(){
  garanteTec();
  const modo=S.rankModo||"clubes";
  let h=topoAba("🏅","Ranking",modo==="clubes"?"Clubes da sua liga":"Técnicos da sua liga",[]);
  h+=`<div class="elOrd"><button class="${modo==='clubes'?'on':''}" onclick="S.rankModo='clubes';render()">Clubes</button><button class="${modo==='tec'?'on':''}" onclick="S.rankModo='tec';render()">Técnicos</button></div>`;
  if(modo==="clubes"){
    const l=[...S.clubes].sort((a,b)=>(b.forca+b.pts*.6+histPts(b)+pontosFama(b.nome)*.1)-(a.forca+a.pts*.6+histPts(a)+pontosFama(a.nome)*.1));
    h+=`<div class="elTab"><div class="elH rk"><span>#</span><span>Clube</span><span>Nível</span><span></span><span>Pts</span></div>`;
    l.forEach((c,i)=>{h+=`<div class="elL rk ${c.id===S.meu?'tit':''}"><span class="rkN">${i+1}</span><span class="elN"><b>${escudo(c,15)} ${c.nome}</b><small>${S.hist.filter(x=>x.campeao===c.nome).length} título(s) da liga</small></span><span>${iconeFama(c.nome)}</span><span class="elF" style="font-size:11px">${nomeFama(c.nome).slice(0,3)}.</span><span class="elNt">${c.pts}</span></div>`});
    h+=`</div>`;
  }else{
    const l=S.clubes.map(c=>{const nm=c.tec.meu?S.treinador:c.tec.nome,T=titulosDoTec(nm);return{n:nm,nome:c.tec.meu?S.treinador+" (você)":c.tec.nome,clube:c,hab:c.tec.hab,tit:T.total,por:T.por,pts:c.pts,eu:c.id===S.meu}});
    l.sort((a,b)=>(b.tit*6+b.hab+b.pts*.5)-(a.tit*6+a.hab+a.pts*.5));
    h+=`<div class="hint" style="margin:6px 0">Toque em um técnico para ver os títulos e as taças.</div><div class="elTab"><div class="elH rk"><span>#</span><span>Técnico</span><span></span><span>H</span><span>Tít.</span></div>`;
    l.forEach((t,i)=>{
      const ks=["cl","lb","mund","el","sa","liga","copa"].filter(k=>t.por[k]);
      const mini=ks.length?`<span style="display:flex;gap:3px;flex-wrap:wrap;margin-top:3px">${ks.map(k=>`<span style="display:inline-flex;align-items:center;gap:1px;font-size:10px">${tacaSVG(k,13)}${t.por[k].length}</span>`).join("")}</span>`:"";
      h+=`<div class="elL rk ${t.eu?'tit':''}" style="cursor:pointer" onclick="abreFichaTecnico('${t.n.replace(/'/g,"\\'")}','${t.clube.nome.replace(/'/g,"\\'")}')"><span class="rkN">${i+1}</span><span class="elN"><b>${t.nome}</b><small>${escudo(t.clube,12)} ${t.clube.nome}</small>${mini}</span><span></span><span class="elF">${Math.round(t.hab)}</span><span class="elNt">${t.tit}</span></div>`;
    });
    h+=`</div>`;
  }
  return h;
}
function histPts(c){return S.hist.filter(x=>x.campeao===c.nome).length*8}
// Painel direito da home (resumo, sem escalação)
function painelDir(){
  const eu=S.clubes[S.meu],t=tabela(),pos=t.findIndex(c=>c.id===S.meu)+1;
  const e=est(eu),div=(S.emp||[]).reduce((q,x)=>q+x.resta,0);
  const prox5=t.slice(0,5);
  return `<div class="card"><h3>Classificação</h3><table style="margin-top:6px">${t.slice(0,6).map((c,i)=>`<tr style="${c.id===S.meu?'background:#245a3f':''}"><td>${i+1}</td><td>${escudo(c,14)} ${c.nome}</td><td><b>${c.pts}</b></td></tr>`).join("")}${pos>6?`<tr style="background:#245a3f"><td>${pos}</td><td>${escudo(eu,14)} ${eu.nome}</td><td><b>${eu.pts}</b></td></tr>`:''}</table></div>
  <div class="card"><div class="ln2 row"><span>${icoEstadio(14)} ${e.nome}</span><b>${capEst(eu).toLocaleString("pt-BR")} lugares</b></div>
  <div class="ln2 row"><span>🏦 Dívida</span><b class="${div>0?'r':'g'}">${R$(div)}</b></div>
  <div class="ln2 row"><span>📈 Reputação</span><b>${reputacao()}</b></div></div>
  <div class="card"><div class="tag">Competições</div><div class="menuG"><button onclick="ir('cl')"><span>⭐</span>Champions</button><button onclick="ir('el')"><span>🟧</span>L. Europa</button><button onclick="ir('lb')"><span>🌎</span>Libertadores</button><button onclick="ir('sa')"><span>🟩</span>Sul-Americ.</button><button onclick="ir('cn')"><span>🏆</span>Copa nacional</button><button onclick="ir('cmundo')"><span>🗺️</span>Copas do mundo</button><button onclick="ir('mund')"><span>🌍</span>Mundial</button></div></div>
  <div class="card"><div class="tag">Clube</div><div class="menuG"><button onclick="ir('mer')"><span>💱</span>Mercado</button><button onclick="ir('est')"><span>🏛</span>Estádio</button><button onclick="ir('banco')"><span>🏦</span>Banco</button><button onclick="ir('fin')"><span>📊</span>Finanças</button><button onclick="ir('patro')"><span>🤝</span>Patrocínio</button><button onclick="ir('prem')"><span>💰</span>Prêmios e fama</button><button onclick="ir('tecn')"><span>👔</span>Técnicos</button><button onclick="ir('tech')"><span>📜</span>Histórico de técnicos</button><button onclick="ir('base')"><span>🌱</span>Base</button><button onclick="ir('rank')"><span>🏅</span>Ranking</button><button onclick="ir('ed')"><span>✏️</span>Editor</button></div></div>
  
  `;
}


// ===== POSIÇÃO LIVRE NO CAMPO (restaurado) =====
function zonaY(y){return y>=84?"GOL":y>=60?"DEF":y>=32?"MEI":"ATA"}
function posPadrao(c){ // garante coordenadas para todos os titulares
  const tit=c.elenco.filter(j=>j.tit);
  if(tit.some(j=>j.px==null||j.py==null)){
    const slots=FORMSLOT[c.form||"4-4-2"]||FORMSLOT["4-4-2"];
    const sem=tit.filter(j=>j.px==null||j.py==null);
    const usados=new Set(tit.filter(j=>j.px!=null).map(j=>j._slot));
    sem.forEach(j=>{
      let melhor=-1,bs=-1;
      slots.forEach((sl,i)=>{if(usados.has(i))return;
        if((sl[0]==="GOL")!==(j.pos==="GOL"))return;
        const sc=af(j.pos,sl[0]);if(sc>bs){bs=sc;melhor=i}});
      if(melhor<0){j.px=50;j.py=50;return}
      usados.add(melhor);const sl=slots[melhor];j.px=sl[1];j.py=sl[2];j._slot=melhor;j._g=ROLE_GRUPO[sl[0]];
    });
  }
}
function resetPos(c){ // volta às posições da formação mantendo os titulares atuais
  const tit=c.elenco.filter(j=>j.tit);
  const slots=FORMSLOT[c.form||"4-4-2"]||FORMSLOT["4-4-2"];
  c.elenco.forEach(j=>{j.px=null;j.py=null;j._slot=null});
  const usados=new Set();
  // encaixe guloso: pares (jogador,slot) por maior afinidade
  const pares=[];
  tit.forEach(j=>slots.forEach((sl,i)=>{if((sl[0]==="GOL")===(j.pos==="GOL"))pares.push({j,i,sc:af(j.pos,sl[0])})}));
  pares.sort((a,b)=>b.sc-a.sc);
  const fei=new Set();
  pares.forEach(p=>{if(usados.has(p.i)||fei.has(p.j.id))return;usados.add(p.i);fei.add(p.j.id);
    const sl=slots[p.i];p.j.px=sl[1];p.j.py=sl[2];p.j._slot=p.i;p.j._g=ROLE_GRUPO[sl[0]]});
  posPadrao(c);
}
function efPos(j){ // rendimento conforme o encaixe no slot/zona
  if(j._slot!=null&&j._role){return Math.max(.8,0.8+0.2*(af(j.pos,j._role)/10))}
  if(j.py==null)return 1;
  const z=zonaY(j.py),nat=grupoPos(j);
  if(z===nat)return 1;
  if(nat==="GOL"||z==="GOL")return .6;
  const ordem={GOL:0,DEF:1,MEI:2,ATA:3};
  return Math.abs(ordem[z]-ordem[nat])===1?.94:.85;
}
function moverPara(id,x,y,live){
  const eu=S.clubes[S.meu],j=eu.elenco.find(a=>a.id===id);if(!j||!j.tit)return;
  const nx=Math.max(8,Math.min(92,x)),ny=Math.max(6,Math.min(95,y));
  // goleiro só no gol; ninguém mais no gol
  if(j.pos==="GOL"&&zonaY(ny)!=="GOL"){return aviso("O goleiro deve ficar no gol.")}
  if(j.pos!=="GOL"&&zonaY(ny)==="GOL"){return aviso("Só o goleiro pode jogar no gol.")}
  j.px=nx;j.py=ny;j._g=grupoPos(j);j._slot=null;j._role=null;
  S.selId=null;save();live?renderLive():render();
}
function subDireta(saiId,entraId){
  if(S.subs>=5)return aviso("Limite de 5 substituições.");
  const eu=S.clubes[S.meu];
  const a=eu.elenco.find(x=>x.id===saiId),b=eu.elenco.find(x=>x.id===entraId);
  if(!a||!b)return renderLive();
  if(!aptoParaJogar(b))return aviso(b.nome+" não pode jogar: "+motivoInapto(b)+".");
  b.px=a.px;b.py=a.py;b._g=grupoPos(b);b._slot=a._slot;b._role=a._role;a.tit=false;b.tit=true;S.subs++;
  if(S.cap===a.id)S.cap=b.id;
  const jg=S.live.jogos.find(x=>x.a===S.meu||x.b===S.meu);
  jg.ev.push({m:S.live.min,t:"s",lado:jg.a===S.meu?"a":"b",n:b.nome+" ↔ "+a.nome});
  jg.subs.push({m:S.live.min,lado:jg.a===S.meu?"a":"b",entra:b.id,sai:a.id,en:b.nome,sn:a.nome,ep:b.pos});
  renderLive();
}

// ===== SOM REALISTA (Web Audio, 100% gerado por código) =====
let AC=null,somOn=true,MASTER=null;
function audio(){
  try{
    if(!AC){AC=new (window.AudioContext||window.webkitAudioContext)();
      MASTER=AC.createGain();MASTER.gain.value=.9;
      const comp=AC.createDynamicsCompressor();comp.threshold.value=-18;comp.ratio.value=6;comp.attack.value=.01;comp.release.value=.25;
      MASTER.connect(comp);comp.connect(AC.destination)}
    if(AC.state==="suspended")AC.resume();return AC}catch(e){return null}
}
let _ruidoBuf=null;
function bufRuido(a){ // ruído "rosa" (mais grave que o branco): soa mais natural, como multidão
  if(_ruidoBuf)return _ruidoBuf;
  const n=a.sampleRate*4,buf=a.createBuffer(1,n,a.sampleRate),d=buf.getChannelData(0);
  let b0=0,b1=0,b2=0,b3=0,b4=0,b5=0,b6=0;
  for(let i=0;i<n;i++){const w=Math.random()*2-1;
    b0=.99886*b0+w*.0555179;b1=.99332*b1+w*.0750759;b2=.969*b2+w*.153852;b3=.8665*b3+w*.3104856;b4=.55*b4+w*.5329522;b5=-.7616*b5-w*.016898;
    d[i]=(b0+b1+b2+b3+b4+b5+b6+w*.5362)*.11;b6=w*.115926}
  _ruidoBuf=buf;return buf;
}
// Camada de multidão: ruído rosa filtrado em bandas de voz, com "ondas" de volume (a torcida sobe e desce)
function multidao(dur,pico,atq,t0){
  const a=audio();if(!a||!somOn)return;
  const vf=velSom();dur=Math.max(.35,dur*vf);atq=Math.max(.02,(atq||0)*vf);t0=(t0||0)*vf;if(vf<1)pico*=(vf<.6?.6:.8);
  const t=a.currentTime+t0;
  [[420,.9,.55],[900,1.2,1],[1700,1.5,.7],[3200,1.2,.3]].forEach(([fq,q,vol],k)=>{
    const src=a.createBufferSource();src.buffer=bufRuido(a);src.loop=true;
    src.playbackRate.value=.85+k*.07;
    const f=a.createBiquadFilter();f.type="bandpass";f.frequency.value=fq;f.Q.value=q;
    const g=a.createGain();
    g.gain.setValueAtTime(.0001,t);
    g.gain.exponentialRampToValueAtTime(pico*vol,t+atq);
    // ondas lentas de intensidade (gritos que sobem e descem)
    const lfo=a.createOscillator(),lg=a.createGain();lfo.frequency.value=(.7+k*.35)/vf;lg.gain.value=pico*vol*.35;
    lfo.connect(lg);lg.connect(g.gain);lfo.start(t);lfo.stop(t+dur);
    g.gain.setTargetAtTime(.0001,t+dur*.55,dur*.22);
    src.connect(f);f.connect(g);g.connect(MASTER);src.start(t,Math.random()*2);src.stop(t+dur);
  });
}
// Voz de torcida: coro de "vogais" (formantes de /a/ e /o/) com vibrato e leve desafinação entre vozes
function coro(freqBase,dur,vol,t0,subida){
  const a=audio();if(!a||!somOn)return;
  const vf=velSom();dur=Math.max(.4,dur*vf);t0=(t0||0)*vf;if(vf<.6)vol*=.7;
  const t=a.currentTime+t0;
  for(let v=0;v<7;v++){
    const o=a.createOscillator();o.type="sawtooth";
    const fr=freqBase*(1+(Math.random()-.5)*.04)*(v%3===0?.5:v%3===1?1:1.5);
    o.frequency.setValueAtTime(fr*.88,t);
    o.frequency.linearRampToValueAtTime(fr*(subida||1.15),t+dur*.28);
    o.frequency.setTargetAtTime(fr*(subida||1.15)*.98,t+dur*.6,dur*.2);
    const vib=a.createOscillator(),vg=a.createGain();vib.frequency.value=(5+Math.random()*1.5)/vf;vg.gain.value=fr*.012;
    vib.connect(vg);vg.connect(o.frequency);vib.start(t);vib.stop(t+dur);
    // formantes de vogal "ó/ô" (≈ 500 e 900 Hz) e "a" (≈ 800 e 1200 Hz)
    const ganho=a.createGain();ganho.gain.setValueAtTime(.0001,t);ganho.gain.exponentialRampToValueAtTime(vol/7,t+dur*.18);
    ganho.gain.setTargetAtTime(.0001,t+dur*.6,dur*.2);
    [[500,6],[900,5]].forEach(([ff,q])=>{
      const bf=a.createBiquadFilter();bf.type="bandpass";bf.frequency.value=ff;bf.Q.value=q;
      o.connect(bf);bf.connect(ganho)});
    ganho.connect(MASTER);o.start(t);o.stop(t+dur);
  }
}
function palma(t0){ // palmas / explosão de torcida: estalos curtos de ruído
  const a=audio();if(!a||!somOn)return;
  const t=a.currentTime+(t0||0)*velSom();
  const src=a.createBufferSource();src.buffer=bufRuido(a);
  const f=a.createBiquadFilter();f.type="highpass";f.frequency.value=1800;
  const g=a.createGain();g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(.5,t+.008);g.gain.exponentialRampToValueAtTime(.0001,t+.09);
  src.connect(f);f.connect(g);g.connect(MASTER);src.start(t,Math.random()*2);src.stop(t+.12);
}
function somGol(){
  const a=audio();if(!a||!somOn)return;
  const temAudio=!!_audBuf.gol;
  if(temAudio){                                                     // SEU áudio manda; torcida baixa por baixo, sem coro de "gol" sintético
    tocaAudio('gol',1);
    multidao(3.5,.16,.15,.05);
    for(let i=0;i<8;i++)palma(.05+i*.09+Math.random()*.03);
    return;
  }
  // sem áudio pronto: o gol sintético completo
  multidao(5.5,.5,.12,0);
  coro(196,3.4,.55,.04,1.28);
  coro(294,3.0,.35,.12,1.18);
  for(let i=0;i<14;i++)palma(.02+i*.075+Math.random()*.03);
  [0,.42].forEach(dt=>{
    const o=a.createOscillator(),g=a.createGain(),t=a.currentTime+dt*velSom();
    o.type="sine";o.frequency.setValueAtTime(110,t);o.frequency.exponentialRampToValueAtTime(48,t+.22);
    g.gain.setValueAtTime(.7,t);g.gain.exponentialRampToValueAtTime(.001,t+.3);
    o.connect(g);g.connect(MASTER);o.start(t);o.stop(t+.32);
  });
}


// ===== ÁUDIOS DO JOGO (gravados pelo próprio usuário) (v46) =====
// Cada áudio é um MP3 mono pequeno embutido no jogo. Toca por <audio>, e cai no som sintético se o navegador recusar.
const AUDIOS_B64={gol:"SUQzBAAAAAAAIlRTU0UAAAAOAAADTGF2ZjYxLjcuMTAwAAAAAAAAAAAAAAD/83DAAAAAAAAAAAAASW5mbwAAAA8AAAAaAAAN+gAWFhYfHx8fKSkpKTIyMjI7Ozs7RUVFRU5OTldXV1dhYWFhampqanNzc3N9fX19hoaGj4+Pj5mZmZmioqKiq6urq7W1tbW+vr6+x8fH0dHR0dra2trj4+Pj7e3t7fb29vb///8AAAAATGF2YzYxLjE5AAAAAAAAAAAAAAAAJALZAAAAAAAADfpB980FAAAAAAAAAAAAAAAAAP/zUMQAEdimEB9JMAJSApR3fCGTRt9dG3qhAKCRcECRMVit6BBhAhDnkyabAMmxAgEQ/Ln+jDEHwf+UOZf/KfghEjgfP/LvIf/9EH/g//+p38u/g+rZ7LYbDYbAYbDYbAYDDCuyBZnMp9+2EB08sXgdQqcDW/eE4G5cA4EBbAxrOJD/81LELSUzkwZfmJADyBDyJgFwBcQVdSMcZg0OgABcPuIU/5BR3k8K0GQ/+wnMplchwYAFsFb/07oXbIuMmFwhEYpMLmyYMP/uh/xlCCDTMiICCAzB4my+VzI9////+YIufoIGbl8++h//////oU8zPxkB3ibMABOUQV62wUUuwvUO4//zUsQOHQL22efMQAFBddiXhOAcFkpNigPBGIEIPhOLg+AuDwJCYaH5Z1PVVVVy/HCVO8PdrcQ8I9VN06mkj4e3+Erinuv3hE/+Z9+bnWeZ/j9Kn+b5f+nSb/q09+e4rvb4TF6ZDnllIjHQC6adxYC7euWtEqhklLC9MwyiRsz/TArX//NQxBAce77t9nmEu8zRyDmkL0JyZKUSvIti8oq2WWiz7nZ/NrNPlFEza2ty5f7eQ/bUrzVAWqzm9JW+6aBTAjo4g5UYymZ5XIXZdWWbZP+X2/tNo/ovabrbSvYvMbatv/+mitcQzMM8MLVl6eP7wAAFuW/zPRoZEqJpIEQoIG5Cov/zUsQTHpHWzfZIy0mjooQosJxSIEUWyKHOslSiM6zFyNFS65b+EqA1XInvBTQVFe0ggwgVKWykZhtDTkY+qLrd1Le5b2i1ZKD84o7ILedalFack/b9Qmduu5h/XSf91q0Txqv993///w7kzlb/GKyhfxRWlY0SZrfJd3GEUlhfoUKN//NSxA4dS9reFjDFV0oCCgsQcXZImykDXp1xmGgqLIUSXcuNhzHVTKZxXhJMby2tCjDoSSOLzCm8QIEyWxWhKVEwi5/rDYvyaeiR7vu5TsIujaHvtb+1VKau1ja2vzWuv5JFqioyI1iNfp9853uh9JQ77k2qStv8NjV7/9FiwLDy7rP/81DEDhyrwtQGeYrQE1MqH1XhKkSZOzVHaRp5SbEYhx9rTi2jP9aUSEnex5kam/yE7JVfp/9P/0Y757Z3v/oeQnvoShNfqmii8TFxBiEUPjBUBxYopEBxgAKLkMTQhJxRs7kY4pIpyUJ+rkMx6i8uwCWABFyfL2vyyzDJJSjZK7pa//NSxBAcm7bhRniNXHXKg11baJnLM53+N7nfwJvrH8F4p0pC0c6KxwBqGqFBGb7yE+m39U+FcDFv1zn6P+8igkEM1DwgYAbZyOEEW0KdCfdH/b/1qrbt1dS//9Ua2Z3jCjwJHI/+JkC4Q8R6QJwhqrgCYrhSlRUno9i0a5f1yj6Q37D/81DEEx2SSu7eewbQomkSCSNazPZnvsOUSF2O7mHK+ZtnzcyAYedbaZdsfHKzLgUS587CyMubgTq+RWKgUWZ1UEhtz/1Q5P9V//6JYnP+gKV/2wEairopcf2P0H65kMZVnQPGCVzjB5pVAJCplzVD6soRMBJQpHHbhoWwwaOerzHU//NSxBEeunri/HoLZOeGd8x0vcVyNDdOmFkbm1EBuuC5it5jMZynqEgfnZi9rdrKdUyT/Oqsg7H9iLty6DsBYXlLsfmSu0oNe5FtllIgYb9F72oQ5X3SRf7jH/cTbzZDtelw+FeEWcI8T+cPZcV4nOcIq1v//EG3AjAZKuFcQRwMYrz/81LEDBzZdtrUY9CwzQuBhDzEv3opAH8SGpnssBghE/bXDHeTMTwu6hgt9JcSco1iKk07lgIB+VfjZ7NrWWjv+aykdDr5qXQoGoZPgECHuR1gN9YOAMNYgFj1P345YNP5L6gfQHdIqdxYkbVDx5eBbv/WRUrUIApQkp86hbn9Fw1uUP/zUMQOGGnO2fZ5isj3asi+ARhBtPMJryAcOuq2KGAdFwy1hYMd1sQjObocw0c0zEWSd7P720ZG8ioYtanT9CjwVyhKexEdkH4HDJ1TBhKXD6/6Qk+AGjwWf/p9j7P/ZJXQlCBAC9+e98u/Uk+FLKrGOcw/g2SUJTEyBzxA5yzaXSn/81LEIRiTqtH2ykS0JXDS7fsjUblUG+2GiWEc8nIJrNalUW6n+6yFKlLyduhf6hjfuX+Y31MFK37/orfIv52T+dvyI////3/u31O4h/qVsJAeSVos+XmIGYSpngz+sJtMoSoi2OuWS1B0t3IatjNEwOKdFIQRL9xBWUNM7rPto6GVVf/zUMQ0GDuq3e55iq8zN10P7WcvRMz//7J60b9UbrqhW+v+Xt7f3//////bVFKxRwutP/JLRN7/SHb9pAt2245L4H71u/JAao43WjFwY09d8KHXJpEzYjM890xqajO3hYb683k2WbIVyz51uqptbnenroZkMlHEkhRVYgJkjEjPdCz/81LESBjprvo+YYS2PgIGpZNLEKvNLUkTPWaX+z/w8TKsYa3+3IgzVfWiGm/+S3pG6XbKy0RqQYvlgCgDa/SeocH2fX4CJO5qdxThUBXSxA07WZgzGq4NXB5tPhdsI0MyfpqWlrudP/2SuZRw25qwVFQ6ofMf+Cx8WU1jFs/57+qsqv/zUsRaGQH69jZgxRIw2wlwMaeRQCAgyAAI1/2cs8LcrfmrlQ0DKARgzFDYqnR6RBAKowtdY6JAjLlNm4cMUd0pUrSyG3cUvriywvV860HQ2kNMBlZciOmFvk2mQKE0VoFjQ5qhfC6iZl///SfHhojen/192qwS1Uucz+8VLBzNABWa//NQxGwaAO7F5sMMkP5La1uL32PQ8df6U5JywxN3BoruzX6Io591FUkg2juZBYiZKazYAm82Zn/HjRd2ikag7NZOBzKOf2GDMEY6//X+LPiR9ueMCgsGHLqZL3HEIFV2Ivup2M6J5PdTxlL3uaw+v+nSAhbduS6sSFAghzKBkM+r9P/zUsR5GgIG6jZ6RpIhbdYKUSZqMGJJVu9yuRqWiMEn5t35FKR4UPn06Vasr6uZv5W86aF5ZU4RykhwvP70ucTcqRxYd8+KVIkOhQsGwbF6dn//Z67sUttmyoVVqAAeU5W2Kq8ErJL8thCw6UaUwBKHjQkChNtQjrNSn47absINWOoV//NSxIcX0mLqFnmGiiCllX/bYa/9J71aXCJa5+eXTNtwAFz5YmXGKNMIfZGFme2Jz6hX/R//XAw571fuWKuBMSoexQ5TNSqMopFq7c2+zZIDGuXIRqoWFImxLy2sVxiM/UyC80am7UELlZZQtEVGO7oZUVGUxstjMtTjrkRnTR0d9Pf/81DEnRgJetHuekZ2YxjzM45Sle6eb9bLm6dRXiqZP//VUKhKF5Gvq1k9ZTGGBOEFHVHP2/UzRbJQ/dAHpS34Xau1WROtBfyZCSnTt0EGG3gYLJJLxbhBnJIopEIq5jT0drEiwTuTpcpBLJrOQi2rVlusHMdyznMenX3dWR0ffLve//NSxLEaaybuNmDKsuoNGMGcLSLg6g8r/0IBuWi6V+ogKNnS5Xf/jTSm3uczoYApOWfKbuDWPtS8ErgUtaV1o4YQFxCIzjzDZckMkIre2kooRgzSIT0psZ7AlMKHVIUdZ4YAmzLjo5pOaWLkoaZWbOgIAqLUvHCdwuNQSApIZLDzpbX/81DEvRnyFtFOeYSWK+tVdHO/Wo2kstVXWzpD4xc1Q8kthJBVty3JLmeilpzVQUImsgjJNi1wOm9RqVETktw+JVCqSrK+TqO4FW6OzrTh14Z27b5f4+Nn9fnZu009HNd8+o2yi4DDiiwGwEFgNyLlKvUDKH1gQKqbSSGtCrYdQSZF//NSxMoacQa8rmJGeg08wkO0Buo/ez8srQQbFw0qBNAAEc1cdr8hQEeae+Aq2Ioac4RcEQC7fUkNE+SiguEFyEEMpqP8arQFRMAgwizODHBYk70lC4phqGeWHPqXKTVWb3dLh4ENR4bdxHeeCfa7JU5csstylk+0wW7oCWSOcu6Js0n/81LE1hwJosH3STACI6NLf3yVf2rtaKgLvv5LoJexwrP2NwzKrspnd81/47xx+pP2ZyYoKOngq5F45VjNyp2m325uzLqtn/////////ta33na2sdf++Y6x5l93Alzv9Yx1VVuVzM2oaoWwbwhyNL8PUXJybTlNE6Z2FlkTyiXIkoOVP/zUMTbLoq2ZA2ZyABxPSEo1TGktH6TlVKUtpOS4qlTCTBqmglQmxClVBVsXFdeE+jSp1DYzCnVbFpCfPq4hWeCmgrA3HEFdCGQgpsFbBf/+ExBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/81LElRj5McgBz3gBqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqg==",pen:"SUQzBAAAAAAAIlRTU0UAAAAOAAADTGF2ZjYxLjcuMTAwAAAAAAAAAAAAAAD/83DAAAAAAAAAAAAASW5mbwAAAA8AAACBAABChwAGCAoOEBIWGBocICIkKCkrLTEzNTk7PT9DRUdLTU9RVVdZXV9gZGZoam5wcnZ4enyAgoSIioyOkpSVmZudn6Olp6utr7O1t7m9v8HFx8nKztDS1tja3ODi5Ojq7O7y9Pb6/P4AAAAATGF2YzYxLjE5AAAAAAAAAAAAAAAAJAQAAAAAAAAAQoeM/bXCAAAAAAAAAAAAAAAAAP/zUMQAD9A6LDdDGAIIty7/0TcDeAYuBEAZ8HygIHCjieGIPvql3h+GPKOBAuH+IP7gf//5STkHzn/1BjcXP//UcxO+CGcLn+GKvwQV2Ww2Gw2Gw2Gw2AwGAwpHjdBE25iydJMAPCLDvyiuTAGIRIOB74uQ1A5jYDMmQMoMpGaRobj/81LENSdSEwJfmaACIg4GDLgWHnnNCcKZPwDkYe6H2BRekhYmyfImhAkJAYPhYkG0E+yklqmBoRAvumAoHFDCEoW5HUVxPGv1WseTsK1DbyZODljmkYdKf///nDQd5cL503NAUB45//gmD4nHAAn///l+H+aVpAAFpyXc0DyO8MSy9v/zUsQNG/Hi6ffMQAJt1q3r1NDI/OS4afWzoqaJhknj0JByjQ+D0UQVuLupX+suWHvazdyQPllod3vXCXu6ockQ863F+lRSffP/f5ZwUcSQJQ0c7wChpZJptAhDiVGjzx9Nj/kCk8NaDXlfsYM1i62IkAjVyXfKGyM29nCATCsREiBz//NQxBMe4y7yFkmG2jbKMUqnSIypWIIlIqV2QyUjV/D0tvWzPn8MWMIbFMheckeOQDso2H8ZDaAEui0x/aH20QhOWW9z0tI0zMoVy7omv5eaaSe17zdKiZIbER/IbGqTz36uWmUI0SBcGjZSoxPIaT6W61J4xc0CDrfLd4vBUGCskP/zUsQMHRJS+hZJhl4m51jAssQdUuOLSJgb3qEXr0Z8oTS8SSg/5QJCfJpxZFpDbKiAIFA4hjBwiqtYRE4glV58VMjP/XO8n8M/KXLfy2Yl4ZmsxwOIgsOKhI0XHl1DiJY0tCHcKKYWESCCKRR7K6KarHK3ZtWIhA61yXf2UcocY5iC//NSxA0dEg72FkmGvhXOkQbnJkik+qjYUFAqL7NGdRcHEcFEIa1Ld0r8dzpjz6zvTOsbHz5T3jlyb1c5pP/IQ/EXt7f++cVql5hsNWNH3C8uFDGeRemNN2npF5BL0ISOAIsRNodE96GqY1zAVFAWMihNkiSV2AApuXTKaOIruErfXEv/81DEDh1xmuVWYYbOCpEepD1OmQXUMmNOB2B0dQEva6LkObJREWm1KIAEPkx+ZlIepGe8Lzr/0sS4gUZU2KY6cMIIohYbbpEAXBgyssozDBw4o9YbHLWgL8DLAh7TWLLWXeUccYWIgk99O0nOHKZc0xtCXD2IggW3JfcBs22qpyeV//NSxA0c+77t9kjFP1CC10RuC7KzDkcKUTjOCalQQM7BYIqBHGWNChSfohPLxwvDX83SGWWLMoUM3BdtP3MJ28YFGrG/kd7Pt4Zn6ROf8rdct9rc15VknXMlddf1/03Wnt66s3rkXIGDGY4vI3Xle+eHKgaskhW5LtpYuSUg8XKCosH/81DEDxkY5vX2SYaKkVn6ahUygaixs7cSs2UTUxVCergkerwKFQwE1NOhlQDrbLBJYQdyjT5JYu7aGBY6olFHNLTw9IvSaexzJNjxwUIMUKoHsH2DZYiXLHUtgdKXV+4tbXWIgAFnJd5QJnIjjRDniEw+iUyYIUXA+C5C7oc7cnB9//NSxB8ZiT7p9jJGxoF8GFnsqKY6GaSpmj03NVQtvoFCwRM8hqDVd1wYS4bqhq5K3PSt8sBwYBs4Oa0TVAEsVGSY+5BbsN4gzmjI9a4BeGWIQcV2qskCRNfbd1exhI1jTmIHALEwqGnuMiCkO/aqUod0pCMmTSbe1yZSLH6wkUY7JLD/81LELhoaevoWQEci7NjJW2HDHVyzMntPNCRL5+XlP9TNQ8hXIsoCOLSQ5Z/1D8sQw46BFLpUzbx2yF9RP3U2IAimEGRUnfWtAE5Kcku8as2CBlIog9GEakWubT8FPG8dyV1sQ/Fh5xw0hZBXZg4rnF2iSKWex0xOrM3S9SATS+4ozP/zUMQ7Gdmu+h5Jhj7SBBLcFmeJhETHHAStF+SIS609f7xR+KothN7aFjGMRkL1zvMEbSZWdErnvSqAgABk5LaBNFl1TyqqxkrpobCQZEsuLysLDyC7JjxEvTjSnI4pY0y/V67qcWyzjGloIi9m80nzyQk4dPynC2tWtBLx5O4Tb3b/81LESBnptuX2YYbqNsdQkc4c8tjjCCwxlImDCmhdvec6uq2l1vFipl1LLEVYBGnJdlJCuJqaTI6nJA9GhIwyOiccDsW5PDJVS0bMxNi5PyXb0WxlDQE5pocemAMGwyYALRkwgybEwoJSCVtXbliZY4xwnvUjcB1Dwu28UWTQ6MU49v/zUMRWGdjW7VYKTBa0pbrrNirS5RGVrrp3M9xikqqkgBGpJdiS7aCm0tVyKyNhRhXhbsg09aWMNTWwHXrjPREU3ECErGLQW0fuVLTTBCVY4VqGZV0JJKHPl1EBUPHnqoxoYekSigHHoAKhE0sfArxVd1HProXHJ/ebZsFW+b8G2ej/81LEYxjBcu32SkbCjIAVuS7RaELB8vTa2UxRlEqKuYAOWVCHbt7fdPLPcg0tisLEZsoHhNSVCTYXO7+k0bt22QvexWMrQtKI44WdWMmVVEKtV5LkRC2OiGvKZiHnWxPMZDqx9q5r/IuNGGqpWMXbSv3edZUFmLG2zFXie81r/sukv//zUsR2HqtC7fZJitc6X/JktYgSBaclzK8jAfllOmyJQVKwSkIiMVUjsjMTze6DfczvUUFngB1TI12vlRhXTPQyciVWB1Kb5mQgIB8OjCAQABmgXDgaOcztQ4Lw6+JSrXyAtFrTW8gSMY9jmcZlBVl99lPjl4xj+xWxpHVX23e9Q0Ph//NQxHEZkVbt9kJGWkfgySgMhAASgi+g6KQUQaToO18iIhnrNaW5wAUxGSiniJaMTa5GzSSuVzm1NEefmjZw7pulpP//+5PApOXFX4hIcjuFZSyajZwsCgUMzL3Cj2k0uWlHn0WjKbx1XyJd56aYZakEjzXJboWt6FWkiUUOjxMCaP/zUsR/GzJC/hZJhm5BgTFNhSbiAzSIP3Fpic5429RZuSackW4QdQYUMiwxaK90hQqsinA4NTpZkr3RvqcjO5ZRTI96b4s4wVAxIghVDQm4vdOkkXR4aYk6WSdWHEPcqMutWr/qoaUABacl94C+/y4khMomo+GvnrkbnOa+eO5Scv/b//NSxIgaser2FkjFSq/RF1L+GAENDVVbIpEnoSsD4RrEQRoW2dIoSMEaCI5sMbWOj0VWb7X1ZnujfZ7U6skEfYDRtxYBwi3AhYwQNYur9d2/oQpaMMhIQASYIhtfUhXAAWm7dFkmSMg1lNPDnMWBawCCwNwhFj3Z2UeLDh5QziZM6VH/81DEkxuSSu32YMUyHua65t+ymLyj7d6WM11iI7bZc1oqlmo2S7qoepET/2nvsJGRHbJWk45v/lKM+A7l6s85yWR+7SEoxFvogugFbUWLcqI+Hbq5WUzyxAAtKS45z0MSGploLCw1PZIKFpL0JxNFc3n0CuvTSwCsYSEAzFxJJ1yo//NSxJkbqzbpVkBLymVcvSoZUICKNhFbiSHKkFVKrt+R5EgFY36vLz++u4hNCDjkaOAKq3GIXQf7Juclb/9l/tSVvgfH/unX30knf8BxaskSL1e27l8mXApB7aUOKiguefhix8+bF0IbKcjv1ZQs53fsN6e1xLdDja3bKYBPdUFJMpn/81DEoBri+ulWMEc/z5+9XiymIZEo7ojt6ErOetesiOZ32VmRmWjO4JEI0ufXLRn/pSv9tm9v/CcY0hnfSRrORZjctXqnJycp20iptPWiAiJCDC5Htm0E66zsWUCiFEunQUQPtyAjMRp2zfeum1ryuEVr+akwkov38BlrnbmzK2JN//NSxKkixBb6FliTeh+nScE/NxhcACUCOUGwZ2c5wpnCzzh79LcmN+e+ZuDozkZ6K3726uzpoVV+iNc7MW7Bpc2Rab0uoDZo8LAEVaXNyosEqvyOe3iuNlRopqOkRg+4uw1Vx1ABIU5HfuvIuhJycVA/a01VAuAYwjgghIGbHjy/iMv/81LElBzKPvLeeMr4hfdkawsalvc9kcjeqR+aITos3NHhPn9Mp+uWG2MaZRa5ECtkgrUVY9p56QiaQ5rMWRUSBV6qSZI64eFpVLv/ppEYaAqTMOnjoFK54GRKTeQQAArJ98lvFyxekfgYePDlYdIlhmZB4RSajw8XJmOYkxwo9c0sjP/zUMSWG7F+6r5JhpTJ7JQeT5PXSGfgxO1qVz98RNO68R4Dil/6+r494gB84gfRW1FbaYKg05z/LbyJZzZKMRadXK//Errj7AZa/fxLQHXIogy1uSWzd2PPz1YIYGzglssLavSscghQrxfKPbRsym2KrFdtaZ7LXfrSmZtq450UjE//81LEnBoxotX+YYboRzAh0EVsqCQuQxHZTWLsyupHonLO2+7U/0pVaec4fFR5zshFQ+YadGcxEX9f0Xez5CFcm9ozf/8iU80wIIEKz57tsjz075hqtfnhZwRumACIBzlHosYAAg85WKQgECC5brqx1TGhwG4PxLZhuaFRmN/RmgNTCv/zUMSpI3wW5hZhTXqUARTE5g4kxChxLE0kCJ1MOECQEnUPyjCXrmDgqtealKXXRUoU2dHYeieWQ50HsZXxMz1xBhdkU6h8BCrkIwHHCRiHEzAjz1iYgdits7V0VeroV5rTkOVzugiYqGZjounlEnKOIaazFprsqM2+pnREMPDi0G3/81LEkCTkBt6eeYrRhEeZurRAEGRaluw/cqgurQ7AsMyZ6OIBt0YSEgyBIelG78bUMzYc98NYezVeOGQsHLvmpQ42kNwhUL2XN0FqjU/2cut/tqFVuDS+HS5IVYkRhl2CuBWuWR///KoPRwq4qAVDw72yrn1clW48pdWkABGm5LKJAv/zUsRyGkmu6t5hhlw8O4jaePpkDDajx9AmACQacYihpTlkXw/UQiHRzHtPliiLT7yLMtiMj+IwWeZsY4cBpAeEIPHwAIFHsbceqjwfeKOgOfsPGB52eM0immRCqriq5dhBbe5jPT/cbdLORoWtAhk3xyWfIziFGJWnKwSRtDWOek/s//NQxH4Z4ULZ9kmGtioPo1V4jaP62QEhCiuh0QLVoHZztyJKCXZRUB1zlq4PnEaZFT3IhJnlvmV4b6eTv7jESgGOMEz3nLOJylfEDjAq1ojhi2sPhijxAnZ7KjieNAgDNVn1wAAZOSeG2eWrakjlVKmTeC/j2HSq5lDATqhdO2Tbzf/zUsSLGuH26hZJho7M3q+G5OmqC3o/TG0fByAzRMsmPIhveSSFLenkUhGXr9JKUIGODIEJFKJCN0QxKwaUUSre5sr3VbbhiBj42oyccF0Z0eMLsNyVOCkiJlVOrFK4eJwmFNrrJtuPPtY+lpsXDKlLojxMnbIq1MxA/FCURxPr9ARC//NQxJUtY/LZVnjTNzEkp7PGmWzOEy7iUiJ02Za1HzKUvuTc5NJEVZJk2VxsRZEAAAEopdub37WqXa2XWTVIQVJnCkTzErlR+2Qc5wiPZruQpzxsesEYXTpXxkypSe8pMGpuREcJEGJbL33MRS5dUh/QaakWxw/79WYh2zFYy6CnVP/zUsRUHQu63p5gxTT/8rfc1v3bRVd/qvtMW1JzmdqOpTMmmb7OblYEqEMCtarkAFynJNIaRr5HBiqJ/zvQyQ1x+TyQ+P7jG0RtjQWV2ob8LJ7TT21PbzLZI5yV/zdb0sTqC3WLmpzfuei3uXfdEpjDh3Ilpm5HJH+w/4MTzP9fO5Xt//NSxFUamirdVmDFUtQfZSAXuQHQm4mHaTgdUh+IBvjLMpWtEhW3LbfrRFSIcirriZyxrVyKTjyKknp3jdvNag+7WlsbHepnZXM/XOyc9tuRrot3Z6dyvV1e5dk8dCGRlBuQnNtrugZ88dlTSQMDhgV/2qNlw6kYmLvBKqCsRqDrNDr/81DEYBoyPuX2SYS6i9gpX+xglO5tqAAApOCLPPnFMDEkw59VEaQpxHH8LnTI4JhEZQudtQSBTTT4LWCykiouzSnwocncykiRzYUeTCfIrJ+TnQxqcQZUkPUAL1oYElqbZwfYtCMUGk3iQeKesgLgiMaJ0sbMd3//8vyiVYgCBbTY//NSxGwZkZLV9mGG6rO0TMM3fpUqKXVi0KXUKja1kgCSoyrvsEjsdi5iD8YqYauxSG/lkiPkrMe91vMybm5BSFOv+XEhVCPEV7PufOf9EEG1o5G1O52//bb0X++hG17U9G//////qpUPdinaDKEGVyM5GUwiReAAAbe//TXb2oiyFQf/81LEextkCuH2YMU39jknmNKWaWLCK8lY69yeHtd2qxqtbVrf6XjraC0/M5XqOiCAxHEQK5Y6pS5ukPO1/8f/87kh1KEYK+T8Y9Sv2+f//m1kJwZsSjk1D0kFm6LJBgWBjQno4K52TazUyzuynMyzTfnM0KnmlHqVhCAAIQluGS76mv/zUMSDHiPi4fZgR2yL0UQRacI+dTtDBCvA+JK2Ftpij9epJ+PF3rMeJE8Jezt1tpX4xpwiOkU3GHEetbTQDBIwcBlxkAsmgr4pATTYRGKB1jv9SFq2JJUCqb2IKFTaVPdZrV2og9oVuY0AErenHfk2LRUVZGeoqUW/6CzkUDZZZhr/81LEfxlxNubeSwaQplDCgOKoK5CxOqCjoQYVD43+55gyXNcUGQ+0cMA7hcUQPJg+WBoS7u31LGnVEiQGOkXfuyt+3LMrcvbEv/9ZyCpKDYChV2iQABy7BM7paD2Nk6IQIqA/Uc8fwFEcj83PpQC6qhOyIgUmjZEzRyIIaQTCDSFN6//zUMSPGAEm7hZaRjbtUqVlSr5828o5FZHjJ2vOx9qJo6WPpu5GtWRv77Vejn0VhyEQ3CDjiejkw+MIDUKJqFhsq7L1ivrVoxAAICVLsPTyFCyrNORVHy72UPGBkeHhKTIYkyBimn5ZE1t8EG4Ah4BdKPwqlTjgrl6Z3Y6J9ledHMj/81LEpBoSQtVWYYTwaduZDTPVDtt72P8roZ605dDUNNpaY38rGQUYcDT9K/y3//334TqEsqNESragCvv3+2x5MGg8R2PlyMijGa6M4BBICRdpcyfomyt3ZyjC2gw7cz5k9mu9rnG1mxEJztZ7fLP00ufJBVgFDCHNYzsJmjgoEL3XWv/zUsSxGVqq3r5IxQzRl4Eu+uBtJBbznlzcgXDCeiXh/QUOdb+gvRUcB+rABO7TNKLPNi4Ih+BcujziQwWCUdDmO4ikwuhAMmWI1zsShGXjocDePFrTpmeIThyVjHzx9m/1sBDpUlau6G4JKRq57UmM/1p8Ju3I5lsc1KRvYQ5LPdL1//NQxMEaEULd9gpMGMyyT3/pFn/8r+n5eZ/5gepNCIJOJQRhfN7JPULjS8mSOVWlflU+S/qqdq2hgO4oY6PcLW3Q0CcIxPCBhZAYtd2TC9XYSTEX0YAAlOT75HqnZWtoxhXoh5Z6ZkVoCrVEwTI2kBFJl+VkJekGwZJkq1q6TGQoDf/zUsTNJ7wWzUZgzXTZ2IYGkiLnNmfkqSlGR20lLs6quvr/QrdyF1ahG3JciVb//vVvpdm3Qq7F3//////uVN5UBq2imer02KKOc9SjMQAhJcl3HwnrP40AbppxI0ZkfYJRlzfXU8aEyP5sMUkCEoJxVDZDMmrrFgYyBmlIvUir6KZx//NQxKQbQ6rd9sJEXRGvmmxH7AIxiW2Tfn56uf/8sXSWVBhHslS7tzmX0PeuhNtDI3dhAaOPCry5wvT8u1yVqJAVdNyau46YoEhQP09ZgYYLWSabuDijh4aV5tqIFM3fIlodrZOjXZJZ4Nvqlq2ppRB+y3L6wr+0cleqswxGgjq7tv/zUsSsGiLW4r54yxBWX6fcEH/VpXeozt8nyqKZFHQMYtQR3iizP375j/s3wtu1uxkuCmlDpG+h6JAGtbcl8skq2nLY3WDx57mlUTKCUbBTNl/6RV0Xn0ikRvcuSNmHFlmm3ISMf6mZAdJTG6ChGUOfI6uRafP3T4Zf/IfDqr/kwoVe//NSxLkbc0rl9noEuqq1LniyEJOigsRETQUALg67r/9P7HabXuLN2AoqtiIOU3JbthD1J67Vooy+SQoiB1EOoUCFRECMxISswUElKGC3UuEGBRAjHesQKIFne1wRk9RG1S5Ay/8/3Y65mDRiT0AhkgZPYza1QqomNNLJNaPsSxJHZ+n/81DEwRnKGu4WYYaW1TXBUXKuJFVOS3TpQ/ZJ1YkQAGSbtnGfmZY+zPDF4Iauiyz3GB5RjKb1+1hSQxSvz+GVNHLFL2uHpMCFqIOG28JJnSh5m5GZQs6cz/iV5YYhCGrUzzmN0icuH8mdn05nvwGOXTlfP5E6TuR0IzLSp5Ch8HM2//NSxM4aCabyHhPGCkWfVNPUnkkarzyapdXr//+QiixSC9g8Eg6cXFDgINQoeDoHAguAgoJqsQA7Tbct+4MFGNZAgVMLEpyiUWdJMLBANSq4hy9eHOoIMKFtu5MTqygnKPljlcq9/fPO/Zw2n0v89ayeZdLMjXWz/21iw4Z/SP5c1ub/81DE2yNcFtn2wMsejGwaw1BCwzL4UhMUSw4z3XYMnYhPCp2ylH/91zXzDQXEQNWAgABk2J1Yu4TR9gHhWdHrizSqWoC8Qy+YQNxoB0jAmEtSBNhMzN9LsLRVUpZLzcvB+TbjVJGmBsFwA5ORYBwwcDb4Ih9jSJhTD6By6CrmXajb//NSxMIb6r7yFnmGUkTBcyVATRjFDg8ocxzan79n//7fbATxEsySCzXJd31hSSh87tktDteSRHvK9UTMSZc/GKzW7X9+XNGvhBLAl3RMmjW3q29v4ksdEYnNbvL5nvz6DlrzBlPGgZ4WArC6Su4eQAMCMS7ZwDSLV7quMKNRv8BG9Ff/81LEyBppAtX2YZLGeVEyiw0iisAArtP051pUkOCmNR8UV6VCLBFAeSw9NwbRr4SclSLpyjHQIjNwuUXwo1z7Ty/nKzFL72Vty//o7H0edl2qP2l/pps0xkYDHHjLGSOb1UeYy71mP82S5j//g2A2BCssYUt+w86QLEhdESJo1HMEbf/zUMTUGSGK7hZhhn4wvLLqa7fpAxOkewTbIHTgjnNHLKTNitZhdtANj4oahi+oItzQZULRtqMbBAgjOmJ1oAAmkpYS6EU4cCQ44xyylmZieHA8l56+0yd7cr3swz6ukH33M9ajdctXa/oOhb/Zyv/8h2MYZmWjrsm7a/qh3uWzLY7/81LE5CfcFs1GYFOsolE3dSojsyDOQ+qHUjVTQqTq9vn6JuVK2MupUfL3oqZcXP3glW52rWZpb22JWpjylEzCRQuDUPnjk+LT7J0XWygfGZNTF40WkiE+fFaEVmYVgAau/61insKKXdWJvAa9KCUEAKJR4XMhtlvLwl3rXvnJRzWOPf/zUsS6JSQW6e5gmXq2VXC5oZjvQLtSBAgjhhqeieuhJZCM7TBEdgivc5mm7aMUwc0oZIgAkhldHr1VPCYuMEawKrZG/9v9iUH3m0bWvmVK5oZIDblF+YXwYAK45WrL8FmBZULScXNGVhDI4j60Vrc14qvYchqvHcYEJMtOWp1lPjVE//NQxJsZ2XLctHpGfEUqnYmpGIZFLpyhA8qpf6eva29C+Uz6Gbgz0UqKMpyGzaImnEGBgLDqLR3//8Yss9dQ5TwzFCOBUCAxKdl28vDpiZVgdsRgSm2Th6ZFMwaeo3S9PVJpz6eXExSEKKnYCLGhOKVSItGLvDSdeGRqX+w5AMCOkP/zUsSoGnoS4hZ6RJjxFQceAaiRVwNRjFIWRZ1f+KvViNkixbOxFX//KB2kVknNEzRxFagAFbblqMQgA7dgRyToCXyj+QA/QdE3xx83KDMklky9xIohKOHJJBQKBxBlBJL1uGLLgULlwpEDxzypEtkjqAUg0q9wYa3N8VF6dbUiB4WW//NQxLQY4V7qvkmGlANs7ZwWUHjyr9rHv1IEpJHnkFQkGkSSlABduUfxeSIwyjLyYTEjZdyMQ9CTkAgMxle6lBcM1sjaSUDC1Fn6QXJyzhmRaH9yNAK1PWTtU7ZlufwSRN0Wg9q4Z6L2AKQ899dazpOEPyvbXtHf/6Ywh6v+rjavUv/zUsTFGajy6fYJhhq//ebr1Oo+Q6n1kVXRogZUkpLf4pH+UIY0RQCZtLCmx/snHG8mUhBtC03uSVmZbINK09FqTy6mjsEL1JW4bD0Lws6xxBxMTnY4GRY8A2qVpSLpzz2XtAgOOQlC1nxNySCX0J8GyFJFi1NNsyDGBinQiWYhCq0Q//NSxNQaSaLZVkmG60q1uS3GwcJKoKCeRCQkO22o4CWpT4eAYYseearFQ0/NKIc9M4DUSiCrxOquoc4iOsXNoM47Az7xKM5WNQ2XPd7DUeOW2lKJ8FIxmhRi8j9gH+/J6WzWi5S86bf5SpjGgxX7fe3/AnMRy2vcBMqIpHeHALW/3b//81DE4BnZKvY+SYZ6/1+8I8mAKTk/kwK4SxUqONCV77tcDLQnGF0tOMM9oyvmgbV8DxHeJMUy4OOmWA/rSMlUyMIDT6GJzDT+HT0+sVbndm+3+H9yrH5SUvpWQHYnx12XYIYaqxiDdHf0e+yFTyn0cgjNNtJ1CbZKUNES6FFCNbTe//NSxO0fOZrmFmGGt0NuFQmTKsol1I1LzuULld9WBNFlp891zKKiUYXn1C8JyjLPUZebpeKJNU49DirAAA27PM5J0Kw8eucEohj9H9FSm5TchLVssmpF0uRTZmL01GqL4KUYlH98bdfhzTGkJvM/zHoEIyAgF//yP/wPcl8HLkMhlN//81DE5idMFtiueNNa/8/CORgaYFIk0pIfP9/////+cm4TF4Npbh41FyqkEklWvcgsd+NFb7HUGQWC7ITl2tCwfGj4i7varGU0pXJbofCVDGq60JC0fm7lt3uP4vrnmid4JSkv7n8+6fzMoImfyMiAeB6SIp/ylmtojJBP541YZ/////NSxL0ZM+bhVmBHfP////+r+djFSD7svVhVzJAYrSckygOXXYomlSLSQiBIIGE4yBaz1S+aa0983o5i1scic7NBjy7SWWdBkXW9RtDnUlRVbCVAnFXCx4kK3uQfS1ZMGEg+QShC/urcQlRcmd19LO2sqsigshxOX36nXSFrHWkltwD/81LEzhlL3v42QEfTAEwIbkv/+ZW19A+5KxtvPiMdxJxx+OuBCLzkjGfPf29yGsUPCI9uhtG0nveZ+v9x29AaY+f2fNnO7TlqlWYzoOo4sfu0lV0dVLQ7HRLmVDMcGHOr5iSJ/31898rnZP8610dmr90RnjoGCFMOIBiYL1GBryWtj//zUMTeGWDu8hYyTGb/LyGG+2qEMyCa0nYrpb1f9mkpEo4LWJZ4GvUP5wfdWXOkedj7ZdKDwYVsZZEJOrvLqkhn7e5o6e28tzxK4zvutWlVcoWzAhkfijyyoihvf5btrb/Rv1V/3Ljd92msPN0ogmNN7XRqTkU1jtbHHHOZT1HTvOP/81LE7R9bYureeYTZiRw6+uzLDznuqCgyjAAAtWv/4yyPtSSTszE1x19iaxZgFljUCfOSfLAyauJxR1HxUailCaCaV4k12jmOyurl3WysFWyq9TJuNJIoYtS26CjFZ8irSvr/uYz/hStpMJBP3S0rdJdPlR/r/9St+srfQMHf8qh8qP/zUsTlHrNbAt55jt5qr8jVhjMwO9uXS6/YzZYDijOLwgn5HPobTtD/9kunfIao4hzo/V7DBCzVyLvQthugnojcbxmp0ialc3IYWzWmi2BwihT171goASi0gLoQwlOZXNW/b/rStRwTPhFm4+t/MOVJ816OTcoEC5r39AoA8gTDAPgD//NQxOAbS1bV9npEzHqXAAAAGOWf93Ylm/V/GV50kOw52U0MQFESaJy1+WH42Kd0A8HpZwcKD4OKjA9ZwKR4OiaXIGDMk4USr4uaW90qA4Dl/lcYY/e9Jx/p3WbB0QfIuLAtD05L4sUGpvT+hiMYXU2jqVAgL2NNsyp+6EU9DBoTbv/zUsTnHKo/Bt5gxVKWPTREMnsevV0/yxLU890GBdv2Ko/QxDyLuk/maFUmjrAABbbDiuE8Zj0/Kl7kJZFfjIdcMq1SJk5RrBA1XqrR3dSUpQhIpKd52UfD8SuDgXSJCcYyhwkwxrkEKGT7PdHVbnK3V40oFkpkUyY7fz42qji1DFmC//NQxOok86rSnsIO/drXW7//2Yw6gl/lipBX2oF60ZIOUnJLfjPjohJqQ0BG6JFGmp0GUIbEIHNhWNSgZRWCkMHQ6YIed5HLydDagb7kaa7sf87eOiYUohJocCIFB0gEKUER4lMpuroiYCtr2/SCL3XVSuAAISFhxM5yP/oUKJAbhf/zUsTLGaJO4fYbBh5ShxAtwABpyWzN9sweBk359CsLWqFC08TiY6epcjnVjGvcLTKwnLCEKtDq3c2LYyb8lRkB1MO8ItHpEhIJ3FEZ2GcepLr0b6ItDHLvTbJQlJUZJjvs6Ozsx3rlYlnZafJ9DMtuXv7cyJBk918442Ny5ex5wY1C//NSxNoZ+WryHnpGSlqAAAG25dly8QSFRNBY6xR+S6AnKREYCDZWTEgExMVSorQE4U0YzNTO2OXnw8zk+wdnbx2mxG3dm5sJKDOcBCA1RtP+Rb9MysluaRGk6VbRElb7dOvJ0bb7ypTWvedly9kUjsZXRSuqWdFSxihg8soQKeTCWbX/81DE6By7Wt1WYMUWh38qiIIFZJKWpgiw5oqEmDiKwgQGQTTINSIJoAAyHDPkIo2NWS46isLKWWgvmy0FKtCDxCEk5uYmUEml0iuH3OkZH556mRluQs5Mm0+6cThaFX1TnTNOT5//9OehO/Rc4lFioEGOGiDKEyFnl/7Nb1VvQfaU//NSxOod077d9kjE/0S8naAAACltvz21jpHlBU8RRKLA2BoIYfiOGQCBqR55IjlvZzXYoGasVKNFRqmT3MWT6/NXftzb/r3xLDkRpSl60tKe1uWooGixoQ9/NufJcKllR+6YIt1GyOLmiFmAyrcR+nD/PNCHKK7Xnj2FKn3rnFfLDE//81DE6B0qvtn2SYZ6TfRxe0NIOirKE/CdnOpJDFSSHqdOINQB3EJNdGNCjW0Y5uasP9LH6npVPIQLlR9jJ4tMoQqIj2JMJnyS0k0elzFkHyGqyb6M44VyxGFFdSDGEDvdwXbRy6iAAApOTNJbCcP1VVx2naUbCXuw0OHy6i9Y4ptr//NSxOgy/BbZ9kPT6HAhz0TnrGRpTgcSHyONFETqHSRT8kTpcUns6D2yuFyKvCf3h5lfOTOFNShHYpSP+GEOriHMM5VM5EVMLpNrnIWtaRWTUBRKBCgMhQMDwwjxgR5KU2U0bo5XkizzqyslHxLpf5dPYTlG9Zkikta3zM2vObF4mQD/81LEkiabttnmYNM5UvklWauyOi0V1zMwVZNyxO/MWHBXZIREruFHCNBc43rpfo+i0cMb7UjN4XKLwppAj5NWEEbLlKMLEIInn5+3ahoIC0UrRy/Lqw6rEe5n6at/92RH3ZKt/+qlv8xtJWDFeMT/+e6n/92Wf/kl8AAIL7cGxm0HRv/zUMRtGKKy9t54xPjooYkunGAXyLbxMHTGq+BrTAhyGpn/0QwqwMhsEyYoJa7JnV35knDsHpuuKLMTCU9SiQI8YeGoc88s2/v98vNOPZumuloIxoEDwacgjG4FQ0i51Vd8wIf////UJxhEc0eSQHAkGcAAALbdqpnYag8pumfG+nX/81LEfxvCBt4WeYbQXErFxKPSKOI2WW2rggYZguAWu0MyYCAQg6CSEKTZuSW9NTZnZvWNMjKBhRy38ypLo08YQkagieNn2NDRHad3Sh9pdaVqWHRf//+FvLkIYdPGB7bjKirRZZNgIAgAUcdmlpnEYSERFUIu5vrmnIVmS12IkSJbMf/zUMSGGeFa2fZrBlAqlNhjfUkk0FsvqTWT4Nz8rpIMBlbYvcpkPozueYMgMiakVPX/7aFRW3eTVet27f/pViX/5zHBtLDtu5i1f+z+FQgs8gleBlqCAVXqAAL3JbukvXYjSPVB0pwJiQhwomm0qOozrjkb88g5lDro6VQTphdtO8T/81LEkxoisubeekR4R7xpBg1WGke4suXtfoMMBNgGMhMvsLv3Yo1Qu07hYyZGdR7ZQlXcQCR0ct1udQ1jv+lPk9tLLUmxU05SFaMAACAJyXb28WQnjlvl/KEmjVhNDES7JYbEw4pHNPq7Jhp35jn3dr0jR71XooFXGAqsHziTDhUlCf/zUsSgGZE63fZ6RngwSh0XHMohxaRXoOOtaVQeG6lpF99DBMxV4oIRC4c3pht09//u48uTGAYeFZcKwkrIABCKUbgnjQOEbcFAMn1hQqyxR1RNdhI059ZOVVIH5MvatZUE3loHHUGIzRWq58ZSTcl8jlaGmXvL3QpDlyTiG0O7//Pf//NQxK8aGNrivnpMbP/06WNdJXX6EUSGTRAEDI9cZT///aAjiaJQcDhkQ9BQgWtySflktgwuNACyI8KrCJx2IHob7JlLT1s5k/3bu+P+fnhHfTeRopAHIwIDtikcekl4NFUqTLkpb55OXgM/PoOzZFhThgElAc/xZnCTNUKU+IhoIP/zUsS7GPqy6h5IxPYwNC6Ws///bNix4JKkVeBCAqXa//l2ZivF1EIlmzqNC0QI3RPaf7MGcmJwrDk6TWigsHGrQyi+eabimdIQMuPOWXX4SoZ5zJlTrkVmbs/mz2ITylTLDBQHSaSSFabUuPgcLtrh17OuFKzR9qb2/xQoUBcChYPr//NSxM0ZEwLtljBHdqQACABbtt/6ZJZREwTMMoTJxGsklyIlmMgADksTV6X3NFIzeWCw2AWtCAjTzmpKtyBQGyVQBwZI39pmsb1govt7kZZhS/DJ3BrTA36bbibld1rfP92opM3/d7uNFDpoNKPX/+qeu8wXEUG6+XfYsWQx+pkpoYv/81DE3hoCHuV+SMT4KpgHrW5Jf2bJUD2hNZgsWvsNkxKYPNhPP6WHxqRhYglCaj/YeVZC/iCVW7e8yszNjaR0692Hyy+0fDNysmfm4vGyUOXO2qq7ZmzMqctz7NjfqiGepDjwj8n6v5msyVUxyaf2nf2d+6tW5lb/+RLEGrcKBTTm//NSxOsdia7ePkmGzeCCavUkKpSbll2dCcGAAKY//EhgQzCq5ZNFp/V9VeJAKascZCKVJzLlLu5SqtnkOuV3Jut3W+ykWDTNTUw8wjgfYXFgQe8QIDseWJAsIHBk4aYsqGBwOhCTmLLN3hwtfW08nevXe0YwicDSzveGkMDQsFBUJrf/81DE6h2TzuV2SYTedFWJAggFbkl2pUI6eJaGsI0x2cqnlYwI56XysBUmJmCZFLcvDpXJqsOuZf9MZiWVCd6b17UjAlNwCkDe5eRa6pC0YjOnblVFUULhZZ1A8NEDZNM/MVidMJpCIkQfLrEr73WrvTTTlhdss7YzZZamCrAeBppI//NSxOgdCUr2PmGG7tDxMetSiAABZty/Q6dTsVgutjI6w0T0TrCSoQhjY9N6rD/YzNMy+Zhc+HNGKfVW56FIKdbR8zD5v3cy7AUEcpQjMqZ687mZkPrTyKFXPmYh4o4hCoTFWAU+8YhUUAJukaxIrY2Undm3oJ62ymeHbayFF6wr183/81LE6R35puI2YYbuAEi1y3blwSNFSIsLvgPbVbffUuJhcxIoPMgxUHb1O0t7kmxLUFSgfro9F6mMxpZvllxISh2hM8zrh+4lZnBtYsMm4CvtDW2/2Go3LmYbQkqH2e2w4JRa50ggTUzy0ZkWBXaZ670/ynDIytz+nylokOodZer+xv/zUMTnG/ny1fZiBwqN5n/2yKWR/jWLyaQW+S71iPPtUpWKknhaRJDiYthNA4HDDF2v95zsuHmJdyrtr+jaM1Dr6qjJDuTNWJgoRsfDkU9iBAITBvB+mWThN42JVUTomMNSbIoqIiECz7apivQbWfOJvOuc30seC8WcBEFS0xeABY//81LE7CBD0uYWYYa+DCS0AzZMKrIkVrfJd+yxUMGXAbAmpOlRoQiqgqSg1qUB59L9KjEjDWTGV3SGVJmTKZO0XpTpfDcJ0jRTzyKkhjF3sSNsGKoSs8gUio0QOMl2MOvFCEBjHUGbUxWsVgW7oqL0wK+USm40zSMe1b27eirQkAK25f/zUMThHEme6fZ5hprWhLgV4yzxbPDpIGjxaHN6IRCWJQMkZE5Gp1GfNFhRRWSNkTnSZSNKXXobbPc1dd3dtAoKBgQxczN11ksfGLy1ygneKHUjBPKjbmt4e4UkLIDD2IIYwnWRcRU8mjUzcSJTIzkFZeYJvEje18gxZSRJMEjh7A3/81LE5BpRlvIWYgaWOS7JEgzXy3fGhv2xaCQOYQIjStMCaDDQkk8koDu+FNCW45JDYBRyNnCouYXc+DhMiDnASJKfa9VycnAyBCRsipqhHE4Wp/5n+ZHEKHvcUfDcunG8xITs78yHmiudeIssxN8eoVpe3v0e/NvObTF//v645D5hdv/zUsTwHwHS3fZ6UD7B/5U8jRXxEgCWvlu/soFg00qDkiwYryzZ3iQ+fGd8eADwwaEEZNknDOfMkNj+jIRIPapEoJNqrdjfF62olKCSywzKa7W/tWjyPVGRnb5PYYq2Rat0ttd3f3TZjkeQ3buiUf6vlY5EYdl3rSmeZAEVIKQHBrKV//NQxOoeWkruFkmGP/GCVZKTku3+Vi/ySKDuDqtHVcu5Qkt5C8hJ+Xqm+AI8ciXtiZgRMkFVwTMS6VEouyj5Ae2ceHDZHhGLMeksZTIzQDCC8JCb9TKP5twjv99L/f/jGUIEsNv+58ur8nMRBDGEkBmbCgfBd50ci0aHDPK2mo584f/zUsTlG+NW9jYwxU5ZxcoCLgi6tcyUCI25b4SXQIB6keIh1A9kTW5KQZVnCjydJwcQkxCtonRQxWupsGNq8f3L4SF9M7nyLneFekcyJfbqDB2HzLT5FK6XgYXLIxWUj8g1qGtuUHzDAmGI+d50Uho72Cr/9Q0Slh4GEA1Sg4PB5Cqo//NQxOsfItr2PmGGyoAFty3VApiRc+hkqRHooUKRUiEagGy7mSSyfE4ryTUyM1IP+tJTUrXuZ38wuCqT6IJmOXqtnfxCF12QyU7lQgxB8y8k2dEYHEkyvFyLMzXy51CFUbkJPKTNbrWzUc3ttIMDieRa0XeuRr/M/XQvev0bf8Ojo//zUsTjGwme7hZJho4w5JGr6t/VqRIItcl267Xtk8PSNEmjEIZe2jWYOpt1IBWwKCpsQinTxmdoHqQkHMiLJlQHTL3MOTkwxw86VlThUsqfgjpXLQ36exFyZiMxFZRF6GJWa//61bUGaKh44wkCJsWp0VHOsVUqQ6VlbXGqLWXREAG3//NSxOwfQ8Ll9kjFXyXMLtvYULLGo0iWZTMzJ5WyM4uTO4oWwnDEN57SQiFECEE0rMQ7FUrQNDYaFO3qIzL3//oRcBmK24yKUzG9sA/uwyMuwULWFG02DK1cYefkaeWhtqZzIrbCC+0Y6GZWVCXJWIen9+m5khc+lofLUz5fmpkZt9P/81DE5RqqrvIWSMT6n89n5y/9BDSIEKw/PrP5vJrUkBVm5cuXk4/BluRcnI0gKDIllXpcKGidYsb5Qx3iYX1k2PeUMmWXB22mlOv7mL9EMtMaEwOfMmBwq14ScgclhcqXetVu4cB4oKgBr6TqbzitXQtSEOkzO1jGSo0ROehe9L5a//NSxO8iq77h9nmG34oY8FwaFFJDrllKsRRGtclu/gCw60ykRKAqtYOiRmIjj2KVhZaG/ctp7G33oWpDWJ2vW1Sdft8bN795pntx05LbbMd6ZvDPpE0JdRIFHkLPzyl4ZMhmUMMXJAyh6VrZfTDZ99CywRMDnOc0gzIMi7xdr/X0eob/81LE2huhDun2ekwyvLrFqIQAAWTkvxdWCjetEgbHQXFCBCAgZESw0BROjZPo3xenE5ScqtMvUgv9kFIASGgA6dGcd6pQO7EQsMO4NopFRUV1OMDI0ZE3JGNpHD5vC/60b1aqNoY36idUyHRZ9e6ky5TqUoIDAmNLMQAhy3lZu5R/Pf/zUMThG8IG9hZJhr6+hT62iEkA3ly+mqrJABa27dVDb4YEktIZQCM0usGoklok5uJcRzCEDKobhMiBUEwIW4+9OMhKarGNFR6sDVe1eIsSCQyvOLNh6MAqLXEIZFm5/6d1ae+oNg6OB0eOPuFc84jFT61WeW+WcsN13iKTRYApuX//81LE5x9SvuH2SMVSz/DgK3Lml29dKiRCLHVojZGsHgxPWNbMBuEwuUaxApMjICGQUMH8jFDM5WT9vyuOIPcBaKV0xXoWZrCOlpqaw+vj20+/b/+fNP18pUdEJTuuwgdT1uB2WEYKgVEu1h5YUA17TwvVReEwHzaZDr3l3l0KMr1vJv/zUMTfGSl28fZJhhqIgAgtOS74rR0RYyJIIwfQF0jPXKQNkooJ+jSPRH0IyVchfBiujegzNq02OqRamr4OAThhNVtlJd0NYR3F7GplUVGU2+ne/fvy/GUoZRIS3p5xfY6plNCGzOsyl/nVCWdKM3b/13qRnTf1sZer0/sHWGKTWPv/81LE7x56RtiuekbuNCLFAAW3JcSohDLkExGZbZOhzVGdKg+VEBKSBZZ6fXyMJkHYicgR1WJEmhP6z7Mc66KZJmhII93nb5t3bby8wyPrQ29r9g+sQKzG+v8QWuCX26wj81+91j3kKX+Kz/aw9s2DR8LHP9Wp//wPO/08uqttWurb9f/zUsTrHbOm6hZIxVbJ8RX7dffvkqgAAWTcp2HvQyVyWZautbPDRaK9J64mnBsu9c+2+cQuMrn7PeYG4YY7RCsFK8eRs8n6jpHsjqZZbRQimrlw/M6Yog20sTbdsS5nRSXDAyZLKipRbKGb/6aBqkbPd6bhOallnsYixIIBZyXQ+Xp0//NQxOoe8c7p9kpMF7S0etxpIBQfscUvq3h+ZkH72yVSC4gVuA85MGkhpYLmLsOKZIt7uyWme74HuHhZus+8JjdLpGfYWexpbId+2SZ4vIz6RfMzye1TosgVBKNKmSOSnSJhamRSlp+csuSovvfS/6kRD63h2fsKL5Owil/L0LcZ8P/zUsTjGTGW5fYzBlrqITP5earmQFk5L2BkJjksnCBtKYerz9hP3skJsU0We+HYvVTeSHibbkJqF1mqnUPt5tN7e//vPDImgsJGkg4TNu0oPJafchlYIKvml+XFFIaG1AB4Ge1ii4uSiwXcRUvuc+fqfs7bpVUowzpqrAAAZOS2gSJw//NQxPQg09Ll9mIG9/BRXYykfCcXldjASDMpA0Tg2H06hLGK1nquQnl6QrRJ0YgkjZw5tJnJ0hDn0norPFwBY7dMzPc0sJw9R2QGeS/5EfDU9jk2uf5Snbm/c+7dIm4GZuyPTJ6yWnkpYEbMPGInkFy5rkMYIoYeLHBxUzmMxeW41//zUsTlGZEe6VYbzDYcBO0isOwxyRIBZyXYqW8xgQ6JQXbAZIdEQeYSIjU7ER9dvpH7kYPmGcySSRzlyuGI4/WKT7pnpTPxbT248Mkc8uvOGX+tyKHNf/9JJbo7sRlD7nn1vHFo1Qok4oAV3zwevACW/D4A5zP67vcQDyQeNSIoOcQQ//NSxPQhOvrd9mGHJgGm5d+WvCJyE6JA0XUeZWeLk5KI4ENPrFC59NJyssi0gg3I2UYipIPHQxsyljtmsLrMN0aA6RBS6HaUQQEaschTnXRGdqOO3pmlZULsQjTXTSQ0zabqtbpkZZVsRjMhC20b3f+dyvv9T9n32l68/KOrZRUbazv/81DE5RsyTu32SYbqqu0UWJJyW7nkisrKHHCjC+hOBph5BzTWNhwWVCVclR4KOEtN7EYY1WJMUIUZRQ8YU2BOK8WfHJi3JTkbMoVYoQTZkh21ATCnFRivX4f8Ljd/8ltJHLC44pUuaDpqmtLNlCeO2vd/+73xXnt59X1T/P2/on9b//NSxO0eG9bp9kjFTwm1yp7v5rmtgga1yXf8rCWxQlXln4fA1UhZEpzI0dkOQ8laAYsc6FBo4xYYSD9rseNmv5kk6nHXYopuSReHbsf+SO4UCixRKGh8nYHRciosSRAoAMsUQue9N1VgTQcUxbKeHHoUg8ligMuxbjMRkYqgLoKshJX/81LE6h66Yv4eSYaLwAAZuWzl9h7kixxCQwOLnlLqJpEYHo0XQUq9D1IJEy7g0cQilAeJbmlqlNqIPs3tYyrmhlKV2tkvTPKeHBKYxVuNymVfarLrCM351xVZoi7HSqZ8RP3OZR/5/TOe/ylkXYh6PnWaz84XfyoY1E5AmCYleUIlSf/zUMTlG5Gm+hZiBmpXvIGprvuVjJAFtuXeoqjwPzLGWyWaM2ggYHhKIiFCick70OjHjwaS1NiyCfzajMlOeG0s43oZ1WI9880XRBeGDP0rIS5R6OHIMIERopJXiug4McQU95+bp+0Y46XeRoR827acrDTySb+EBU6XMnUDVNeqjAD/81LE6x8TJuFWYkbuAWbluS0PQVlh7jIevPgJDwYHA9aVx9RB8MnUloSnyViSFVqnQPigWLYoxvMBw5CDzftKxl8JsACCRFRRCPXIQtuBPW2/TxElVfP/26TIqOax7/nXm7/ketOlxj0v+RF5ILysGBPntasTOJnDP0jDoufTxMk3ev/zUMTkGsmi7fZJhs6pVl6WWChKzJQBJr5bt4L7JHmo4tuCyzcpdyODUGc33kltzb2p+BCLnljb4eMt9JEY0N3JBowsWrUG89SjvB0OByMzVaqxNmLlLp+rWRureqa6sjiDxCw2aWdQWQMMzNLRO8I+mcY5mUQ9xZMdyCt2ysiAAbb/81LE7R+zTuH2YkbO5cgKjaTJGugVXFIoPiKBOyiB5gJCYTEGtxQu1kqTyRctpOXXLW5oeOSFFJ4hlSn5h5fgXSlW3qryORZZkNCCTistLS8rcjlgXh1KVrtt/+FVUjSebllvi7stVUnoqrS9H7UtJR6GVfrv9JqybMxDmIh7uiPujf/zUsTkGmJK+jZIxU5PcRUw6sRVO3JflYQCAWTcuYI1CWBRGiRk0CMR6I1UKwqSQEYBGUBCq4oU8i5CfIDLlLRZRDuVFuZvWJTpaKHmwhFFSXXoxKoECB+zeRGdZKeMEDK2rkTtinBjFRWDYGYOICdBpxMRkEMa08En+9XQXN0+mh3y//NQxPAhG67l9koFOyxy8wKqsIIVZuS0igkSgOLmhPMfIQsQkofSNABMlRUCDJBdYghNHP0jW62PUnBQQppuO7ndqDd2Y0VYYVQ6mGwgibqwSA2p/ceBY0XCbnMPIDhEqcPPS4woUYZJHhZpZGhrHjQIME44nefeQQK0jp6j6qbJXf/zUsTgG9mm4fZJhuqn75GokAgFbcl2MyZVyWbsp1rsz6eS1wbquZG+CfhEpyGtQ7mYdsQYcRRLlEoczXLmnupkxublOgbrsz2ztmYi883W5lBp6qBvRXkgYBJhU2SC/0xZcv1125fWUi85a+mqLzCvjP3bvm1//P/5OfXzxXH0P+L///NQxOYcwV7l9kmG6vfy77rcA9q9UYKQSQ4IQKycckA0mKz5A/rxz66n1ctmMKgVT0aWCX+F1BVAgUoESZiPDqCPCayTJtUH8sEAFUEuURpPTSZniGzE5UjUekBanetcyarmUyzQXlMp10stzC+rCisrU30m3N4O9U1DVUd+wVfXnv/zUsToHsFq5jdPMAMLnW9a434y7zDhSeuIkKnmz8Y1bWc6fySZpuFHefKzSA+VLJGV7VWLSSaNrEut+3hRs4+It4rhPqd29h2zWlfmkKFjVdUrWuq08OJm242bYiRUWdUwCkhaObu3lJFqsUKFE1Im2P6yEUgiCIIilDn2ZmZgICEq//NSxOMwC0LCN5h4A6qlAwEpflxlVVVS/jdUKqt6r//9VVVj+qqrgTHvBUFQWlQ1U+CobwVBUGvyoKswVBY9rxKCoLB2VBUGj0FQWPVgqerBUFgawVBp8qCwdYq9Vayyy1lYKCBhA4OWVHQ//KuoqrKkQyHhsYGzpw6cXUXgFxUVFRX/81DEmBvxmpYfyRgAFhb/+KioqLBIWEgP//+KigLBIWEgqKs//4qK/4sLKFxUVFf4sLCwqKpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//NSxJ0UKPk4CgDSPKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqo=",verm:"SUQzBAAAAAAAIlRTU0UAAAAOAAADTGF2ZjYxLjcuMTAwAAAAAAAAAAAAAAD/83DAAAAAAAAAAAAASW5mbwAAAA8AAABqAAA2ywAICgwPERQWGBsdHyIkJykrMDI1Nzo8PkFDRkhKTU9RVFZbXWBiZWdpbG5wc3V4enx/hIaIi42PkpSXmZueoKOlp6qusbO2uLq9v8LExsnLzdDS1dnc3uHj5ejq7O/x9Pb4+/0AAAAATGF2YzYxLjE5AAAAAAAAAAAAAAAAJARAAAAAAAAANsuummqHAAAAAAAAAAAAAAAAAP/zUMQAGgE16AFYYAB+3gRMRQd0GjNLQFNfRraBpteLUAICAB1Im5bXHcsvuztr7vz8oBuI6s4EAEAaFg7AgIjpLBuDcnxnANy2kEASIjszsZn/0WHCxxswPKr16++UX3xhYcPtlDn8hEjgf/9QfEAIQccD70EkkkkMJt0lW4L3l8X/81LEDR2iFsjLmGgA0tCKyCdOKpxcjurHiJotwGgIkdTELmG+mpgnY3k0fTIYJBbuPqy8F/CSDzJxhvjjMh5Gh1bm5fHI35ilNC+5KHi1Njsx/+eJcuFJdNM1UiXj66v/6DUE1qmAkGrIraBw2z/PqdtdQUXepZAAzW5JfFUPsVBcMv/zUsQMHEEC6XfJGAP1oItyosKLRRJUafAZfSOwujBTAQBnEGCcQMswZBe+8QWMATg4gkVJDyqkSo/TW1Dv/5jXrQzf7p//fy6HoKuyYteS9jpV7Qt8dgXwPigeSfUBzv/3fC6xbnxlv/3BkitWeqgvW6iSIK025OcDsmOHzEDx4veL//NQxBEdwV7iFmGG6xB201e0eKnSxFTjjcNktlMnqFniZhtyYwUAwxLMSZr9WG2hwkNuQpfglctkW2T88QI7+d/A2i6bW3sjXJ10D+/Wuvx/b65Z0edf/nXxNQ+v/fW74F5cWdejaluotWXm8bC+Y1/4CK2AAGcm3rKewf4mhf3BWv/zUsQPHclq1fZ5hwR/oYSyImVIsHWh6+ekk5yl8lcFAnVHGnRkIg5M0GIg6MLpFORk8gxoHoghbnk5YDq9KZEfnPCD3osyHhO4PEBz7W3uDbwNC4ohZsGAixpJKxIoVDSw014SPfvdljepMobWdfDTzq9bR6qKEAmlJb912yjlHSXA//NSxA0dI+bp9nmE13obXhzqz/DmpltmavTF0wKagLpbQoindVdR8imxu+49dXpI2EMK2HN6IeZ2IoDZAoRruyUQuW32+x9kIyWe3Z0MjkVRY5UKrLOnuz1I7Fq92zt/9Pv920av/9UrzfVfUh3UioLJDCp6yIBFZSzOROywhjott+z/81DEDhlKWun2YMUuI1o+Q7cth/PYxqiTMv32v8djpQHXNzBQpN9maxa+PMuA0mV83mVLs3X+7ORJ1RnRMlXuv/+Z+p2OdzsFB4SE2Cl0tcUlwsUVPa6//9+GxqZ5ZhCnljr11YAgAAKeHE704VErk0gLoHn9nVq26pg4o3l3Ib7O//NSxB0Zi3LmlmFHXdsqx7tmps65jskMrfd601R02Sj39dzdO7/2QqBx1V5Tn9PsvtnS+rVMcIAKpznER4yqLVBAjyf////kgQkItHDvOj10KDQABweqCP/ux80U1ikFyrGDQscIIAgLi5OKk1iYolrP1Mznm1UjT1rvVnTrovMrfu3/81DELB5DguCiQIdT7WoyILvbXnNLUeHFu4QnohTn2yXnLmV0Qr2J/XNHd0rnYQH4c0KAbjypWIAAAASyOZO74cDN4BnCc8IEFuaBEAL2eTCpvZb36rbkfnroCAACeI27qWhwgBkQVsQHG2mTIGLQgmZr7q0zuzo/FnV6cvLKRzLL//NSxCgZa/rh5jBFXcyz/9r7fMKWRnJ9M+HIQpQhDNE+TCWYV8VRfMMwqXhXykI5Mof0zG/lYz5Sylb6tBgitIKoBD063IJMmHBVhRARIBFO7/bpGkR8nuGnMRMEsUaRecQeDaQMCGrdpMFIpnyRzZxCls5dw4HrCiLMkp3n01ZkTkr/81LEOBixmuLeSYbMeXhElPOfmX2DrDZF7w6xzhKtLYDazW8Y+MICyXFehhVv93iU76vU/Vlgac0iQrXJbb0kDxCdcg6wshorsGkUMJv1U6qpXc3R3EGBBwIDFtpl26FKddGXma0M+FMgtKXI+n5H0uFjgnSlBFdaJMLoeVQ1g0H1JP/zUMRLGime7hZIRuJQMC/Y1aYBSfe6sLoBDpIABx/eQvVnCc5QUZpz4IL4BVnJd6hQS3CwfG7O04hBJf3nYOb6ax11Oo/ZT4riPOiWpZoy8yuWb/Nfz/ImX/L61v+Rl5SiE4UrqWtbw3/klJ/+R9l5o75vZPJ/7u+dvMtLbOekyNf/81LEVxjL6vFWWE1fmax0ah5fAZYLiJ6BVakigq25aLNEgQ8iPgDyzsbDlqORnfqWT3RNHck24ohNXzRd+hhy1DG2Axs/TR/4jkcRP7Lr/OUQ2evSk+kgs5mR/Ef+2EWd+eX7fe0/h+XeWoX/emdYnkgxwTlifa94QLkC4wKZlaaaFf/zUMRpGhK66hYzxjaAAAAAnLhFpjEU3xA1RSFFZjQDqnrO/OJIktTCMiPlxkSic23tdZwbP6IAsR+ajqgBOCVx3cvhMTiFgswBRdCAZPCxYgss3aRchopfkwCJKuFCDMfXcGYVTA49gNhs+MOxB0lJ1auNZoWlAks1uS6aeJCAGRP/81LEdRohEtKWekbMLroGSwNbAomfSKVM8VIY9+zSVX78tRuUW9HXJukNd0XkfLlIrQjGlRU7WZDphm0XccDghYyFjN75Dgqx6hk26DcXONEPPRqnD6iYuQTsCyOi/TuoEhMhpKUFyCqAqf/20n3sVmKUzUEBIcAYPiGsJUu1UQwmWP/zUsSCGcku8hZJipqI09tBAo0nNObGa2kwY7E9RxAf8t4dStFOi0SnrU58Isv937nl///nX//On8RL+Wg0J3MARHQwAY+nhERK7cfMGHNiGT46Us6vSHggHi0zUHB4d0+l5eSgmfDgcqjxeYLVxgeL2zPFlFmS5eY48OFFYCuJZmp3//NQxJAodBbYpkjZWO5Ls45NnP292hIUrDszvSZuvqAAVdM6tveLmE0pH3XcXlpW4TnQKHTCex89SiKyxpY04VY2cUNrIVttlViMz5S7TaHtyIXSa34y0VcFkfnmPkV6SKCyBm51RcDivtEPIClJdFcEYTK39mCzFTvuahqws7NSr//zUsRjLVQW2UZg2VTKdNnj9SlPTNZfGMhK542rXJoU5XLpVQyAllZxXXjmVR6LpeOoViUfBLlhluOcpRbbq2adhp567BGTV6R9k/ZWFjGROeVLyojfGwUjs8nOCQlPaoRBMBGeABu5XQcDHtypC0TmhPBVnJgScvku7N45W75SV9UU//NSxCMaQmbu1DBHUKNjwuI0GokYmIlz7IkvmRFX+BR55zLZFwrMZblnBERXvHqZbcEZskoVKoEc9LHLgkDsrM5dZ4wOEbNUhq9Y9SVsFkzyB5GVRCFMW6gH2vmEiyJcyJkc0MEpJ0XSZdkLzSJDvUhmbJnoVl62LClxfH75e9WeCRn/81DEMBkSPvLaSMUQVJVan73tczf22pRpnsskqLV6K1L1IoI4IDhkmhLCdYTpGsFmYUNqMqO0///egAD13paCxKqlQBQ5m7ZXJa2YkFwDsMiWQ+sxAgFlNtIkhfLmUMaDFbSbolkFGfdYYhEz5+90Iv0RiyOVe5VSI8vh8Vqd/8/v//NSxEAaOgr23mGGWK8Zj+wUdJVQCAmwmdYWXDol6oKvZJTpFbsRCVkRct87+jO4dQFH1gI7qJSek1JLNS0KyId5xBd1jQV4S5tMDA6kFgo8I/0sfnZRs+7VUr0zbG/UqV1dipL7+MdDrgsINDnH0DYKhw6Gjqx50HzNzIWEZYMkUnz/81DETRlhIvoeeYauGimKM/kiEK6J29P6mLEv+qgPihsOIWIhdYWQFWTkncUKT0gwFhTpHKgVHJbFUcVfqTmqhBtyrSy/1PcgS7MRRtAJUnCQl9zUombqXp54bMjxcMMVSQALNk/C1ycotDWBF5uG6ZnRmyQdcXP/+tVhM2590HR4//NSxFwZMVbl9lpGPrAcXBJixA4oXfYQACZLt5q0mFQVvnKGyWDOcaBFATllgkZI8Wb6sGgVP9AugCqXag6fTg0sdipqR7Ipmy31PQsEHpUZspfPRDnbIS1abI93IJrleSOV921BpzjZisVlPLS1K/u/FKyf8zMPh6XdTuoViIIQYsD/81LEbRnSSt3+YkR4kyxRcBqJdDyl8SqXNnXFKIRHWSKuJq3+oXDtn2ABJpZ0UBY2QhgxuM2YcQVzpftzdVsSdyXzSq5OCM/yY20ysi/eqb+2jV/kUIKKLPHkPj3dP////+AgA2L1Ja8YggqDMAAAlbdR74yQFqUzY1ryzuO0aVWlKv/zUMR7GNpK3fZgxTLZ5mIT7syIfZcO3uN4Tk3EtfReoa3oDyUB6irwgdle2ac8Pu7jNma6jPGqzzm7aIhrt//qY3T3/4/oCOKHV91Trun/8nKIim6yXagHn1dGeOpq0RJcUlHbL8RYKgGfY5ZQQpOylqhESdpx3RybPz+KzcY0HZL/81LEjBoSRtaWeYsozSlEiJkVKIV2IqMqohlRjyYo9rs7q1KeokrGIxKubiVHZfX/v7PZBdqTMZiDXsCysgrwk4kx1l/Kb5fJy7pyZdIeforNgEB1RNM+0VA/IKItUNW40AHGliHw4roUxiKdKPA8okqmBXXNHEotC9wwzYi1W+Rtff/zUMSZGaJu9h55ij5WhWVGdVpQXLqKnsjLqVEHla1rrXR/r//pkULWXVOM///++IXKDUTVs5BpMl/BCirOtNdarcEuKPO3FOnFWOteIhQQcl2OVQuDopphUldaYIFiFEPvnDph4Z6Rn7uTuKiHZUVp0ahUpZXsi23I7ln/s/39dt7/81LEpxhSSt32YYrQn//72BAETCzXiy////L3ONknvjflqC79jGlA8SF6tbMwDwlKyDeDZnq+D+AGUyLYIgDGCA0hRNzQGnRXWjunosOA9VHk30Zx9JC2YS2YpM5PL9OZq+p2MeZZ/z6JYai6lUGBkF2rnBQp1/GyxZBIy23///3LGv/zUsS7GKI+/jZ5hLZtyusu5wpcJcMIkxWWB4ooZcOECCm3ZNUriYqwMwpaD5gHS6rUoS1vyCIqEbil80NJi955LW/vnFk73q4Kq4GhCWCueCQrnNqCFjKTu7uZs1+/lTvDwwoQxoj7cr+RAi11TOZz/3n9MiqYsSgoOS01//v/485B//NQxM4aKZbq3npGWMN5tDv5p8Kg0PcypcEGACxBs2MFyOLkgTjgKMMJvXD9RqugtxdQ6CwpUWVFqCqq6hyhR7KmCZZARsEInChcbJCIgs0eFLukRBFzH4jqTYrT7uCNtzy3bMV6nIbb/f/MazAUAImbxytqj1av/+ep6JW2YpnWKv/zUsTaHCJG1hZ7Blypog81yW6kFiajAKZHF8OtJpqGNdN7VCZwNgW5lKWWSuL2LIueaOUblHIgp5JB8TwhmXTIbKCDF1iRmV2B5ZEa2lrz+MYiPJ22/XOrtTYCfqFvz6UhLufGUmMMDtO+5Wk2ZFrpnnlSz/P+T8v9YZnZFWD9X/kP//NQxN8aGZ7F8npNBfX8/PsK/+l4WiEJSVqr1YABWTlv90KmkPhFR9rKaITRMOmRCeNtYpeQt/wPImG03jwDC1XZncxe/CrkZWQ3fEWJFgoHDAwyRWRYm4hDA+cUvN1v/iwaKUHsIUpAwrMJcqvRuy7EuMXoeKnkheqybqqSssL1qv/zUsTrIQv26hZ5hn/NJsVkk5Ld5psuKoBWRJmFGjqBkoyCS6JImpWDPiB00xTuogz02nEVUIDvQtCE2shkCYKzYJXh+sI0IvW1gYQS1XlXZQYogZDRE2w2ocpl+aY4QkngYYITR8Y8upR6hDUEEOEj73cSqjou51Fq/CdQLBsk0TAJ//NSxNwZSSLdVkjNKkqMzKYZuS7MXcgumnTlYZi0xjK/wuOmLi4BiZhj9rfBLdidNPggyV5SrY/VPJuvXd1QOqIbkzManzKRIdKPCiPreiijTmJH0VVCp6d6UyCjfOnIH5b+Zm+P39grHdHXE5/f7SRv1gR3exPCkD8tM6X3Y/vX2vb/81DE7B4BovI+SYay33vREl7Vy3fFIjTInKzy4KOqkDUEkyJA4ABkZWqwcWcYRgRKYYjaQKVm4YyxrSWEBgKuowUWI5CcVQjwGbKyr+lK5zOeI9j/Lb9buW5nT3s7nlzLLQO8SQ1bnPuMYxQIkLlCzmgeAVPilYaCC81PEyzAAF12//NSxOkdeZ7h9mGG055+sQ9ChIABZuXQpVOL0CsoJJSkmkuCDxc3YUE5stC4TaZkVEhhPQzghQGvNjatENCmad27xKYwaoTS0W0s9el/9plYb9m6eRvrsChzKs9U05S82ozdSMtfr61VHXX7K9nTl/RVQiPozeb+VOm7lQE3PqHl/Mr/81LE6R3qiu4WSYZequmkCLXJd00kvHymO5MJnh2VD8rmFMexKlKq0bso1knPeYbfq8bNTk7SXlpr6a0TcTmZlt7PYSVGLz42t13Hbhy/5dhKLWA4QCkqLmobhdI5AqBVTdw9GveKmCS33B5b2fETw8CwLWZVxqawmDBsgLy5A25zlP/zUMTnHFOu3fZIxR7KpIIVqSXQsB4KkQpXrxIwsImpcVGwLdzwVmgevBD6pAixR8SAypL0xWoopxYY82knhV5Q/HHQGsMgyiZbHSkQjM9oO3Ossyzzz/msFbGw0Tct8indNXbH0+RqnAIWWFybWiYB3MSo3qZ84x7Gma+twZ4yJ4b/81LE6h1hquoWYYbaxOE0q9HaltXy3f8vp2OTDaiMgAkzDTh7GkJcAka9aTe8+JRTIq/ONLKBgCQAuimTUYlUJDVzEg+pVc4ofDxzUTshF5EoIvW7oYrZ9sqsBBMMtXFcwoNEDACc1x0PRygiPFZhMchozck8wWgUc3oSJ6ZY0eAjC//zUMTqHjpG4fZIzW4FnssVqKYFduXVLVdOMWdEBgNvBtVzeobWXGJHFrudLdE4mWQSOByJzz4L1Klfu3eC4aKe5Qyt0Zfzs1Z31yy0YuKTb+BE0CAgUZ6SUs3mlDrXFAj3HHBM+t7dF8cdADDzu3rQWBPCAFlYQfSXQo5Vbmg+PHD/81LE5h0R9vF2MMVOXa02SrXJd/mBRnjv9x06aoLwlIz5YZ+udk64sogFmSjgN0MJn7peULKIFGnIEtBLViMU2mEtOT+nAVDAaEFDJXYOQldERjz/15G7lXM86ZxMgwcUz4lAIdYNLZcVKhncTmHm9/Gj8lnr/8z/N/+uwzV+eB0Ge//zUsTnHHHu4fZJhvaEeB837yzJ2auUZ8//3aqtIgWnJvfD9yJof5IIlSIOkizEnpkrxuSEiSQEi4exRbrpQnAoplGRunnDLuoBg/HbKZvYmKHVjZXF0yUGFBII2j0jAAo26QwUFZs3uBB8RILlGJmJyycRHxbZ+QaIljx4aapCmvGt//NQxOsgye7qFnmG06qBOhhs9FSdraRU18u38sPaOkaOJUUBQYFwxEuzFGJ2zq5wbdEWygxNpm0xJQ/0e253cicKmJ97TE1S66rwSpBpAgLocYOceZ3U59yP1d207Hpqudqem7upEqclyzq27+krKruxmKYh6kcY2AhVJCevprKlL//zUsTcG6lq6fZ6RjZKEriyXTT2RyqtEhWnJRCWvDQy2fLQFDJilOqKQyQCLCGrPMsvMQOrE32hxaEzXKUBpXI/tcgjzZTbIRzK0Q5kSpRbikZXo4mWGxV7grfySzxpjj7ELx4kfGjxs2wYKarxybGM15ohDq4J5V8WNaqFAgBk3K75//NQxOMdSur2FkjK9naD6PgNtNXjg8UOroUIcS6Sz0DZlGhWKlHHBg4mky+o4KJGEZitRhUT2lvztQi8wbG4O84bTwRYs1ouvH4RgnkgydE7h+gy8s1K2XCe4KKrLrhw2bGCCCBKyr9yCDTQxK7FU2tU0WHDzSaYqKORhEAZOWzO+v/zUsTiGXF66fZJhs4Wq0j6dcVFBfKKw9LQbFcC5qSgnJa0g3XGTJWJjShgzXOktXG28tWrNgSEwkEinAqJSabOZGZmfnPOiRDis1YiiF2jhihLa6vDaHZT1RiIzfpVfUhXKr2uaR3f97ldxLD2RHVzrV3Rn29nqrHMwLUr7saLpI54//NSxPIdOZbd9mGG6oELWH3vNr/96VWpAAWnLbBQjUgXihGk4qt7KSMzsh0gWMNuxjannXg+si9PIJY0p59Tpa7HBoIZ3ui3MiGU7mY9XnChnHZXk1d1fTs3vpnVdui1v3nGBK/q5UKl7exKGhRkOF7mRqRvG55IfEQZS4gcJCiVXPX/81DE8yGTctlWYMVTUO7aatAAWTcsyy2ysrCytaSHSKBYfqIwyKiwaCCUHDtQVPTQoxpvGS43ACIv7CjyhvandwnngZhJ9MqtNkFIMLMMBpI5UApjCqLVr5kCUFDdWO9w7kJYdPu4hpiwAGCF7Cp8uw6YOqFXGEI3Nh1ugi6DI118//NSxOEcAyrt9kiHWpBrO4sbWcAJFrw2xQIIrbl2bRkuRTPCJG+SDrvoAEWDkiCuSA4p4SUzwiUb0oKHqgvyCYbGNekX1Ia7pZ57uMX7oOEEpYJE40NrDwNqwOcKlxApDHLax3Plqix0iWuzDwUcNa4A3reWvdD6Jw+TGEjPir5blGP/81DE5x75ytlWYkbuqoyCBbcl2RGzaYhUx1YoRMs84dFIlB0qEVSQ0xvhgww4k8F6UaUYW6BnIjNM7Zx7Qb11aAnoVyPOQ+C0AGtQgJIT/jJu/SGbt1ZucyxjUmufczdI8HtcK+v2GiDBXzfurfV//7W7A1Mt/pvPffXr/+s0kLxT//NSxOAa0WLyFkmGWhrerwbNIBa5LsQCgERQAYQLlWC5R+QahaKJumwXI8WjGMayd7q7WLJj8qkCBoSA6eZq9LN3ad0aEnFdWjaHx0QOFvyJm0aUvWS9zHo4SsTISnEwhQXu5TzqbXY21b86qVT7NZT+mh+t2SxbwQUUdlnLH6arJ3X/81LE6h3xtuX2SYbrm53rHf91v1WIAhWnJdv0a5C7zZiwQmZPovTaODlImUf9ZaRO4LYnTsT6esuKCb87pxm/xDhr7MRnndabjjCAGAmXSaUEZeNAzcsBUh8ECA2eRhkPoCgWKTgnM3KAOhnTnO2qoah/R+5Io19cAlmFBFVnLd30gf/zUMToHls28fZIxTsbB6XEnnvHoUvvFV6+MAkOhVLKqxJaWyFi1BQ2UCEAC2x3PuUsxFkNSpROaxlV80gVITl5v/a5NYrSQ2/+ohfcszupU/7onTKOMX7fDjaWNirTrgyI9SZ92p7O60qN3futX1sEqR/0kbL8vrs9V9/uiZEmH///81LE4xlxWu32SYZ+iSqvzUyElFFnLvlS5N1aAreTIDheKZPcfLSUlgfMHbFC7pOkWvJLUKXBN0i7PNJKAiCxtItENSzI516ZubBHP3/92cIVLrlke95FneQv/6QJ73Usi+nL51XBN5nHJKTIZHPPwQUPUGzn43FU8/eEX5cBOgWydv/zUsTzIHrG5fZhhvfCh6mafnff7oLSDhHAxev7RnAdPc0SVbcu0lAqxZppFMUUWSOTLIBQstRloEHrmnSJpCEA0CHxMkxRfEOkZn2nKWCJ+vewvmQgqUQ4tz8IoN3PXZKfyfRrve9Prd1eslHRsr1sQZVenJeZnzyPPqRciCjspiue//NQxOchK77l9mGG7/RlmncJ2E2MQouqhUIw+knJdvRhMZZFzEBhwWZ7TOG1PdNZEWUdBRny3Jb28xiO1ZmS0WqgF7V0tM6DN95YUK9qkUPLECAqgKoJEBQuTWKHHiEhRIDdjd+FxwgNwqPqiJyVCYysIHFtPpeanrGRFZTv0KetUP/zUsTXGwt28fYwxN61BGpCKokQAbkt2xVRB9sejIRIA96ObEGhQJgsKUYwIfI7bLPYh3lIC8Dh/LlCZF/LvcyfZcfxD5lnmr7R3IXjPFNlL92QoJWGb/zh/IF1VKZEQdrFyObHVQisWsW3U/07aMDFhJGLElSoaAxIYMPEmlWn882x//NQxOAbkV8CvnpGXlYcK5UsHJUrJTFF7RROtcu3QMDLhopkGKtw6CkSCFIByiZdOrbQmvJpiSmJU5zTirKzrK5t1qrs51ZwEhBTIU1dJHLuyJdfU6af7dkaM9tSXSSyo8/cYTNFqy4wRG1goJguL2kA4ixpV44Z8k02z1LLKJCI+P/zUsTmHurO6fZJhwaiFfmCrXLd/6SAk4eHeeYYFDp5IwoUFarlW9ui3nFDe3Pck0hIkMkVwmICijIztq99ekYNcWbCiNaT1xAIc9DO807mCNlQ8rWsPyIcY+It8sHzMd0fOIIIK1wcp1yzyKnjQhzr257mMy13bOjGX+bdSf97NR9c//NSxOAa0e76FkmEXpU+7oNz6oAK7aRO9cu/O4C/UxPRNEj/IsSDyacqqQtYyZZlZNrkRTaefRwbW18jxDfbbT4AamuUZxCIUWzvZ2e1Gd1eh10q8rtN1017Mx23pvTZjWT0d7q6ted1ldWVA6x/yW/xJWfuH+gPQAlhha+HtBu3bc//81DE6h7b0vF2SMVbjf7+H8rNIgNPy3dLUPS8SHVrKAhYmU3W84xJyylPMGX6psybk/v+eULomZSvWw9nzvsz7WsYjGx51sfe+//B5E/MMeWs6VNjFvU8d/0rUyRG6uhGVnXStnVyPhXRr4OpDbL0qiSNczfrp/eRyKjsSlFddvt9//NSxOMcoqb+FmGEnyqC/wAH8m5ZfVXyJEVkk5bv1RTFA5IOkKNSLp9Zn1Kwxc2U0JtEUI+koFjGjKlfQLX9jLObxR2tCnUnlzwl4aFybQjxSme+Zr/QzO4gSA4VoIF3VJskX0N2mR8XERH0V1rEAsFiplNEoUTEtTym91SggAAm5Lb/81DE5h5LrvYWYYTfWSmqqQmGFEAedgrMpjg0HxU0ETxtgoTYeWYEKORKFATZXTKnxCgVJlnJuKjjRriLTLHsRKSEyuv2J/W3HL9z6Jh1OFSyzSMIY6HU6EFXmpQt1PPvI3chGpyIVp2uzUZFBIDCxcVseoaTLLYq4s65icnC0WDT//NSxOEZefMGPjDE+pB4oG55tNXoAAA3dxSq5edmjb9xPk/MFx40WROEURgGAYCPTs9La+BW8num45vZUJW6kMqiUq5IWtAcyphL1V9dlfbSknoxGToCyiohEs2M4bEgKo2zxgXNViUTopHRYkKoiqZzrRS784u+KD/tdSqpEAFm5d3/81LE8SBKyt32SMVWBbx/E8KeNiSWS3Vt+UH0IsJisKES1axBhtyfjErDD0R8lgaina6e7x7dtfIp8vH19QOF+mbL/M1qfZra2PmO+O5zapy9Uuwe3dUMkqGdjVW7W+9H/r9bM5GZzMnLmq7br0adGfXlIvTqRd63QHzui+ww1l38rf/zUMTlGhk62fZhk0SiXpJyXf5xQViaCp5tYtadOSw1BJbDUyBUPaFk5naLo4EB0WcasRAQegysVpXIZqbPD4hFcyQEWDPiRRaJvMw9H5YKh2ZXz5o07JJmaz85+B1fEzt0Kl0zsMkXaFcOfJuh5raf/5n4zxQYLhz4zLIkoR7Gqdj/81LE8R7DquX2YYT73/wqjSJSVa5dv6kjDwhJTBbRG2jBTOUWEmhZalQwxTngRCKrqMkFeCevGlOkXS0ukjdzIkFG54NfOGC15/afbTKWIdIvL/9nSsWN/l+fx55+uvmZI5Fvf4XvpCCDlSdxbGTMowBqcwgXcR1pZ7n1FhAw+YLwEf/zUsTsHhMe/h5JhlthOK2klBy1y3f21BmJx26uqaYJO0jDxfFSonXXeKMwBwCljBpEkNFUrZzMhTUXcKiYKmiUAc3lQILCKGErwxOYYBhWvqCpxTGk1dj78vG0NA0BboW6RaaHNzbNBhRupMZGiSlqWddzKg3BuhT6hRVOsDG1HVoi//NQxOkdatb6NkmGeqai8Bx6WBhxZKVtES4sqSQRLct33CkkRIjWOcrbBJNrE6kRkcQS9ruRkpDkKrBROUc6+5Bqa6y2S5NAULZ6ZX13dyvLPdEvQK1SIt/S9KHI5Sq11t99UIYSw9WWFAisHQshA14eGPVFSXsUTWhYoXU+/YvUbf/zUsToIDq68hZJhu7rHSonFFRt7SJYrcl3eOhmuEpqOyvWlZ37mvTkTDhSWQxdHUKCEuF+kDxlsswoWO4fdAk9yysuyuXL89r4qZHCNSay53WWZq79zqzufctu7PTXT6K0+vunblVnY2bV1T+b950eV3JVzol//u2x13hFtmmOiiro//NQxN0bakb2FkjE8hARZy7KxIjfYWFEMWdC6Y1BDPG8c6IjBVv2jWK03JJA2rTBqZgwQgVsUWOHZrC/u3wzcWCjKU/gOMpc56FPTgg6Tkvmbc/eN7SJ0zjaEXlnTsR6Waef+djUvgf2JfCDsSnfirwv/yJ4FlP0RHJYG7bYTS7b/f/zUsTkG0u+9hZgxPrlhbDlvzhVxRAVty7EhoqcOMkcppzLqeF0cWIGIDyPqZacW/PZYtP7GOZkJVAtPq7K7YtCDl8Hh5oZ3ZjKSlCqm+j8KF4M6YI2uaNMp6z10ZMln+mSrWzKju1+e7atU7bLToU1jI9/3VAUWwmh/eYfgda479Xt//NSxOwfGyrp9npGP/ne77XtgvEiPt/bv31r8AoCGvt3QnpivPNLCOsUFNe7kcZKEnSe/BVQfbsbcjfpfmVi2LoqeGOxCAccUXE9U2uxRIeE+8WyflTs1z/yiyyFNHiwyFN0oZl23zKl/D8zf+/STzuhzub+dNu88wWiZFz/iBRUFDL/81DE5R0rKvH2SMVvg+1BCXdmoxlGiq2UFbku2YwXBxEEsEQPNTRE1fCrDWQSoyztKsxDC5U5/nT2o56jdKg8zLr0R0MUrpQhZxJM63a8qROZf9uWqIamza/FruRBgiOUA7BZwyGz4lciyw9AR0KDAThYVSOYkCn+NeIAAlBR5ff4//NSxOUeY1r+FmIG9qpN8FTLKs4kXpJy7f7pBuXQBJS4IVWnHxecJGUaU4TQ8OrhczgxYMZojpDxTMW5MqdCvkPggA0pk0IlME/eZae2pCMxiMjIlb+01F5WfYVdqZn7yzNhSorXzQqS5G/S0zM9lz+kW38m395U4DDj3otCJpE89CH/81DE4RwR6vH2YYZ+jobZ4tW1pB6Scl293AaGQDEg4K1ETA5JP6XSAfQs5FBEpWVU5QFJSoJoPuK+rBIGwTiaU3BchRwDIbI3Lb+A0lggcwJP3MwQxFJAVpFCP+HyaZ+eU/7z61tZb+fg+0AVg8XAz3qWXLoAwgNAYXUeY584c73y//NSxOUdGysCHjJGwjxdEJPIuUjJFhAtOW8gHw8uiCzQpzplwR0hgjWNoAPJkA4J1hReOFbiqgc5k0FKS8uXl1KPdY/PqkcyzevgxJ9InUHYBBMqZSl79OV07HPBgwWUtKIXa8iokGYwiQUSn6n3KV2V9r1PvOmBKkLxIFiwmSqglBH/81LE5h3Cev4eSYZeqSXYvztWRKLrlb4MRKF7hzZYqcBhwQOtLjzd/0iaM1ICQOMY2XZMwnlUneZ2d5p/8nSYiX3u/hcmWYR3LQveUW+76lZzPa99Sp4QCFMGc3aDOSGRWhbwVA5kcOT4oOUnMifuftyzqpZ+VMv9P/I85/9KxaaLP//zUMTlGtla7hZKRhrP/S5OTZkM/ibL/Hpdg3JVwRIrNct2WTN26EEwmsUJgoilCsNMKDXvmRhDAGecQUQdho4wJjxJASgpXu5Z/eWhK9ekybFzd+ne2mgZ65eygJNjlAyPUbcKnQZQIwUNlTRaEjimPN3VuUr1zRI7nBWhYyHIJqL/81LE7iILvuH2YYbfKRhp6r0K5YCrclu/y9Ym++52V5ZTjfjecHZKJVUgXStBQ9xnOAYVhakloPphs+V8380nnsfzPy4KrnDKkWylkWKJblE0kUidAQwMDYogOOCL0vuTXxtAiCyNDGE6YMIflHCzALn2hiUaKkCgeis8n4tVpyAAd//zUMTbGpma8hYyRkZ1/zFjFthl8VY/xMWVkP4rIiZaU2P4/kQJmm2ElC5Vra5AcXXDyALgUwqGEYySz5AaZfNvV06tKti9zFu1UEJLZUPplFMqzjgTOm4hhweHM75zEAiQArP14nWVqD7dOZzPd+v9v3ex/UnoHfb3+Zzvzu7b/7H/81LE5RrJou12eYaKvWfR0Qsb8ttqhgAJS3f5lVWWSQ3HqfgHc69RdBGVYTIcjwlREc4liyNaJY6QDNv1cJ9uSaBSnNgJlaGZuxnMpzQv11nZq5kxwyocvMrW5XQ3UamTASFiIxIbGmW+LL4/XiTEY7H7DwRCqCRzrGoe+ei9CcCQAP/zUsTvIFlyzfZ6Ru0iL7fL612KWbOmxxiLz7K+clxVE4lyo/ldq8RlGdSAkHlz5wlnp2uGledlRCWvlWJFSt7wXrBfLsqoMce1zoZYdzrMIpVBIcQq2GrURHuzjuMFCFuh0R1qs47r1XRKKK3izxoEdRUosiiI4pDMxIkh5mRHMfXd//NQxOMagXrRVnpGzPqswx2ZOpOTnWcQXQrZtUTGqkrnx1IZYBIt9dXQQAi258YYC8vMSry6ZKqdblwMoUBGI4gmH8bub00YE1pdRZMjMExVsvJduCaxyMpzgLIyjHGal+Rw/Q0xl60zBF98DCEdOHHyofFXXyCg5DkWSIT6s0TA8P/zUsTuJQuqzf7DCvDCScjrE29jrRK6LFS6gk0OzvnUQE9taq0metW5dt+50M2uqU+fPC7EV6nolWfE1TDBNQ5gyKuuXViIeTj1tbJPdk8pSLCkVwd3nnEYkLotyoCfcVGCoiR1w1RnFggWPxuH+m3G3RrKmEVMRAlYKmThcmGlxYRR//NSxM8b2Z7RVnpGshtcU1uGstb+6oiAEAEW5NZykx9MLflUUszLyX1tRBFngvI5NMTWxqt3v0+5IBRhzkQZSojK5SsrOhWNlSV5bI5HWi66/bUI2C8qlFEZSm9zynbN7dXzC1hKJAG14AqBmTiOW6hSLdD1sB0hAaxC6ypCZwuH7aT/81DE1RnhfvIWY8ZqoAACKzemLLyAwzQh3GOjjfsQ+eNMERGhMypKM3HyEObp48gOEWNVkziMgHIhAMEWc+mwepPC3V9SJ5WHZ7xr1saLxv3aba8/0IzlJ/++S+Yzz8ay7tnM0MTMuoTRhZ6kqCCu7dKbvRa//+vX/TqzZR3gjtMf//NSxOIbAiLWFnmE6qvqTuR0RsoRuw34VaVjMAgFNUb1hIlXB7fE/PNBmu9OZ+MCutA2D/CKZEkdOUNMqkFeLMWUDHvcFv7y8ZkrxzQ4AQOFQAD4VSDAJirChmEj5UPtm4yNaXWaphsDBV4VEYGJ0NMoO167f//kBdYdFm27Dow8DDD/81DE7CBLqs3+eYU1QAATBBSVURABKK7eZqhs4FAnhfj9QhBUu2inxY7MwHnuRPXlRG4ILmmlE/R48s0sGtCy0ilvua7GY0yhtvh2/M55U9Jn727XOTUgHF0KHGzVbd33QiRln1Y65iZUaokSpZGKh/6/Ju3Rl/U+qeT3uZToh6qQ//NSxN8buOra1nsMhEwcInAnitD7SIZCIDUSf/TVsbRvVbkt37uIN4v+HFFIUr3UdCVv0ZEYyOVBbWpKcYWQdnoNDAhYHQ+ZOJU6KdhyFoTmCyWn2rD+NwCR7nVIiD6PbSlUSx10dMp2dUbtxV3o3X3b2aXq3f/Xr//+nKKPUo5/Bn7/81LE5iALOtaeeYr0+ZfxxE1P3NvIkE61qSZkusNhzfNoWGn7Dw9zjJPxrVDw/qadEaKq8pTA9uMtEioa+x89jVnvjZGRKZphaaEIq7gmGkJxaPG17KhSbrZlzXIR9BPVtQ3T1dKFY6J6akL1avXbp0/7dG4aXHW++KyA8aHRcNE4m//zUMTbG0NG8hZ4yttksCyVgxAAIyT6xfBnMD0zzvQlvRLQPpkdtZAB9RyBH+YbA8b5QoTsC4+yhIij4E0wUTw4VglFSBldJkdfdHqaQcScWEimTRh9ss6TGYDshFFH9taJRJFR9y0TVC53DrMcZ950L/dvun/7e32/06KqnMVqe7f/81LE4xxjLuoWYgTeT2fMzZxFo0jGT3S+xe4ASLDmPuwnsI9GsXUSqQOJ4ZM0egkDPIzZIIvAgySBdhpWUtlaiBt7C8MiLuRkhGdLpyJa2hZdzVYos8vQzhDhplseoyAoZAZ9ds1FmIw5T3RyMx//+Mt77xC1KFgQFDgUIeOmaqVCKv/zUMTnH2O2zfZ6SuzKSWZ58DTpmwQKpT8aFueDgksIKE4rLp23Kie2V9XZSIZbU5BgzcCkEBUBlEwzY7M2eIZkhbvf6VrUZYCFDi4f+hoJ/ZfZMhysV1RN3djMzy52dGO/pVzorG3k/q59PY1q9b9aJTW1Pa7cu5j0YNOGucAKxlv/81LE3hmBetlWekayHrJUKtJIL/cjt32zWGUBcfkIuulU8DuuShe752qYfPkSpVFBeqjuVUImQqZUUomoMzEe3jDhHFkcUErxncjJSInQsie6VemX6hME+Ubth3yrshjee7ovtyqlldmM5r/2Tc87NtYy2L0Y9LWt7pa/Xt9OqlqjMv/zUsTuHsvG3XZgxTIWNpuMkg61t22mNrzQfuSHVuE43r0YYtJjNHRty6OTRuONp/9OSatlQBBn0FWPNSJKWHl2RpVSiFAXY+vxr2nYEZQzE/3PUl0zzPO+2dtJsyNoalaRX9P///vV2Wci3pMU6MQ9DFm+S6Opj6WSnvuxLsR2OLIM//NQxOgdQ7MGPmDFN3Dq8lCFKTk0zrbMeNbeq4fh/B4BKmJERHVZ4Zxp/evVv4oCAZXRo5kKDkTBQgZlD6mpe0pqL3Q+dne8PolQEIJEuLRTJ7TlZGrR1636bVrs96//3S3avtVH6otWel6FT122daZF9v/VaGqhnRhIKIMhgolEpP/zUsToHXO25hZgxTudLY0kQWZuW2+reUKvewzfcLthEs0UwD7hRT4JGk04rAvTYMslkmBJP0TgjhBAECCuAj+SFaLdYY7h4XPPLveQwpUbumc63kvCnoVzL3BHTNiIEh1EjnlXqHitJ7lUIukvIhY62suLquzwuWNlJirZe3OC5A2E//NQxOgc68rdVmDFM0AvZtWtkAKrOSWBFXA3EQwCRibGXc5oe6Ip8SAaHF7Jh/xXgmdzftnESyJA+Bma8blQqtNUNkEM271Szeox5TuZ8nxjLlpw8KMFVoexOTNrFQKABATSsaVcTQ5y2JHnEqaxz1KvQ+0+48Om3itvXFXOyxISnv/zUsTpHeKi6jZ5hrJDTNXSyJJaZyXPm/SPj6TNvdXwoB7qnSlHERkamKHp6YU9GnfRRrWFodEuUpUmTKgZYkipDgxaDoLsIt247s6ny0pe+exa2woU///5H5nJZC+yEn8ekt8tZel9Ptz4Xf5/9/dhOKHn//brrc+8v9/5pDqsqSgl//NSxOcdOZbiFnpGlgLYXQgIsWhz5iitIA81uyXOA4oEAwDsr48j1D7Gz3krE3Wx04vYbvJQkV0qvbnLy5rag7Hn95x/+8MmfB0SNOigmErBQNAF1LTomev6iNSlEeka5IsI4K6mqZ+iJZH//0a0EXBNNf1mhq1r6/5LbZIfgBSMoV3/81DE6B8DxuH2eYauPYWMeQjxmE1ExckECoJIAdp0aheRbEPYkCJKqDmN4DSD9YEbOnyCugUBbDtgu2BBl9euK6UqYTr9jRR4aRiGj6EuXrKKQ5Fp5iOJSNk8dsbWMvrzsTc/ri7VAUphG8q8pxTLLEoDnc04r/ier+Y5Yub61y+q//NSxOEW2R7qF0kwAoUKuc0SoW5scK0ZYNm5ay2sTNeK+1lTuErKrsyP2J8rossrqGrI00ZhiWxGfYQ2A9iv3r5XbvGxrs22W0mIL31164vWufasKuc5tfG/M9x////FqUgmnaNud8v/LcUKEKSAYtuCwq1WvdQWFDTRQ1xUxBhNjpn/81LE+zkDer2Xj3gDoUa0JiTyHGLrJyYuphCAkJLs40dEoQgbHtGly561rTOWXLrPUDT/UDSgaPCI8DR4Sgq8FQV8SgrBqJQWlnlcsDR4Gg71A0DR79YKhuCoKhNMQU1FMy4xMDBVVVVVVVVVVVVMQU1FMy4xMDBVVVVVVVVVVVVVVf/zUMSNGcD2ZBfPYABVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/81LEiQAAA0gAAAAAVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVQ==",inter:"SUQzBAAAAAAAIlRTU0UAAAAOAAADTGF2ZjYxLjcuMTAwAAAAAAAAAAAAAAD/83DAAAAAAAAAAAAASW5mbwAAAA8AAACpAABW7wAFCAsMDxIUFxobHiEjJiksLTAzNTg7PD9CREdKTU5RVFZZXF1gY2Voa2xvcnV3en1+gYSGiYyNkJOWmJuen6Klp6qtrrG0trm8v8DDxsjLzs/S1dfa3eDh5Ofp7O/w8/b4+/4AAAAATGF2YzYxLjE5AAAAAAAAAAAAAAAAJAQAAAAAAAAAVu9x94KnAAAAAAAAAAAAAAAAAP/zUMQAFVGl7UdJQAKUABie5/wh4eCBiJGFydIExXqAUChBi4NBSRcXP0T/iv0rd/9K93d4d4RN3h30RP93uA4BoHhYCgLCQbgLg3PgUBufAoHhgnD0P/l////9H/////UGFZDIZDIJAIJBIJAIBAIO8agkXqCM+rCAb7n0t2Xglo//81LEHyIKCt5fmHgCTntKuBEAPBcDprbuF9mShjPBv//1WTAKwZ97ajf6v0aZaqDAf4vXe/nd/raPORQE3eK8/fnWc/DA4LDHtzp+HoUICaZR+DCQlnbcruntn///////9pZNsjPQoIE//8MtPz6jjf//y5DIKoAABAG5Lf5qyUTObP/zUsQMHJHixhfMWACn7ptQkOld1lE8TRDRBLB75OUUOGpNDwgaMcbmxsxY4HllM3waulV8Hae/dCGxevexjebhu1zXqbToalrbuuEjQ6ncJudVTxyvOy1VB4woMUm9XaF8hFm4oMu97jmMTVQmg+7r//uqiJJO0bktzcodUYXuX8DQ//NQxA8dQkreFnmEXosUQZAZcEwcUQJHya6QHopkjn8Fn2ckkRPJADEBrVXRBQSAOCRdQ4UTEICmPZl0xxv6MBGSrPmd1R9ej3VP+yn6EiAMcHpeAlUq5Q5MOYLklKpvcVAR6eEjrFL7oBAQNCoSUdI9KM0ih1Sbkt3boq7cVUOhD//zUsQPHMme7j540xJrbIUCtdwaYUFdZfsv3T1ZHCqKYPopNMoToWMt7wnCKFBvInWKg3OMlO+6e23ipIO+831BETzppwDJiZR8CMGMteX0VKYMQKEw4qggdu7LKqWV0jVFG4of/mEngywKmSIkKOFUVdBGCvJLatmbIqlI4qtd9As9//NSxBEd2y7ZdkrLFrktAqiBM4QpOkyuUh6fZ2qtGz0XwdjdTql7mVBk6H+/llOWY2+PhrGVZ0MG3URLo4OFSIy2szsVVoPK7XoYyjKeqqzPrSYa7nSlrpRKMtbbte97f7WWcsYPhUPg2JEFwJ1j0/2oZcqAAA23JY2FLZXNE6D7sKX/81DEDxvyHs1WCwYagjPjmFkl1DYDseQKCinuFUWFZKBjhByDmHE/Ec/BMiLp/qX6qf/JeXEAUnS9guKA1fMDQPU4bhxugsVXV7lLmDN8w1wYUAJ0BxKMbWmUoJwk72pfJGz62Mt6XDte0rYVouUBtuX5iKQuRnjzQ+CgQownITcF//NSxBQcqW7NTnpMVhSYnKFwMXvW4gkhRbByytrsJW82m9W23hqcx2dHY8R/m/s7ZGfGqc5WwA4BwFByTbHqKK6gTB5wqKA+NLRLAzWDShF5gkQrqehqyXX/Bik66Ncn6QC8OoCxcLDWPchNpJAIIzctsyC1CQmJl1qhpdWK8LdFkED/81DEFxu6xtoWYMUO2Sdpj9oFcS2gHITUzEywMhXa2R+pYUyWmBumpex/VFFAwRKuzNpSmqpRU+xHVLOVGet9DsS3Yx+n//eQ7OSOzHVXOxUVQIQifeBYBE9o94rEhoKbKXGrlMAACSbnvFjZMCJYSNNEsCohbTUFdrJIC55RCyoe//NSxB0YEaLNVkjFSugtyamv8OqDFNJtLDn2EK1AHTGGYLehHgxawuhUktwzqDtz5R3ACA7VjQ4EjSSZ1iOetsV/tZQ8XxHkld/MVf0+n/qqwAAOW8TNTtIH56WHPOgJtjoeHGMhdeQbOiHjzSI2ehYUVc0OEhMG3HmQURRKJwq2HqH/81LEMhnBbslWYkbsf3Z8i93rlmChA2CrS/cXlht8+KBkyYCq75FYUHGlisxMBO8KHX2+YRHMKOff84+U3X+xiJeElIlUkpbd+xcHKHXBekAQHIlDavLLqnx9CKSjA6uOaw9IDS1apuFJgbZMxJqjOrIXptbD9PBMe5z//GEgn1n+Rv/zUMRBGQoC7j4yRqZnyw0EIhewsi8rjnOdecUnUvrFqX/9ZHU3svjeL165QvKRVdXEAV3Ld9atVpRMXXS3tL4kgakkF25bZDYzXDnxMomsHbs7v5reBdO17szMVKR+lCLz3HPpFC/9QaS7FhYiup51IQm6bGD0Bl+8APGjUqEQ8kr/81LEURppmt1WSYaWDoGG2hZMGjridDlyfoaoEDoswMxutCGqWpAEAoxyXfCCQcoglycgy8OELFR0hkOFGl85WtLbqy34j1t7y9+1Tw5nDdt88/+vacw3N7fLz/OUNYuqWRyysRBZcqV3UjL/VUeyI2lMckDBveA3//3/s7YsGSxkBP/zUMRdGmsy4X5ARepl3aPHYZctzwfiqXdlpRIdV8lujQJulJELTwmfhNQLnN8aaRramzCi/JSJqzV6733S8WhSRzES2yATYZv/mX/jx38O0s9W6BgAan81+XQnEJUpfXKoMvG2DWHMW1K2ukdFc+FmU3aI9He1/tbwi6IQL3rVgAT/81LEaBlRkuoWKwwGAs3Jf0sUIBAzIjWcycacTE5EPTDIlUWpS0pN40v8+ssUVuD26xvPH7m52ngtKBmK1CmvSe0icIaHCN28RWoql4xofXPt13iJrfuori1TsZh9zTz/a31M6jcp/2qAQBm3B+WXCrRGrBpI6iYQwbRFRjEfgp43VP/zUsR4F2lq2XZIR2JxGrKzcA0QCDs1VkTewfDEYxFS6iSk1nl059bimOBHz8MsF3qYLIaUcaAb4uJs9CrmuumKCXLJ3fFPnyT2IOeUTcAAu3f+cYFyQaK1UlMa3oSu+fkwKQ5A8FITpz1xepSUPymfKFA3PfQtVWK7v6noG47UGKHq//NQxJAWqYrVVkmE0ogGh9nkE8Wbihk2oNgcADxdYPlkqCb1rQYbNjjehwk5Deu80JFw12Xauv7pC17qPTJnKoAACUt0zsB2W1hjCgKieZFVlANieFQTCGUT3pfeagFZictnxXlpLVG6QlZqe0PVCYkSKcOOktHrK2KIlX9cKYHCn//zUsSqGgEqyU5LBlxNsjZBIFDamgKARAw6VGijTAqGiPTJbAKKD06VLzmhoQPBpDtW7+rk/8wq0AFZuSYUsBfiiayRdRRjTsmxK2KShIiVRIzBJdJABtLJSsqamV5MHp1jSqYh0ozH25z4cqn++P63Mcs+qA2i517rUDXPNGWleJHt//NSxLgbCV7JVmGHRDfhGZFnm054vBOkebj0rxx5MjE53puZt93lFF7Xy25EoB9QRkbSmVEQC8jSSJ83oCRqCue5zsb3I/MY6/eC+6yLD1cNxLHZdzc2nmXf8QsSgjAgUHTc2BW9DhQem8FqF4JhUGTgjNHlKSESJoaHRUgqdWLa+q//81DEwRj5atlWEkwyukP7urHuywXUlaiABabku57QcnDcMfRHuVhocNiIOpDDk8Gm98nMOt5NIy7LI7OzcoRq9VOLTQIsgMtmHXQkRuUzKmogIHg1Ohp4sK06cOgpfQYek5Gl/9e1IBFzVgeJgFKd7Pi23p6g/EJMXHPpAmyEghAt//NSxNIZoW7yFkmGlrktsEB94kZbN2Qk1CeMCJpYWFImGdES3vclCT777jEoRslU6Tej3pr8n6WpN78/eUaSiv5zP9XwLqS7HQ/z7G5ybMlYWRKgdbgUhX8KHr4BjsW05Vld32dQ7i5X713mv1V2/xfozYgXw9bF8/K1f9l/pT/O4t//81DE4RnBat32YYbOM7X8pZIeknLbtcynwkTAoMvphVncStYgjAsptVds5tQkmTXNONc7KLSyiBUYnIUouB3qgl06jscIrC0u+CFYI1JdD1diJMz9iIrQZpTJ3VPKyhs8XG8uHmhkSQofXfOpOZI2X+6dtj+9k9CqtzEOKtOLtjqG//NSxO8fQbLeFgpMG9V9xtWpJoZUk5bd8iNSIgLJEbKMFGiYiEpUnK0H2EMBow8BEDBU5GKICDJKVR5V8mmiZet0nizOkuX3V81mEo5qiZyarVQMOSDMOdbGxkheawuUezrlCI9DNdnpFsflV39Ol09eN9PpZLnJT+vD/5l9n/8/nbb/81LE6B1TVvIeSMVaZdXz/78VTvX3imgzyxLicyrQQVm5LVHZvNMrGSM2LkRM4PmBUGCVVluXVxqhvxJlMSkaZtYg0yTVHfUv55n6BSe2k6m2Y3eYwqxUtz1fnIZMaXmh9ObcpKeTo4Q5RGHJDfK2nuX+LwNjIPKuAVs8oVv3r0+1f//zUMToIJvC8j5JhtYhe5mwS5EBXcl36ZWi6FChTJVKs4ui5EOhodKOgWSlHSYlVCIHspSySrxFBFCppvNfJolUaAY84iaJkcI1xBdbbCD65/voEEhEam9PTb6hAsj5z//a1GNjVWEyZp5GrZl9kVDhSeed55+X/18i6pfTbK7+2a7/81LE2hp6tt1WSEWublzF9/WFBu6uWgsSztkAq3JLv50dQh0FQ2aTO5NYg+EJCkWRNGbibrx2zZWEckLFkow4odGznD/i72GFxse9Xx2kTPE13MShmICN28X2XFNRbmZ/c4mwM5Ym8IumNsZC8FS7gRCIeAYPETDAMHULHqUIlN/kJ//zUMTmHzuG3VZJhteGpKvcd+zmAHU6KarZSa5Lt3gzIPDj4sg86WXIjzGkYzcRsuMt//X6x57G1yPdfpMLHSXzhWekgpqUKiKIB2Nd0To7jR2IjDxTwjixKqp2fKrcWUyyilltFNDj42uTggqxyeUp5eCWKLQxI40NIZkUYSxq1DD/81LE3h0yNuV2SgcWNA+TEhH+0plAvswxmJBJRQdhYiFFrKbofsDMWRqGtiCxhSN4NVVVK79ViRIWrcku/OSRgUeDJJsDNECKaWrIaCwek4PlPt4NQJYiCktZUufOFnzO2/TlzcNISIwYpEd7/f7bxhOWZ5/vN/33/kOtu5U7hVJPxf/zUsTfJJvC6VYzBn8fTUdc28YhNNia/7+o4hamRz7NGSsN471qgAAZKS4TpJyRtk4dO7rC8uQw9QSKSjIQUqs4LSgzj10zNFSbbFz7CqvDs1PSCCzW9EutY/Z4H3bR/VvVZyWxCtNsMi9JpomykjAqTAwwTbG9XLXTZ983fSKBy8kC//NQxMIZGgLuFkmG0iLAgLnb1CANVWazXTuelymGg48DkkWiWqkiQaKTkl3ygI4yk2GgE/HUbhWHyK1BKshkJq5CwUwsJOGh9w/nlUQKJ3JiFGT8IoZVS2uW2XHHYVsRITTNYZVCTHHPMHnJSVEnW8oQe6VcaXt28MqmV0Fu4TOMEv/zUsTSHSGm2VYTEB4Fhs0uzRqGkoBZKCid9YkSCtXJdvT+8ZAMKHXFYjBdwUHPm0XSXcYc2cuvM8ovNELT0yByluVFpbimGno6ad77CPeuRPWcHmVxdKvv3Xru3Up3SI+J3/b3xnn//u/CYP4Gj3k/9fj9/g0lBLLa2o60f9r7IXE1//NQxNMambb6PjBHQmjPzjQAD+j1gAAAAA0143OmA2KmrDBw/iJrGLJKwbXqCyCncPgaGpPCILDhhIIUkCHFJlPRB71VqtksoqFIW6aS+OJa4jube88DEIEtlxEhkpgWsoeC7iMKCh7VWLLlV+vNTx9xrbe8OfQiWKiqFx5O0Bwsmv/zUsTdG+EG9hZJhl+LmOjUfLrPi5y9qD5EDvoVhRAISRJIt6T4fSRnkJo+23GXkTKyJEk2qpqpooWVu31WfV0V+UtzcKNpVVXUjIseuso1E/pVVppHxOUNF/vxptj4LPVQpQ41HuKqpJpnm+036RFbOV+l5cc/k/67ZfzPeEW0cMAg//NSxOMfEkLanmGQ7GLmiZzBp///ioGUxDKK3KWkkhSpSR7zI5HVjIhVE1rih8qaO8jGUhIqssrJi1nYI0e7S05pbctQzYinM+/1eixl1VStR5wrFJwa9RJT8bSQEoDB1r+VCn2ZEIT3fnZ2V1KouukyUzPVvltn3s5HrdiqZmM1jCz/81DE3B1i4u4eSgduZVRl2c6v3OGG//9glO578grIAAhIE/2HeOTFcDQPWFyNBCHYDZY1MAJ7R0qTKlt1AtpLptTOKyrcy0skyF1x0ptErUJ081Pxv5BiEhQBAKrxqIZFjOCYKCIvZPdUyKYo6lpdu9bJREvXdKq17qVZm9EZV1Du//NSxNsdmyLqFkoLarsQH5wEVY2if0nJLvncpSqxwTjbI+tDkgTcEyIk0GkrdttNOR3HRKaIEoDA0Dxp5EyIgSkQItl3EVJ75DurXN1OiXIQYHw+Kt6oODTnFHUp3a3U+zHJyi7moibNWif161W72qnSqXRtTlozP/VVZxNbIixX/63/81LE2hpa4uIeMgVNTkovc9JE2qkiVTbctzitMaKioAhIJgCz4nchRIFXmA0idHZdFTUNUIg2oIKjBDABq0DOxUHUUAXNlIrkcI+m2ubHOf+6UdAUEoNGuBxVICF7mVkUPEcprSmn69DPd6Etadus/++j0cAACbcsyzjB6eonV8DxlP/zUMTmHasi8hZ5ip4pV4lFIRR+uTA4Guqle4/jB8uOo+YidOWVnsI4y+ho0fdkijphbv1NZEZNwDMzp1YL104FFOHUAXv0WDUzBaFWMnKUq/y4EwMUDhIgHWrFWCgwD35IrVXQGpYF18s/MDA6DoIgiygbqh0aElKNYcDbHYaVhQD/81LE5Bf5nun2SgamCtuW/7kKsSEyFllViWwsgkViKUR0Lg/HaupdiueIVrc1i2KkbLkJ8vKZ9ARM0awwQOtxMTsFJ6chWZEOroggrOGjurQ+ACyr27/kUd6qRqWaYh1XnWZ6Mc4va0ZYmt7e5XuERelTUkJCL38gMWdltSPQhRA7JP/zUMT6IFH+2VZhh0a6EUciAcAYMi5wUiNs0njjahM+JIhW1ZjFXZ7WbSgUFQtJ6b1EE28HFlUGNXJW98MhAi/hzklVGj5zeR1QZv8wQF/Zv/PfVzlM7kMipdi/K41nOkRrLq7onGpqXQ6StrVXdW/RVH1fgLxzV7h/9up81l76fu//81LE7Rz6btnuYMtKs/DdhKIBJNy1WhKJhkKyudlQD4ChoM7ljExiIo8JTAeCw+oNpNYsibZSWZcNCZALgq1pKqT/ZLEmh3afm8+cONRuJeZ6ENr/X0UzlDXz/6WE5s1vxA8liXnKA/VCs1SGDywECgjZe8Wj2GryYTZ3o0HWMx9xm//zUsTvHusq5e5Iy4fcqR6Os7pVqUYFYpK23etSWhOM1qhBkAYn4Vh7dHIPLOOD/MWxrzMJVkI4lYYWfGM2TN18/Phtpqwb50siOjZHMlVYToRiaVUJA5KoFCrtY6Uq5zRqCrCYy8DtfKloR30W6YZF1uq609Q4CktH0xlTU8OCgsWd//NQxOkeUbbd9mJMylqEEASrOW7pjMiAUJJaVJGJSlAiPvMpGBd/VZmD4zpkAIUJMP7YlNVvNNlRr48nKL2fBmYk/ra6lOq4MKFGKqOjVoI2WqdencrK3ZO+/Pd17PaY6M/JadDTIqLK7joxys7OQrFlWZLU7u7yE9LZl/r1uJ5aoP/zUsTkG+ny/j5hip7qOurEElV5bdYyQbMmQRXkhcLyFFIkKwouihlDUcS3FoRrDsI7DJXnvENruxmNxZdc5MTaV/2rOpS+8rNsYCKd9+NAikKVGetLI5XtWUzz50nlu59SfIPayUOw93r3Cm9TNB5HUCMvo4YDD7xGJxxObgdRoH0X//NQxOodk7bqFkmE8t9rq3YDJPWaS1InN60iXpJSS7d1pAEiLn6DiDJ55VmGRSSyU6RSozxYM5Q6mQR2Q13GRhWKDBiSEdCVbeImuf6zMUGURb5Wd3o3QzIkibJ/Vuqp//Xt/y8hErWVATD7Gtimk4QnRxt60JkDr0CfWzraVdEQFP/zUsToH7re7fZJR44rty5eVCHLBBB+K5uYICvvJWK2OmuRSw4reiYz15e8Vzf3pCgKNhs7seznD9d3HvdxsPHCjz4qWLfY97SKueU2tUFXC3c8f24e2zS5Cb/q98yqKxMhOq86lo/J7ZNf9DIU7ZQbIULpIjW/tkpQ50Uud0hGZG1O//NSxN8ZctL+HjDE9uzvYuRnIIeeDMq95iTV0AAAKrt3qmBGEQOWteArTXQqLsTA7RMJyARzEHI4FCDoEB3B1JolhzdTMcxqkllafNEjrQ7icWdM/K1vrvdb0kzqwtSmK/uW8xPrmkmwADYbJKY5rXL7wfupelqpGOF+dgno29tAaWf/81DE7yGTtuoWegU2Z71HunG6Fa0SULW5bq+AsO3y2lFsfmU3FG3vOmLJaHVH6YozzLvRQMMptCJDgOJCyGRuX7Esehcn2Mty9xkCiCCAA8toLtWwszx9mi7uNPNkTRw4eaydTcIVGSOIC4dNiiI9tU6Y9TbLlETQVUxQpyqogAA2//NSxN0bkbLd/kmW2OXVc0PKtdzN6vXE8NhfNbfCa2k7VIwWX1zl7QuyZuBFIB7kKEdkj0SSiGZWnIvl0zTn1Q9qnU6WLZtomJBhT/8aHCJMRXKJNuIkcjHOdlIR09yaql5rMynlZfLXoxLOp7LRhpJHFsx3tmc5qpYz9UKVvZuykV//81DE5Bp5cvYWYkZSO/GhbmOriFTiTptvec0X8EEKzct+G5Qg4iwoOmhXRwNGMptojJYD5hSshoKXR3sPdjiM8l4wYlTOZ9iOt5bczcKy98QY37V2/3mpaKd4Dy4BPEgyeaukLBg+MJOe/pUyp/HboMDxALGUl8G6HVqEsulNA/cN//NSxO8iQ9rh9nmK7yA0+4NYv9WBUAk3Jk2z0KBHCqTsPqwLnMKUkD8PC6FS4thmE7XLXrlvHatlMmRYzVceLQ8zBGIcxzNLkbuxj2p8vdqDAUHR/7OSX2mvIhHpdfde3Vfd3c+k+Z81z1/Vr9JrWa2nTZKqt6r9SNqcXqQD58Pr8n3/81LE3Bs5bul2ekw2QJqFEha23NwNdRKIxRzHiYwRCaIGi4fIYYMRj1gmqR26ogOboVg0+EMq1S7XShm1W02n49oP2WES+e0ywMEFnmH7lgmixDj2doR+9+fIU6XLLs0uEPXLvzJDliZEFf/SM5t9nukjCb/WzanT4EjnifigqGrFnP/zUMTlHCt24VZgy0Yq8ku9q25JMhZQ9YUDwZBVGbwWAMXD4YYDajjCmdA8UqMYNQUoZpjIqVkWhM4vqHqFpRsrz1HEd8rW1iODBI//42M1MFqmd9cvxQyoMS0jKGWToiwvaJ38y5xeL65yr95nkXFmz/b7dz/LY9aUNU2JfX8pmRL/81LE6RxT0u32QEfT/h4ot74jYInLK3WZmaFdyXf3xQnF6ypShQRYOE0yA0hQrsF5M30nqG6dbSa6AWqk9OA1Lr5Z0LlAh1i4z99/e1a7OcGBVFGN+dGQ6HVKPuf9df/ZvURiUCMuNhwKNS6kwogKJKfoiVSlYFVuYmxjwwZ3C9Z98f/zUsTtIMOq6XZKBvvzdWVACblv9iAIidUdAAKggQ2AGQ9a7aATNA6DXQGGDp6209PZRtgwQSCYZZTkNzidIJYe2iIuWePjIey3LR5d4MMMYH8q5CzqDIWIhFZc+5RFAbWYQ6pJdz9hZcSPTkRYTOKGzcLNYJ3jSbzJFZtULjiCPzXG//NQxOAa2kbtVkjLLsw11QAJt29LUlSZfSwjZakPJtlxEBsFguQjDm46g96afdM5IkeMGBM5KgMiknr6qJMNa1Lv99vFW0k1ZbrOURBnR/9uyqTt+Wtmfme8yELZ7KemqIrS/SjJ0T+Sv/6+6rF2iQK3IvqiHlfWvwitDJf/OKLYav/zUsTpHXFy4VZJhQ7SqqmiD1XJdywOiEoLkIpDHBpKF88gC6FpkmReCBq3U+PsXZEuqkxAxQSQadWQF6YYfUScmBLo46dw2m938xbfdiwtM5fFSU+kTtdQlY40x0bePTrUntS9qxYmJztGpCq5U+seHirNdLqz7REEiJVcMCoJAmRJ//NQxOkdCzLhVkmK15tdyJAZM8kuVRbMiKMt6aLEkpMqRIXEh8VGKJDKsVYRaIYM7s4JY+es5BGSiYPuc2pIUpX1ozg/yffmxCD8lHzzrX/HrkpGzX///iod+Efw15VqsZCiPvViDOja5j0maUU1bv9kdImddbq5vKez9a165rxjIv/zUsTpHWly9hYSTAa1tv/6U0u1UIMsYhdFmReuzRIekjJbv2MpzoMHMY9fDX4dpoPZUcFnrKeZin67s5mSRE+SZfZzoPtDLi7JLTkaira7q9K+wwIn+PUHWnDLASvUl0sPdUKxDNER5caoYOhdtCnjs5QP2BKjUw4/VZoAjgwhD5cI//NSxOkgu77uFkjFy4vV0ABZty18BrWm2BDcGR+/khyQ0gxviZTLIKmpI1KxK1r0rNRRk4MRaLk61PZttEwfef48IvHTVPaoy7h8ZlRSRALDGZ1nrPztnZPxw1qGPdFs6zJx3RUfvVLvx57Fyxxl0mgVF9e5i5OpCLqfE0F1PDrVF73/81DE3BnJov4eYgSerIBwqbcuy1RD5IIe0jO+gxIWp4jDFhIkNlTqVAYFRpb9qlf0O5ii82v5sqRDpk2QG2CkYJhBLnckM71crlRGsYpP4FF/5is1iaXRlYrMW7O3tWXVer1Zapsi+7faY7XZrr4YpFZSMdnKKGFFCggYGLV/4dZt//NSxOkc8oLhVnmO2q23BOJzWzWERvohIGYlGdXlEipNy3URM0iIGtIJVOgVFBOGFQSYGz+5VElS6whw70EFZ2Qc6gGNIDEQsjKqHjwImrl3eXZCKZ8IHTnKhRmvy4HsnnsVH3LQhcZ1y7wO6pzAwCGU1HRoRQ04AJiK9nipRIovePX/81DE6yEjJuoWekTT8SRKVJqW3ajFMtjrUarjRGxyVja1Y8Gl2+0UyTbgbXaaIW8oO73DIWjuU5rGvRMo7VmUExczW7U6UWP90rxmhG/fdSlMAqtu75S4p0VviepkyJPgbIw2nirUtfStbqmXi+vmxz1/dczf45InbXcDcylIkpaP//NSxNsZYW7pdgpGHgDUZcbRUTGPHp071PYn2oQAASbck6XTgem959WxFi49NkRSHscRYyRjpYd/IO6QecjG9gYWOyBhRqsOpu9DnYGaZQyf2CQCMyjHzm1JCpgabo0s8i117AUaTa4LLFCYPgRKHvlVi4qIZWqQ1kZVyepouh4lGY//81LE6yD6pvo+eZD2TJKzK08p18QAgu3Je9MdZA0cgGY0+yKVE0zFDXTKSRp02pVddqk4doDGDDT9afCpfdTYiZx5EchjTNysmrIkKF3X9aSOotSl/En0hEui4aTvqdk3zKLW3pKGXG3gTmtNkYUgAwNa2Jz9OqlemKVpHMIKwAAAN//zUMTdG3ly4fZhhu4u+JdvqPmxZJYbzQesNHGJdSMCYYzZRYikNUHIhfVQbl4ST0nK1gljiHAkBzieHyeiZXE+Beg86en5sm4aLCRYnbTqkJxu33W1mzXfQYdrNua2Hs7fkzFBbHnx1Swda1vHvQsqBlmExrQgbU5bWQsdenhqSUb/81LE5BqZzul2MUdqJYqoOkFmF6U6GvPopOuviRJMSlJLd7TULAjJozwfKKrcgWBpnCnj9cqVmEQxDuZDcW/bKRQrrrpfSzPotfD0/1188X+EQd37dcD7pUiptekv280UalpgdjYgvVxW43rYEKyj0zJbJF8ruYxgtu8y8UbIBYkOaf/zUsTvIgGu0fZ7DOzqgZBdySzO2YemJeWVUZOPhudj0UkxPfRChru8WaBEq5VnQ5hUOxehDOsDhSi8pnzJb8YQbPzJj/yhBFUYX+f9CqXC8McQWGKp7IqaJcjv//9vhS2JWPcKIz7A+PUbY8TgJjAGs0b1YkY22VSlq+mVaFQWHhEs//NQxN0Z4eL6HkmQOmlcZYgCAWblvouZmYpNPXrDmLMyH7tlgwFchqFg4KTgbz6SQIpDZeYcv/hdvgH6f/yvsTT600gUW1Fi0N8y9QgcSRiGbbL5DL/O85/uzUt648ZPhGhkbzv9uXeZHnYWS90InT6TLnoSz8+/z4Mwyb6EC7ck9v/zUsTqHepy6VZhhs59FPi8/do33aU9+PdqiBAAZty+ivKEqb1l+SLtKULozBMwPCytzekUEoxiwUVXFBUqjOp2VxRnkUT46o81v2X2cSUyaJM59YT8aseJDS1EAIIKnVbnJUGAQBA/OGCLV9//Hq8WrsuU0PyztKTUTtSmgQAAAZy7//NQxOgfmybl9nmG0+/aA+Z2xWqqp6w5252fx8PCaGGozKJjQeMoXn0BKexAhcBKFgdcKlh5ZwVmEwBIrINJp1IYR0rs5u5VayEZsv9g7CvFYmMzlgg0aF3BQVf3IQeB0wlQQC7SwdFHJdY0Q1lVllAizWsFQVO0OGhubQfyrrFdUv/zUsTeGLFa6fZIxPLAy37q3hONIh5SUlt39KBtGk0yJEBehKPSswDTKOtDZMOpc7adoxCnJXCuZSIhGRkVYcd4EkJM2cQP0m0eKCKOhhAq70/8fiHY5khx9muySz/vqG7/9TbMHHhqMLRww6x7Cg4SlFqrD4saurGqv+x3adV7mqQk//NSxPEgQX7WlnpMzFqooBC1uS2YCLGxIRilQM6RYygOnqXsXFKaToGyaa5kreTthzG8q2NAGYg2YSxWzlp3ZvlM+j0schGG/XqtezsEp06aTY1G13meFD/3+HufD2Pe7uYD+dkbe71wvJM+dP/bYXtv/+ru1tkV+x77fVfu3+d/iM//81DE5hwyUvoeSYZ6z+X1Ba25d/KRRd4kyJpxdAjcmRtQVeWMxMPRV60Fe7/2IjSKpypMY2HbbNMnMRpW5FqYpE1DyQpnmeVK2o2mOS7v3KjE6IpWKf5b7PnuqWPVb3zs1Lr6pWm+xxPoj/1uvp2v5xvXAo71fTdKdSne8wUA0k95//NSxOodqXLuFipMF4rUnvwcyqkiBbkluKn4tEQTlAREq96KcxOQI+WASO6GHIyNjRSM6LS9LSeaysTKJavThSUbK/NpBZwyLsM75+sPn7fym1yUoThw6FE950QPFxU+eEqTUk09Qtbv2OXsgUewMmBCXW4oPHsSQb/+aqEoADMl3lj/81DE6R4qsu1WSYTfN3obT8kI7sEJACC2iSCGUQpVl92J0oAOjupNRWWjkqpz1TDKQ/LxwqPC2jTsLObx55mj5k40tFSMEjZCzkYaFORnzHurokUtoOO6sslGdZkTXZC85/QtnUx6qLtwHDw3QUGWdR6hsCNeQcbpVEjLUDSzpgG0//NSxOUaMirx9kmGarX3fWlQ6ffbMKDZ6+jphhgTqbDGK1qNFTxT9bVaFSEZLkbNoom56cDKRMjqaarcnUrvbuw+BZMyqKiCVOUMlWhT3S0l4PfsMSMZkq5pkbdmZ62zgPAw/831j6asHyJqTuR15COuOGcQOENrDPq/dTOxl7aTBor/81LE8iJCes32ewrQPUs47pfZKtUmtYm9RJy/2mT63/510ZQSZqi3KwLtVMqHCSLS8lvhFLefUv52ISs3kk399jRzFumX81bxWw0FWu4tGppiuqVhvySHwkHXobaFxLEpH6CFSdX5F9GN0N0Vvb0L6+7GNV2MjNQe2n9NsjP+n9ul0f/zUMTfH1rC3hZ6RrF1qRBTHnY1Co4aVahoHqEC3Fj3cUNq7zYTjbccd19o8D6SAeDNOKhIDFdDBq2j7McsHa9e5GlN3TAKWzSOl+YD3Ihjsx2aruKe5VLfZI7S1RVeioUv+83qWhVATyUN/rL6PzFbWVCu5Lbp1Gkehn4ZYqIRYC//81LE1h3DKu42eMVKZklPO/duKdDUFAmFTBp7ffICyqmiJVSSktujZzSgKikmVeGgSNyvdsEyQwulGmrStTL9OzbaFFwYg8xSQMeJ7GZZuYpqyr5zK/SPKdLL5n/xm2SqrHCJGkT/JUYysq//eTCrVWiRhBdDjUOnoSqLEh9AQ2K/9//zUMTVHFqnCl57BFoukk8OkpkkaW7nInF4doUQfpNyWXeCfsTmxkiiFAMDMcFHjx4KpQxqOsQTtCZkXgZGYIGkMUKCkrtdTsM3pGYIRAkWqjnSRQmLK56eTih80g0RkVvAAYmAbUccu1AnihYgKC4EDJhCh4eADyCu9la+bcN/l6P/81LE2BwySu4+SYbSW8TB0GlMtilNpCrNFhZUm5Jd/aqw2Pgyux8eVuOwabL/mpfudsX4i+DXIpaIKPDow/aNgvGbehvJGMxbT9tq33K6vfCbXD4gQzxp7UzM+1r9TJPvMTAb/1Bf9bi78WQAw6eLTEIenYAENdpv+vwe7lnb/vj7r//zUsTdHFGG6h5Jhm73NfNOUTGJIHmMjrYnkpMWVgXlmPt34zQH8pycdCkIPJ30+GyLKPKhZRtFABWZJNd7n1OZe9+bG/oULpcUEC29nNUkDMoX0s6mxgJzmYE1m+pLE1JQVSGJA/8oh1DqumKy63XYBE6alr1rFWbr4xCbxpZu5pgw//NQxOEpdA7uPmYMUxhadAwYYpRTiWIEim5KttLW6Q3f+K/8PPmk/nvz29Rc8zEUm1Sg3M6lSanVGieOt6v0OPvQ4dbVDz/U/ud3U0/zn873u/TvkV5gGk0ITRxT1cxOiy5OQRWVYzChCUobb9QPlPB8gqh2pWDBPcHM8UDQ0CTgJ//zUsSwJJvyyobAz0yYsBEp3Bo1vLwhcFSNutEFS3B2W+x/uMPXgi/n5wzA5koCF6EI7MEhyVc98jpvmUqLkAnRs3sJ+Vu4IV0KvoZbiyHPytoRTImU3Y4p/I9tDdEdNGf2/v/6fM/leh6CgQNPbsQGDLy9tlAgIUnHP9SGomQmAYiE//NSxJMhA8ra3nsE0TQcPuh79kYLrbWkpz09MZg3Jpa5gzMV3bH9HJbJScTCXmI7lIrkc+d/WRGvOt19t0IeQgRldt/vIxeD79Hi6TTqe6tQw16xyAo5pjvWKBgQC6f+AAQBDPoACqWSMBjfJt4K5rAPcD2MJdl8oUaIjIbEXAJgeT3/81DEhRoZot6+eYS0u2MCVrFhWZFVbx2M4kbF1Cu+xJa+HD3LJ5BGaubxXGLETepc/TmlOR5+WnaqKGc47Z/p6lOq+3dFdThcG4sOFRRC4rb/nqYtmtqa3b5//v467/7mZ4+30uMfBmnzcVW/jbeFY/qam4rqr5IHLaTE9jrLCwoI//NSxJEmJBbatnjRUKeLyUMWxwy6lIMwGZSVrf9nB94DUH6W1yZg11yr1c1lBumyNYuWKExayLgtNWy2jK2GC02MZpjqruloeiY+9/comzWbrm7SIVV5ufvmwnFhD2GDJtNzIq6BTJ48Bi3RdoVSnS3vL7WrceKiIPEcXbuR2dhUJuH/81DEbhzhpureE9AQcAuDrKqalAKmZudhE5txqIANjJekJZNTQ2ZgoLxwODX0sjikp2yyzSpwRuMuOqrSqOplzMtnOyV3QqbL6Z30aWyf2XdtTnOfIwQiNk5G73kbyMpwgAAMBnndMl87kIRjoBi0BCTBCET4jAhwoGAwHwwJw8f5//NSxG8dSt7VRGGEtMR8T5wmhFWkUgXh/9CeijpZaAOFpYYq2TbRCN0a8xfcpobGpvANitAZsAyTilEf+SNzh+E65Oc/nnlFO/zXzdnaTnf+dfzz4ZjSVdi9xExhBmbS0zLt9RJwdS0zRbnHBCxyVuYWQwt0jbCCaQQkYfEsQNByJhT/81LEbyKEDuIMME0Y2OMgihu3rbGunZ9wycU9Hn131nmSknfX/8GKt0UySkk2hAKkaRgGqIxAgGe6Kgog4W/K4CwklQ+wvos5TeubduTCtnjbpqdLQpcy++X3/m0xf/56U+6r+WfHmqc7IGa5MsJMOk4mbN8Jnzf/JvE0FTV7LJjVqv/zUMRbGNOy+v4YR9AaAjN833DjJBXyxq/25Eo0DMD2qiSiROFpCHLG3h7jNGoDsGujSZG0z7Y+9ckrTcuoojVSUyv369U0PdC8aIOzv5HbmeTm6EIyM0NBUMCp4DgercEVjqXChhLSZ/MtTUXv/j9I8gMlJXFOjFuKHEE1tVU0Ucf/81LEbBmhkwI8eYZ6LYQDuvogJY2jZqZLurddJJUwa5ilyZx0ZFy7paZhhEw/uHKqOkrn+VVTKIV8m/I5CMzm/7v+cU5wmJapVa6yb8iKuutqJhMcWVHlSLKnkgy1y9dFfRMkQ6SHMPzM6KhoklXkpwQotIST7LH14szL8BV5IgVRhf/zUMR7GZHa9vwwxPSAkVNradD3EYI1sbogoSj0chNHDaG3EWck8VrZtC1EFZgqD4jCOaD9QJEAXZV/JVNAQhGDSIs9VaA2KjXIZaYli868jBo9KnRd3V+zke763YNB2RWgAAaboP05huzqddCHJaJFkhiVaATAY8JCMWnJx0xtEkv/81LEiRnhCuJUelBMcqtYPbgvs47SSyLDoefXElcpLFpqxitmeMiYiGBUsBSrDWvQhbAqVclgKkRkCmQks9YdlSKodIuOnaame7nQm7OrOkhFLFaVgAAku/3vWjSFB9cyYBEuILhclctH5gvuGF1+LX36Fz+EIupjD7cXSGAaVH2ei//zUsSXGiFi0e55inzaBRulNZ0IkOfPvPW5/jW4RjSJG54s3oIDEMPBtyFnnLSmgVJkdE4o90jkkEI1etV5n9LLKdf2/qWBABAJUjlrc1pRHE1UbMIdKvjDGZLU0aqFKhTPYrobUiqnln0Mpvu0+y959TjQFHLHgR1PyroRi0e5DoPR//NQxKQZoV7AvmGTDFBQJnhGahgqJA8aSHIjILIH1m5+zznax93sLgTfuTJ5gnDCDiveZQNKCdWAAApf/SBWSUT8HOLGcaUgKw6IbhI6eJqRUwcz03WS/+X+cNlXniHMfZbyH51JNh+bRiGEGD5qfT1un/lGmJjG1ve8Lz1//tP9rv/zUsSyGdHK2h4wyvKL6PNvPMigoHhYuIA17PRUXIxqg0cG4LAjFCRCKPMIdW91PiuTGzxZAwQM9QHCqiIyTtMiATlyISmmAogC4D6ojzG8qdL7vgj8VipEZWKlh1CTgID5aBU0nexaQReKGTJt3UjknO2E4i8GNcBOAM1dsWhWZkqF//NQxMAtNBbNVnoTPHMz7VRfklZMSTKyV7B+9Qr43Hmnia34dr3xDg6hv3i5XmKBhOJFqb46jTaw5Sx48v/x7ui6fPM5WshTu3v/zpSqtwUyIxSHQ7DkOhZkdMys5SP/+v73vTM+WhwVFESU248LYnMPT4a+NmNv2fsyVe/9Jnxqp//zUsSAI9vG1XZ4jZGJPdkl5PSc5GcLJkq8fF4qgUChsSIMlmw7bAzmpzLSpg0T4MUQQOQepsaLam2pTnJ4VW7rTubPSj5oxfjTBStIINjAzVIz/dqEOXXhUZWZ3Reh31KmgJ2tMurtoR3SQG55nGOEgegtofIzLEDokWNY2NSWQz////NSxGYb2g7q/nmEzMpeMQZJCoxApTWAhhwAFfvd/uTLGjexKxiExcaxlhHSQcYUlTnJ5s2zVk3SZSCREJzbh6bmZ2FCgIktr22qWj8EqgIk6BgAiwkrqCiQk4OWPAIrmgCJQ4OeAiKgMHBuBb/b4VLSSbDxY9BZdF7f/9S1HkBMwVH/81DEbBupjt4+eYSwIFyK4A6Dcjk3nUhseK3TtqAmtxubFk29lkyak820EDzMVielzEIHZCdMknqsrpIqOg4jM7su9ldMJ5BdZTrU5tpshzuZOm7nXeztust3VSGOND6w68o4SMCwYGGDgtd+pja09rRc+JAgCDDio4b/8+Rx5aqQ//NSxHIcEiLVdsGKegdNOfrPBTK9G4bIVAyjN2nSyaiw4hezIzq7UDKkWyWFzRFlQsNljzauTksiSQXGUak0ybRGgy89dTl/BUNJQIwo5ajCiIWUomxSXdWIUrK50mI5XmV/7Ss72VHqrNMYrAhSoi2O8yb2/9f2/pza2C2MpaIBK03/81LEdyL0DsS2wkSfrKh5fr10Uj60dhQk4QOOJBBQwdgqoAAAC23dtWeCDjH+fbaZiNfUY2SF2Z4miHmdOk3yBmazujhjJektZE53OY5D4Rry+7OwFRe+FRnc4H3008DYi6N+rCxMXRzgJRDRUTsAYnr3NbcWXJjaxNOnnxouFgTBif/zUMRhGym+xf55hLx7N///tl3lAzEDoIWBAEBK7eb+nICLoFYi0OiwqLGmOBCeMz/0POxsHJMTLnw+lLSS2epcx3q3Wq1o9p26/pYwHIikrBuV5W/o5rkqWr0SkjkW790Iv2Of7f01bd03ut1KUYrQbu///7KYueFwVgUF1EXURlT/81LEaRlyus3+egTYpKWyT41htfgxY7dmSzbE3fcjI5WySpsEY6k+uPLGPDJfztah+i0cSEQ5r6ECVqa3+aYR0+0gzyRkrf//cZf3PPdNzdVsAmouYJ1QeAAz6WQgmleCcQhkA40wkdLMt+fTICSuwknKLcpKk4B26UVxG21xwoQJv//zUMR5Inqq5Z56Et7Z9Sr6NmgCvUXFxo8OiQ531KQABTf3DtS3Qga1TGpSdYTnsskQRM0UaOgbKKktJZSUNHTuQNJOaVJhwidpkwUUVsiw7nS60q11GK+tBNf0vt/9Zs3ofLifqJrescz1Mgh/+i3XS+3qUbMbJHfr+KGpAy1Tvbf/81LEZBpaxsoEwhqYqkrU1rM12Ca6QpRqW6wQ71PIQ11vcRRg7y9OFatjcofF8OEoJbJqTRjwpodmj/cgs6v5Th8ZzwGWRlMml9IoUAR0XFkcoCZB4fdKB48UxV6DbkicDq7/8+eWXDYpWjT+0WaRYQv/paTLBlRd15LDMkqJpy6a3//zUsRwGgEG4j4TzBT9s9IIl6n2BWDtCHO7NaoSzhsGFdnukaCqpdGby0lQ8TuyXxZ8/8iznnh0xfzfGG5Waz98I7ot2T0FP3mfRFbvfr8z8grWZEqgKNNC1P20vCRZwF06f9T//kXOJXnVSKngIBgCUrtf4EuMOjCIbBlYMjIYni53//NQxH4Z8iLqXnpEnEkFiNQkda9ftkhQurbk9y3fNo7I+cqc50mZ8yjn/XN7+86+XoE1oqbKHz/EoYcVct32GSKWgJoGnDYnQROmuaaKpeMa4DvFNLv+uLu6L/5TQpuloAYACkktw1V7uA2O8s1Y6ggZW5MojsFmca/ZNU7EYhZ7av/zUsSLGjE60j57DFRpfDNYZklNagl7/zwwlB2s6gnn/rYZK1F41KnSu4Ee//NYd7mghcCYRmmVmUSM+77F2ssgsjPZCdDt17zvVIIRK7BBtSE95UO31K/kPsCE4lCr1plhlOAjnl6RlYon/+kYDiqBgTAJAEkuFWxtxDF3KMlQh1Xw//NQxJghCrrN/sJFMON0yMmw2zeW5LYTqZfaHIqxb0oGPWpXPuhU1EGvZmtnEop2Xrs7rnOBkfRf/7X9Ko6EIrUIdaBDhVyUCinf1exRus/qnf6/4hApisMKDABAhkAg3ky+EwIslrmzifg/m9TGUbgDDeA4pAKU5lDBiLgCFGhqrv/zUsSIF2IK3r57BKjbsXSzFH32tfkQiKVwvrdDJUw5q3HAELEq110/3uZ/WRXYiHQz5DI3/7MvtyWqjGuim7M41DVS8hXvecQHklRuWiMsHhPeIaRFAGNrvlQSj4+7hCHYWlBDiX2fXeoQNVI6cAB0R4zmRoap4A4qVOnRLKxHPGaq//NSxKAZOr7SPnjK7d4KjRrVPMJBU6aAp1o8rT/X7FUipUSHgMeWJcOnSvyr0MZPWBJZ0c12ZdivdJJJCRSU5Jdv3KIjbHmIisqkGMcJKCpNUfCVM3/BJ1qr7lT8F10JTKnPlBAr3Oppr8DhocUfCry7QNFQWJhYOEGIqaEhxrAt29D/81DEsRopBt1+CwYWtAqKzJkzjaSDDxoihKu7Uk2lyCsPV4o90RGL+zW9aiGACRyXJUE4k6IsiTcawuHiIhMtExMjglm5WVUbtpXWmW4lZjCqOSY5+Xm4xO1VSIfb4C9R307lu7vXX/2iIiJ//9f//oiO9z/+7/oiO7u/+9////76//NSxL0Z+TrZnjDXKjzfXCSiJzc8O737u9S7u+4uhlb8i56fECgpUHxvfblmJ8V6Xy98u5iIggAoFKXUAK1JuXUIwVwIKBLiMRDIUccYgXFcb+N7eXVfMLoyd0j4uZuVW35RaXaun47W7734ScBR35brnhmWamv4mpXWV7/j/5uLY6P/81LEyyCkEs1uSFEmvvq7aFquWtg75Wh+azM0D26ej7qrGFHXX/oeakVrz3t/1IylZhCk6hlTVIdMUl2xQ+UYY61jcmaFRltwLQ6ByaPpRVyYZAbDxUGtKpBYDWk3P7yL7ewH8eoZwN4eSJesDnNEevI1jM1pFB1gELAWuarxtPSSdf/zUMS+JMwW3XZ6UDpQjYnVBAUQvud5QEA6YNHoAQfiRUPFxp5QoQEblLlfBU6W+qdolnKe5AKlmBoFbz38t//41NBtYK1uQqqQXq1tOXUovBtdAmRdAKwicQDwUOapV2YoxuCUqIiolUOAgL1m5Owu1VmjxUJCwJqEDEfY7sPGB8b/81LEnxlROtV2eNLWUGAYqHGi7a2r3t+izX/t7a0VTpZ016kZHt//6tqpzi50UjbPRWVnb2/ysREc5z7HOiFQ6FJoViOcaPZ1KUQYPiQjOrBwPoMIBD3gAFwCBNrLvxs/Xb6WyeNLPCKwo+7IsSU40xwlGksfZaFevmaAcOTLCmj+V//zUMSvIKwS3XaKCn4vBK/QSSrtTkY2Gvm4iGwfYaPKe96cEh4OE2AhPNeQFHVtWIREdjteVKjRp7Ern+39lV0Z15V23Ue5ZYEDW3HN+QATRF6T1sB72UYZjYtZ09+z0GfeGFmluaRSMUS+BvA9CCI+cibajKdXkeWh1SCwKFwwJmD/81LEoRmhVtI+wYp8aDw1KAWLCFGgSFCkE2rVGmJF/vqx+ADiDLBpq9JgKbP5Q4o4r/da+y6Opgirply27aZfphs2mg2yjTaQWxyK2RDfY14OTlRUPJgXIOmsWmrsHALRcw1dxoC4jDqDtx/+3/zXUOKzbliNDO91w710/x2sRW1t7v/zUsSwGQE2zNYLEB69pVw6/TfBDkbniMPNuXh/e1vSbqql6i/8mXoXWSEnMF4oweIZFpaGRtSP2nFfOP1YYJTCnezRwu18Pqv1/sG8SPlafNYN4YoZBHnJdvWH3lPRV0ZVPggqsTJZusUBBU0OsHbXK5JfxZuZcSTDrO4ACLudC+aO//NQxMIkg2LyPlvQL5Y2WtNSGq5Ve3/rYEwpFO2zo/7OQjdP/+3RF8W0gAMbiZwYFaTK2EQOy8Ci5kkGAWeNqTEf/g0xr/btjkK31MQlgYAACgbG5lvTYI/GJa9ssApFJkVjQOjqTaA0KsV7CxBWNCneiCqJn0wMKINlNLYJGCi1Av/zUsSlHDIa0jbCxJwU70KcN83qMDudGUkFRQKhtQFG4eVrMVnuoOqfnusisY5jp1f0+o1b///1leROnSyi1CqgAAIBkUg1NS4PRAMlYwLAP9WX27OB/vdJY1aJyXe2pAKumNhOQkh91WEd+Sa6dhwisiNPSBQJT0bgRdTQWEUghHpy//NQxKoZiT7J/sJGdH//r/7HRqW9FrZ2ZUU5QzGAGAxFFQYJiRYR5MI7P///+MpqGdAAoA1y+4/cm0w5NlKIKAXmDV5tx2CmMDBOVNY4ql5eagSJy6L1rKR47MiKDCOLoJocWe/ISShStjxqS9ODTQYaaQjYFQosm6xPxE0aVrr2Of/zUsS4GbqG0h54xRREBgVaAkQKEywOuno3X910r5L//9TFqAJ2ppu677GToTSaTLNkkdGbql448YQnXZowdKcZ4bkZdkdQzNBlUjqdMm9vwj7Kk1+hSDAWXFh8Kndax1YRyeH18uEtW65hgVaHXhxurBWKHp7Om0NHYaZzq0P6ul/0//NSxMcZoWLNfsMGjOVlnin2FkLEAFm5bTCkhCQk2pNELO6SoS0nrkahu7yCI4IQKCyO5yECmIFMQ6mjHUxgRedKsqupQh3UQp7Eu+uSiEbS4LZ6no3+alEZ6W35lVrb9c3//Y9m+Ziabf99BLKnAOJgoRFnQcCk4xHp6usIIJOqzVv/81DE1hmqDu4+YYZObjbbrNg9x6QLNhSgzjQW6CVaPz9yZk5gGPLH1ZsSEZCTcTvQKLby/FwQiKd5wFqyryFn0kmJVEHbD9evlwxqBS5a6bZFPVMMzKZqenRJnK1XvVp66OWV+6oiymIMzaip6uXGDqNH3eKvJSJGvO2YOmRZYKNj//NSxOQaQyrBV0kQAoRX7fSekC1Mz5zLi0KRxiatuz/ceG40gOUuoU9oCumaq2lpebxKWm8u7ueMzwN+uM7j6+JHj/6za+4td2gw751/r/71//9f//V/Amr8/eafPv6ffpevlilSzUPSGoxKCjBFISIUy0Eyo3KHd6QpkhiREWhK1A7/81DE8TXj1rV3mHgDCqMu24DIIcaU1hxgTSHeDukSofGmSZw3HcZjYTnh6BMMySSR/MWj+YKkKscNz826SSZPPnzR+S00B99LSPRwuk80S3vM1mXJu+DFI6lV/RWOg/bnXxXv5unU80bP7fva2D380j7Xwdx1kYd5eN5fT2VFPJZP//NSxI4wW+bKP5hYAbPnnqe1lJO9pcxt/DtDZM8ffxR8499kgmLsZHve9qhOII8k+0uZOufE1HEXUtbwtPMxwpVI1gJcci2q0NO0w4te4OTAmsG2QZBXEPRqXPPKqLDPc5ZpaSXpGMyNzE+5sYk5ZiiXRjB1E7KJqXS8UGNZsMQehgb/81LEQiNSEsl/2GgA5NE+LpdQYxdS/rVR9aB5iWWfcupIrv6lJOtF1dVTf11OpTIpOcAJ5orCgvABdm0Vy+XKuL9t4GLJ3XKFGDm2qa2sECatJAVCx0Db1aIGOAFxyu26v8m05FALTP6roBVZBYjDc7tQ4eJo1He54GY8SmdS+Vxwzf/zUMQqJENWzh7D0HyoskM5SSOH7c5sE1pHNUQ7NCYLih43mn+K64h4R2JEAPJxqafrc8VESnCaXMTdOrxUXUkZ6nhxUSkO8712n8XX81f0y/3/TmpcFjDBEtUNt+omvu59//+7+5QwEG5jxcIiEQJ2ENIGkTAQ0ABk069iwb2EeCf/81LEDh15htLWekrQHFW6YhPCH0kvGURaqxyymSt+Lqa9MbptIx4uMQp4iAoGMq+uxuJNAEBGKy19CevSYjIYzP4gKN0kqwTeVFhpEF2qBxKRTLaNnWWBdCXxIJ336oq/ySliqz5FKLmQBKRIoPtEhNwcS1TwAGVASYU3KwrrlpVxW//zUsQOG0nO1j56BMxsWnJEWr+WPdMhdvrwmEAI1ulEopC5wFo9JlBRZ6hl1Ci1qEcQRMELe0xm6o3UQ3q/BhG+2iIjVIOGIScsxaEs0ft8tQqq9hUIiYPBU6V1f+TPnWi7if/KkSgiAxEktFWCBgHqCmq9t3qobaGQBZ/uGIrK+N9T//NQxBYZI1ri3mPEdLoY00z+Jtuzu8dge7plvcym+sFKDJ4JXqqP6e17pZlvt7gZ/N9dP+3qN9ujv9+hjdWZ/t8QecwYjzrdldDXt////86sCsBV79n233i9ggXGECAXJPNsK6baNpxDVOlmka3iHT4nmRRktkKaE1susaYk8zY7YP/zUsQmGWqa2j54yxAqS3IgeZQqHptNGBgGn+/WjRH1zPoIGOAIfXKx+rSkKVrlRu1qG//98yl0mp/6leUgeHxE9wKkf/9TYNFoCNSqMJBW5Jd8uFMHJqwcFBUyCbnIVhpBGdKgcbJqzNKvEG+a3OdUEyVood4WINiAuDAWYfOB6Vni//NQxDYaIQLQ9lmGOoiygqAi5BlrLTxYsaiolSu0SiJNNZ1INFZ1AGCgdbo/oEUKB0VViJ95J0JiCsAgtuEI6pGXrXJbv4Mk5TZOERhgKyCxPOTDkfZydJaiSuhJ9kcTq53yf0nhBMxfz3935re/29S2ILOjn3vhuhcTDUCjLVHzS//zUsRCGLky0XdJMAI0JwmecLSFw/FZ4forvCgNy7wkqEXlndgro/+AnvWnS9G+lAgIEhEkoxnVaqZwYyroJEwBCFqznPK+zQHWoH6e+X7cgCAoD8XDZIIhuTA9rjeOgahyOgmgkEKiWmo+k1VE3JRoRywdklTE1CSySWannSSNN7ui//NSxFUvbBbCP5hYABjJAuew404w5VrLrLuijrlrJcVE921w7B2HIqouE0adUT1mj2HXvY+21L4ZNebn83th9Ruo2Z2Q9Ot16tcPZENuapj4OH9ihzY99PuX3/9/////+5889VLP+p46hi7DnvJknzk7KY40YnoYjKgq+6QRb13G9L//81DEDR15PsQBmHgA7qCCcuca8wQiOh8aDQ7P8sDECWLmqHDLEzwYV4C4PptxCSMVqndQm19WX77dFpEze0GlNSYxi3m1nNKYg+0yPARKh2oPmq1hRswC4bFXfHbqyAMuhJ7okQSUbpihJpI4za5sdHo/v/4vkAI1RKc34LaXUuIT//NSxAwZAobZd88oApSLeCnRYEHuFJgqTuxre/nCEDhwkcpDEK1mZkSRpaUuU4leZlK1iTOs6GqYzVKqC93Wjaf9PvUuf6fij+3/7d4xvcJnGirx4T//5k7cIJ0hMp159zHNERWskAqk3I07qiYsfQdQNux1ShBmW1h9Eg02ZY+O/HD/81DEHhjrfu4+aMT7W6BgyERn9MsyMroXpn0ozHTbmVn9zGydX6lM2WT19U+j7zv9/oA/f/831/9VE/+/////9yIdGYETr7LrO5qiV6mFnV4+ytUBlptJy/LdnB8ifPtQdNYj7qFeTZ7hbZvb0LKUlVriKFPOkYo7tsVcOVuU6rah//NSxC8Zq7LdlnmK0vnSiG9m8hbZwm6+3/U291byW+30FfOb6ep2NJOb5ujoV3e57Pl///m/+RvI+7S87Cj57AqXGpNNqCAIUVE5b3GazvPYUBpM5TQNwHgXd2cKQhOqG9VXEDuV7JO0LgXpbSLiOfRztnuSKeaemjlU97r+nb3DsRz/81LEPhladtIewgTcGgRbvf/+X+r/1dvt9Wzy+9vUuhRYl44a2aDoDIB0hZ//0UuipVqyyoQABSRTmVTlqVqxsRrU8Eg0ItdXuFmUQ45brVZiGA8zdxlVnSRKhUWaXummxjVxBZpvuMurV5omtZ0Wz9dWDlKan/90Zvs9UjdVvWmFEP/zUMROGfp+yfbCBNZkWVn/vN8N9cGxoSa/o7f/uykVGmrU/jS6UaghOWzf/5ax3j9ovosNcWw8njK1MzM5q9iVZivWea2wxoxyC6NpUNOqKtREhocxAZCCLUbhIRilZvkodgsVHIlm19fxzVtRpkraRNnbKNSK/pi5kNcc0O69g1r/81LEWxmiJszeeMrwHEKhT//CSjzP6SK1wABluS1EaZASwcgBkuQnZIhIujiIkTSpLSi3qIud6AhCS/dMc6dm977M5qnJY35DKRrj/8Qm8OQo84w0jK5f0ysHuWPRVdTDtpG6IupTVGVVCoZCZE8g6v6fuvWiG7F66SU6hCJeU3btt//zUMRqGLlqxVZJhs5JvUffaQFmEU7pllZ8dzfRwzkSgZsG12ZaILy5C+mR51I9KNQgAcL55lla0Kpm8Xc/SM7V0IByTsuin28e//PRePnds+f5r1fytLGlj4YFkkTnzlAZVQH3tcn9/vPu5QiZ69VPlNyXDfI1FEezjZLQirdjxYT/81LEfBpCVtoeSMzecP2c06uuaGWEpRzPBvnCmRlheT5UgeC0JFtDaJN7S2PSwY5MjQvP7eO8yCi6Gh1dSwG8Wm0ak7RgSQKhse+QEgHYH3C54oXEwLrfd//6VihtGgWkaomQWZSclu3666lIwgbNtioKh7LClMZSNddvOz6G2T/gyP/zUsSJGdG22X5AzTL4uYlRwoMHV5kVgwRbaaCVVpqXfK0MStNQW2V9J66FtP8j/sPDHjqjqR9KWW6dAqmdP1FR7KJs07eywWv9O3KCZgHeTc1KOHaQWnHL7XTFSaA0eEoNhrDwkgS5NGE8OZF+dEeUiOnXOUMqstr4ZU8iNykyQJS7//NQxJcaMfriPkmGWihOJ6/z8lQWcym3fSebjTlZMRhdwmQSsc5BkafmkJcx8k7VT/8svc9tMK99aWNo1R0IKtuS75JGBIQ6jC1KJF6gkqTVuzqdq167ivcpB0DmS0mXHcV3x3EFrpfken//euZNnyoZkSHCZvI3v/FN/LXCxGIyzf/zUsSjF7m2xLZJhnYe4s9z9sEyRQlLP/5dcJkNdYcg2k7WteGjq+CCr5bLhsBqpQJ/X8l2YgM9QaD70Wro3OlOT00m1EoPgOpHDI4c3MEiFdmPCAhP15ulYM4J4cIQ9B1Wl2MLuuzHJP/QjM0Ca4tZKMcxJ3sAjt3qIW9K0IF+ttef//NSxLoZW87Q1kBHtkRqnLDibg+xrwyibjmMhhyqwEQDTct1JmxUEBGibMUwymF2XiOTITT0gkYTqTVYzLGErm4nTaqHhYKJy75WneCZ2UeEDnd/bsz1oYtHedqEcehCIyb9rFay6if3tdzUQp/vt9PtrJTj7CNDndZM+cTi9QDI2DL/81DEyhkhqtoWSkYW0X3tAyFwpG2BEG3JLPkxKUwmhXLySirzx4ZIQmuJRAhjpfli5+CNtDeSHBpB0RA99eDmZbr9olnPuHlO66ePvGMOzG+Y+2cWkQbMVpPtyt0p1gV9q0VcGNuvmzUCXI9ghv1EKnke2g/eXhMZXMj/2TgkFS+5//NSxNobKs7FdkjLRg4Ig3c9CCxLG3a9JCu2GY2ECGskDJ7cCnJtZhHqJEgwuBojgPQ5RCDFB/Ni8ZRe1CQ0sBpls3Gke1AvH0+BgHIiuF4yChYgFcdyYJI9pjsz1aMFCAsOjg8OU1WsHZQaCQ/KKFYdvn5HyZtl73xkzEYl2SqS6kL/81DE4yD60r1WYYc2xexk0azOzsYrkZVCPZabJeRzNWi5GZu27fWV20Pg3cv9ru/+9RECNidNpQq2isAKs/JdsiFqRiqBIRNG7YN9s6o0gRsTw9h2TEDe9hN0VVrEEqNnjSxLHYailc1NviM5WmKuFDnhTBBAZBCfp/kH0NMvVrtT//NSxNQjItqkDnsE2BktIv4y2prG0i34GKvIdmRdNS5/5GbX//9WO5xsHjjEanNeOULy8jpGZF5FXMENEc1VlkMj9auLGhaAP5TlfdP9msAAXbktdA0GEDmCPDLVDCPmVEioFCcVmnOW1ts48QiSaFKhCttsGgRYkI0ezY2JZmcPkDT/81LEvSIzqsl2S8djqo970VGJfPWulEKjy2XVs7KrkLJUa4s1szp667p6f/qoqVmrU7nOIixyBl1/6O9/QdW8+8iaXL3ABb5Ld7nyBEySIGicVMULtidEiiKC7HzxBjiWztEZrduZ9WRYREtuMZF3KfLYZUJTKaOHpudlI2s+uOluvP/zUMSqGurewVZIyw7WPX/SS96/2cRgkF3ycayeATJ0xY+5k2KmUIDptUd58ap8JLUKDL9kTJYt1rWpNICSFqKUlu3/lpTw5IWIhA6bs9EGEmZMssmyAMTuC2q0IKkw5Op19SOQsozmYMkLJpAwb/2dwqKzqZ2UO8Qbl3vmxUobBg3/81LEsxs6Cs1WSgbeH2kmKcQEZu9MIMn8MHTrD6SbUjT8TXDXI19i0d8XCTi3t1XAAC3JL/DhsWC7S6aIjKslHoWlygdk07jPc3CgqtQ7aLs77WMds5nR/lcjNdFFjP/7TvRGNuhyTkKtLADDkXC8KCYlaSr5AG3Bhy1ME63HkvWLFv/zUMS8GimK4j4wxUbMLa1tFfp+vr5w+UMZNaSAGpJLkl290dWIjZSKiUHsKwySxcgVIhxpTJsQDUDEUEq+2SZ6ndxyePoM2aOX0jiuJgyK/p27zPdHTxkYqB6uY7umHtAQTUInOFVIbJu/RTExc0IQsFFjhgqB3NhEQQ+AC6VrMlj/81LEyBghwslWSYTOKmV8R5Q5zSrgWUbclv+ICqN4Z7mdSS1YaXo679iJRWev8xKm4ts/FBCtdJJaLdGtf55qcxU9p6HH1cxDq5jlywdJH3pqxubvf2Z1Q6h5xMrlGRuh7q9XpZXnUXbOshGAHjFL6hU7FEGKmMWd8TGkCjPCS/9Lzv/zUsTdG4na2j5IxUapBGrBACm5LTDF41LZ+4yIzC4urx4RYUrnQ9lpUsrtmF8QfrorY6ZeTDk9jbJHdRd48ZbJcsN/jEFHCFb//9mvUWrOpa1IOeOz3PIvkuUIHKhqqTlRDLdLo3XLpajaP1OR8iKaM3u2vtT6tabb09Ppb+iETmR2//NQxOQcEk7M9nsUXnQJgrWHUukXJLd/8+eNK8hjlOFT3ZjQovvjzR8dN5kJ6VQ0JR1UC+LKYLpAstpYxatYplX5+2/ixQMlA6I2kOSt8IXNzTQhpsm0y50Ksc92JSevVvIqeuHBGofqHyrRj5//8NIbZe5PpOhIe4qta2tCKoAEgf/zUsToHZvqwVZiBRJty6azrKjoJIm0RtRYASNCsyYRqEyBtrBTk8BFaJ1iUn2EkzjkopL1JuHIzM1ZZgBblGC0ztp9WqyysrVUqO5SzkOZDGdoizKhqOUr2Z7U5jas2/Lytze7FQq1ysoqTUtGSR1BVQSeRzwMiUWFaBZYwJxEcaON//NSxOcbWZ7ZnnsQck8RGooPYMnpWLYij0vUKxKFIsLkuWBFlKBeFOGsXFQpgyj9SppIo90IJciXHAsRipsAooAERgZKBpQVTQxWmysk9DCWxikSiI2z/1k3xQpIk2aOlmtz/JJeJYSV3/NbLFh+KVElOkyi2RS9/ybufzhVUkv1g7//81DE7x8izq12SYsKqJLuHYQRGRkMCflVlljo9lllI2VrLLJZZY6F//qrLLKj2WWVDNZZZYyhgYIGEdE//yVlBA46Wyyyo5rLLLGVgYKIGf/+hK0001VVRB7v/gTTTDIf/6RVVVV000w///5VVVVMQU1FMy4xMDBVVVVVVVVVVVVV//NSxOcdMUJcDGPScVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/81DE6BeaMOQKCAZhVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV",fim:"SUQzBAAAAAAAIlRTU0UAAAAOAAADTGF2ZjYxLjcuMTAwAAAAAAAAAAAAAAD/83DAAAAAAAAAAAAASW5mbwAAAA8AAAC/AABiKQAEBwkMDxEUFxkcHyAjJSgrLTAzNTg7PD9BREdJTE9RVFdYW11gYmVoam1wcnR2eXx+gYSGiYyOkJKVmJqdoKKlqKqsrrG0trm8vsHExsjKzdDS1dja3eDi5Obp7O7x9Pb5/P4AAAAATGF2YzYxLjE5AAAAAAAAAAAAAAAAJAMGAAAAAAAAYik+GhMeAAAAAAAAAAAAAAAAAP/zUMQAAAADSAAAAABMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUxBTUUzLjEwMFVVVRt1/2mmAyP/81LEdQAAA0gAAAAATTAZG2mAyNpNDAZG2mAZHSaGR7aa////6a/p//K00yM6aZe0ZHWZuXDtNJKTQPKmsUtA8wskitaBMgecRSUoeQJmGpIrWgTIFnIrVgYWBlVgypVR9//////vrKs0rLo6RiwAAAgiHlV69/G373v6wwPF69/Kc//zUsSJAAADSAAAAABv4JnfIHCKRqEJfIyndCfqd585zn/znehCf8hGU5CEJIQOEdTnkIQgu9RMPuQnRhMBwDD5JCCAcDgopFD4fD5zyOIBwU87KeTQjkFCdTqJnQjchCXkznOdXkZCN9DneQhCUI35z5znOcmpxMPh4BwAEcAOIDJB//NQxPMaOx0gDAhNHSCiz29wIUjFgvHW/NHJTmRH+f5lg+cGmtdeCa8DVpgPc6/A9zoImwBmfe2B3zoGEAA2zAaxe3wMkVA6KsDjpQmQAGSf+7YHMGAiHgZAMFkAfqFi4Azv7f1+GWBW4qyCiPyIi5z4qP//qX16ozQbYCIQJ2BsYP/zUsT/ITvp7AFMKAFWgs0OXAsXFFBsfDGZhV/fr///TDeBkg2wEQAdweoSg5oj8CwcdoeuI/Ub1///X//1eziGDLBtgFgg0xOhWLRPhzx2iCYsZ4nxVDuEeBsBLjeVkwkkm1OkBbqLyUH2hwQBGuxMFMSlHMYsRei9gZNbD2mECoO4//NSxPAy1BY4VZugAOSxoLtkUbWesRhTdoZROgRW93mcPw/Dzw67jIWWMXhxX8NuwnG/D/y1/3ji7vOIxiZibuPjC8ZBchymh2MdnpvmDZIrfjD75VbGGFe3T9/tbOpvGxz8KHvMb2fNfSbx1y9T4ZY6y53////+Y/v7u/yyxs7OCUb/81DEmjA6RrzLj8gBGBsiMCuMP5/P3/4tWiwjr7hkQZRJTkjwrk///////0MpUFyOQ2O6gCnN9YdYQp99pa3JfLUWWZqxPMtuH0TmVtAFpr9QnEzlA1AEeSoAm6JH8KBojkyJmUaERyVnIhxwEvH2O0WdLoksJoMSos0PzSW3zM6V//NSxE4rAhq8r9h4AMrIjIj35+IQ8jStrisWaoLG2OertcTdsUlRkPUSDfXtrevrdLzZx7W1fecf33m984xndabnjhJiDb0BCTIDAsRzBh4qtIKAAOmyEu7JmDozQGMk9DD0WzguihiABUraAJKcku+5JUmiM4GhRaWrLmzxAYJACQH/81DEGB/rKu1+QYZfkAM3ezJHaSnEKQ0WiPaIkyS0G0OP4ZxaFK/XFKKTkvYOkcMJQCMjHYSFEM8wRh9kioPbqIpre33sOqUaGsytP/9Ov9zvcv+HNlUkWnfP6f509uqGw3vGJv52L4zfP1TC7eyK+7wmNZWlRi3y3f9M+yrTPZg0//NSxA0c6Z7xdkjM9tqIbNhVigwJh0sTJSQG4klrWiiEETzPRmwZwK+qVDjkwIvqxRaXLSPptIReS00hVJf6ZAql9fHPDRoXGhp7DKQdHFgYJBgAjAkFAIAWFc0ByaSrZ7yxsxGqQUWlZrVdUzcoLDgaF0rQAFnJd6MMGI1RoEWPmE//81LEDxzCFuFWeYbu5+3N68TB5kxUa9fMdmDHnp2nZx5RoshXdCVLNNtUXapcwvEkJi9XyYPDIXyT6CaXhIX2Nc0mRQiLzyMK9IqQq++CQXqhB5p4eLDkAw4OCo8+fQezBcuOT1tKQzOuHjaXegG1m8gSAKclyCwKECyqObKL4o3qRf/zUMQSF7lW6fZJhNLRA+mNlAwo4d2e0U4Ianb7J+pulGoKaonGlnezLNS93S1NvFKBBJkCMME5T1qgsLRiZEUYfknvMvW3ldsOKUGZLZdatoXvTso/20+K3atIVXJd8BUOEtFVDEAJ194HfYQihUzmI5zaA4UQpSjYBRgcpyiBSnX/81LEKBpZMvV2EwYa8UAhYJRrRFRDSfhTPhQyOQbZaYwVBJR2KPTFRYiZLGnlSi2NYuGkHinRebFMRkfq7CkTigUAMpma91qQkthookQqqSICt8m2ViexO1pozqIOnJ7Bz2HWqKY0SBtFlpwzDhAQxEJdmRNUfQiTnpntCIqMge60lv/zUMQ0GXq29hZIxNo9laDFzq5t6mv29ap0VS9mQ09WkZ0/66//1GHIDZZw0pIsVix4V1AwTNtkMLOzex/6UeUCK3Jd8JskEJp8YUQ0rNKjmlBjy0HMPLmTkVj02Hrk8gnIWK4pCBYcRDJRB5zlocfG3AQSMTmAQcLYTTQZEjwYBQ//81LEQxnY4vF2KYYevOkni5pJRxFlwornVNH3iILlradRFs0kDGrKfmEQaLgs19xN6sYBpuX1XNocdlcWlg6Gy5lgOSGxKFQrwYj93HvwLHPLrh6NaZhxkyPl9j3bLwwonrk1SLqt6HkUiX7IrV+pgw4ZcSjyKBy3T1OVUJnQORqYhP/zUsRRGele3U57Bs6RLGyIfNHgOMD/cMtGFf6HzRlCU/SvTYSiFbcts0KaaJiyxpKEw5Opi3JwKDpGzwfVJFt2fJam+Jg5VznKL4oMwSS+butXox9+cnUMj4FaTX3432HZsx47lhZWnsKvaLDxG6FlreaDDAODa4GPx7ROqHwGaCTx//NQxF8ZCb7t9mGGlslfT/o1qqkSDrfLd6OCFTCEJGlshZPEnPEng7iiFXofTn3zW6TQuOJyeWPTzkkO2Rk04jOORwb/XMGyDqIhDxMwyxIqw3uhYMMBxSlFDyBIRE4tXAqhh8XySKZtqRnsxnTu3elBc1vUXCZ+qBIRdyXJsTVIgP/zUsRvGTF2+hZBhj5X3KbkCMn1SRehORhQQKwhjumpU3yqW9l0ci6/ikqjup3G4pbFmmIGmQGSMqNNX4PvDZRwIOKKpfAWxQqZahSjh0y8kUIh12802kY/9+uwXWHxC+T22UPdwfI2mNEBWTkrwo7pdNxzH8D5bX5C+xtnTtzixW62//NSxIAZga7p9khHagtAv97gYE0cQxgTO22LOFmXl0zJuCjEwNChg6KgsdKov8uNv+rU4e3mlqU52ztLhxh+GDblBAnIZgVZwxLlBa96bpR13TXAEgAuW7+8kCEwqsvosIjY4zfbI0VXQHz3EdPSM0FVxHrjGhTPmwVUeXuODtGIdhD/81DEkBfZDu1WOwYecULtYGo9TcXNW01BuRbLxFUsGzmjRxFc/bRe03fXtc00V+81yQIxCyJzRDEMFojpB6JJGUenEtWYztffK+FHxeJ41BJIw4FZOxGe1DpPJDVzJtZ/qGcrLKNb6M+0Ej5ckaiaYbG2YfC0gaQa3En7l2KAAgB0//NSxKUoK4Ld/noNHJP/aYgwiREzZl9SmSgWJvtVDYxPWBFy5ZYNla7ZIMOA/q/WlZDeWcoqy0yFjZ1MEokksRxaDxhDQMPKdUXG0OibuYzJSuB/L1c1FT89U0a3ffEcfwlzGhlyNOkO7mh9NW1WzkR//P0S/uROOtKS9NivAdcEkVz/81DEeiWj3tX2egdUQvwi4b1COZUye28TkBvDPiXLRP6PkZGeOZkrVsqgAANt65yhnGdCsoU/ruzTWJWz1ocBQ2xhftOrl3ZyKxSmtuc7jyUcTilLMSRs8vfVxH9Z3E8ZG/oyIFLLmIoPw/0SiTOFpxuXDQFDaiMcTdR57ETjCEVI//NSxFgrg6rB4sJRZEjTmhPEJMSGMUPUefdLF1vVf/7f99TdrMOmeIBQ2glDkOBCts5K8q1mqjj3t9qVesx2iq/vWiYqqOGkHHIQawraby0d0vKrK/F3PxcfFwOmG+zMJsppkhACI9i7VP3Ej8ZQgdF+ePZ+dSJhJzqSCOJiScVDG6P/81LEICGantaUewVEMLu1/3kqv2+et0EaJXZrSGifDFXauNF4P0NGzkFU7zLOPOHPfKwHbHAwA7IZjohrlld11f6bV4d35QhCtKYGL91V/Y+uYryzlMId/UsUWdIH5Vh54jDAuoXPxY+5wcPhskBDm1/yFcIBACBKNyS1qZZkL4ZRrf/zUMQPHcOm4r5ihUzV88IqtWYl59bqDHHL77auktQYwgz1swUmH2y00RjuzCSCAQMek0iVSerkxmtDErUhFZPm7q6oM7/v6/qGTqgtm6gKEZrIOjdRFvDfu3/9n9AdV3IP8NV9YlX6pXy1fdBy7wUDxCSPaJQQAAE407YkEmZlmOv/81LEDRxZotKeekbwJ+kHcH8HFYS1RgMVcN511L+nn1Y5sQNqjSyllhKxbaqJNC1WoKik7Y+6MgSzfauarGfEUKFLuY5Ihcqg8GXCOyIYoVSYZuda2SZaJXFdEqCp2IeBv+Wflgpw7lQWApbp/BU9gqqIggFm5JnTeqTyVJAwdSDhyv/zUMQRG2Lu3fZ4xPbirpFU/nZ0NYlSwK7cGBcQOI64slEOVIIcIQLUyMrS/UjXPtz1QnSqLrWvyI9ktZO9d9W/prnHch1eKTIzJ++qyI6V0T+y/mqexXqBmaHCf5eyt/89t6hAcDKAiPrEAAC59/jcC1LZIaxTR3sV+GezLrqRsqr/81LEGB0y5t32eEs0Rl8CLrQ0yTMufLFkpfEoUJMQQxQLPGTqnh9myu14EQUczI/Kf624GFePE0Z+QqG1O7XVxUguOEnERQBwGFdFnQ2iJv7dauIPh9CRodbBAFTtUUNeAor/EIOPJAw6gAAGWrv1cxrVHwXvNUtNn2MGRD96jcdWNP/zUsQZHWLyze7CSsxpCcDMdFLIeAVqaSvSEyZEiadCkRL9QDVPVkoNRSIMbopzlYSWYWSXlEwZier0Mjp//Uyv0X6BxV9/sQ3qdDFLOQ7GTQj//26Igo/5ADuWGMhp6QidOr8kRD4suTpsoQAiXInf/8N11zDGtDy9eRx2CasjWjZF//NQxBkcMnrePnoE+FrBYXCZ3PkaExS0kqSe3L9GlwFDFl4rv2RKVr+Z8kFS1S0x+8wUCgAsjoi/H3q8MQzXy9J2r7+hDt9vzt5C/IIFYPO/ygZOjngLBwdcL7Pp9rPWVkQ+p7KoswlavTlvkJ4we8Fpo9XBX7CgIMUJMRXInREzcv/zUsQdHhPy7jZ6BPoRZSRA7RjE6h9x51D72HWePHUWWdo9GDyEhhoydnFVgdN23XTCgXZ3hYfma5am+vqmuqP9/qhvUxvU3yiwFuDf9//1/QcpeHNKbU1N2FiS/+HN9Wfyy/y5QM7k6q0gWaSTkcllCJpwdlwQSjjTEyOUccoVSwB5//NQxBoai0ryPmDK+rsOTypIDiFAQMc2NRSxxzChopSmgZDUyoMUeucUTSK8P54EBVzO0uw8va5STK6233EWZXaFj+sRT3Jf/6D/3/f//9Bv1bTo/w9/+gt+SdcK1aAAAWTbjB6sth0EyiY4rnUMCQyHCoTmCdhaBQWElGPrayRy6f/zUsQkGcEu1fZhhs7NQPm/RrYukeZcNHKtC+RsEQnLD0SLzIgfrEJ+8sLBfaKlIzxelS3EhOIiQsGGb3kX29fYz5skO7PrSF2MVhgPMqNrgQAAAJtt3gOzi2r1wGDVU9PIShehLoSAAcvkiQWMN11YE1CSN4W5BJSt+8nu8Z1l+/Yq//NSxDMZsS7WnmGGzE17gjJpThUo8Tu6AIhlsVPihMgWETmpGg0Exd20+KlEOcc/6dpxuO5MkXYtTvwi0NfluJ3RNIpkm5LbrZbNwILwm6tWlw7kPgjpJV0dAsOeYRL2rmryLjxPEzSXtfOTdaK1GrZvJTPFyudUtMjlszWbzU/TZHf/81DEQh4T9v4+eYqzQlDshCS0ndvv56ozTh8cLjHC0Dg0ePXQnT/9WpIdErRW+ciEJsdak1sT9PdVu33sUyDTgPZllcwARLScuNvG3Un2wN9VtZSyjVOpGtU/cwh1HlO5D2NvXW7TSBQUEorMKolnaM8EO76aiL6OdbM6PzEBlZzO//NSxD4aeg7V9sGE6JIt92cvR6o/1sy6MO3ggoBrT31uYJwSIlDOjU7+6vmhyQZHIWz4q+kI/ksmq0EDSMyduzFPEySWoYCijMecONwNWGyK6DSGQpXQFimF0MgDiGFkSkTugMjEyboO4FNdJG6ZHE8+k2hSiuZWSuVK+VxmaFL5Jfr/81LEShpTSt6eeMT8qfgk9Ct9/3+CT0AVbq//5v2//t8EnoFbW/J6u3Tr5CrSEFdXpuWumbseQ0w0TtzEhcoo0e6Sc6rO29wd3kszhELc0GFhG4cJRA5mBlsyL2EZaONSRuSL0wJNShrNYcfryNr/y6LU7eot9P/7t5w8P2kN5G9iL//zUMRWGqNO7hZ4yvb///kUStqcSFqgxr+pT0MOxoFSoWr1oBqm3LHbc2LpZmRJQv23MeeAqdZzhqmdafPsbjCxHpTSwMRkLVxXDFoqE48D+sElaTOxwmH7nA6kb7BYPvHM84ekoVDnzyZs5WDxq4SFn6Fb0b/6G+7fPpiAn6CLfVf/81LEYBxr+v4+eMr+7/AQPO/Un2L//+30b7/KPHS9qIAVtpuY6nw8PBoP4rUsVvgZcjfgLNQc3kZqarmuVqNrxXrbiScEpO8KEoPhFnV9Tr8K1Sh5PXSHS3yOaS8bz8vskwQ7oMnICe/Z8ZiXkagadf05Ghmo7irP6HE5VeoMBIRVIf/zUMRkGPHm4fZhhsqwEAG25Jx5AR4iSNb/LksEH3gZ49aPF9MoQ6Hc6l6SWvkmRmlLfzq84Zb8TuhW/k9FGbgofWuWfePTQot5P7QxhJIJBu0WD4hONs3C0qj05HjHvt///NhpjRTKhgEBLqHqrSKaLbVknanKpsxAGRGKZPPlQqH/81LEdRgZ4uH2MwYWea6Mezhau6Nc7rB2wltsrGKMKdS/+7TPzpzcnDzr500/uvttiuRjmiZgZMkbnpRvNT6ON5dEban0BE3//+p/qcfVJOjMRndEOEFnlwRF1h9w4v/JsCpQNq9gXTN1pBIEQQ7Ld9JD1DeNmhexYm6ZwZ4vi+mpH//zUsSKHBsW6hZgRYp6Yo7I8b3/CmnVuw8YiE1AHgT1c+Cggh1lrBXH1GMrvHZPSR3g2uXtnplZmG3zHnyXvZm8cHFpPKl32aitMYeDyfqOF20QoQ9FHOa1hLb1FjfV980/48NyDdS5u1hZaj1Mf5/qcNzGpMHmZrOpNeig0MDSnzJi//NQxI8ho+bivnoO+LMug521gSrW/qI4dCsO+jGnD8VCZYrWfSHJuxVp0lJpMPHAVInC8bwzcx3vIUQalvZKi18ZRBD9xt3sYwmpDEh4apr6v9A+/oIn9RF/uL/Ucf4kr+oIqu0oiBMDN0PxB+IcqC+Ik/8TGS5Ie5o8RvWlMwEIGP/zUsR9HeKO1fZ6yvCRl11nuxWiYayZP2pvpfBAkMWbRtvGCjRQ4/K6s3T5zbYypVAXOv4e0P4D4zo+6GEAvz+pf57Kj7WcPh1XZBK0dd7X8Y5+gkU/wz+RvoV/hwI3hzO/o76qBo3U4J/kM+Qggckmbq634Pkf+plQIkJQSD4IraUz//NQxHseMuLm3nrE2AEIk8AkuHqJllbmgUPdQqxIoZ5eWB6zML1cRb380Vzva7B8+LBrqR+dpKNVe2XCVUr8gEeOeFi66/xr3BSqQyVd08R/X9H/b87fRPqLfp+n6v9W/P+JEN6m/X8j31EQ36k/V/r+g62sffsHkbZ0AzEkrdHNv//zUsR3G3QC4tZ6C0hizGdCwRypKGgyvLCYqt1IHkQTDLXcxr0WDraHz4X9z42f/+zg7W86YknEVwybP5HX7IdmiATQOGXYGfludpTWk6gVD52x70r1sd64u9n+bE7QkeCJsS2f3OLtSadKqsigNtenJLZFsBwEFOXKLhKJh/Gr046L//NSxH8ZyX72/mGGnCa4eMTsGNEzxGbkTHyolyUpNlUyKyBSSfvTWrQxqT2ECVdVQtc9XbZ35f/+3mMY3KVqaGN6J+b1m91E+an138xnCvKnSMRL/8qBQVniwdqIkBW3Jd6jMLllrkJCqsFCgYjxNmjAYfJSJdQzmSUleV4CjCVJaFf/81DEjRljPu4WMMT6JhSnfyMGpw0UiMp/D+FHMQ7jvuZF/pdaVeH7Tykp9OFlLSmhnf8PBIGGnRShL1GNdEy9d/2qIbv7E9fX19EPty3tGcjB1poujBskBjIjQIQpAuQgit1e6iH3fUQiDIVgcQQfh8KIFD6SKgo+4bcyx5MhGget//NSxJwY+kLd9kmGdhnFgVA8coMBkOA45YtfLkP2xE4UZZ99SwIm1aDycoBGyEMBYylynHChMEyC8AAZyW8x8nYzJBMm7jmnDGo6S9sb1nb7BFubbIq5/0d6v9S10Vmo2rM/Nf/dcYCAU/anjx64fatTRLr9VNdn2Wjh0rlZyFZFBEb/81DErhjo5uFOMkaicfNRRQsWZYstRzZRGVzgrpDMwLxZEomkADhLHMZvIrw2YPOs8scfyJcaKi2xVhOvj6n90zDl5XrH0rxIJbCyNZVUIhfHelITMwXpEOOJXAPb52jPF6xexkSGViqmK7zQkJ0IuqxOBgfkszIDKId2Ua2AAAQL//NSxL8uxBblVmBZTrv+rzcRfkaTd3KLmmlKcQgQmASBMeM6QqwMoV5HVmFAiLPdag32kqnrBiGRqhCoxFSKdKGr1RUa+7Fet13///2lZH/+tmb02/95sqBkrV7o7t///+jzLpUhzHFsDKctpUZRLpKdFcMKFjKoG5nFigZENBiQyQT/81LEeh6UBtnuwkSUauCQDzX+btrkABsFn7zwM6mywQw4KJfVR1yvPLVtKxcSjz4P9qwXD438DNSqjnpmhkryqGg+86ErfKDztdilGfcqU/6/mUopcymcONspBe6mOHQgOCc91vKqJnWlnFrv/8EJIOHwkLP/9me0aMUjACYJcTcuj//zUMR1GwIy2exgy2SUNuxwZxE35fqqrCVqnK3Fxpl6jT5PzZ0MWYhHhQGZ5VAdUbqHnulF9zasi1U7Tqo+zIRjl7f/53Zs5zmVfFw1UWPFyhLExE7JM/rN/rHkIDKnVNI/8VWfLslBM14pW1PxIFqauSckDBQ+RTmGG9ZCUyFMmxr/81LEfho6DureekpUeQLiYKysydD9jnPupq2lW7wIBDOqO5H53MZ2c/s2zm7sYynAwszO7oq//2ZdFYz7e9ve0t2P9///7U//Tdbm93Mj69+//5yE1ISj1cWzoSdhpfQABKr/Eaj+ZOhwIVEjzUUkGL6zIQplZAlb54l3FgoEJEEeV//zUsSLGaPK/jZ6BF9KO6RXJ5DAjUicaSPVYc3rR06pq5ysqStrsn/2cqtmVq5W+ZTX3KUpsvtb7WczVkldf/2d06f///+7ba1lUK4Q8BIVwAS+S2f57AX1DdQ5WJW5masPVIWeok7ElH8rSiUacQJSUGh8pVlmIVmjCXbgU1jafXM2//NQxJoZk7Ld9HjE8LulNhCJKgnNLpmmBCUmo6EzKD71Q1adlTzs2mVhUiAgsW55EkRBqeGTp3+e/37NmJTvYSW1JDbXy7f+dCsSSsvFRRlHdT0sTnF5LoFqudfbc3sERVcu/GLc/IUyHT9pvpUY06cPI1R5RRJ+0P6Eqv37gSsVR//zUsSoGaF21VZ5hugpVJ3211OqNn127aepyFsGiVYgsgZA0+Zq4+76+NnWFdAACUl3zC/03F8WL4KHOEFxjzDz2l0sQ7sghLg4xEJd3urXAOvRue/P8zGQJmNwHAifN4ES9oltbxr0iagVfz0y/YnUzHJFfsCgrtjnVjJKzn4jE+sS//NQxLcYQrryFkjE+hyLD9gmV86ffIYsP9w3yobHqvf7eRNbp8avikOQha6OiWPhggqNwhzsEUv5xsD16tqyLbW2B6aDpjZ4FYx0JwetmZC+HBmHHvE2pGRgequAb5NCVmEMQfaCLg4wlZACnJOLYyQVQFjvtNvVO1DAxysswPvP0v/zUsTLLJQW6VZAXzaTfnv4l9mSGWZF5rQ4u84XYXocucKmTf+RsVYWa0I6w/L//Phf7+NVHJkrJBDIwpgU1F4oPaTJnZUxiasYHF2UUHrMwlFqiYvv6BZkuIj8mVGXlWGjclVWJ5CUgWAODMkLCJWbExOhIC6NKC4gHxSDbpJC1iQe//NSxI4qrBblRmDTHjB0sl0muQ2yWIyUgaPMDo6jJDrCMDIkCzyVEjEq2SIRgW6a3y3WaEywe9IDC30mwTBKRTFyTmNuS7t4mY1z6W+suz1ZAOAQMZ++vvH4ztlbP69kuKYo4wPhUBfrN78VNy5y1pVBcE1g0TPOQ+VEBZR7fq/h5OH/81DEWRoBZuX0wZBQcrOeVd2uQdAbGpDsUxGUtgEARDgKdVDFBkVicKA8vAy2RGZq2qq46RlKgnDLlKp5GoPirGH2vR1z5zSRCgI+OgUq9RNLWmdKJHs53QSBn71//L+d/3+LfYv4l+3vN8yrsdvrp+2n+Lfp9P3b/5RvZhgU+V1I//NSxGYZ08rmtnpKfIBquBMQZluVqW6GSqH4NAWrPH3Sg7ReYrVzeuS4Ww4YYaI/bD12UkDA2dyfmXRM1vnrJ4i8AixMhSh1IJFHfSQB1pw0HaiTkiA8lhFsVDaxVTYHFkhUTGd2/6QnAtqBT3fZSgUpPidVJOqAAAAEr8R6nYHwAR//81DEdBnREvbeWNLMdhSnSkxTqHENOgiYdPLDBYzz3npg6oWOrEL2WomElkoynEsKgs01PFgMYTY0zk9mMTiMsg4BqafS4XcdUHGN01BUY8OwVH/xFw6Q//9T/Uj7A1hQcHCySy1A7LXlAAG5bvu0903cWZdamqzEphBQrj0ObRkO//NSxIEZ6ULShGJLCG0iOXmCQqNrGWmjKHUssR68GtjnNlEnynuHyp+yvo3GlOBoDCIOA0XP3pYgyMS9Sz2OBYEs1AdyWrWlKrVE11Dv8lp9e6wN+L1HlPWvUDQisckURrfJd3MmHH0EY9QZUJnkqISu3tJBp7d1zcBSJn01qyugWAb/81LEjxpxNtH2YkzgdB5FqRnuNKm6hRxhSUdTird/U6LN/fNK5lKravMy266Nf9Ep6+ysJPjefnUfMGYhMHtiWlVqSpNGMDpVzJQeSVJbv5PiZr49RzaqMcOE84xBdIxkrNpy9hsshKxQ5nDbpnKv5/Jyf0r0p5cSFtM74MI5u/5Gyv/zUMSbGDKy7hYwS0rM7S41h5ErJ1bTtz8v/5CiEDPPcoEhMYS4BRcz5IYdYU6yO4PXOZ+4CqQ1yTDdSjVFXct3/2SRqRJJBdWULAgsSQTLUmOow3DRADzp18ciJGbWVZmeRubztWOQYjnS6DQvT5UOfEM5mIre1KV0dUt/9N3c7Fz/81LErxoaTu4eSYaSmmv/uwGZ3d0utDIv2ZW5PZP2++v/6BxRwDodFowmEYtV0AAcnpjLdLXMLwKICWYJsDhOJT7cJT7kvBhOSJX3nhe7PI4ybuTO5GYirtuymuvro5nt3/X///////////Y7O1FfDupzFdPV/ZsZnYtZM5DLjL2CGf/zUsS8GYum5VYwxNrLSwnVOToDH+OUABgWgPUYrRYWTMg1enKKgyDEAANw5vWPu6fEnL2+fomC7gMrC4PIDFV3ulIUHf3JG/vvFtUtDpeDPXPsAxEpGrvVxkq/tSvy/8ioX//////NyRRwAxjHYB2CRslXGkq/3I/8h4h660kOhDdp//NQxMscA/rdRkiNX4iKLmW127lGODJnFbLwlDma/VFMeQsJ4QAFcFrbsutwQ/Qlzxtq1pwcaflLJBJMFKCzyQqzdLvfNdjibO8YOTKrIltaGz98tqtWN4kNURXS6PWS2fTfoVTOzNt61/////k2dENI6lQpOaIh0OlRaS3/+YTeyv/zUsTQHIP65g54TV0+SF0i+dFHbntekwAAIrbMfbJtVbkiEBrmks65AgIR4cre3i/R6itfNuadZN5VqWCalFSt94MaFZu8Z87DviDFZlZ96Xbpcvv58KzfDfcgPr8v2bqGRcYESoSwCKq3esB1Xe1HxRZ0iCbXrXtP+iqnMAJBJcRc//NQxNQZ+qrd9nmKnPqJS63DUuaopfJrlPuSPMJRVqYhEKCIpEqVsOgO3N159wHEy1RPaSCiCAWqu6NVY/cclxnCCqgpTBjDTkzpl8cwDFDhlMsz/SRTIVbmqW2ymzudBz6uIC71RlP/9WkWyq53Wh5GSrd/tT32779u7Jq2vRG84//zUsThGRGq3rZ5hugZ/B2HYifD19WjJBESLFSbTVHkeNz427PIkaikNtP0Zs9mCSIRNGUlYqHk5WL/NWJbf1qqLXPIEp6sUcc53y2kVKx0rqRmdklR9W+vW6Cn7bcfqsgd0IyBD8Y/zN/+VHqyKLru8WdSIxBp7e+TMmTT3mFNXq3p//NSxPIhK6bWvsDLEXpHyCui42U7bd3xysZFEjVusyT+jfhuesKDu9JmfFuqmza1SsQsZtbQlrVp+FLfdPBfkzjU94QWqb9A7G1mcWPPty7wwJ8uPygJHbQjOqKiEs1SEVq5y6kCMBjep2IpCEKmiIIFaMRSt7Ptktu6e1FK+Rnfplb/81DE4x4cCtq2eMss5FQ1lsmm3syo06kV7Ve/Y5OeCVjOrmSSrqECT6B6arZEMJ6nI0lJN2ctOgMKpMJMMmSV9oVQwBfKdXq8KohAP46WdTWZ6BwIdSnrkp8wtVp0u+3Ja7AzyY/jplmiWzNEYEeEluE3RnMqvoMq86O/muTU31Ur//NSxN8iE+Lm1nrFKHUUY7BMAPUGoQNNaUeuzFl4Fxa3uXqcmYkr9OlaA2JE2hYirYiigzIAOKNSlJXRFIoPFJdxXZzF0Y9Kx+BqA8QhIEERGM6zIFgCgYhe9s5LyzZn3SQz9qWZj5YKBpseccDE4Tx20jsfJnN7/yc4faSdnl0qqAj/81DEzB7x+ur+M8S4D48QgwMDIKIkqELRt/+7q+tdKerpSpRUiFkQAhmkkuq2VAMUksqJWz/kmtQB9puLJ3ZsLtoFl2ADDwZEAratlD83MEwGWmcQ1yKNqiuU6MX5RJizKFMf1UnqFItOg0SM2VMDkqGk4iMKBoSPiUViEFG1rZaF//NSxMUcAXbm9isMeCLizdn1yIlOlvh2z/Dp2rArkoffyCIQtSklJbBtIXQNhRIOWCo0yAtIoSxurCdvafEJkdnfHRrtjjVV9/ua3a7THbNP0olZcAnA0HTJUPSS8xaCoT9takxKlqw0swVGBpDwmIg6WqHlmuay6z+JTrPDt/2uavP/81LEyxo5Xu7+SMUkqgaEqqmmTrXLd5Yl0gChoDhaBOWACCwVJTjzsiViWt5l4jhTELUgmxEjdHwixhyvTyhHKzKu01Hgb1SEhmrGuuR+nsWqtCQeql0FwoRUCbiwZFzyWBsBhwXAThrLwqU5FrChirMcECFwmO5z69psiUUgooQFQf/zUMTYGVkq3hZJzAL6qZJFKr5dvUEEJERgA4JuxJRxHLWksRwE6aUKvZ1SrvKerxFHFItrSGa/dSyt1EVXdQr2nXVrlVL31fT3ceiVdaiT704/rfebR3uNNxeiDBQOAFDCptQlA2AcmFEIWgd4fan825ZCedZKFZq5PJv0jQF5F23/81LE5xyhuuIWSMtK1Mo5IEECA2UYmuuK2iAnSLrAgYR9ucF5yYpAxCO+0YrLBiUUaSETqRRx1Bm3b2BWk7zQXaQQJqTl0Wn0iSjO1dpDAOTrU7Nzx9RrHy3idxqlDptl3uv6i4iItlf/vvvv2EF6pWvri7+vGVde1w9x/8E/1//zX//zUMTqKewO8jZKEx73H7WTXKkmC0qpJwKQhooo4WJv/pvta2+ph1jlUtvpnpYVRUYLHRAsBZeeqYdUCM201UeiOOtrPOFcsK3u+BLNaPsFUuAyKaup6SgVLjyXzMqGaJ5q/RvW3XEOIerEEwIxo5LLZ8wq81GlVUaibsQRmRUZxuL/81LEtyecDu32Whlf7KKu16n180hDfZrxvi1Y2s09CxOKzutlZS9XPbZTjnWehpezIZR2NozP19iIVQQzSYvo3///9XM+voqehUn+p//9/2+5nyN/qf6v+f+vuhl91J2l4WlKtCIBIJIxVpzyamoZD4vjkZlpCHR1NVpoA2Ck+gwjRf/zUsSOG6PO7t5j1OgFZTUXAtjTvVrQ2KTO85giigECY4os7liLvhyC1q1NNDudHQHcE1y7aKBORmUwjyHvYjZzNk6nDqyN/5fU4n6m///r+rfEvtIb8v7fU3U5B6EEtR7I1YQxAk99Y3P7jRwEHszuZGAJphQnX4lYYqNkBLCvAUCs//NQxJUdC7bi3kvFBEtR3eA9070ozF/8NbWphbQCHnJ6Z8dnYzps/9OjKUvZKTxcaogOFHVmGoNRnMRQgpTsdF+nXT3Z9P///81tO1P/71vTZXGErAiq8pQCorZa9/BULg0SYK4ELRcqSzmhJ4iSQauJwdbEGfp1CZD4OqBSKFnPG//zUsSVGkuu6rZIyyzcpTcgQmzXvpkQ7gq3PsTQm0OO0VsDopNkmIGOKirbwWBoU8IaoHEymsg4veb7//8J0qFGZ8+cQSE7yBPkEBW7//gXD2xu0bLaiJOYsuJLZNIdqFGppt7iu55VuZHHzyRxTdlon3zzyRSe6nHojUeu9nUw7911//NSxKEZwb7mHkjE1GC5OaY05O/+y+l1Z7Ox+XEnsPeaXOq15n/Xa9KkCcekV2oi2oPQFiqnvTWAE0H7Tz1ovLXkAAgLRX8p8RaJjDrISNKH2gCqEa7JUiPOtxwrJbD5LwoVFW4Uys+8Oz0RJZtl92aXY6xf0/pCE7oaHIM5yV2xegf/81DEsBtq3tn0ScdURWkuYuLmRcnhHqL3Ol4EcHnPYa/tX2+ixHSu6xrHXyLOIkVm25Vf9YeSRNH/m94dcshXZM4eZ9c73joZEc8OGQ2XqqxEbyqHIxuvrM/5Pqq99TvT+pzwkCOyJIOQ8Gtm+6mkyEmEJA5e0HICSA2FbRDVFv+r//NSxLcYedbZ/DDNMLz/W904ULoeYODAiffQ6oEQAAlDjS7vBO8Scvf0489IgyOMLC8z2eeS8PD2+CGRubkEMjKzfaG5/CnzNSrth9QVQTWfc4WbUtSnpZbc3SIpy5gZKmQFHuFWIbeZDAvIA4koVWvrI/6vJ4eJkRYTCyix1y7FqvH/81DEyxjhyvo8MNDeEiFl2xp83PzZCCginGFFu2nnmBd8rrucr2SP9s8tPB0/xXE8GRrzuz9XOZKCshx3qEq5N1rM5gHA772ElYxHRprTuYhRALAMTsYvXT3HXtUiuuwcmxXY650ITdbJ/+tWszVmAjQGAusjBXR/bdt0+1KFkC+x//NSxNwZcULeknmGWLSqpAEAMdmP7bdBTwayDhPGeI2kxY3JQPtKNQsivfzb7lSuoEKC9rvUSl97pDw2i5kdEzjD9wxv4gQHN/vrE+XftS637SbFVmrgKE0d+7v/b/JT6EP3OERRqJCCvZo3t0Pz1QcrBofZ//UHqxZsZrNae7DblAv/81LE7B3ypt30eUVoANIGNYIBACMCidjCr/yl1r/bNalSPJlW3ESCLYzG1EpFsybWNq0vkPBFsl2hcAIZJdR0rH+b3IoszTajspQY78jpkZUVgwo7odv/2+RENozHYqHrI7OpTen7L93+lSPKMUSJGFS+u0l/wzOp1+kXJUsYPMLIiv/zUMTqHfom1op6S2g1CsdwEJ0but3vYWWNBYkyNRgY8aocKHfGOIgtJSZBtD7INONnq2PrhAlM/k8x671ZVU4WDFrUqXOhe9SdHAykZFEhVU1+3XL+yq6FDo9ZosVHRxZRqhGmJQoSAIdYKiIadD42FSDjzLXTv/Au/H4SStpVaB7/81LE5xzast6uwkScouFbQlXWGBlEW5JbfTcyrHrFYlF62jMIUjjn+JY0V3Cbct9onIZuVCCUZ6CFH/hvpkpJJYeSLD95H9MiUcKKVe1/4MfDylNcKF5He81Oj9hEh1QaQWlY7I/btYxmVBrNMlaXIeJXFoaLLbeLq/poGBXi09869//zUMTpHdoy8t56Cph2i6qEgBVm25t4cdAYPpWXLTUDh56klxgPZo8gsZiqrb5pZrOU90KOTHV+PTnQihkEX5wzEZkWtN6MHCERs5nYhJ1PnoQgwGRaJ/Sj2RlsyiYeeCEEDMAHHsDVSzH8SHLBOc/rAYP4jm/x9lwMOMHC6jkxxAD/81LE5hzKevY+eMr6GbcufXIAnOBgU5+gKQj50rDNFiHRFZSWo5FMjAVUuslE6MnBU0VIey0ctE9vOqh3fcbbfdUrH9tfI1lVDf4SrZNxrW+hOKfVSVFm+5zlWjytLS95ueX8rixLr6jYaPEZCMNvKRsytreNQac9ow1cJ7eb4J0zfv/zUsToG/oW1fZiCp62P/yV7kZK7KMZXccjv/v/MqB1Ki2jYfEopGmiqSIA0Fgqiitc4XkN3LQpcVKoiFQ0hNEROSgsC5IB4RAMDzaKYpBYjFR56QAALt23n/9eFS07KkuITq+qkxZVIZYbTWfVnPMJIKy49GsjomuKXAaPIyzhf1/W//NQxO4vdBbJVmPSMta+Sms/7h+7KTk0O95xKzA4SiLH6WUxGteiOftLMAhwtnQqYCxwTpUEZ/3B8E4HX/+z/pajNWq2VOXgAAC5LtutfBEVDQb8u+9UzJ+MhFEQg8LUmI5EByBATqnWGUrUOdlhmJZu+RhyxQ1NTSQMDVfo5NfOXf/zUsSlGmIW0f5gzzAYQelVcEggn42b7WQCFvP6zR8+8FwXFAUFRQCqjCADHh0y9a0+tQLgk8WDYrbJ6kxQXHAgUCC/0bKy63iFjwjNKoIAEAApLvdxWfzl9C0xn1rPVMPkWuLZjrAh0n14VXKFE9HBzOiCyRK6jv701SarqrtVamZ3//NQxLEeya7N9npGlHIruVJ9tOptSOICgxxcYoHEBpHukjBlMn5N0lMn0nI6aLQVFEMERhhqmajLjX/+y8sWNUPxGHU4yizleOltXh5B0WJPEATA+LG0gyxpxb3GYfL3Nze/T/LzE8PV091dSeXLnyMqkiQCEYpGRu3Gm3+MUJjwZf/zUsSqJlQG2p55UVmFulhLo1hxKRw+iIlpWsjjj+5kEG6jLkJplp1RIyM/rJ2qAufLKCIvz4VPqJ5sooRKqkf3wad8+OZ/QgMDOQxQiZQyAxBys39gfjv5A6eos8GBE8OBIeRDEWFgww6yISCGOcFkEgXEwVDiUPqSEQMgFW+rOHms//NSxIYe4iLm3npGlFlyuM4fW7WBOEIMBPMmtJBtkYZq6nu6SwsHRn0oghU/+VJuo4gaKGc3LkUiuopK+t+Y4AySsqEZdv6o3ofTDAaAABAyBBUiG3XM4XpUr+x472+SAkXIuNvf//p4oKXWQwIChCcrs+unokvaHDJbjPl+EULx/L7/81DEgBnp9uLUegTwNrqP11ZoazaPJGpx7eEviMRa/bFH91GSi/yogn1UUwCQmTVyGFFfygfoBBybak//r8xlP1CihDYkfl066CQFuCRz8zBoGTalBzaBHBQJE8KHLQ5+gP+6p1CQAgAEwDMGtxuv4csrGltWmv7zQYJ0xKEu13g0//NSxI0cOgb3HnoFKEVx/Jm8CJspoLnCaoawB/WY2YCoYUQczNDz8v2vVsfO4LJe2Z4Ug5nWX3MEl6Z5EnPfHwd/VS19I8jWyv3lG+gs/M/Hf9/Q4ue2yitv//+n6fzf7/cn9F/t+r/p+haFNgApGyOebX+rDjmB1Que6MWBxeWJPRL/81LEkh6EBsrUw8649SF7h9HoPVO4EV+ZsaqCg0LR6ChY9a9km4+rTEveAuWv+oZfN85gvb6IBT6cBl13O9I7wm/hIX6i29T/2/p7oru3OX87fv+pfp+cEZ+hRT+gl+GOIsu7SdjATJ2V6JAimlGxq7J8XzlfblBfg5z6bW00xw7MK//zUMSOHRtq7v5YxaQXlb5tXgoJgXH0ZAOAKA2J6QgxqbiILN5i72OeEpL/r6JN0MkYJViASB3/QBgVhEVA6TIyqx/oBps0S/3rS/62nUz2qv/+xgnaZCS3Ku0iRlKbjkl8j7OlOO9DpsZ3z8S98Q9S7MlqpYixw+0O4jpDq+uJnn3/81LEjhlJYtnuG9Asl/jICsfas7K1F3baozhBTtUGhdVhCcpClboDZqlCKranCmZv9Nm1cxb0jOCDyjfhVT7Fp1cmyVDXyVv+/fkpJdWAAAIhOXb+lq9iMLE+U5aCyBQIYcLTXqRzwLZ9h3jKWrsBPZ2a5gpU39EJRb+rIarqjNZTjv/zUMSeGgp29j56BL7ryN46nZU1X62R2WjlNV0d97Vs1p2Q23b299HkFFDEoSz31f/zEWEXyxp4Mmp14YIYv8s34GtAB+CFaG6S6gJMEqlxSRp7prXRi3LowYGFL5qzJ+ysdJ9VPI4wJCbkbfUumaaZOd/Ln3y9z36/C00o4GelcWj/81LEqhiywtqeSYRYqF0EIoEJpWD4eOVvBAHxyYWDGf3f+GGggwvC1DdnC7xAgAACZLf98RIJIz0tHxeLqCMGBUDBpxEIzSzJWcXnIZrsROWpq1X3rFdKazWWmiKuzVVpFXtclbKvvXpM6lcjWVQVZXwMHqpIydIe0sw3vN2lPpabGv/zUsS9Gfo63hYaRjTAsDUfjApj0WVbpwOJ8eqyY4ZrjQrrkxUInpyzeOM8WoSckXIxYfbexE/Ss+sQ89ZZirdX5l+i+JxqH6RV/F7D1ZvzrydM77b8K5Z2M29ZFH1KbBDBHW9tjpVV9qYCRWCldvKpUlbGjG2ak9JKikfJZtoUO42j//NQxMsrzA7V7kiZUU7rQ7MjKLnKR3swJqVQsOe9yCHZKySf6Gc7uxzEAyBxDui2/+17SWOhUOwx0xS2qWbepUf13VsyPNW/ytrr1L/9HQtEOoZ3Izq5Ck39f4UJ/g2mht7N5sW0ICAGGkCk0xK4CypKYkKiRLctc2+OFGVj6pero//zUsSQHLOq6jbCRE3fdrY2bOb/ku1nVnXR9PVaMgrezf9kvU79gaD6LbOfKos1UOoYkdHKKa0IhY3p//NL52OvvQdTOzv7/X84xmnIzW9G81P///9OhxxxUOSzfyfOUgw6HQwqkQIQI0IVm/pi1jNERxHRDbCXKy00STRTXszfNrpQ//NQxJMdC1Li1sMOnK6EqmbJo2lhGmKcg8NGP9xIBJOvrVNwcnZ+WEct7rVEqJfGmAv//8TTuc7eQ4q3sLf/V29CT7I86cytosy+t///9u0TArV3K3/5f1b5vsHqkwAAQArrSw8YSIWspa63qCT909sywK0COUWtXMlnsRbJ4LWnVv/zUsSTG2P+3rZ6ypwiBGGwtGPgizcagURS3VACAflt4lcf7+S8tEIDBBRJK//+bqiGsyoZWIx2M7/+vrkXdnZlaz5zf/////3plDAqKIZ/oNbBEogiuqgSTkqRESMBAGNZhgbDsRr2fyBK5sC57Wt7GGK5tmzs+PRvKjNqZ20YMBOc//NSxJsbo1rajnpEnIxvTq+6sioxrzqYKX//9fTaclgZ3Y5Azvrp9/eiIRGJnc6pVFbRv/1////IgxlGLLz7N2+fW9fYEz4NVcEkf18S3CGSH0IBMiVJSg6Jo/UDz3O3HS9fYt4UBmKjO7oG/2bc1tyoSgINWJ48WnCOScJQiCTCYoH/81DEohnb+unuQwQ/HiDQupRXVhUWAwgQvF7WQtJCi2Y0RgMHUma0O9mr20MVrfE59QwOF7y6LTahlIRu8Bd/pQIBbCMxsIM0DVSTdSfcyibr8gBxWbhHAMkt6EInxrvWkaomRC6LL//++ZRZmyR8748Tlf83Zz/+bv5sfJXh69iM//NSxK8ZeWr2FkmGkvbYz7WbDyn3Z993/bNjO/+ZLfN/e6ju0uU7ZkI1BBkSj2ww8y4QCwhSZNApGlqltAUv+AbvokjlzlH1BRuLylmQuehWtCElcAikggIRRghijYRpo0LZBa4CY8oIdxmQoi/0ND9F/7zL5rxCiPkyC4MOdLHC5J7/81LEvx20Du42GE05CAoKwsZDgyXBeCjL0KDCnCN7eX238ajC0ggo9rFh+oaDQVI7ZdQb5IDFEgCHhFbwo6rUUQ4Xsu6rZ1aq3azh0y8jpg17ee+Uqe+I0rm6x0X/XetdEb0NpAIQ4ynab00df/1Mql6Spz6GpDLAGeyaBQ2YC4Z8bf/zUMS+GaJS6jQwRvxM1bRWZZJ0PfUyMT9qRaqWY0SaqW61G4pYkAoFqmIwScotBZIZ1GXFTwOF9MEArUn0jZRINLVrikNyhvVpkELnRbxvnzJo5lwqdOFkbk72XHfqFyAutC3Wltb32sAqnCMXQZHzhvpJMb4r1SXsmb/bkyMSGC7/81LEzBlSvvr8QEWs4AGXiv6PkgECBKHGzXfSn6P8BphQQRlAIwlOjAcAAi0vJAmRM0EAZQzt7bIqkpZ1qRghg6BNRNLPbx1zVT35t0W5R97hQMEqn3G2PQ6weEQzDgVQKCQKB0eNJTlY82CsGdYNA0+dDWeiK+2p+Ivli0VKuvSBdf/zUMTcGDli+vxIyvQBVfUhCAXomW4+tsDmJ0Ndy0xTczxLK894mo0ZRrDMr8wM1RnmGEun2q94KCDr7yK2+PNHXx0KJrVR53olmZQZlUig2pBira1bzH/E19N9SqVkqHaj6V9d/PboRDYCMBKxq9///3bSwYpjVU49EehSl6o1f93/81LE8B8RYuLWeZCUH6KYbk22FQNKGyy5T713BgtT9dLWNOMtijPpw6YXehLLTaM0kfUZzPOV/U0BQmFSFJ60ws27J5xffKNiALNbzk0xJfUxRKtQymElYEAlvqflJIKe1wRjUodvkf0GT7/t+QMboSpdw4hwzwt//6W7vrEIbl1ZwP/zUsTpHfPq4jZ6xPDUiCroYaIBAWUMkmYijrTa6Qd3zykMFCJV65Jpt03qqLt5Nqd27leSWzEiRK4pCd0iUrSKIazzV1HgpCKQNlQ6B1ncbSidmaVlR93pO4pip0/N8oU/wX8QT3ItJWc7JmP7kGSznK7NZf/+f/6Blb5PqhOgEV/t//NQxOcdcrbu/npEuPUbiD604aXwIAZEDJTGKVZu3DWsuIunhnjNQCsNLZVE1CZdRr7P57qG/LQxq26tcsWFm0o8vAkff/2QglrX+vYBGRvx8wREMTrbjRSWm7n/6MO+xvYOP9xX0EF9RcdSpgKDOqnIFB+RVc4dZMn6Iv7fOb8nnP/zUsTmHeOm1pZ6BWBM3oIDTsZznBKsP4HPoFyh4cvHJCEIuKSs53/7Nz0qlQMqtGccI9kXY1WXWuoZ11WG6udPPwNO1WS66/bFNrL9db/wOR95bYkLYw4xGtNHGrJdSrTnOZR1EKGurmTlv9FGrLUfCxd+ovb1O/f6ETWVY+SO6mEn//NQxOQgA1LSFnsKnOo+c/s/zP/0M/RVzmEcxl3Gh9Mw033HHv3Xuh7UoxYi8uC2hYIAAHEFmFvMVXDsIvW2+bJUuplS5K9nL6hqGq2zyaE5TPrau3wMV2xv4eoECWXqSNXDdmKTctLUtaOY6Ovam5np5ZlXXMnuDj9rau70eq+P/v/zUsTZIePS6v5jz0T/a9EAEutnJ8nN2UU+cWatBAIvZSh8PM2QOAZupzfM/0/t9G84mToMCR+tGKPi4t9QrKBX9arpRlB2xt3KS3wdv+uz0CgM2WWbGzpnqWmMPKyw6S/Zy5Vz0Dh6HzduazhS3dvYCGAyd+crb/7rckO1rOZCTqpE//NSxMchiyrOjHrLiFdGRP/6MBCknAwRayEUrVO7ehTGcxAAQJ////zdznu13I7ZFFiWUhGIKPsei0ARuoyxuZ7v/zRb96tDQlISVKAk5PBVx6EJFlApHg+lcYccnU8ZgzEq8qchDiKUbDi2TL/dN9rpffuIQqbeNBWA4Pv/rm7ciKr/81DEth47Jvb+esSduYgdubdVSQQrGmf//ziYuBc5zp7S/rznI6oHw+afJPS/+d1yhYFpcEg64CsQGDylkWDQKIoRdJgVhBMhpZFQIqbOpfY+Bexdo2QLR2ipQcJsNe3fZ2hrfM5+qV2xFujIcVbUIACUs7PJ2b06IQjyaUdjbq////NSxLIdckrm/noK3JUsRUu693a7Im6FaRnHHgfFWJoZ/6PUmJRj0grGexjgoCZPeq57/JYs4IACDgCVmxD9yoLGyN2LPXD6V75lWlYnLCAMLQYMkbJzQscZzhvMvZS91GZ6h59ZSIlPTOzg5PstGsIN6P/ostCEMbs9tPuVmaZSmSP/81DEshk6PureeYpcQhTv7k9F5bP763i7voVmVTN3t6fq3jLi9hd+RTWAEACCCCrKpBlugESGDZX6+bS5q1dVQDrAGxOCNStEq3C3PRNSjCU2DNNavP5bpQdkIUJCMzHG3Vl3PTOdq9Jn02cgkPB4QW+ZdIB1bKEJqyQiGkQVO650//NSxMIaW3rWFnjK2PddEAh9oNPb/vZiKkr8Ffw8ogAAogqzBazoDKHDkhNjfCagsDCrGVTtUAqWBVtu3iuUann27j1TaITbSNFWDe3szN+3LQWkM3vEe3bW9s7d1GR5wThoRh8bVb9zrTqGs2ypizTcLpfwwylgoR/+tv+cKSglGrP/81LEzho5cs6WwkScXZXVgYAGl7RV3ivlDpP1rcmOju+6zzsbjFdPIGMVsM7cpiRJBmtU3448OWFWWYm5eZfsOsvDpLtVTLOVpN9Sufn2F7nT0TG+mEMBx5hAgQxpISmZkAiGNl37aHjHTTbPW5mf4emoMFAiDgAd/Ifr+T1ZMH9LxP/zUMTbGclGzfaLzDj959XWkalqRTm2soAFhptYlcgXRq6xusNa/dqTlaW2Kqty2mG2mMUauNpGeq5jey/ovoKX/k5N1bOM58ZpRnGDqMbQScTuZZKCosOGixCQsCtrph8LMTmm0ldqVnmvK9nXz0zhPiEoFC0CUSE6rKBy1zX8Z9//81LE6B1SruIWeMz8qmZfuCS8l6pheFyQWj107hK5tJMryitTMN6FaHKGJxaUWNoRsRn0AjbfZRkUIECo1YZ1Q3bLtsAFf2AhyRNlRNZqdtuRaCzEyj+7Kedlf/dW82/20zGibxWI8MmU9fQtF03zamX////+8NBuJl35Ix//qBOyuP/zUsToKKQO8ZZIk1N3StXnr/8tGdHRj0V1utWpa779o7HUjTOWFYQHaUpkRyHGOqtIk4pdtAGw27jGCYS2hB+H6cVsJq4kyJ3iyPmg6m7t6HrSuCsIEefg0Gp1N94iAoql1z4TYfTef8XUzOZktr+XJf+20p2lZ9Of0hIwQB9mSGBA//NQxLsZ7BcG/jBFWAh0fNFRUz24xtXv+1KULimVY9h65XVSljuuzRur93VI0TSe0zc5xo6gfgZHmbEbnpz/6xBbRcBbmPN549N//p0imJ20yWM52pezmuzS3/R9q6f+6rPZLPWzu6A2B0AgEjjRGXLiSbgAIvLityUbMttot+t0Tv/zUsTIGbJm9lwRhhQ0XqW7VbhlIm5LdrELrRMyBBuIIIoiGllXBILDueXDX3lFqWYSO5C11uUFhLM6hrxwK3WIAA1IZ+hm/j3o7qCizfI/XtdZiy0/13qOOt38i+pwePmG4qDi1cK8W7rbUG925X5f/0/P9np/mW+4r3PIn07wDC7l//NQxNcZalL6/DDFSGX/Fsq5d1Ntq77wC6shQKLwULi7irlIawxKaBo9b+222j7m7m22xqWJ9En3/+21VmuTgXOHu0/SlfWybdmrNkq77PjNE29vV9lU/0/7pfZb6rnoRS6I7ERqo+pBkvQUzHGr56Yh7YQag216u+sexoqoHFrUEf/zUsTmHSky9vxJhj1xirtIhJFZKv6UXRomlEzxYkKiJNzrKGmCcWmUnNyBmRSfoDQvfjNT4DTdNLQ6axwZIcB6AhdJjO/nnr5I5b7oNf//zrFykd/v72Ecl/zyFNBAxyJkLF6gDICymRtdEZYBmhIYjBBhlseqhahnipLvZrap2+4W//NSxOccotb6/EmE3Haqh2Q0TUdtrH+8ujYYQuikdlJCTjBFMiMp5MlxDnQ+pYeNN35B7GhE7tdWGYkZh1flT4rJIXw7z0p3J0diLK/+aXur/+j06kfVVlEsjlVjmVUd2IZDMjjTodio7CFRjFNoX/sfS6FcoKqbEyv0zvLXe9/u4V3/81DE6h1i2u5YSYaYNU//KuVGVLZLt9UHohOTfK6YAIHmPiTBjTyRI6UH3ac/oH2bTZLHOhGOqsfe8QX/mlXCO02xyMrKfMQze3orGQG2JOVzYlc1O/8vmvMzqst7zyUjtXZXymRWyGqO96FIoW1bB5/3vnNiVuMmBHJJ2jbupFr4//NSxOkd00ry+kjFMaQB+96ICzAswArspMuy4B+a6isJp2u1pEXo12WeEzjlW/g2quPlq3loqTBFgR3HJfpfUvRxNpyf+31/WrmXaedWapE8Neq7dJvlzp71p0WeZU46Oqo0GvtKkuk+KWRLANcThfoHpeusasFg5Ydw7LrirRKo9bf/81DE5xsy2vr8MEWoczNJ267SGOBoFkgSzLk7iU2CR5qFwE/W3y5WIhkk5ySLlkyZDMyfZemNh5ND+zTC6OcAkRRJXTSs1h5aSbAiy7P+SOcP/vvL5326RESg2qX9Ix1ziHkpEdQ8wAnBUABBmPzeVwyGir0qGvp9S7XFfOf2lKZV//NSxO8eKvLmOjFNcCENySWKEDQ/YwE2QWLOJH1HBmRTh4Hp6MMl2kdcECtDGbJYPRnsrVdVLpp6JURzQ2jqNjMofr1g5gitIPvyPR7LFNMzLHlMAd6pdDe8EqVUN5Ory0o8IW6KYeB3AWBHgwCbelzTRlldhClhtVoTAxk8GXAFNyb/81LE7B0C7vL6MYZ8tKqjU1F77bZFR4AodnA0HGHDYONshksaYKuSMKmUVidHaklfxlc4wxYKH1EOqm6S6OarwiyIsatQx+bjnR+ZnJSU31ROrM6vcnXFQ1QkI1vXFIYEahK5GHWdUn8CHgyWDR0m4iHVH3fzP1NDTxEeoPKamheTAP/zUMTuHkru7vpAR6gEZ6QL/6pVBINAcSw5WVTCcR7YPNdpjQGPQowSFLRNKc/5WSHZAo44FSTZhCimrMuW98swTlH4ijtZVN1I66dIkK9U2V2Dft//ffT1MsmI19EGn6oCUq4UZs5qxlV4f+x625iRJRfYwolRPqDpV2ONclFXLEX/81LE6Rx6zu7aQEfIBXkiooBSIiH4NDzp0SuDquICAgVoBW40TzSmOIBm5ubG9thAthol2IwERqKTJtO22ORsJyUb1+Z3l3IZ4YG25tXTryMGG7uMRonQrLlSZ2IoHI4VCmf5leZur1MxQcMzalok65Ren3kKeh9vRbHTCJa5oRckmf/zUMTtIZrW2jTJhpxsXnULPCCHBQF2jCb0/S+4HDkDiemq9qjDzqtChA6GBdekQAAwSAvWDGg3XIwQYjxFWOUfIQUy4yhsKQA2K6iSnE5RViw3aBhAXLMRiYSLpCsR6sdWYqtmlNt68E5ttTimwAlITVnaxlv53d3KxFbKUpaKn+//81LE2yG6stI2wkacXzLLupzToqoqA2hlqlXT2s11UphMr9dO3//1drzsU0AId3KiUBpj3EAs399GXscvONfoUqZQFHwCkRm31qlW+I+HRCtscAXEtyEarLys7rLKpeYo1cGs1QMuGzhCWkGFhBGzbJpYGBpVUpWZiyjuTu4zdampUv/zUsTKIet+1rZ6RJ1G+f+cQjXv+Wf587c39CIjXGxQ8B7P4y65zj7dFf8nrcr+lXnLqMEMx8GQuqIjQNQAh3+e/1eK9tbnYpmqgjAAEA/5w9nVq9QNl1eZklZ2gShHCSRQflJCBIc13pm9Lo8HmRq2S+F5YhVOVWgqDgzQtqcieFFY//NQxLgfok7m3nsGVR++HQHlc2xxwch2P5mBH4i9pl+OhnJC/zz/uiIZlHmPc2xZ6IMiCiYPuS840XOHDhUoaxBAyTPd3//9AAwfJwoIDmXMhlbGPLBM8egmbDCqySQMK38WuJGoepUMZ2eM1noBFjPIK+0sI+n8+o0emEnPpWwXGP/zUsSuIiJGyozDELQn6nImoUsdcgMwgDhJa8I/kPiV+OwsqGMkLM96nMqBNYu5IghxH6TR9wv/czX9fUFB0E5B/+owyvhpM+pJFRIWLtqLOJg/PnNDTvaqW9FOT//6bX+9kSVUBNeEgAPJR3fSEMfvj/aj1mmB9aQAIAIb939YWLK+//NSxJsj2yrN7HoFjeW3rlJblkXGpQdKz/MG5zyF7SrlGhNy2uUHLZgQlWRwx2Rumw5JYgQUcz+W8d4XU44ESmMt4as+t4g1gvTfLRpVzBSaYzZOXZtXzTOp3nMLIHl1oHhtFmGB4rM5kWwJralyMQzsqOiuZoYpVlzJo/b/+n9v5L//81DEgSVb4sX0w9S4NjV+h5MSppl281iXzaN84od0ynJKpjERJvobdlll1W04MDN2KzLILi1a+2fruKiq8y353jDN6vnBoqyZc44Kxs9DfGgZBKxwsUlTnQ9mQ2Dm+HjAwwLSiMYM6Os7SERmKiKp6+k4Kr3lNKiEVJVecgsokZrn//NSxGAgayLetmPFRC66pfuz77zSpkr////0rGBQyGzxgOCk+SNrf/taCodUNMWNIlpEoLbkzDnWHir3XSsnZ760zWFYJAImJwee2X0K2Uve7C2H4KLG4W5WMJTppqyxehIcRVDnQys2o5wxlOljufTO27Z2Id//s/Ncp3UZVoiKpH7/81DEVB3rVu42YId6idmUrI2dfZkN52n////tdFdnssVZLg1yJFifdpUlwxoGNi168aIXRblJLkqUeC4SUul010Knu2BOJYbmQVf25rBFLY9iD1IpEFbaUMK0ZAMYM8hDqN46YJE3GxyumFXYypvNipUv/+fM0jLFwgMkm/rIi4TS//NSxFEagfL2NkmHAvm8kKTg1b9/9RWSSQU0SrSofbpK2oxz7u/JohpprbknluXOEdsSSqKlkQZFA8FiCLI0nKGY+d/QLVHDoSmZGmlC3oYV79W02qhnrZexTn8iN3J/5eHUHPpUi33yr55vojvz4m7+UQuuaIEJCQgAlh//4g33o3n/81LEXRlqtvI2MIdSAmyLOP5Sx69No0MhKRe2pd8XgyWGxOiJOtFXcZEk2kXFrtwyEGDcfcgsRRw6qusBOUKfmpP+SedMHIRT4XCVskOvrITqRXUu6fejNtse11PdkKm/3a6/f5ZpXc4UqHVTKnXp///6t07IjsxXdymYGIAYpSucGf/zUMRtHTPO4tZIxN0RlRNW0oMD7dBCACq2dAOsbaVSRU2FVi6Qri0KDMEDmB6LKuEuyKpY2omIQo/DKraPhsQykt+roTvOvkeTp3u27sRVXMhADvvQtDECoQaI5lrRa+YXBKnSWWASh0OE3P/+39WGByjRUOQq0zkESi3KlREAMBz/81LEbRnZotGMCkYcC3Mwa7HMQ7o7tNPLT+V7olFckHBYqW2bk+lca6GCl2TOBFS07ntbaZpmTO26kuJ3c17W4mTIa59HG9eaxM1t//XzleaEyTQc2hxPWr1ECdKYUZ///1GLvZ7auUITOBTUiLt+e3p+KzUZxsUtgWY1Ac1aDU3KL//zUMR7F6Ii3s5gR4gXRCJ5EnOloSlPQayyl6fn76nGxJjWh6G4YY53QjuztcqQZhKC+hrW7k7KU/odu7kfqAnZEoGbUokz9Wdvn6mefoKFCKGsjdZ3+T///9UV01hBl0cAHSW/7DVh+7CK9aLaqrQk5iGvuB8mYJAm75iPoqPWYjL/81LEkR5jsur+YEVBRIC6L4xtPc0yEPDrma4jerQQeCsmxMFxqfdxuW319VXmfTxdxqMstbZnSJiguJDQGkrUay//N9X+j/Efzfl/X9vuLbUKGfVv/////+rfQXbkCRKlKqtahkf3GtWXQQCaiE9vUqvUKkGEdK4eWeF0C5q/rcAoZf/zUsSNHJwC7jZ5iw4JWe9GQS1aO/eRqSsaarSyEV+yKkkkyZMxKiFhRz59J3BG6qeXt55f94OYDeBgiGRQ+VIkxGBXWf/aWDYbWRKOf//9GB1WvPBsk+2aPRe2MREBolJHJ6SbdMZ2HjpT0lSAs9HIEWoGgGwTjM6b1KmoxB+rovB5//NQxJAaAbbalnsGjLXsykuemhbqd7MVleqFPEHRtCOWORA1Nna/fzUQWugpyoERJ8s2ajHWac1l//3pyLORxcUMZkGLUimOn//////67WYWKC4K4BWCMAAKSHzryzHrSN0jg8xZGPGwlr6wtr7iui47qAoFgg5YaTPkZcTorJcTbf/zUsSdHCOq3t55ipioJGRHrozlpzEhzNMvKk1GYdSgKNXk/aQMXOzzz//KGKBbiKp3A5gBDhUzvw1So9AoKlhln////UMnj0TBJ52plAdNKSaPHgQ9iKFucziuXQJ0hTdRBMZQ44gRAw6oW0ddQaSw6j7qLmiA5PtLvOFbSmYuuXNI//NSxKIawbbGjsJGzBdiEmN1ks5kCamo/0u7JIUP///p/srCqLVxZRJ5XUYVlZFXt9dcur0////6p7fr9NjCo4YBHjXpgAzlUMWAAGUtF8Nd0QO/MZoUYvk4iaQigSKkaYnEFGUJGMCU4QLNtNoz7cWCXE1Fo1rNAdrSU9ITltCJXcn/81DErRy7ruIWegqeYp9/K/RBCyM//VcivOAIjhU+J6U/355f7T3D180CAuTBEMOHBAAB9q3l9rVbrv/+momkSaabkt34mQeYoFINM7JLz2dI5tFR3qd+KSiK+OvdFcp77Rvjiudd+FW5doRKv97bnjtKr6uNMXEeg5PPG+jVDx67//NSxK8aok7N9npGeHntNqP3lPPnLyHr1zKh5lq86xY4a4HwSxVsjkyp/ByKRCHpf2hDFBqBDmYLFxHjQw8+kvm0eGSkm/S4IMd+YePe43Tip72r43kxxSA8BuowO7k8HyBXEZDBKeDQ0P1CMsUEeoC/maLXa3dZmB6FauPgdOFpOQj/81DEuimkFv4+Q9HmRljylk+f+sN5pWHdPqhIcXVgppmSFDfTXHchAceERXE+No1N6fUkvO5/ft+2pAT8hodaciIDWKIAQNAosMxxYJESujImEggeJmntAbEKMOBcSkbbicWbIRhJhGTGGwTijChhA0ykmxInR5Jzd3sP/mzrP4yY//NSxIgnG6LQpGDTObrIP/+e5fPDKYvYv3x08XmqfLxyFahlVHM7W4yHv4YsoGtYse72MdyiyxEkeNcfXI5zBicK0vGOOpJaxGtpSvWcTl9KdMbRgnQmla/xc9SWte/6L/IWX9vR6wyCiIkwH73dz3MCQIgYal0UDw26y8PROHxgtmH/81LEYRkqswL+QEdYI94bWoZ3RHdd85CHN/bNfcKmCVwmkRCiwy0kWEWlCnq8gzsTMhLX2daEul2dovvystfrTJe+UJmQevDNjMRg4JGRmQ/6+8r1r0Mz7Jy+SkK3uAdNDBA4FihdCxNW+q3a/+97VOOkdZowxVWXZWKK2xtsgq9yBf/zUMRyGbq/Av4wR5A8WKP3WhB3sbBDr7Vcy5jzXw5nMfZszwv3DtHvd7u2u2Zut+zNGp20/ezoYjENAfpjXpERLWsvkcXzK3dynIHyhSRDAFHWik8iUZAMVDhirGTiMho/vJqlnHWseQW2R1BuSaxwgmVXj8OMAkAlMNiEEgVI+47/81LEgBni0v7+MEes6le3CEXLGpRcpNuwd2Mtq/ECpu/WmllORyUWmoJCRrfrEQepBQDjXQ6oiprGBLcw2v9iVP7NZkbzwmArIo0ApIuU96k/0//qJLr+5cYuEtKTrLGrCleq0ICGW/P5OhUgFgByIZbJK6vGay4nNtB5GICyJzGsMP/zUMSOGOEy+v56BpiBEZapWZGV73ndXboUmp2PWdGfuSHP/+6VlQSCJtAnBk+VilAcCIMk3/XofCHEuR////60kqg4XFlHhheQevaCUm5G5ZBdGgwsxj9ARFW1/2Txzx/tMQImAhhfkCFZTx2sXgPJqRlHkKGDk60/9HKqGlIPMjr/81LEnxnpruo+ekSQU/pI5B24VlOd2b9knO7Ds3P/ytQtborsWl///////85F9F+S67HEIYAbj0JD5XKkas0hRXlpJywduH3kmTHEg3xC2KoNAECS6WuHEVJM6+KPhy6ucACoRDqrUfY/q5CfTeycxnFQqHlBwdepQ894abM5ZwdFhv/zUsStGdOrDl54xJqL5LHJTa6tBERCv//Z0tjfOpOgyAo0pFr60aBFeq0m76p7cRUxxVwmOBvtYSUk7ySasGGtOz0uz5vdFvQbOfYaGes7tjRhf7eTgpFotGWP/9d/2AqZZmpO+XC6shfnlIMfo5EzgsN66H4sICkAK5+a//938CCq//NQxLsXYVbqNnjKyhEH0OdZrZAnNaLcaqeNSBhqhbImqahrgvmbKKROpjqKiSr9DkZKqpgcMi5dXWUPbHrbzMilaQ0FS0onEVxMygf3EXEz3MvFd9yExzVXLRpHFs6K/Mg8nqJB0X3eY7+iv6GITQ1n//ERQ///+ZTvMhlf6k+rB//zUsTSGHna6jZ5hrrF3MYBji7dbsN6xAqRQKWrrBav/2lhcrrQPuGKl7uLGwM6PwyWGkYjBcWXlNKM59cpaDEavhjjj8rEv5J/PL0jBszkmJzaNkxKoY5WMII8gtNZysZ+tUOqHdSfa3p//o/yN//u37//nDgT/X//p+rfm+ip1KoD//NQxOYe267eFoIK/uwSVuhAbxQwiugQOGASnflWEtvZvbczm86ZwxH9x8oTcjEANMX7PzW7/xnP99r43ZraOTbHIuqw5z1WOg6o00yy63fZuq1ZS9EI71pEMrc7qpiPWq+v7lb6t6V9g4YVE8O88UCwCPJF06ou8479UuQBrVywH//zUsTfHKPy5jbCRLpxyLP9FTgCQxMOO//beZJ8Av0s91O8LMBYF+cJKZnBQBiEFOtXKlqxdEpV7aJdyNic2IaraNtIiKtRneKiI1Lwr5kNkymcWuy3urkmViEYimVtimYxxgw66eh/3//jAYhVaIjg+6VMJLZ0EhZxG+jv6oe2YOjl//NSxOIcGkLJ9sME8G3uv1/Uq00KPbocVdlLmO8rB0OgY6Kb/82qqKAIq7bcrcz10Vk2kBwZHJyA5ESkPPnjBMajsk2WqYJMtpPW8Qjnb09QpHTNYkI7TbR92SE6XqmgkPGVlQ//2Om6MgrffyZv53jlCKZTPIqoY8RCjXt9n4vp/Z3/81DE5yKLssWWekrxvW7XqWAan20VoAAUm+dRMqMjbMyP4R6HeuUWaUZOi8A0KwqL7sZPA+0XjxevgXoqpDY/q8TLhTmolo6WgUh036MI1OalOlWS9X+Z0jY00TlLAxEHJGEWmBUTfPPvvYLPFHUAEuQUqVUrUtWtEYj6Xs3dvH2Z//NSxNEZGj7SFmJGPid2nu+pEAcruXZ0rXcVlQ0ArOxAnBg5m0udp2drZFecm2NidebUPO61gwUs5T2GGNFEYYJh4cf7P8tENdJb2vVJcYvPd0/SdoQYIAQTUhYGATAgelPdyLnW73NzTSlGD+ExeBRISU1ddu1Xu9qwmS7Ahb/akVH/81LE4hwBXrnmewyss/DoUD5QRdwmAliL8BWL7Un3ZuDVIsMNGgXxfiyCAIfI8gq+B6PFZEyyYe2mzv5gRX94kbO46F7hNcZneSt71slhUdRns9oeL2/3rX9LwJZ8slb+sdrcpqwQyVmNN2SQ4Dc+V5Vn1nD6Soy0uXZMhXSXSZDTxP/zUMToMoQW1hZ6Hx7WcXqZYWqBu9oOI97vsEkDDMriDCYrMz3ayKbVjnLeeg01nk/X6C7RViigszDEQ4oDGvQOLbu/SECOmQIEomrmEAc/2DsP3e5QayyFHOQLqiuNzK3TI2F0rLQwFzJ8149r755H85c1SYuMulkjUUiFptUoar3/81LEkydbnt42eVc6exhLP4Idm2OB8orwIMwEUIAno8Feljq8KGgYjgyQbBRlcyjaEZsyIspWRLsj5OrsQxwrWMKBDuZjbGKYgMqDSKTBJr+Fhrq94Z1AaHLM6q+U/GujzTTXZKiMdoiiV+v5/0H/z/yX5b839vy7+Piw7oan7fm/m//zUMRrHvQS0j54zxD6fPINuiFm6jjb55ju88LkmqyimLbbibkm978XAldf6OB+sCGw61a9Xltn4RoFbwYtBphFyhYiHRZWY5KIK7udk0qJHUcpDjULsyl1shRhz2MLGopjPSuVtJy///RWN1Uj9RIe5HUW/4VOyPfng7SCutFxI7//81LEZBpyYvY/TCgC1IFzQVc2jIYtQRQ7kLatdrklstIQzBVzdWiJujgFgsMqWqDywGG6dRnL8sEYUwSiHBESPIgmh8YNw7ASXEkdJ5AE42NicaFCJNKpG09kOOsdhLYIA6SQ8kktJUD8gdbLKNzRBB1QbFJtdNLYRz0OfJu00NV6PP/zUsRwMJQOuj+YWAHz0WkbTuekd2tKd927qXyyS2WJqw6Uz0+lBsu64Raqzv92doov9LdUcWUWoa/df81wk9J3/NLbNR013b79++Z9jYO7qjZt1VuJ5bNR/Lf50WIoqgGQipSshJXLCqBEFgSBIVEyKXkiRNWQhUEUjQCAUfVVM/////NQxCMWUTJAFckwAPat8z6JT/2qqr1VU5oKE0aRRGA0eh2Cr/JXgq/W4NVA1EUShsShqIv//WCo8Nf87PcRT3//BqoRF2DSFZPNvJTc0hIhkZIDbMrySqaS8HstKrJLw3IyIwDTQjkdoQSIaf+7GKGBgwh21RVRWf/uUyqjt/3KYP/zUsQ+F2H9dABIRSiggQOGosK/gIWFQy7wKFRYPP/6hfULMxUUEj//9QvxWkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq",goladv:"SUQzBAAAAAAAIlRTU0UAAAAOAAADTGF2ZjYxLjcuMTAwAAAAAAAAAAAAAAD/83DAAAAAAAAAAAAASW5mbwAAAA8AAAA7AAAk1QAJDQ0RERUaGh4eIiYmKysvMzM4ODw8QERESUlNUVFVVVpeXmJiZmtrb29zc3d8fICAhIiIjY2RlZWZmZ6eoqamqqqvs7O3t7vAwMTEyMzM0dHV1dnd3eLi5urq7u7z9/f7+/8AAAAATGF2YzYxLjE5AAAAAAAAAAAAAAAAJAKAAAAAAAAAJNU6rbZoAAAAAAAAAAAAAAAAAP/zYMQAHCFxzAdPeAAgCx4CGIY9L+JuP9dCFjjfFsJwdDhe9IDymWNXs8BD0PZ5E4WwnCEKcWwhDo/yDj1k7VakHrMuEchoKCaG/eRNQ379/uj+eA8iQ1ezyJ9nkYGSJm+83/xSlMvIgnD4gdggNBATh9H/KQ//h//////+9dx+Px+Px+Px+PwOBwOOV3jEIZmIT8XT6beCY9UsJv/zYsQeJ3K2xl+YmAAwQyy11SzcAIgqIrhDCWLxEyYPAYBAJCLLJEnD5ECbNzcZQAgIH0ItZXKxscUylpiNgxgGABGhGVqJwzdZubtijEgISBsRBSTHeaOiiitSrb7F8zHLImXCOHMNR4n+tv/+Zm7GCB9BjQuGZq+v////TPEwtzBqQwIP//70w+XPpdAEC03LoqsHXn0BgoIWEcX/82LEECLj5sV3yUACCKxpkgebUDaJYS9EIKUCx6HnkDRUFEG1g+ZtI4hpYZ8wIs2oqMLFr3KHnS73RLKI1XBsEZY0TXdvps3A2teI4tuK3WZ4ni9Y6ZWX4mdq0t0+KX/1eI+I+Pixgyv7njjqo/5xzV/FxGQ1/vb7TV6f/UT1G3xd9dLsdLPQhdBBbkt28gLjIXEhU+6xOhHxeBQ+//NixBQiOvrJVkoHV4igpJxO022giGm5MypCshYL6hW6F7eQcTSr8W9PUXNRtBMtMjH2kgJmrxUipGonF3CRLH4sKvUup1Rc/O0yQsw4+Gd9qkQpF/SqXz6aSj73Q/TMjIQ0xQwUJ0jdIxF0PBL1lSxZUonyttb//f//pZSO8yy3NtAEacl00X6BES4y3hRYZO1rS9UdFOE4QSYKkv/zYMQbIVvqxVZhht+O0XNAI0QflomhwtjG7HSEILsgBn7tfLe37/WqMhO4QjVoeouI+gvqK303aFKORZcvKfw9NjI8yqw2znlpUYgSVDxj0OB11X6d8uUvlP9z/TLpeQ8qE5+aUKxMfKRZJfbz+rS5Waw6aUE1NQpzf+GpjPakijATqdSomygGCHOUawoyQII/0KEUG2T9QCOiZP/zYsQkKANOpA56R4VfnRdlGTyIYTOJgXABpFrQ0fLgc75BZ2mlOr007w76imNWJeZgcqPprQOQ48kOm2xtIF2FdgW1uU1nXV2nicMaUSEiOjuRksfPpApLD3s4N09y/7mxTzIVcxjOevt7duUL2LMk+FzP+X8v1hhD7O96usOs6+pL/0Ep9ys6Ck5f5aHMcLGrB6CTBeqpFlchyGr/82LEFCPD0rQOewUrjXlUZRbCflXI/hP2asVHKlijNkBjLsEIH8qCsxTGf4qP7y4nhcdiKk3dtP7h03WQRZ3HmIDByuznubsfLQEQ4EeYqJf7lKYoaPOZmS7AiLJdKblmZdS7HtvZbaOyq3PpSmtuocxlrS+Uyl7XtdFZV3eCtaRga5M0wRf7pAIZWr7bv8hCXN9HhMkzDCbj1LU///NixBUki07iNnoFPxQWeK5+/RCsTicf5h/MusS53jtUpY2p+btVUnirs/S3/tBrGT/LzYgPXqUexLo/82s8Iqa/1XP9TjDcJDBEGA4DRw8HkAECMPxomhBF3LPG270yGnOz0QaOsXd6ZEFq06fqrkpp/7v0e1ATqfMRVh/XfuMGVOkjmCHnB/XyKoAq2nbpnTlyO1yK4yCo2Bc/Kf/zYMQSImQG3NZgUTeFI78VTBeZMkk/Yvts1nPncyIxJOlZEZAUhCSNIvvxlGieMyTC6oGIZBiC5ZkcplMwl3RkyziNBkiHtTVToOR2udYmKZOUtCSpdwIAvQJQbDYIEUfUijowrddv//z///7fxf8XencXF8zEtVmJ7OS0y1FZhj5CvzqCEAC4M2mZWt6Pcehwucw+T8UygUQQIP/zYsQXIjP2xo54xS0RxHB0juL8WEvSoLCZIhQ1RbB6Dka5HOznqnhuMgPhjkSlXGEopCD7yWWEcKL9PGfeWU7PpbOp1ndEfbzc6PwpGVSi9EF7qS6Ky/7o7qxHdUBjBEFFQjnMqucyu1kP///+/aRuSiV5CvWhaQRVwYppROqGAAANXhX/7hwDQLajPNNWyLclFDdBaQ441ZsvVK//82LEHh8iqtK2eMU01xFYT1Si0nFRTdttdyFRaCEk4YERBQ4xouut7IZaS9ZyKc7W/fpY6EjiWQjMy8ihlvr9Hezmcsx7l71a/+u6bdShjzgEbKi7wOIiVOonaK17qyT2C60IINUsoAGlVLrtAFf3J/vLzn4e4mbXt5LDH2byGnFzxWCp5Z5yqUqw07eTATPOxgULCbWZMdic9sdD//NixDEfma7N9nsMkM0sCdvt761//HimO8W7Ph335G779fVoMczLOQKesYS1YFEpgJPpAaTwVHiwjZMGsWeksdFxQ/PgnUIY5I5QuIS1iDqC1hGu4KPYRJmtFeQAAXd39YkKHFOAFY3Rp3x/GXSgGHxmaKXSwWo/O1yl6rR4aLDpCcQgVTI/b2jmsZiUTkZS4QQrbZhMcW3CP1zsW//zYMRCH8GevfZ7BpXMs0T83BhSVJv72FYU73/sVr3X9Qxs7PgEEm2nxdNu4pz7u1xt80v6d2NoVu2VpiV9Tf5Lvv/uCHkrJvPlzIJlFJOS3bEaImW8yiZrdq6lpLEYdYtBWn9ErTlZFCEaagfm5HXiHQNjMdD0LmVJDvIiS/f/nRWSI7V+rTvCDQ/PSKR+4ru57497xqYwUHwOe//zYsRSJhwW4j540N6piXekg10HLI+dNDIv9I+k7r/IMhKihdvr7v9X4eRcgBcR2NFg5AXDtijYcXEcwu+S2QbniAAco1lsgwXepLtIpLDs9JjxyoMRAAtVfr7003sCIHQlo7GpT1jlO+vQMsCSqrs0HQSIMLJAipxtizm3Foe9I2bAfRIyBR1paqn4tuZu9u+eYiuo6yH/5v/t1/j/82LESSVz/s62eZCMQdfx2O7vQXqYoaHYNhLA1hQODal8seEM2OLBWD5kKPQRQjMfWSPurlmup7O6mIUWb/q////SIi+HX/hf/v/5Rr0hHWTWLs2quULHXmaookSmuSkj3cLdijCKtlweGgi2GEUSMPSep5QtTM4gZdaXBAmrDeSKIp5ZCQ3VFFGqy4QkGXU3MG5FEOEzvDSEpcCs//NixEMf8/LeNnmGlg5vnfI3Jmn//ln+U1JQNRAsDSmSPqZMSq8yjNyflnm3ad1U75tP8l////JLCeTX/L+3/39Cxc06Eq6nCxqQMAFAk5G3d3NsTmZB2mVRRW22IV6vOtlmEgBhx2kOaSJI7qTbSUE5laOF/tmttcyXSQzPSRRTRpV3FadOb6aR6SIwt52mOr7MpGVVyEshJxZ+EP/zYMRTH7PW1t55hL2HUSgUMFMSlVRldCN+1v8n053clGPV6N3yem7o8qt/z/9zvyO5UH1mhbzPzoACAEob/vqmWgWD6zK49SiQrjUQMVVnHajPvdkWnC7P8mO4aZuNJfEL75HpK73W87/8Z0KLatjdXRe+bd4jYx3uHw6u+m1DlbFDtxs+q76HW1uLrxnntaLRsPx0x6bUL3LtFv/zYsRjOGwSzf5hntwxyoBjl3qT8VsRhRhczIb0IXB/hUHaTweg6lSkFYiRjjrOEWMYB0kLFzBZiXyWhDz0RZ0HMZKQghAydI8yxb0gciGp6EqYjewKhDIMJ6kjjR7gxHhHQt5ul5Iivb4+trlPwozvMZlec3EillhPyJzRzzpzR+HRRwwwa28b8TMdoP+1dJLmfANPsgafqGU31cv/82LEESJzitSiMNL9cMUqhz2lhncKiHmPrl5UkItCL8pnZCPse2Eb7v86ZuR88qxRJOECh7Zt3i/bR1qbjGoGyDRS2hKrWqYWWKqNH0z940goSMTbTJ7eUJmYH4p7K8k1OyRKL2YT1PKMQzrQSZqpzhkN3z2UZf1m6mWUShrAoMAASQOUnYUiUm3FIkB4XlxVupKuIliQHENrLRRF//NgxBcemsbm+hJGHdplXpS3CFZwUzWi7VtQwVwYE7IWQ2zgAznHFscIuhXOckPslIqfwuT2zn+s7u+Z3yWHlnkDBOTVThqYYowUojbjbDMREOWiZjdgh6M+csy6gTbvcVO3tFYeb/3V76tZO3gvu2rHZCHd/lAZmb5mVyw7qzzXgVWHBCz5jHs1NzJcib+YF7kDVBVyeub8lBtU//NixCsd4rLm1EmGVBCuYMW7ccjXnhyW58z6W5X9tv7T/OcI+N8yanRwfAdFEhS1dWdmNimkVlBWmpgzriQsmfAYut7o9FAqeNuAixKqbpLuJcCbkQgkm5C68OYGnQP2NQ36URicUEwiR56DHs68tLd9ET6IzcsaZsyU4NqHJlUih4O6hVBcS3yhJ8LtkRZDpvYsPL9KWUvw/Us0ZP/zYsRDH6tS2jBJhnQfSosYUtAQi4ohTYEDXFWOGEoPA1IEGGiRxwQfAk1aPGYSTQlY8U5uVLzhND6qiTJoYkTVfJvB4hYYtM3/NptydSA8zbGg9VFlXNH167pbq8Xq0rMw9WXlzn6ucrfWY+eyi9BoTODIWCU+aYOnz9WZngQWHhazWxTKFy8axJw+9JcpnotO5yKiKoqZQccMVkf/82LEVB/7vuZUYMtRlUzDS0KQZaIKcr6oJCzocpEs0//yd/e/XorEt5X71FdZi3DqnWXuyGyfTzTFQlFVSRNEAqlfGUDsa9QFSJVkol0iPAQ0Qmyu6TEBsVds928xxoroNETm+7c6vhng+QoWR9CIvHyziHp81g2h058LsypTKn/DUIpwx1JZgzdGd0F4JBB4sEz65QWcKRIwgAhg//NgxGQd+k7m/DIHCA76bMKDaqW34X3tAhOWIsDUToRV0qKaqIoAN+7FpgQ4+WLvN0ZWIC0ZLdUlWs2UWPR3eVRrRGUiBIAiCKRS7+S1MwkJFez8yyjF5O51Mp0shS0//S6Ks/5MIeSFpuJM3ZWhVQbPRJGs6D0U9O3l9NqDaLJ72m9Q3/b2hJUZ3uY5f2X9UTmU9BReFnQ6khmq//NixHsfI7biPDDFef8VpkIRUTMqD/NY0mikPg2eRt8PbWT0gdSJCUsuyM0CGvLgy+eJMEFntmm+V62xJ7qfXJv0fQ46SlZl1Jqh8zOH/999lM4GBgiBqW6yEFxxNFmwlS6QsHnWOo/cu/Tgj1mwi5i3l3MXBNpdJfaTEBEDM1Fy0PGBRcZEM0ZL9QDsHUA2uMtEB4Srn10acZpqI//zYsSOHWLO4vIwhyTIIYR+vvDqJnMsqiJ0ySx6jyURcaEmQCMGYy0qxulqmcKEzM0YyMo/BWayWe6Uo1xD6712MZo1josy1uTSm5DEvFWdKSo+m9Eqru+nP9Ue/29G3/sq1UFnJpivfHVMaCtK6EAUHEV+xtFIQWoIhHEuStmkSMQDsYA68o9hhmDlIJqWiogMG6IqCGxKjH7UMoP/82LEqB4bqur0SMUxAYG9h5JdWf8gfnGayhS1JDq4Vs//l/6Wrftr3jKRmokKAypVgEQMBCI0qWaDJ0JloqCodceEqyygqGtZ2eiVf+VEvxFfiJh0RPrwNprm245ZYTMYatgv/Y3hXrHWxwG+WK/rTxmCPiOwj8dRoNc4swrm7ZWvEqZkYCJ2EC42KZgUhMTldCVQqrAYdBAS1Z+k//NgxL8eIk7N6npGcP/hRl7yJXYjt7+iMdzsZf/RHypyMcKZWf7PLO37f////6X9v/lKlis8zrmRnWgMyPARzAAEYvW6+bwl01rBRonJMVIzaqSqzVUefzb9y61L4VGImuGjqfilCwJY8vCmpDNXm0aU9aY6mdzpwqFO873eCsZ5eSwFEKOtb6ULlp8yB4c9/MUX39A+eq87K7pW//NixNUd+/7yPnjFN6Q70uYzqX8qNpQ/6MykOQzqZ1mds7NO7I52YqirwnLCPYLCzkUSJ7cCqNABWxxoYzelEbgykE3wlx4ZeGNwiBV0NkQEts8xwN1hRKg5nNCkcE9eF6cGxGDOz99OU9F6G9FA9VHMvsuK8reDZRmEX37G8rGYMZ8LWZIidcV9raTcT9XVf9FC03/5RQWDx758oP/zYsTtIcNmxfbBixDoG6p/wULHGfL+IAeEnx9dR////3/PHrE3Yqh8z8f6l2msqjolfSjmp7//4+NVUosI/V3tGWxGKrQAAiUC1P/jxMza1II0+gw9ockeP2Eauz4CjAfVq9o8SHxuEEuP+pgak/SJT+E+ZNX0KhRz6ruJU8a9Ch9UtEf68kmi9yPrrBUJResVvlfmF2fupt/65mH/82LE9idLxrVEwxDbP/j06/ko40Xe+LYkcwoi9tZR9c9///Nf836fGNGCcmMJCojeosDggdKijiH4qwyK6xBchVWAC19exHJC/zzJ8DLcTFsktsYYrLlrt+/SFQCaNJDQHENISU+NLk2C9n+TdUo5yLGomcxTwWXihcG5GpQokP04SViP8T0VqPxZzW2GXTWnTQmm21bs9fPBrx2S//NgxOgjCu7GFsMQePjj2FhQCIN42yqu6KtvxybVO08zJgu1X+ULFje74FnD0BwLK/PWBGDkG9tNNo179TK///+rkCleyFByKFn9crsPMqu4U0VGFnzHsxygwNlRZNTwqID8aopxVaABfh7lvrLp56FiimpllNyftnNqA2aShMVlYWFRlHWWNEHOXA20apyiSQ/UGMk/kDBjEpbI//NixOotI3apQNPQ2qh66TTKhjZRTHugTltDjYy3xy6j4eUebiRXuqJM6Mag+HGoJ6BLA/FOcOoiYAMACAi0RCVGRcpOy1JIiQgym+BCCOvlalyRQbeu7UDwC4LAbidn/FQ8DwYOqq/i7+P/5+/mIDk4sXZJ9ihz/Xwx4pQoWNah8+3xKDP/q3/zlY9/E4jShAAFXw23KZZ3ATMZaP/zYsTFLes+qUjL0NkwGU/FWLCssiDE12F/QqBQOER5Ds6zurPZ82WC77IVQSB/XBcRX84z+CXoflsb52GgvlGJZfoJA+8IjNqbk9a3T3HDai/lA69S7L6b43DtnG1y/u/KnFCht7x0k+lV0B5aKAgFurfVui5Y+pu/Gttv7j7ClFM+9H0WIgnrU27g8kTAkhobXY6YmSxLiMiyy4v/82DEnTJkDqXo0tuoSbdJq2qqdFL12GKSyzFBLsoh+vUkMtJFTXqlSlVd1qPN3WvLr/1sfbaukcN6oAAA4Es8ohdkcCX2JOUgUc81oy6kIdqXQW+okVp72Jb1ZUpQ5EItvrpzJbCqGbo4cj1Z34Gs1+z8Ay+LUvJbL6W/erUneZzKrJd2xlRzvfuxqz+sdYbv3GjCU6CWzUzasdr/82LEYiz8FrH0woXQe2z2RaysY9u1DJ7WKIFCLDTzl5CIhjfq48GimJmsUIghZi+xI5CJJIceYSH//9KsrGGxIYsxrrPdi6dtiEZucY33Mb+hr/oYCANehgwN+3DCyaAAB6z/GnqRSV8nhyKUtEb51InDEAQucTlRwR6Gj+a0YySvWoW9C9McFjN9WXQ+iAeSWhKrFpbMzyL4zlfU//NixD4oA1a14svQ3FgIcPOO/1Fd2hQora5w4FdatRTBAgD8Y8fWq/GJI0T4/qeW//n1NPr/+LODxO+bKJpq+4cYDYRsI5Knna1k9W/////+nv9YKc5J/+eUc/7pRxTkIzDQEdUHesSmeDRYBn4agD/6u/DeEedpwTNlXo2JgbsUkLV+mCgDeUrK63FXMgYEnVI3BsM9mHvgiGHrZf/zYsQuKZuqrKLKy8httA7LoEjv2cad+ZPIcqSAKPK9uretSTOgKhrZ69+9Ywyl+dh3OWcL3crVe8Mjhx0q53LPPfcNY/hu4787beYd3Yht/i5hRogzKXf7aQRreyVqtMU2OXbvlLNB0RN//+TZ1E3ckxVHooBGV/3Fuz6MJf+P/2EP+oSK2ARAgAAM1upRN2jViblT6EUYGbg8kNX/82DEFyNr/r3+w8rdmU3nYb1kTKx/JMwDFX3TM8ZC+s7G5TNECAwsMJsmzJqr6DiXdnPXxqe0WQGxAeRqarmCwE8a41otLtzx41guRf0/zj6riu/9/T/uArftGkFX3bixH2J1AQrLVy1MO///39vGv/xjf6jm/yP/iQuyp62JrfuHZu24AAIB/8oXOrZIewBPLYMLK7Y4a0/E7A7/82LEGCJMArnswxrQ37SWtpxgu4cEAPC6TScjEcGRxcrHiJhSiKA7s2+Haqffk+Ns2dlF8CVBSOeUbJmzskSy0VqpTWEzASVl0m1Ktf6T1fsTiB+qszbo1pqQLKu90DhQ6Oq5Tq//+orV7+aJ/6Bq/V62/7t/dNv9Rxv+bOQqrQQCFgmf9ari/t6Lz00SJhMpjsViMvg+OODG1hAj//NixB4hC9rB9sMa0GQdK7bSHVEkXriHx6ufPSqy9vUj1jdykduyjrnIbYnJvTTcwRNjIsNi47pqrQCBHkmkj/V6utX/KiU1XqeapvqTqc4TT6CPU7HTSvfrNP//9jfVrskX3/1N/zFN/60P/NFN/MfkjFWVARBAJsl2raa6//5GuAEG60QTYcinY8cPwOxJqLSGYHbrvt2fh9LE7f/zYsQpHhOyyrZjS2hmODrTLsE5G5fMs1rCahuK1TZG5eSZKh3KwtJH/2deWtrk3s1ECZKOhEOsIMyyWUwkDpf3gK23qZ2///SL/8o/+hhZtH8RN/zP/oLu6znkFdQEEn7vGG6R4rmEdpBGStMu7WlFHecJnbDlXjJcW0ZbMjasnwv36qtcLrGp2KWtDTL3lfB++i7ppDzBYoUGZaf/82DEQB/btsHkwxrQmCq1V0DES8HUOq/6avb/+svl1veuYGJ7pa6KV9egYE1d1WsgcNW//9BBNSX95gbf7ot+hTNf9k3/e5q3CIF9SoIAABAGQnIt5q4v7Rz0CGqlXuDYqW6S6OcTLhN2GhsYtdSlE8fQ3bc+2xvIvval943Hf2vamK5pDQ8sjpmp/qmlqt8clkAoARApWRk6/qr/82LETx6idsq2eguAytp6BwaORvodhVrch2RPnIqGR/nGA6d//8uFtkQAyWBqXIHucZ8SphYy4XrogAIFgyWmpLRG2VVxR3HEwMj6BEV83P2Oq26JFwo3tOnQvTlVCumzRdrgQQalpZcOywPq475cFILV9d7pmlKvulQmmMjOXMjO+7jCnuqM+rH7P/7lQxjIrs60NT3lMZ////f///NixGQfEzLKFnoFLNuVWUiWMUKCpczlbu3piweIA9MAUQgQeyqoAAq1uW1Eo/tkFFTFicvE1A1TYyJyhcoJqgiWocKRN/EqxlAc8WslLszynZm725iDQrqYYoBhmp2Fsxn4paFU/IhSRY+p9b7U+7lmX/+UzUsiMnEAiR6bz/hTiNfUoMYPDA2HRRhEKSRsvJjEBWBmoAX8jnh5Mf/zYsR3HyK20hZIR2JTJY0oeZqoAgKNty6BU26xWm5sgJBCMDqFRArAjCINrB4TGs2C30GRIsoppZoZEOWJaxjj5m3luVMvIKM1yotj2MkFiR4VMgUpqgH4YVWZ4bWgsHndPAm3Da8t0fz+X5q2Nv//yLwREr05iv/5idPWoXONM86rn/e3qn7/Ctq/zJXdkqiCAzW5bSdxuH2QZIf/82DEih8x0s4WSYbPuAJC+WeqIPVsarFhZtXcmupJRN9QDwJygMWCAHclrsSSkxHCpWuRyxR5uOy/m6T6RW5unTm8ufnp2Fz/4/P8sjVbtFa++nlfl1kyHp1TS578z82sTuKKOkyZMjtAOcDPvn/nmnfgQzET3gGIBA+IgBRk5Jkm+CbsgBiyaOJqM1yYha6SbT4Rv+FlCQbc7Kb/82LEnB7DHtoWMkaT7u56FtSPJrC/8v/hf3IyhdiRO+o7li4XIum/TlvdyyP/IIgxuLjzVMw4TremOOwIZFjPFIrFiPPVIFwQx6jiENqGtJsk3HOU7YLYjBXEBaEoFY4Q38B4oMxCfpumNqdzTmVh83uSjw1s9nkV/jzvIMaG/iQ621AYGS9bUY396PJn97v7ZxNuBWH+2TUxWHWI//NixLEr3BbZ9jDfHoAyXJv7m5FyEnOJhAww5pkoTm0AUS0lRNbprJOZjDm5YQPVthcIwmaVFCM2Rk8M8i9T5DzPiwsohzr/hcrbzMIJ4RODfdzpnHWnHV1+fs+5U7VuOJHdJb65ZBY3eHdIOkSxZbR9N1zDRYYDp9UfHtDupa9K+ejopRoJiVx3O3n9rhISp+Yo4cHB2hx7N1jNjP/zYMSRLYQW0e5I2TTVnH0d2B+t08czLTrLR2cOrUNhR5fW1OTtcJNi7lcZW8nq8rcZxEExBan8ANx0NO+ns+7V8rxkQayJS4WC2I2lpyNSIKOdNe7zzJN1QXYTOcDuMTvYjHaHiwW0Q1RwgrCIruG+C2a0qmc3//Iuc+/GSF3h/epQnSKW6JKeaoCWlUIYjvY0Hbt0EN2VEEOU/f/zYsRqH6q+4vRhhpGss5ptDm2cRv///7E95r1+hvykcNqkMAAQpBDE4F1UahwqsBSM22UbxnjsRwo1BmNQkWZk1KOtzzAxG9UUQSAy1NyhQvOs0ty1pGmfkbLdVMmPNSPcEOsZT+8dGb+Q4rCZmVpQKQCJMmsQ+2o8ysOWbIDVM0wcs1EpcskdEoSHVjREVcFZruZZDvpDci69Cnv/82LEex7SztbSSM08aqyCXrUm5Y4G4WIp5CEpy0bPFqxDidSVP0jixg0XRt5eu+w316feSQE9rW+/drHZXS5CPoqvEhws6Mxam89VD8siqiBBjfUXIumT5dj4iMd5sO5bRcgTOpa7OIzKMTNS8SAuqw5sxOslX/8pw1I6WTf+1Up/Dy7/Sh2F53OqRrM+7THFnbAAArMnJVqZluhl//NixI8g7AriFmFHbkhL2wq3oNcBoK37ypbagvzT0arW23smewph+eEp+N12cRHGm34oOPvXggayzTDdTsZDdsv8bkDT9ILLFw9AeKjM1hp55CzApZAmFO7iBQkP5fIxQkRxg+WWKdCV3amT6ZaLnziBdhn6gc5fOuhH88un/+hG/aaQ+fP/1/7XjHJccj1u3GNQ2KCrDCyKzJIFKv/zYMSbJZwO3hZiB1eZS3bFW10cIGEZzR1W4GzVQRd5EL0dr6wmlDP66oYNo8qM7NCIzY/qXXvZwZky83MhmQq0f9WMmzhRlM5WcrarmswpnoKMY0xUNMZS9/sW+lspdzlVvI1zO/eZmkZPrZ2VmVtSs95bcxuZdXchkmAwTFY55xh2xEon897qyQJPVTltaTwH3WVgeH4zwavGe//zYsSTH9PW6jZJhUexu0Y+esLlm80GLW8CNBazuPKS0Pw8wluytmzkSmp32SXN95PCZr3Ps5OZ3O21XkIKPZiqgICdfRt8jsXZXECwEz9Tfp/tVfZSIioxyOzMLdsz9vvVZtVRmWxUXmkf/+astHYolmtNpmRrvCL8qABHLbktKpCVZUNaeWBgZQG4ilGDxYkmElRC8iWY1EWxGwj/82LEoyADtuIWeYUvCbenDqiXRWuVkiQ+o+hT+KxYomJpYaNkir/r2eo4gY3xPNymvYsUOhtVXjlLnvhua5qP4+PinqDhaJT6xU8SC4TEIsLDZZhMyFdLhKdUp5gi1A85Tq9wdJhJ+JUrgXkgDP0xcYj/gIDOBiEEoUB/8w08MgSi7Bi5V/ga8RoGVzYBjEcAEgoNjD8OAgCgYeAA//NixLMgAlrOF0lAAhgwSkBEiABAnAyAJwMDC0DEQfGsGzB7zIeBYGAiDYmwBwCBwDFnDiULOEFvhfQhwBQCDmjUBsFiDSOGaKxDhcxfId/BIFilAwiTI+iSGNJAgZCizUiZIqtExMf+FzgyQ54jwZwggrZyZHIDkjEnSqZEyeIEpIyWxktH/+LpAiQlEgJDmH8niCE2cJEiRocVRf/zYMTDOAtCbA2bqAFUWWXWWiy0f//mamP0TdaJ9MPTnj2zcTQXpoL5uNVMQUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/zYsRvAAADSAHAAABVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVU="};
const AUDIO_NOMES={gol:"Gol",pen:"Pênalti",verm:"Expulsão",inter:"Intervalo",fim:"Fim de jogo"};
let _audEl={},_audBuf={},_audAtivo=null,_audLiberado=false,_audPreparando=false;
function audioArquivo(k){return _audBuf[k]||null}
// toca o áudio k. Retorna true se conseguiu tocar (assim quem chamou sabe que NÃO precisa do som sintético).
function velSom(){                                          // v54: o som acompanha a velocidade do jogo
  try{const v=S&&S.live?S.live.vel:(S&&S.velPref)||1;return v===3?.5:v===2?.72:1}catch(e){return 1}
}
function tocaAudio(k,vol){
  try{
    if(!somOn)return false;
    const a=audio();if(!a)return false;
    const buf=_audBuf[k];
    if(!buf){preparaAudios();return false}                       // ainda decodificando: o som sintético cobre esta vez
    if(_audAtivo){try{_audAtivo.stop()}catch(e){}_audAtivo=null}
    const src=a.createBufferSource();src.buffer=buf;
    const vf=velSom();src.playbackRate.value=Math.min(1.6,1/vf);  // 2x → 1,39× mais rápido · 3x → 1,6× (a voz acompanha o jogo)
    const g=a.createGain();g.gain.value=Math.max(0,Math.min(1,vol==null?1:vol))*1.6;     // áudios gravados vêm baixos: ganho extra, protegido pelo compressor
    src.connect(g);g.connect(MASTER);src.start();
    _audAtivo=src;src.onended=()=>{if(_audAtivo===src)_audAtivo=null};
    return true;
  }catch(e){return false}
}
// "libera" o áudio no primeiro toque do usuário (navegadores só deixam tocar depois de um toque)
function liberaAudios(){
  if(_audLiberado)return;_audLiberado=true;
  try{audio()}catch(e){}                                           // o toque do usuário libera o AudioContext
  preparaAudios();
}
// decodifica os MP3 embutidos (base64 → bytes → buffer do AudioContext). Roda uma vez, em segundo plano.
function preparaAudios(){
  if(_audPreparando)return;_audPreparando=true;
  const a=audio();if(!a){_audPreparando=false;return}
  Object.keys(AUDIOS_B64).forEach(k=>{
    if(_audBuf[k])return;
    try{
      const bin=atob(AUDIOS_B64[k]),n=bin.length,u8=new Uint8Array(n);
      for(let i=0;i<n;i++)u8[i]=bin.charCodeAt(i);
      const ab=u8.buffer;
      const ok=b=>{_audBuf[k]=b};
      const pr=a.decodeAudioData(ab,ok,()=>{});
      if(pr&&pr.then)pr.then(ok).catch(()=>{});
    }catch(e){}
  });
}
try{document.addEventListener("pointerdown",liberaAudios,{once:true});document.addEventListener("touchstart",liberaAudios,{once:true})}catch(e){}

// ===== NARRAÇÃO DE GOL (voz do navegador, estilo de narrador de TV) =====
// A voz é a sintetizada pelo celular (em português do Brasil), com ritmo e tom de narração. Não reproduz a voz de nenhuma pessoa.
// As frases combinam bordões de estilo conhecidos do rádio e da TV com frases novas, escolhidas conforme o momento do jogo.
const NARR_ESTILOS=[
  // "Globo": grito longo de gol + frases de arquibancada
  {nome:"Clássico",gol:["GOOOOOL!","Gooool! Gooool! É gol!","Olha o gol! Olha o gol! Olha o gol!"],
   quem:["{n}, {n}, {n}!","É dele! {n}!","{n} balança a rede!","Haja coração! {n}!"],
   extra:["Que golaço!","Que beleza de jogada!","A torcida vai à loucura!","Explode o estádio!","Não acredito no que eu vi!"]},
  // "Rádio": voz de locutor de rádio, rapidíssimo e dramático
  {nome:"Rádio",gol:["Gol! Gol! Gol! Gol!","É gol, é gol, é gol!","Gooooool, meu amigo!"],
   quem:["Bola na rede, {n}!","{n}! {n}! {n}!","Quem fez? {n}!","É do {n}, é do {n}!"],
   extra:["Cruel, muito cruel!","Que pancada!","Entrou no cantinho!","Ninguém segura!","Ele sabe que é disso que o povo gosta!"]},
  // "Emoção": dramático, voz mais lenta e grave
  {nome:"Emoção",gol:["Gol do {t}!","É gol! É gooool!","Entrou! Entrou! É gol!"],
   quem:["Foi {n}!","{n} não perdoa!","{n} resolve!","Frio, {n}!"],
   extra:["Que momento!","Que jogada!","Não tem como!","Estádio inteiro de pé!","Agora é com a torcida!"]}
];
// frases por situação do placar (usadas depois do nome do autor)
const NARR_SITUACAO={
  abre:["{t} abre o placar!","Está aberto o placar!"],
  empata:["Empatou! Tudo igual!","Está tudo igual novamente!"],
  vantagem:["O {t} vai à frente!","Passou à frente no placar!","Agora o {t} está na frente!"],
  amplia:["O {t} amplia!","Aumenta a vantagem!"],
  diminui:["O {t} diminui!","Ainda tem jogo!"],
  fim:["Nos acréscimos! Que gol!","No final da partida!","Quando já não se esperava!"],
  inicio:["Logo no começo!","Que início de jogo!"]
};
let _narrVoz=null,_narrUltimo=0;
try{if('speechSynthesis' in window){speechSynthesis.onvoiceschanged=()=>{_narrVoz=null}}}catch(e){}
function escolheVozPt(){
  try{
    if(!("speechSynthesis" in window))return null;
    const vs=speechSynthesis.getVoices()||[];
    // prefere pt-BR (voz de rede/natural quando existir), depois qualquer pt
    return vs.find(v=>/pt[-_]BR/i.test(v.lang)&&/natural|online|neural|google/i.test(v.name))||vs.find(v=>/pt[-_]BR/i.test(v.lang))||vs.find(v=>/^pt/i.test(v.lang))||null;
  }catch(e){return null}
}
function falaNarracao(texto,opc){
  try{
    if(!somOn||!("speechSynthesis" in window)||!texto)return;
    if(velSom()<.6){try{speechSynthesis.cancel()}catch(e){}}                 // em 3x a narração anterior é cortada para a nova não ficar atrasada
    const u=new SpeechSynthesisUtterance(texto);
    if(!_narrVoz)_narrVoz=escolheVozPt();
    if(_narrVoz)u.voice=_narrVoz;
    u.lang=(_narrVoz&&_narrVoz.lang)||"pt-BR";
    u.rate=Math.min(2,((opc&&opc.rate)||1.12)/velSom()*(velSom()<1?.85:1));u.pitch=(opc&&opc.pitch)||1.0;u.volume=1;
    speechSynthesis.speak(u);
  }catch(e){}
}
// monta e fala a narração do gol. meu=true quando o gol é do SEU time (mais emoção); contra=true quando você sofreu.
function narraGol(info){
  try{
    if(!somOn||(S.live&&S.live.pulando))return;
    if(info&&info.contra&&_audBuf.goladv)return;                                   // v53: gol sofrido com o seu áudio pronto: sem voz sintética por cima
    if(info&&info.meu&&_audBuf.gol)return;                                          // gol do SEU time com áudio pronto: somGol() já tocou; sem voz sintética por cima
    const agora=Date.now();if(agora-_narrUltimo<3500*velSom())return;_narrUltimo=agora;
    const est=NARR_ESTILOS[Math.floor(Math.random()*NARR_ESTILOS.length)];
    const pick=a=>a[Math.floor(Math.random()*a.length)];
    const sub=(t)=>t.replace(/\{n\}/g,info.autor).replace(/\{t\}/g,info.time);
    // situação do placar depois do gol (a=quem marcou, b=adversário)
    const d=info.golsA-info.golsB;
    let sit=null;
    if(info.golsA===1&&info.golsB===0)sit="abre";                 // 0x0 → 1x0
    else if(info.golsA===info.golsB)sit="empata";                 // estava atrás por 1 e igualou
    else if(d>=2)sit="amplia";                                    // já vencia e abre mais
    else if(d===1)sit="vantagem";                                 // estava igual e foi à frente (1x1 → 2x1)
    else if(d<0)sit="diminui";                                    // ainda perde, mas descontou
    let partes=[];
    // 1) o grito de gol (curto na torcida adversária, longo na sua)
    if(info.meu){partes.push(pick(est.gol),sub(pick(est.quem)))}
    else if(info.contra){partes.push(sub(pick(["Gol do {t}.","{n} marca para o {t}.","Sofremos o gol. {n}."])))}
    else{partes.push(pick(est.gol))}
    // 2) a situação do jogo
    if(sit&&Math.random()<.85)partes.push(sub(pick(NARR_SITUACAO[sit])));
    else if(Math.random()<.5)partes.push(pick(est.extra));
    // 3) o momento do jogo
    if(info.min>=85&&Math.random()<.8)partes.push(pick(NARR_SITUACAO.fim));
    else if(info.min<=8&&Math.random()<.7)partes.push(pick(NARR_SITUACAO.inicio));
    falaNarracao(partes.join(" "),{rate:info.meu?1.18:1.02,pitch:info.meu?1.12:.92});
  }catch(e){}
}

function somLamento(){ // pênalti perdido do SEU time: o suspiro sintético de sempre
  const a=audio();if(!a||!somOn)return;
  multidao(2.2,.14,.2,0);
  coro(247,1.6,.16,0,.78);
}
function somGolContra(){ // v53: SEU áudio ("Olha o chute...") manda; murmúrio baixo da torcida por baixo. Sem áudio pronto: o lamento sintético de antes.
  const a=audio();if(!a||!somOn)return;
  if(_audBuf.goladv){tocaAudio('goladv',1);multidao(1.8,.08,.2,.1);return}
  multidao(2.2,.14,.2,0);
  coro(247,1.6,.16,0,.78);
}
// Apito de árbitro real: dois tons ligeiramente diferentes batendo (efeito do bolinha) + trilo rápido
function apitoReal(dur,t0,vol){
  const a=audio();if(!a||!somOn)return;
  const vf=velSom();dur=Math.max(.18,dur*(vf<1?Math.max(vf,.55):1));t0=(t0||0)*vf;
  const t=a.currentTime+t0;vol=vol||.35;
  const sai=a.createGain();                                   // envelope geral: ataque rápido, sustentação com leve queda, soltura curta
  sai.gain.setValueAtTime(.0001,t);
  sai.gain.exponentialRampToValueAtTime(vol,t+.012);
  sai.gain.linearRampToValueAtTime(vol*.82,t+dur*.8);          // o fôlego do árbitro vai acabando
  sai.gain.exponentialRampToValueAtTime(.0001,t+dur+.06);
  // ressonância da câmara do apito (dois picos de frequência)
  const f1=a.createBiquadFilter();f1.type="bandpass";f1.frequency.value=3250;f1.Q.value=9;
  const f2=a.createBiquadFilter();f2.type="bandpass";f2.frequency.value=4300;f2.Q.value=6;
  const mix=a.createGain();mix.gain.value=1;
  // tom principal: dois osciladores levemente desafinados (batimento) + "trilo" da bolinha de cortiça (~38 Hz) modulando a frequência
  [[3180,1],[3236,.9]].forEach(([fq,amp],k)=>{
    const o=a.createOscillator();o.type="sawtooth";
    // leve subida de tom no ataque (o sopro "pega" a nota)
    o.frequency.setValueAtTime(fq*.965,t);o.frequency.exponentialRampToValueAtTime(fq,t+.05);
    const trilo=a.createOscillator(),tg=a.createGain();
    trilo.type="sine";trilo.frequency.value=37+k*4;tg.gain.value=fq*.02;       // profundidade do trilo
    trilo.connect(tg);tg.connect(o.frequency);trilo.start(t);trilo.stop(t+dur+.1);
    // o trilo também modula a amplitude (a bolinha corta o fluxo de ar)
    const am=a.createOscillator(),ag=a.createGain(),base=a.createGain();
    am.frequency.value=37+k*4;ag.gain.value=.28;base.gain.value=.72;
    const nivel=a.createGain();nivel.gain.value=0;ag.connect(nivel.gain);base.connect(nivel.gain);
    am.connect(ag);am.start(t);am.stop(t+dur+.1);
    const og=a.createGain();og.gain.value=.5*amp;o.connect(nivel);nivel.connect(og);og.connect(f1);og.connect(f2);
    o.start(t);o.stop(t+dur+.1);
  });
  f1.connect(mix);f2.connect(mix);
  // sopro: ruído filtrado em agudo, mais forte no ataque (o "psss" antes da nota) e fraco durante
  const src=a.createBufferSource();src.buffer=bufRuido(a);
  const sf=a.createBiquadFilter();sf.type="highpass";sf.frequency.value=2800;
  const sg=a.createGain();sg.gain.setValueAtTime(.0001,t);sg.gain.exponentialRampToValueAtTime(.38,t+.015);sg.gain.exponentialRampToValueAtTime(.07,t+.09);sg.gain.setValueAtTime(.07,t+dur*.8);sg.gain.exponentialRampToValueAtTime(.0001,t+dur+.04);
  src.connect(sf);sf.connect(sg);sg.connect(mix);src.start(t,Math.random()*2);src.stop(t+dur+.1);
  mix.connect(sai);sai.connect(MASTER);
}
// padrões: início/fim de jogo (3 apitos: curto, curto, longo) e intervalo (1 longo + 1 curto)
function somApito(){apitoReal(.55,0,.4);apitoReal(.55,.7,.4)}                // início: dois apitos curtos
function somApitoFinal(){if(_audBuf.fim&&tocaAudio('fim',1))return;apitoReal(.5,0,.4);apitoReal(.5,.62,.4);apitoReal(1.1,1.24,.42)}   // fim: SEU áudio; senão dois curtos e um longo
function somApitoCurto(){apitoReal(.9,0,.4)}
function somExpulsao(){if(_audBuf.verm&&tocaAudio('verm',1))return;somApitoCurto()}
function somPenalti(){if(_audBuf.pen&&tocaAudio('pen',1))return;somApitoCurto()}                                               // um apito firme (vermelho do seu time)
function somIntervalo(){if(_audBuf.inter&&tocaAudio('inter',1)){multidao(2.5,.08,.4,.2);return}apitoReal(.5,0,.4);apitoReal(1.0,.62,.42);multidao(2.5,.12,.4,.2)}   // intervalo: SEU áudio (+ torcida baixa); senão apito sintético


// ===== OUTRAS DIVISÕES AO VIVO (B e C) =====
function mkOutra(dv,forcaBase){
  const lista=clubesDaDivisao(S.pais,dv);                 // clubes da divisão ATUAL
  const rg=rngClube("outras|"+S.pais+"|"+dv+"|"+S.temp+"|"+(S.dia||0));
  const ord=lista.map((c,i)=>({c,r:rg()})).sort((a,b)=>a.r-b.r).map(o=>o.c),jogos=[];
  for(let k=0;k+1<ord.length;k+=2){
    const ca=ord[k],cb=ord[k+1];
    const A={nome:ca[0],sig:ca[1],cor:ca[2],cor2:ca[3]},B={nome:cb[0],sig:cb[1],cor:cb[2],cor2:cb[3]};
    const ea=ESTREAL[A.nome];
    const ka=chaveFixa(S.pais,ca[0]),kb=chaveFixa(S.pais,cb[0]);
    const fa=forcaClubeNome(ca[0]),fb=forcaClubeNome(cb[0]);
    const cap=ea?ea[1]:Math.round(6000+fa*200);
    jogos.push({A,B,a:A.nome,b:B.nome,pais:S.pais,div:ka.div,ia:ka.idx,ib:kb.idx,fa,fb,ga:0,gb:0,ev:[],
      est:ea?ea[0]:"Estádio "+A.nome.split(" ")[0],pub:Math.round(cap*(45+rg()*50)/100)});
  }
  return {div:dv,nome:LIGANOME[S.pais][dv],jogos};
}
function criaOutras(){
  const L=S.live;L.outras=[];
  const base={0:70,1:60,2:52};
  if(S.div!==0&&LIGAS[S.pais][0])L.outras.push(mkOutra(0,base[0]));
  [1,2].forEach(dv=>{if(dv===S.div||!LIGAS[S.pais][dv])return;L.outras.push(mkOutra(dv,base[dv]))});
}
function tickOutras(){
  const L=S.live;if(!L||!L.outras)return;
  L.outras.forEach(o=>o.jogos.forEach(g=>{
    if(R()<.04){
      const a=R()<(g.fa/(g.fa+g.fb));
      a?g.ga++:g.gb++;
      g.ev.push({m:L.min,t:"g",lado:a?"a":"b",n:pick(SOBRE)});
    }else if(R()<.025){
      g.ev.push({m:L.min,t:"c",lado:R()<.5?"a":"b",n:pick(SOBRE)});
    }
  }));
}
function htmlOutras(){
  const L=S.live;if(!L||!L.outras||!L.outras.length)return"";
  const cor2=x=>x.cor2&&x.cor2!=='#ffffff'?x.cor2:x.cor;
  let h=`<div class="tag" style="margin-top:10px">Outros jogos da rodada</div>`;
  L.outras.forEach(o=>{
    h+=`<div class="bfLista" style="margin-bottom:8px"><div class="bfDv">${o.nome} · ${S.rodada+1}ª rodada</div>`;
    o.jogos.forEach(g=>{
      const e=g.ev.filter(x=>x.t==='g'||x.t==='c').slice(-1)[0];
      const lance=e?`${e.t==='g'?'⚽':(e.verm?'🟥':'🟨')} ${(e.n||'').split(' ').slice(-1)[0]} ${e.m}' - ${e.m<=45?'1º':'2º'}`:'';
      h+=`<div class="bfJ" onclick="escolhaVerMundo('${g.pais}',${g.div},${g.ia},${g.ib})">
        <span class="bfE">${g.est} | ${Math.round(g.pub/1000)}k</span>
        <div class="bfC" style="--c1:${g.A.cor};--c2:${cor2(g.A)}">${escudo(g.A,15)}<span>${g.A.nome}</span></div>
        <div class="bfS ${g.ga>g.gb?'w':''}">${g.ga}</div><div class="bfS ${g.gb>g.ga?'w':''}">${g.gb}</div>
        <div class="bfC d" style="--c1:${g.B.cor};--c2:${cor2(g.B)}"><span>${g.B.nome}</span>${escudo(g.B,15)}</div>
        <span class="bfL">${lance}</span></div>`;
    });
    h+=`</div>`;
  });
  return h;
}

// ===== CAMPO BONITO + ARRASTE =====

// ===== PÉ DOMINANTE E NÚMERO DA CAMISA (v37) — derivados do id do jogador, sem mexer na geração do elenco =====
function uId(id,sal){let h=2166136261;const t=id+"|"+sal;for(let i=0;i<t.length;i++){h^=t.charCodeAt(i);h=Math.imul(h,16777619)}return((h>>>0)%100000)/100000}
function peDe(j){ // "D" destro · "E" canhoto · "A" ambidestro
  if(j.pe)return j.pe;
  const x=uId(j.id,"pe"),p=j.pos;
  const [d,c]=p==="LE"?[.18,.74]:p==="LD"?[.88,.07]:p==="PE"?[.55,.38]:p==="GOL"?[.90,.10]:[.78,.17];
  return x<d?"D":x<d+c?"E":"A";
}
const PE_NOME={D:"Destro",E:"Canhoto",A:"Ambidestro"};
const NUM_PREF={GOL:[1,12,22,13,25],LD:[2,13,23,22],LE:[6,3,16,26],ZAG:[3,4,5,14,15,13,33,34,44],VOL:[5,8,15,18,16],MEI:[8,10,17,20,21,14],PE:[7,11,19,25,27],ATA:[9,10,11,18,19,99,17]};
const NUM_PRIO={GOL:0,ATA:1,MEI:2,LD:3,LE:4,PE:5,VOL:6,ZAG:7};
// atribui números únicos a um elenco: o mais forte de cada posição escolhe primeiro (goleiro titular = 1, centroavante = 9...)
function atribuiNumeros(c){
  const usados=new Set(),eleSem=[];
  c.elenco.forEach(j=>{if(j.num&&!usados.has(j.num))usados.add(j.num);else eleSem.push(j)});
  eleSem.sort((a,b)=>(NUM_PRIO[a.pos]||9)-(NUM_PRIO[b.pos]||9)||b.f-a.f||uId(a.id,"n")-uId(b.id,"n")).forEach(j=>{
    let n=(NUM_PREF[j.pos]||[]).find(x=>!usados.has(x));
    if(n==null){for(let x=1;x<100;x++)if(!usados.has(x)){n=x;break}}
    usados.add(n);j.num=n;
  });
}
const NUM_SLOT=[1,12,4,14,33,34,2,6,5,15,8,17,20,9,10,11,7,44,21,18,13,3];   // número fixo de cada slot do elenco gerado (a camisa fica no clube)
function numDe(j){return j.num!=null?j.num:""}

function camisaSVG(c,gol,cap,num,kit){
  // uniforme vindo da base de dados (1=principal, 2=reserva, 3=terceiro); goleiro usa cinza sobre a cor do clube
  const KK=kitDe(c,kit);
  const a=gol?"#2b2b2b":KK.c1,b=gol?"#8a8f94":(KK.c2||"#ffffff");
  const claro=x=>{const m=/^#?([0-9a-f]{6})$/i.exec(x||"");if(!m)return false;const n=parseInt(m[1],16);return((n>>16)*299+((n>>8)&255)*587+(n&255)*114)/1000>150};
  const tx=claro(a)&&claro(b)?"#111":(claro(a)?"#111":"#fff");
  const id="s"+Math.random().toString(36).slice(2,7);
  const pat=(KK.pat||"listras");
  const listra=pat==="listras"?[0,1,2,3,4,5].map(k=>`<rect x="${12+k*4.0}" y="8" width="2.0" height="38" fill="${b}"/>`).join("")
    :pat==="metade"?`<rect x="24" y="0" width="24" height="52" fill="${b}"/>`
    :pat==="faixa"?`<rect x="0" y="24" width="48" height="7" fill="${b}"/>`
    :"";
  return `<svg viewBox="0 0 48 52"><defs><clipPath id="${id}"><path d="M17 5 L7 9 L2 20 L10 24 L12 20 L12 47 L36 47 L36 20 L38 24 L46 20 L41 9 L31 5 L24 11Z"/></clipPath></defs>
  <g clip-path="url(#${id})"><rect x="0" y="0" width="48" height="52" fill="${a}"/>${listra}
  <path d="M2 20 L10 24 L12 20 L7 9Z" fill="${a}"/><path d="M46 20 L38 24 L36 20 L41 9Z" fill="${a}"/>
  <rect x="2" y="17" width="9" height="2" fill="${b}" opacity=".9"/><rect x="37" y="17" width="9" height="2" fill="${b}" opacity=".9"/></g>
  <path d="M17 5 L7 9 L2 20 L10 24 L12 20 L12 47 L36 47 L36 20 L38 24 L46 20 L41 9 L31 5 L24 11Z" fill="none" stroke="#0b0b0b" stroke-width="1.6" stroke-linejoin="round"/>
  <path d="M17 5 L24 11 L31 5" fill="none" stroke="#f4f4f4" stroke-width="2.2" stroke-linejoin="round"/>
  ${num!=null&&num!==""?`<text x="24" y="35" text-anchor="middle" font-family="Arial Black,Arial,sans-serif" font-weight="900" font-size="${String(num).length>1?13:15}" fill="${tx}" stroke="${tx==="#fff"?"#000":"#fff"}" stroke-width=".5" paint-order="stroke">${num}</text>`:''}</svg>`;
}
const LINHAS_CAMPO=`<svg class="lines" viewBox="0 0 100 137" preserveAspectRatio="none" fill="none" stroke="#ffffffcc" stroke-width=".6">
<rect x="2" y="2" width="96" height="133"/><line x1="2" y1="68.5" x2="98" y2="68.5"/><circle cx="50" cy="68.5" r="11"/><circle cx="50" cy="68.5" r=".8" fill="#fff"/>
<rect x="24" y="2" width="52" height="20"/><rect x="38" y="2" width="24" height="8"/><path d="M40 22 A11 11 0 0 0 60 22"/>
<rect x="24" y="115" width="52" height="20"/><rect x="38" y="127" width="24" height="8"/><path d="M40 115 A11 11 0 0 1 60 115"/></svg>`;
// pontos recomendados de cada posição (x,y em %) por formação
function slotsRec(form){
  const sl=FORMSLOT[form]||FORMSLOT["4-4-2"];
  return sl.map(x=>({x:x[1],y:x[2],tipo:x[0]==="GOL"?"GOL":ROLE_GRUPO[x[0]],role:x[0]}));
}
function nomeCurto(j){const p=j.nome.split(" ");return p.length>1?p[0][0]+". "+p[p.length-1]:p[0]}

// siglas curtas das habilidades para caber no campo
const HAB_SIGLA={"Finalização":"FIN","Cabeceio":"CAB","Chute longo":"CHL",Velocidade:"VEL",Drible:"DRI",Passe:"PAS","Visão de jogo":"VIS",Cruzamento:"CRZ","Passe longo":"PSL","Saída de bola":"SDB",Desarme:"DES","Marcação":"MAR","Antecipação":"ANT",Reflexos:"REF","Posicionamento":"POS","Jogo aéreo":"AER","Pênaltis":"PEN","Resistência":"RES"};
const sig=h=>HAB_SIGLA[h]||h.slice(0,3).toUpperCase();

// símbolos de cartão para listas: 🟥 suspenso por vermelho · 🟨🟥 suspenso por 3 amarelos · 🟨 / 🟨🟨 amarelos acumulados (1 ou 2 de 3)
function cartaoHTML(j,pequeno){
  const t=[];
  if(j.suspenso>0)t.push(j.motSusp==='A'?'<i class="ct sus" title="Suspenso por 3 amarelos">🟨🟨🟨⛔</i>':'<i class="ct sus" title="Suspenso (vermelho)">🟥⛔</i>');
  else if((j.ac||0)>0)t.push(`<i class="ct am" title="${j.ac} amarelo(s) acumulado(s) — com 3 fica suspenso">${'🟨'.repeat(Math.min(2,j.ac))}</i>`);
  if(j.amarelos>0&&!(j.suspenso>0))t.push('<i class="ct ag" title="Amarelo neste jogo">●</i>');
  return t.join("");
}
function cartaoTexto(j){ // versão curta para o campo da Tática
  if(j.suspenso>0)return j.motSusp==='A'?"⛔3A":"⛔V";
  if((j.ac||0)>0)return "🟨".repeat(Math.min(2,j.ac));
  return "";
}
function habChips(j,curto){ // chips coloridos: ideal=verde, bom=azul, fraco=vermelho
  if(!j.hab)return"";
  return j.hab.map(h=>`<i class="hc ${j.habCat||'bom'}">${curto?sig(h):h}</i>`).join("");
}

function campoHTML(eu,modo){ // modo: 'tat' | 'live'
  posPadrao(eu);
  const tit=eu.elenco.filter(x=>x.tit);
  let h=`<div class="pitch" id="pitch" data-modo="${modo}">${LINHAS_CAMPO}<div id="ghosts"></div>`;
  tit.forEach(j=>{const e=Math.round(j.en==null?100:j.en);
    h+=`<div class="pl ${j.suspenso>0?'susp':''}" data-id="${j.id}" data-t="1" style="left:${j.px}%;top:${j.py}%">${S.cap===j.id?'<span class="cpt">C</span>':''}${cartaoTexto(j)?`<span class="ctc">${cartaoTexto(j)}</span>`:''}${camisaSVG(eu,j.pos==="GOL",false,numDe(j))}<span>${nomeCurto(j)}</span><small>${j.pos} · ${peDe(j)} · F:${j.f} E:${e}%</small><small class="pf">${(j.hab||[]).map(sig).join(' · ')}</small></div>`});
  return h+(modo==='live'&&S.live&&S.live.janela==='lesao'?fantasmaVagaHTML():'')+`</div>`;
}
function bancoHTML(eu){
  const res=eu.elenco.filter(x=>!x.tit&&!x.expulso&&!(S.live&&x.lesao>0)).sort((a,b)=>POS_ORD(a.pos)-POS_ORD(b.pos)||b.f-a.f);   // v62: quem acabou de se machucar não volta para o banco
  return `<div class="bancoF" id="bancoF">`+res.map(j=>{const e=Math.round(j.en==null?100:j.en);return`<div class="bj ${j.lesao>0?'lz':''}" data-id="${j.id}" data-t="0">${cartaoTexto(j)?`<span class="ctc" style="position:absolute;left:3px;top:2px;font-size:10px;background:#000b;border-radius:6px;padding:0 3px">${cartaoTexto(j)}</span>`:''}${camisaSVG(eu,j.pos==="GOL",false,numDe(j))}<span>${nomeCurto(j)}</span><small>${j.pos} · ${peDe(j)} · F:${j.f} E:${e}%${j.lesao>0?' 🤕'+j.lesao+'j':''}</small><small class="pf">${(j.hab||[]).map(sig).join(' · ')}</small></div>`}).join("")+`</div>`;
}
// ----- engine de arraste (Pointer Events) -----
let DR=null;
function ligaArraste(root,live){
  const pitch=root.querySelector("#pitch");if(!pitch)return;
  const eu=S.clubes[S.meu];
  root.querySelectorAll("[data-id]").forEach(el=>{
    el.addEventListener("pointerdown",ev=>{
      if(ev.button&&ev.button!==0)return;
      const id=el.dataset.id,j=eu.elenco.find(x=>x.id===id);if(!j)return;
      if(j.expulso){aviso(j.nome+" foi expulso.");return}
      if(!j.tit&&j.lesao>0){aviso(j.nome+" está lesionado.");return}
      ev.preventDefault();
      DR={id,j,el,titular:!!j.tit,x0:ev.clientX,y0:ev.clientY,moveu:false,live,pitch};
      try{el.setPointerCapture(ev.pointerId)}catch(e){}
    });
    el.addEventListener("pointermove",ev=>{
      if(!DR||DR.el!==el)return;
      const dx=ev.clientX-DR.x0,dy=ev.clientY-DR.y0;
      if(!DR.moveu&&Math.hypot(dx,dy)<6)return;
      if(!DR.moveu){DR.moveu=true;iniciaArraste(ev)}
      moveArraste(ev);
    });
    const fim=ev=>{
      if(!DR||DR.el!==el)return;
      const d=DR;DR=null;
      try{el.releasePointerCapture(ev.pointerId)}catch(e){}
      limpaArraste(d);
      if(d.moveu)soltaArraste(d,ev);else tocaJogador(d);
    };
    el.addEventListener("pointerup",fim);el.addEventListener("pointercancel",e=>{if(DR&&DR.el===el){const d=DR;DR=null;limpaArraste(d)}});
  });
}
function iniciaArraste(ev){
  const d=DR,j=d.j,eu=S.clubes[S.meu];
  d.clone=document.createElement("div");d.clone.className="dragclone";
  d.clone.innerHTML=camisaSVG(eu,j.pos==="GOL",false,numDe(j))+`<div>${nomeCurto(j)}</div>`;
  document.body.appendChild(d.clone);
  d.el.style.opacity=".35";
  // slots recomendados em transparente
  const gh=d.pitch.querySelector("#ghosts");gh.innerHTML="";
  d.slots=slotsRec(S.form).filter(sl=>j.pos==="GOL"?sl.tipo==="GOL":sl.tipo!=="GOL");
  // posição natural recomendada ganha destaque
  d.slots.forEach((sl,i)=>{
    const div=document.createElement("div");div.className="ghost";div.style.left=sl.x+"%";div.style.top=sl.y+"%";div.dataset.i=i;
    div.innerHTML=`<div class="ring"></div>${camisaSVG(eu,j.pos==="GOL")}<span>${sl.role}</span>`;
    gh.appendChild(div);
  });
  if(!d.titular){ // reserva: mostra titulares como alvos de substituição
    d.pitch.querySelectorAll(".pl").forEach(p=>p.classList.add("alvo2"));
  }
  if(d.titular){const b=document.getElementById("bancoF");if(b)b.classList.add("drop")}
}
function moveArraste(ev){
  const d=DR;if(!d||!d.clone)return;
  d.clone.style.left=ev.clientX+"px";d.clone.style.top=ev.clientY+"px";
  const r=d.pitch.getBoundingClientRect();
  const x=(ev.clientX-r.left)/r.width*100,y=(ev.clientY-r.top)/r.height*100;
  d.ult={x,y};
  // destaca slot mais próximo
  let melhor=-1,md=1e9;
  d.slots.forEach((sl,i)=>{const dist=Math.hypot(sl.x-x,(sl.y-y)*1.3);if(dist<md){md=dist;melhor=i}});
  d.pitch.querySelectorAll(".ghost").forEach(g=>g.classList.toggle("perto",md<14&&+g.dataset.i===melhor));
  d.snap=md<14?d.slots[melhor]:null;
  // titular alvo sob o dedo (para troca/substituição)
  d.alvoId=null;
  d.pitch.querySelectorAll(".pl").forEach(p=>{
    if(p.dataset.id===d.id)return;
    const b=p.getBoundingClientRect();
    const dentro=ev.clientX>=b.left&&ev.clientX<=b.right&&ev.clientY>=b.top&&ev.clientY<=b.bottom;
    p.classList.toggle("alvo2",dentro||!d.titular&&true);
    if(dentro)d.alvoId=p.dataset.id;
  });
}
function limpaArraste(d){
  if(d.clone)d.clone.remove();
  if(d.el)d.el.style.opacity="";
  const gh=d.pitch.querySelector("#ghosts");if(gh)gh.innerHTML="";
  d.pitch.querySelectorAll(".pl").forEach(p=>p.classList.remove("alvo2"));
  const b=document.getElementById("bancoF");if(b)b.classList.remove("drop");
}
function soltaArraste(d,ev){
  const eu=S.clubes[S.meu],j=d.j,live=d.live;
  const pr=d.pitch.getBoundingClientRect();
  const dentroCampo=ev.clientX>=pr.left&&ev.clientX<=pr.right&&ev.clientY>=pr.top&&ev.clientY<=pr.bottom;
  const banco=document.getElementById("bancoF");
  let sobreBanco=false;
  if(banco){const b=banco.getBoundingClientRect();sobreBanco=ev.clientX>=b.left&&ev.clientX<=b.right&&ev.clientY>=b.top&&ev.clientY<=b.bottom}
  const re=()=>live?renderLive():render();
  if(d.titular){
    if(sobreBanco||!dentroCampo){ // titular solto no banco => precisa de um reserva (escolhe o melhor da mesma posição)
      return aviso("Arraste um reserva para cima do titular para trocar.");
    }
    if(d.alvoId){ // troca de lugar entre titulares
      const o=eu.elenco.find(x=>x.id===d.alvoId);
      if(!o)return re();
      if((j.pos==="GOL")!==(o.pos==="GOL"))return aviso("Goleiro só troca com goleiro.");
      const px=j.px,py=j.py;j.px=o.px;j.py=o.py;o.px=px;o.py=py;j._g=grupoPos(j);o._g=grupoPos(o);
      save();return re();
    }
    const alvo=d.snap||{x:d.ult.x,y:d.ult.y};
    return moverPara(j.id,alvo.x,alvo.y,live);
  }
  // reserva arrastado
  if(!dentroCampo)return;
  if(d.alvoId){
    const sai=eu.elenco.find(x=>x.id===d.alvoId);
    if(!sai)return re();
    if((j.pos==="GOL")!==(sai.pos==="GOL"))return aviso("Goleiro só entra no lugar de goleiro.");
    if(live)return subDireta(sai.id,j.id);
    j.px=sai.px;j.py=sai.py;j._g=grupoPos(j);j.tit=true;sai.tit=false;
    if(S.cap===sai.id)S.cap=j.id;
    save();return re();
  }
  aviso("Solte o reserva em cima de um titular para trocar.");
}

let TOQ=null; // jogador selecionado por toque

function preencheVagaLesao(sai,entra){
  const eu=S.clubes[S.meu],L=S.live;
  entra.px=sai.px;entra.py=sai.py;entra._g=grupoPos(entra);entra._slot=sai._slot;entra._role=sai._role;entra.tit=true;
  sai.lesionadoJogo=false;fechaVagaLesao(sai.id);
  if(S.cap===sai.id)S.cap=entra.id;
  const jg=L.jogos.find(g=>g.a===S.meu||g.b===S.meu);
  if(jg){const lado=jg.a===S.meu?"a":"b";
    jg.ev.push({m:L.min,t:"s",lado,n:entra.nome+" ↔ "+sai.nome,les:true});
    jg.subs.push({m:L.min,lado,entra:entra.id,sai:sai.id,en:entra.nome,sn:sai.nome,ep:entra.pos,les:true});}
  S.selId=null;TOQ=null;
  const aindaTem=vagasLesaoAbertas().length>0;
  if(!aindaTem){fechaJanelaEscala()}else renderJanela();
}

function tocaJogador(d){
  const eu=S.clubes[S.meu],j=d.j,live=d.live,re=()=>live?renderLive():render();
  // vaga aberta por lesão: tocar em um reserva dá a vaga a ele (não gasta substituição)
  if(live&&!j.tit&&S.live&&S.live.janela==="lesao"){
    const vaga=vagasLesaoAbertas().find(v=>(v.pos==="GOL")===(j.pos==="GOL"))||vagasLesaoAbertas()[0];
    if(vaga){
      if(j.lesao>0||j.expulso||j.suspenso>0){marcaToque();return aviso(j.nome+" não pode jogar.")}
      if((vaga.pos==="GOL")!==(j.pos==="GOL")){marcaToque();return aviso("A vaga é de "+(vaga.pos==="GOL"?"goleiro":"linha")+": escolha um "+(vaga.pos==="GOL"?"goleiro":"jogador de linha")+".")}
      preencheVagaLesao(vaga,j);TOQ=null;return;
    }
  }
  if(!TOQ){TOQ=j.id;marcaToque();return}
  if(TOQ===j.id){TOQ=null;marcaToque();return}
  const a=eu.elenco.find(x=>x.id===TOQ),b=j;
  if(a.tit===b.tit){TOQ=j.id;marcaToque();return}
  const sai=a.tit?a:b,ent=a.tit?b:a;TOQ=null;
  if(!aptoParaJogar(ent)){marcaToque();return aviso(ent.nome+" não pode jogar: "+motivoInapto(ent)+".")}
  if((sai.pos==="GOL")!==(ent.pos==="GOL")){marcaToque();return aviso("Goleiro só troca com goleiro.")}
  if(live)return subDireta(sai.id,ent.id);
  ent.px=sai.px;ent.py=sai.py;ent._g=grupoPos(ent);ent._slot=sai._slot;ent._role=sai._role;ent.tit=true;sai.tit=false;
  if(S.cap===sai.id)S.cap=ent.id;
  save();re();
}
function marcaToque(){
  document.querySelectorAll("[data-id]").forEach(el=>el.classList.toggle("tq",el.dataset.id===TOQ));
  const h=document.getElementById("dicaToque");if(h)h.textContent=TOQ?"Agora toque no jogador que vai trocar (titular ↔ reserva).":"Toque num titular e num reserva para substituir. Arraste para mover de posição.";
}
// Seleção automática: só troca jogadores, mantém posições
function autoMantendoPosicoes(){
  const eu=S.clubes[S.meu];
  const titulares=eu.elenco.filter(x=>x.tit);
  let trocas=0;
  titulares.forEach(t=>{
    const pool=eu.elenco.filter(x=>!x.tit&&x.lesao<=0&&x.pos===t.pos);
    // melhor da MESMA posição, por força efetiva (considera energia)
    const fe0=x=>x.f*(0.7+0.3*(x.en==null?100:x.en)/100);
    const atual=t.lesao>0?-1:fe0(t);
    const melhor=pool.sort((a,b)=>fe0(b)-fe0(a))[0];
    if(melhor&&fe0(melhor)>atual+0.001){
      melhor.px=t.px;melhor.py=t.py;melhor._g=grupoPos(melhor);melhor._slot=t._slot;melhor._role=t._role;melhor.tit=true;t.tit=false;
      if(S.cap===t.id)S.cap=melhor.id;trocas++;
    }
  });
  return trocas;
}
function autoBotao(live){
  const n=autoMantendoPosicoes();
  save();
  if(!n)aviso("Os melhores jogadores de cada posição já estão em campo.");
  live?renderLive():render();
}
function posRender(){ // chamado depois de cada render
  TOQ=null;
  const root=document.getElementById("app");
  if(S&&S.aba==="tat")ligaArraste(root,false);
  const jn=document.getElementById("janelaEscala");if(jn&&S.live&&S.live.janela)ligaArraste(jn,true);
}


function golFx(texto){
  const d=document.createElement("div");d.className="golfx";d.textContent=texto||"GOOOL!";document.body.appendChild(d);
  setTimeout(()=>d.remove(),2300);
}
function toast(t){const d=document.createElement("div");d.className="toast";d.textContent=t;document.body.appendChild(d);setTimeout(()=>d.remove(),2400)}
function registraForma(res){if(!S.forma)S.forma=[];S.forma.push(res);if(S.forma.length>5)S.forma.shift()}


// ===== RESULTADOS DE OUTRAS LIGAS (pós-jogo) =====
function golsPois(l){let L=Math.exp(-l),k=0,p=1;do{k++;p*=R()}while(p>L);return k-1}
function simRapido(fa,fb){
  const ma=Math.max(.25,(fa-fb)/22+1.35),mb=Math.max(.25,(fb-fa)/22+1.0);
  return [golsPois(ma),golsPois(mb)];
}
function resultadosPais(pais){ // resultados das 3 divisões de um país: usa os placares REAIS da última rodada jogada
  const out=[];
  (LIGAS[pais]||[]).forEach((divFixa,dv)=>{
    const div=(pais===S.pais&&S.divAtual)?clubesDaDivisao(pais,dv):divFixa;
    const L=S.ligas&&S.ligas[chaveLiga(pais,dv)];
    let jogos=[];
    if(L&&L.ultimos&&L.ultimos.length){
      jogos=L.ultimos.map(([ia,ib,ga,gb])=>{
        const na=L.nomes[ia],nb=L.nomes[ib];const ca=infoCor(pais,na),cb=infoCor(pais,nb);
        return{a:na,b:nb,ca:ca.cor,cb:cb.cor,c2a:ca.cor2,c2b:cb.cor2,ga,gb};
      });
    }else if(!(L)){                                  // minha divisão, ou antes da 1ª rodada: sorteio de reserva
      const idx=div.map((_,i)=>i).sort(()=>R()-.5),base=[70,60,52][dv]||50;
      for(let i=0;i+1<idx.length;i+=2){
        const a=div[idx[i]],b=div[idx[i+1]];
        const [ga,gb]=simRapido(base+rnd(-10,12),base+rnd(-10,12));
        jogos.push({a:a[0],b:b[0],ca:a[2],cb:b[2],c2a:a[3],c2b:b[3],ga,gb});
      }
    }
    out.push({div:dv,nome:LIGANOME[pais][dv],jogos});
  });
  return out;
}
function guardaResultados(){ // chamado no fim da partida; usa os jogos reais da minha liga
  const L=S.live;
  const minha=[];
  L.jogos.forEach(j=>{const a=S.clubes[j.a],b=S.clubes[j.b];minha.push({a:a.nome,b:b.nome,ca:a.cor,cb:b.cor,c2a:a.cor2,c2b:b.cor2,ga:j.ga,gb:j.gb,meu:(j.a===S.meu||j.b===S.meu)})});
  const outras={};
  Object.keys(LIGAS).forEach(pa=>{
    if(pa===S.pais){ // minha liga: usa os placares reais para a minha divisão e simula as demais
      const r=resultadosPais(pa);
      r[S.div]={div:S.div,nome:LIGANOME[pa][S.div],jogos:minha};
      outras[pa]=r;
    }else outras[pa]=resultadosPais(pa);
  });
  S.resultados={rodada:S.rodada+1,pais:S.pais,dados:outras};
  S.filtroPais=S.pais;
}


// ===== UEFA CHAMPIONS LEAGUE (formato novo) =====
const CL_VAGAS={"Inglaterra": 5, "Espanha": 5, "Itália": 5, "Alemanha": 5, "França": 4, "Portugal": 3, "Holanda": 3, "Bélgica": 2, "Turquia": 1, "Escócia": 1, "Rússia": 2};
const CL_PAISES=Object.keys(CL_VAGAS);
function clCriaClube(nome,sig,cor,cor2,forca,pais,real,idLocal){
  return{k:pais+"|"+nome,nome,sig,cor,cor2,pais,forca,real:real,idLocal:idLocal,pts:0,j:0,v:0,e:0,d:0,gp:0,gc:0};
}
// monta os 36 participantes (os do meu país vêm da tabela real da minha liga)
function clParticipantes(){
  const lista=[];
  CL_PAISES.forEach(pa=>{
    const n=CL_VAGAS[pa];
    let ordem;
    if(pa===S.pais){
      const fonte=fontePrimeiraDiv();
      ordem=aplicaVagaCopa(fonte,n,VAGA_COPA[pa]==="cl"?campeaoCopaDe(pa):null);
    }else{
      const classif=classificacaoMundo(pa,0);
      ordem=aplicaVagaCopa(classif,n,VAGA_COPA[pa]==="cl"?campeaoCopaDe(pa):null);
    }
    ordem.forEach((c,i)=>{const fz=forcaPart(c,pa,0);const o=clCriaClube(c.nome,c.sig,c.cor,c.cor2,fz,pa,c.id!==null&&c.id!==undefined,c.id);o.div=0;o.idxMundo=c.idx;if(c.pelaCopa)o.pelaCopa=true;lista.push(o)});
  });
  return lista.slice(0,36);
}
function mdc(a,b){return b?mdc(b,a%b):a}
function clConstroiCalendario(n){ // n=36: 8 rodadas, 8 adversários distintos, 4 em casa e 4 fora por clube
  const perm=[...Array(n).keys()].sort(()=>R()-.5);
  const cand=[];for(let d=1;d<n/2;d++)if((n/mdc(n,d))%2===0)cand.push(d);
  const ds=cand.sort(()=>R()-.5).slice(0,4);
  const rod=[];
  ds.forEach(d=>{
    const g=mdc(n,d),L=n/g,m=[[],[]];
    for(let st=0;st<g;st++){let i=st;for(let k=0;k<L;k++){const b=(i+d)%n;m[k%2].push([perm[i],perm[b]]);i=b}}
    rod.push(m[0]);rod.push(m[1]);
  });
  return rod;
}
function clInicia(){
  const parts=clParticipantes();
  while(parts.length<36){const q=parts.length;parts.push(clCriaClube("Clube "+(q+1),"C"+(q+1),"#445566","#ffffff",66,"Europa",false,null))}
  // ordena por força para o sorteio ficar equilibrado, mas o calendário é aleatório
  S.cl={temp:S.temp,fase:"liga",rodada:0,parts,cal:clConstroiCalendario(parts.length),eliminatoria:null,campeao:null,meu:parts.findIndex(c=>ehMeuClube(c)),hist:[]};
  S.cl.jogouHoje=false;
}
function clSouParticipante(){return S.cl&&S.cl.meu>=0}
// calendário intercalado: a cada 4 rodadas da liga (a partir da 4ª) tem um jogo da Champions
function datasCopa(T,N,iniPct,fimPct){ // N datas estritamente crescentes entre iniPct e fimPct do campeonato (1..T-1)
  const ini=Math.max(1,Math.round(T*iniPct)),fim=Math.max(ini+N-1,Math.min(T-1,Math.round(T*(fimPct||1)))),d=[];
  for(let k=0;k<N;k++){let r=N>1?Math.round(ini+(fim-ini)*k/(N-1)):ini;if(k>0&&r<=d[k-1])r=d[k-1]+1;d.push(r)}
  for(let k=N-1;k>=0;k--){const lim=T-1-(N-1-k);if(d[k]>lim)d[k]=lim}
  for(let k=1;k<N;k++)if(d[k]<=d[k-1])d[k]=d[k-1]+1;
  return d;
}
function clDatas(){ // 8 da fase de liga + repescagem, oitavas, quartas, semi, final = 13 datas
  const d=datasCopa(S.fixt.length,13,.08,.98);
  return{liga:d.slice(0,8),ko:{repescagem:d[8],oitavas:d[9],quartas:d[10],semi:d[11],final:d[12]}};
}
function clProximaData(){return agendaHoje()==="cl"&&S.cl&&!(S.cl.fase==="fim"||S.cl.nomeFase==="fim")?"hoje":null}
function clMeusJogos(){ // jogos do meu clube nesta data
  const c=S.cl;if(!c||c.meu<0)return null;
  if(c.fase==="liga")return (c.cal[c.rodada]||[]).find(g=>g[0]===c.meu||g[1]===c.meu)||null;
  const e=c.eliminatoria;if(!e)return null;
  return e.jogos.find(g=>g[0]===c.meu||g[1]===c.meu)||null;
}
// simulação rápida de um confronto
function clSimula(ia,ib){
  const A=S.cl.parts[ia],B=S.cl.parts[ib];
  const [ga,gb]=simRapido(A.forca+3,B.forca);
  return{ga,gb};
}
function clAplica(ia,ib,ga,gb){
  const A=S.cl.parts[ia],B=S.cl.parts[ib];
  A.j++;B.j++;A.gp+=ga;A.gc+=gb;B.gp+=gb;B.gc+=ga;
  if(ga>gb){A.v++;B.d++;A.pts+=3}else if(ga<gb){B.v++;A.d++;B.pts+=3}else{A.e++;B.e++;A.pts++;B.pts++}
}
function clTabela(){
  return S.cl.parts.map((c,i)=>({...c,i})).sort((a,b)=>b.pts-a.pts||(b.gp-b.gc)-(a.gp-a.gc)||b.gp-a.gp);
}
function clJogaRodadaLiga(meuRes){ // meuRes: placar do meu jogo (ou null)
  const c=S.cl,jogos=c.cal[c.rodada]||[];
  const resultados=[];
  jogos.forEach(([a,b])=>{
    let ga,gb;
    if(meuRes&&((a===c.meu&&b===meuRes.adv)||(b===c.meu&&a===meuRes.adv))){
      ga=a===c.meu?meuRes.g1:meuRes.g2;gb=a===c.meu?meuRes.g2:meuRes.g1;
    }else{const pre=(S._clPre||[]).find(x=>x[0]===a&&x[1]===b);if(pre){ga=pre[2];gb=pre[3]}else{const r=clSimula(a,b);ga=r.ga;gb=r.gb}}
    clAplica(a,b,ga,gb);resultados.push({a,b,ga,gb,meu:(a===c.meu||b===c.meu)});
  });
  S._clPre=null;c.ultimosRes=resultados;c.rodada++;
  if(c.rodada>=8)clFimLiga();
  return resultados;
}
function clFimLiga(){
  const t=clTabela();
  S.cl.fase="repescagem";
  const direto=t.slice(0,8).map(x=>x.i),rep=t.slice(8,24).map(x=>x.i);
  S.cl.diretos=direto;S.cl.elim=t.slice(24).map(x=>x.i);
  // repescagem: 9º-16º (cabeças) x 17º-24º, jogo único
  const cab=rep.slice(0,8),cau=rep.slice(8);
  const jogos=cab.map((a,i)=>[a,cau[7-i]]);
  S.cl.eliminatoria={jogos,pendente:true,resultados:[]};
}
function clJogaMataMata(meuRes){
  const c=S.cl,e=c.eliminatoria;if(!e)return[];
  const res=[],venc=[];
  e.jogos.forEach(([a,b])=>{
    let ga,gb;
    if(meuRes&&((a===c.meu&&b===meuRes.adv)||(b===c.meu&&a===meuRes.adv))){ga=a===c.meu?meuRes.g1:meuRes.g2;gb=a===c.meu?meuRes.g2:meuRes.g1}
    else{const pre=(S._clPre||[]).find(x=>x[0]===a&&x[1]===b);if(pre){ga=pre[2];gb=pre[3]}else{const r=clSimula(a,b);ga=r.ga;gb=r.gb}}
    let w=ga>gb?a:gb>ga?b:null,pen="";
    if(w===null){ // prorrogação/pênaltis
      const pa=S.cl.parts[a].forca/(S.cl.parts[a].forca+S.cl.parts[b].forca);
      w=R()<pa?a:b;pen=" (pên.)";
    }
    venc.push(w);res.push({a,b,ga,gb,w,pen,meu:(a===c.meu||b===c.meu)});
  });
  e.resultados=res;e.pendente=false;c.ultimosRes=res;
  const prox={"repescagem":"oitavas","oitavas":"quartas","quartas":"semi","semi":"final"}[c.fase];
  if(c.fase==="final"){c.campeao=venc[0];c.fase="fim";
    const cam=c.parts[venc[0]];c.hist.push({temp:c.temp,campeao:cam.nome,pais:cam.pais});
    const kh=c.chaveHist||'clHist';S[kh]=(S[kh]||[]);S[kh].push({temp:S.temp,campeao:cam.nome,pais:cam.pais});
    return res}
  if(c.fase==="repescagem"){
    // oitavas: 8 diretos x 8 vencedores (1º-8º jogam contra vencedores)
    const dir=c.diretos,vs=venc;
    const jogos=dir.map((a,i)=>[a,vs[7-i]]);
    c.fase="oitavas";c.eliminatoria={jogos,pendente:true,resultados:[]};
  }else{
    const jogos=[];for(let i=0;i<venc.length;i+=2)jogos.push([venc[i],venc[i+1]]);
    c.fase=prox;c.eliminatoria={jogos,pendente:true,resultados:[]};
  }
  // eliminados da repescagem/mata-mata ficam registrados
  return res;
}
// ----- Interação com o jogo ao vivo: meu jogo da Champions usa a tela ao vivo com clubes temporários -----
function clCriaClubeJogavel(pt){return clubeParaJogo(pt)}
function clComecaMeuJogo(){
  const c=S.cl,g=clMeusJogos();if(!g)return aviso("Seu clube não joga nesta rodada da Champions.");
  const ia=g[0],ib=g[1];
  const PA=c.parts[ia],PB=c.parts[ib];
  const CA=clCriaClubeJogavel(PA),CB=clCriaClubeJogavel(PB);
  // monta um mini-universo: usa S.clubes temporariamente
  const bak={clubes:S.clubes,meu:S.meu,fixt:S.fixt,rodada:S.rodada,ids:S.clubes.map(c=>c.id)};
  S._clbak=bak;
  const meuEhA=ia===c.meu;
  // índices 0 e 1 no mini-universo
  S.clubes=[CA,CB];CA.id=0;CB.id=1;
  S.meu=meuEhA?0:1;
  S.fixt=[[[0,1]]];S.rodada=0;
  S.clAoVivo={ia,ib,meuEhA};
  // garante estádio e elencos prontos
  est(CA);est(CB);
  if(criaLive()===false)return;
  S.live.outras=[];S.live.emCL=true;S.live.tela="lista";
  S.aba="live";render();somApito();playLive();
}


function fimLiveCL(){
  const L=S.live,j=L.jogos[0],ai=S.clAoVivo,eu=S.clubes[S.meu];
  S.pos=posJogo(j);S.pos.tituloCompleto=clTituloFase();
  guardaResultadosCL();
  // restaura o universo da liga
  const bak=S._clbak;
  const meuClube=eu;
  S.clubes=bak.clubes;S.meu=bak.meu;S.fixt=bak.fixt;S.rodada=bak.rodada;S._clbak=null;if(bak.ids)S.clubes.forEach((c,i)=>{c.id=bak.ids[i]});S.clAoVivo=null;
  // os dois lados no sistema da liga: meu clube mantém a mesma instância (energia/lesão/gols já aplicados)
  // desgaste do jogo
  const rest=S.clubes[S.meu];
  registraNotasDoPos(rest,ai.meuEhA);energiaPosJogo(rest,true);
  rest.elenco.forEach(x=>{if(x.lesao>0)x.tit=false});try{garante11(rest,true)}catch(e){}
  // renda do jogo em casa
  const casa=ai.meuEhA;
  if(casa&&S.pos)recebeBilheteria('cl',1.4);
  // lança o resultado no módulo da Champions
  const g1=ai.meuEhA?j.ga:j.gb,g2=ai.meuEhA?j.gb:j.ga;
  try{premiaJogo('cl',g1>g2?1:g1===g2?0:-1,S.cl&&S.cl.fase);if(S.cl&&S.cl.fase){premiaFase('cl',S.cl.fase)}}catch(e){}
  const advIdx=ai.meuEhA?ai.ib:ai.ia;
  const c=S.cl,eliminatoria=c.fase!=="liga";
  S.clUltimo={ga:j.ga,gb:j.gb,a:c.parts[ai.ia].nome,b:c.parts[ai.ib].nome};
  limpaPartidaEstado();S.live=null;S.aba=S.pos?"pos":"home";S.subs=0;fechaDataCopa(ai,g1,g2);
  const meuRes={adv:advIdx,g1,g2};
  if(eliminatoria)clJogaMataMata(meuRes);else clJogaRodadaLiga(meuRes);
  if(S.cl.fase==="fim")clFimCampanha();
  registraForma(g1>g2?'V':g1===g2?'E':'D');
  save();render();
}
function guardaResultadosCL(){
  const L=S.live,j=L.jogos[0],c=S.cl,ai=S.clAoVivo;
  const meuJ={a:c.parts[ai.ia].nome,b:c.parts[ai.ib].nome,ca:c.parts[ai.ia].cor,cb:c.parts[ai.ib].cor,ga:j.ga,gb:j.gb,meu:true};
  const todos=(c.fase==="liga"?(c.cal[c.rodada]||[]):(c.eliminatoria?c.eliminatoria.jogos:[])).filter(g=>!(g[0]===ai.ia&&g[1]===ai.ib));
  const outros=todos.map(g=>{const r=clSimula(g[0],g[1]);return{a:c.parts[g[0]].nome,b:c.parts[g[1]].nome,ca:c.parts[g[0]].cor,cb:c.parts[g[1]].cor,ga:r.ga,gb:r.gb,pre:[g[0],g[1],r.ga,r.gb]}});
  S._clPre=outros.map(o=>o.pre);
  const dados={};
  Object.keys(LIGAS).forEach(pa=>{dados[pa]=resultadosPais(pa)});
  dados["Champions League"]=[{div:0,nome:clTituloFase(),jogos:[meuJ,...outros]}];
  S.resultados={rodada:S.rodada+1,pais:"Champions League",dados};
  S.filtroPais="Champions League";
}
function clTituloFase(){
  const f=S.cl.fase;
  if(f==="liga")return"Champions League · Fase de liga · Rodada "+(S.cl.rodada+1)+"/8";
  const nome={repescagem:"Repescagem",oitavas:"Oitavas de final",quartas:"Quartas de final",semi:"Semifinal",final:"Final"}[f]||f;
  return"Champions League · "+nome;
}
function clFimCampanha(){
  const c=S.cl,cam=c.parts[c.campeao];
  aviso("🏆 "+cam.nome+" ("+cam.pais+") é o campeão da Champions League!");
}
// --- jogar a Champions sem o meu clube (simulação) ---
function clSimulaData(){
  const c=S.cl;
  if(c.fase==="liga")clJogaRodadaLiga(null);
  else{ clJogaMataMata(null); if(c.fase==="fim")clFimCampanha(); }
}


function abaCL(chave,nomeLiga,nomeLongo){
  chave=chave||"clAba";nomeLiga=nomeLiga||"Champions League";nomeLongo=nomeLongo||"UEFA Champions League";
  if(!S.cl)return`<div class='card'>A ${nomeLiga} começa na próxima temporada.</div>`;
  const c=S.cl,sou=c.meu>=0;
  const aba=S[chave]||"tabela";
  let h=`<div class="hd"><div class="top"><b>🏆 ${nomeLongo}</b><span>${c.fase==="fim"?"Encerrada":clTituloFase().replace("Champions League · ","")}</span></div></div>`;
  h+=`<div class="row" style="margin:8px 0"><button class="${aba==='tabela'?'':'s'} sm" onclick="setAba('${chave}','tabela')">Tabela</button><button class="${aba==='jogos'?'':'s'} sm" onclick="setAba('${chave}','jogos')">Jogos</button><button class="${aba==='ko'?'':'s'} sm" onclick="setAba('${chave}','ko')">Mata-mata</button><button class="${aba==='hist'?'':'s'} sm" onclick="setAba('${chave}','hist')">Histórico</button></div>`;
  const nome=i=>{const x=c.parts[i];return`${escudo(x,14)} ${x.nome}`};
  if(aba==="tabela"){
    const t=clTabela();
    h+=`<div class="card"><div class="tag">Fase de liga · 36 clubes · 8 jogos cada</div><table style="margin-top:6px"><tr><th>#</th><th>Clube</th><th>P</th><th>J</th><th>SG</th></tr>`;
    t.forEach((x,i)=>{const cor=i<8?'#1e5a2b':i<24?'#4a4a12':'#4a1a1a';
      h+=`<tr style="background:${x.i===c.meu?'#245a3f':''}"><td style="border-left:3px solid ${i<8?'#34d98b':i<24?'#ffc83d':'#ff5d6c'};padding-left:4px">${i+1}</td><td>${escudo(x,14)} ${x.nome}${x.pelaCopa?' 🏅':''} <small class="mu">${x.sig}·${x.pais.slice(0,3).toUpperCase()}</small></td><td><b>${x.pts}</b></td><td>${x.j}</td><td>${x.gp-x.gc}</td></tr>`});
    h+=`</table><small class="mu">Verde: oitavas direto (1º-8º) · Amarelo: repescagem (9º-24º) · Vermelho: eliminados · 🏅 vaga pela Copa nacional</small></div>`;
  }else if(aba==="jogos"){
    h+=`<div class="card"><h3>${c.fase==="liga"?"Rodada "+Math.min(c.rodada+1,8):"Confrontos"}</h3>`;
    const lista=c.fase==="liga"?(c.cal[Math.min(c.rodada,7)]||[]):(c.eliminatoria?c.eliminatoria.jogos:[]);
    h+=lista.map(([a,b])=>`<div class="row" style="padding:5px 0;border-top:1px solid var(--bd);${(a===c.meu||b===c.meu)?'background:#245a3f66;':''}"><span>${nome(a)}</span><b>x</b><span>${nome(b)}</span></div>`).join("")||"<div class='mu'>Sem jogos.</div>";
    h+=`</div>`;
    if(c.ultimosRes&&c.ultimosRes.length){
      h+=`<div class="card"><h3>Últimos resultados</h3>`+c.ultimosRes.map(r=>`<div class="row" style="padding:4px 0;border-top:1px solid var(--bd)"><span style="font-size:12px">${nome(r.a)}</span><b>${r.ga} x ${r.gb}${r.pen||""}</b><span style="font-size:12px">${nome(r.b)}</span></div>`).join("")+`</div>`;
    }
  }else if(aba==="ko"){
    if(!c.eliminatoria){h+=`<div class="card">O mata-mata começa depois da fase de liga.</div>`}
    else{
      const lista=c.eliminatoria.jogos;
      h+=`<div class="card"><h3>${({repescagem:"Repescagem",oitavas:"Oitavas",quartas:"Quartas",semi:"Semifinais",final:"Final"})[c.fase]||"Mata-mata"}</h3>`+lista.map(([a,b])=>`<div class="row" style="padding:6px 0;border-top:1px solid var(--bd);${(a===c.meu||b===c.meu)?'background:#245a3f66;':''}"><span>${nome(a)}</span><b>x</b><span>${nome(b)}</span></div>`).join("")+`</div>`;
    }
  }else{
    h+=`<div class="card"><h3>Campeões</h3>${(S[c.chaveHist||'clHist']||[]).map(x=>`<div class="ln2 row"><span>Temp. ${x.temp}</span><b>🏆 ${x.campeao} (${x.pais})</b></div>`).join("")||"<div class='mu'>Nenhuma edição concluída.</div>"}</div>`;
  }
  // ação
  const prox=clProximaData();
  if(sou&&c.fase!=="fim"){
    h+=`<div class="card"><b>Seu clube está na ${nomeLiga}.</b><div class="mu" style="font-size:12px">${prox?'Próximo jogo na próxima data do calendário.':'Aguarde a próxima data: a ${nomeLiga} é jogada entre as rodadas da liga.'}</div></div>`;
  }else if(!sou){
    h+=`<div class="card mu">Seu clube não está na ${nomeLiga} nesta temporada. Termine entre os primeiros do seu campeonato para jogar a próxima.</div>`;
  }
  return h;
}


function lbMontaTemporada(){S.lb=null;try{lbInicia()}catch(e){S.lb=null}}
function clMontaTemporada(){
  // usa a classificação final da temporada anterior (já em S.hist) -> a lista de classificados é montada com a tabela atual
  // Em S.cl só para quem joga a 1ª divisão em país europeu; para os demais, a Champions existe como espectador.
  S.cl=null;
  clInicia();
}


// ===== COPA LIBERTADORES (32 clubes · 8 grupos de 4 · mata-mata ida e volta · final única) =====
const LB_VAGAS={"Brasil": 7, "Argentina": 6, "Colômbia": 3, "Chile": 3, "Uruguai": 3};
const LB_EXTRA={"Paraguai": [3, ["Olimpia", "Cerro Porteño", "Libertad", "Guaraní", "Nacional (PAR)", "Sol de América"], "#111111", "#ffffff"], "Equador": [3, ["LDU Quito", "Barcelona SC", "Independiente del Valle", "Emelec", "Aucas", "El Nacional"], "#1e3a8a", "#ffffff"], "Peru": [2, ["Universitario", "Alianza Lima", "Sporting Cristal", "Melgar", "Cusco FC"], "#7a1d1d", "#ffffff"], "Bolívia": [1, ["Bolívar", "The Strongest", "Always Ready", "Blooming"], "#0d6b9e", "#ffffff"], "Venezuela": [1, ["Caracas FC", "Deportivo Táchira", "Carabobo", "Monagas"], "#8e1b2b", "#f5c542"]};
const LB_FORCA={Brasil:80,Argentina:78,Colômbia:70,Chile:68,Uruguai:68,Paraguai:64,Equador:64,Peru:60,Bolívia:58,Venezuela:56};
function lbSigla(n){const w=n.split(/[\s\-\.]+/).filter(Boolean);return(w.length>=2?w[0][0]+w[1][0]+(w[2]?w[2][0]:w[1][1]||""):w[0].slice(0,3)).toUpperCase().slice(0,3)}
function lbParticipantes(){
  const L=[];
  Object.keys(LB_VAGAS).forEach(pa=>{
    const n=LB_VAGAS[pa];let ordem;
    if(pa===S.pais){
      const fonte=fontePrimeiraDiv();
      ordem=aplicaVagaCopa(fonte,n,VAGA_COPA[pa]==="lb"?campeaoCopaDe(pa):null);
    }else{
      const classif=classificacaoMundo(pa,0);
      ordem=aplicaVagaCopa(classif,n,VAGA_COPA[pa]==="lb"?campeaoCopaDe(pa):null);
    }
    ordem.forEach((c,i)=>{const o=clCriaClube(c.nome,c.sig,c.cor,c.cor2,forcaPart(c,pa,0),pa,c.id!==null&&c.id!==undefined,c.id);o.div=0;o.idxMundo=c.idx;if(c.pelaCopa)o.pelaCopa=true;L.push(o)});
  });
  Object.keys(LB_EXTRA).forEach(pa=>{
    const [n,nomes,c1,c2]=LB_EXTRA[pa];
    const rgx=rngClube('lbx|'+pa+'|'+S.temp);[...nomes].map(x=>({x,r:rgx()})).sort((a,b)=>a.r-b.r).map(o=>o.x).slice(0,n).forEach((nome,i)=>L.push(clCriaClube(nome,lbSigla(nome),c1,c2,forcaGerado(nome,pa),pa,false,null)));
  });
  return L.slice(0,32);
}
function lbInicia(){
  const parts=lbParticipantes();
  // potes por força: 8 grupos de 4 (1 de cada pote)
  const ord=parts.map((c,i)=>i).sort((a,b)=>parts[b].forca-parts[a].forca);
  const potes=[0,1,2,3].map(k=>ord.slice(k*8,k*8+8).sort(()=>R()-.5));
  const grupos=[];
  for(let g=0;g<8;g++){
    const gr=[potes[0][g],potes[1][g],potes[2][g],potes[3][g]];
    // evita 2 clubes do mesmo país no grupo quando possível
    grupos.push(gr);
  }
  // calendário do grupo: 6 rodadas (turno e returno)
  const rod=[[[0,3],[1,2]],[[0,2],[3,1]],[[0,1],[2,3]]];
  const cal=[];
  rod.forEach(r=>cal.push(r));
  rod.forEach(r=>cal.push(r.map(([a,b])=>[b,a])));
  S.lb={temp:S.temp,fase:"grupos",rodada:0,parts,grupos,cal,eliminatoria:null,campeao:null,jogouHoje:false,
        meu:parts.findIndex(c=>ehMeuClube(c)),hist:[],pernas:1};
}
function lbSouParticipante(){return S.lb&&S.lb.meu>=0}
function lbDatas(){
  const T=S.fixt.length,d=datasCopa(T,13,.10,.82);
  return{grupos:d.slice(0,6),ko:{oitavas:d[6],quartas:d[8],semi:d[10],final:d[12]},volta:{oitavas:d[7],quartas:d[9],semi:d[11]}};
}
function lbProximaData(){return agendaHoje()==="lb"&&S.lb&&!(S.lb.fase==="fim"||S.lb.nomeFase==="fim")?"hoje":null}
function lbJogosDaData(){ // lista de confrontos [a,b] da data atual (índices em parts)
  const c=S.lb;
  if(c.fase==="grupos"){const out=[];c.grupos.forEach(gr=>{(c.cal[c.rodada]||[]).forEach(([x,y])=>out.push([gr[x],gr[y]]))});return out}
  const e=c.eliminatoria;if(!e)return[];
  return e.jogos.map(j=>[e.perna===1?j[0]:j[1],e.perna===1?j[1]:j[0]]);
}
function lbMeuJogo(){const c=S.lb;if(!c||c.meu<0)return null;return lbJogosDaData().find(g=>g[0]===c.meu||g[1]===c.meu)||null}
function lbSimula(ia,ib){const A=S.lb.parts[ia],B=S.lb.parts[ib];const [ga,gb]=simRapido(A.forca+3,B.forca);return{ga,gb}}
function lbAplica(ia,ib,ga,gb){
  const A=S.lb.parts[ia],B=S.lb.parts[ib];
  A.j++;B.j++;A.gp+=ga;A.gc+=gb;B.gp+=gb;B.gc+=ga;
  if(ga>gb){A.v++;B.d++;A.pts+=3}else if(ga<gb){B.v++;A.d++;B.pts+=3}else{A.e++;B.e++;A.pts++;B.pts++}
}
function lbTabelaGrupo(g){
  return S.lb.grupos[g].map(i=>({...S.lb.parts[i],i})).sort((a,b)=>b.pts-a.pts||(b.gp-b.gc)-(a.gp-a.gc)||b.gp-a.gp);
}
function lbPlacarPre(a,b){const pre=(S._lbPre||[]).find(x=>x[0]===a&&x[1]===b);return pre?{ga:pre[2],gb:pre[3]}:null}
function lbJogaData(meuRes){ // joga a data atual inteira
  const c=S.lb,jogos=lbJogosDaData(),res=[];
  if(c.fase==="grupos"){
    jogos.forEach(([a,b])=>{
      let ga,gb;
      if(meuRes&&((a===c.meu&&b===meuRes.adv)||(b===c.meu&&a===meuRes.adv))){ga=a===c.meu?meuRes.g1:meuRes.g2;gb=a===c.meu?meuRes.g2:meuRes.g1}
      else{const pr=lbPlacarPre(a,b);const r=pr||lbSimula(a,b);ga=r.ga;gb=r.gb}
      lbAplica(a,b,ga,gb);res.push({a,b,ga,gb,meu:(a===c.meu||b===c.meu)});
    });
    S._lbPre=null;c.ultimosRes=res;c.rodada++;
    if(c.rodada>=6)lbFimGrupos();
    return res;
  }
  // mata-mata: ida e volta (final: jogo único)
  const e=c.eliminatoria;
  e.jogos.forEach((j,k)=>{
    const [a0,b0]=j;
    const [a,b]=e.perna===1?[a0,b0]:[b0,a0];
    let ga,gb;
    if(meuRes&&((a===c.meu&&b===meuRes.adv)||(b===c.meu&&a===meuRes.adv))){ga=a===c.meu?meuRes.g1:meuRes.g2;gb=a===c.meu?meuRes.g2:meuRes.g1}
    else{const pr=lbPlacarPre(a,b);const r=pr||lbSimula(a,b);ga=r.ga;gb=r.gb}
    // acumulado em relação à ordem do confronto (a0,b0)
    const g0=e.perna===1?ga:gb, g1_=e.perna===1?gb:ga;
    e.agg[k]=e.agg[k]||[0,0];e.agg[k][0]+=g0;e.agg[k][1]+=g1_;
    res.push({a,b,ga,gb,meu:(a===c.meu||b===c.meu),perna:e.perna,k});
  });
  S._lbPre=null;c.ultimosRes=res;
  if(c.fase!=="final"&&e.perna===1){e.perna=2;return res}   // falta a volta
  // decide os classificados
  const venc=[];
  e.jogos.forEach((j,k)=>{
    const [x,y]=e.agg[k];let w;
    if(x>y)w=j[0];else if(y>x)w=j[1];
    else{ // gols fora e depois pênaltis
      const fa=S.lb.parts[j[0]].forca,fb=S.lb.parts[j[1]].forca;
      w=R()<fa/(fa+fb)?j[0]:j[1];e.pen=e.pen||{};e.pen[k]=true;
    }
    venc.push(w);
  });
  e.venc=venc;
  if(c.fase==="final"){
    c.campeao=venc[0];c.fase="fim";const cam=c.parts[venc[0]];
    const kh=c.chaveHist||'lbHist';S[kh]=(S[kh]||[]);S[kh].push({temp:S.temp,campeao:cam.nome,pais:cam.pais});
    return res;
  }
  const prox={oitavas:"quartas",quartas:"semi",semi:"final"}[c.fase];
  const jogos2=[];for(let i=0;i<venc.length;i+=2)jogos2.push([venc[i],venc[i+1]]);
  c.fase=prox;c.eliminatoria={jogos:jogos2,pendente:true,perna:1,agg:[],pen:{}};
  return res;
}
function lbFimGrupos(){
  const c=S.lb,cl=[];
  for(let g=0;g<8;g++){const t=lbTabelaGrupo(g);cl.push({p:t[0].i,s:t[1].i})}
  // oitavas: 1º do grupo A x 2º do grupo B etc. (pares de grupos vizinhos)
  const jogos=[];
  for(let g=0;g<8;g+=2){jogos.push([cl[g].p,cl[g+1].s]);jogos.push([cl[g+1].p,cl[g].s])}
  c.fase="oitavas";c.eliminatoria={jogos,pendente:true,perna:1,agg:[],pen:{}};
}
function lbSimulaData(){
  const c=S.lb;
  if(c.fase==="final"){ // final em jogo único
    c.eliminatoria.perna=1;
  }
  lbJogaData(null);
  if(c.fase==="fim")lbFimCampanha();
}
function lbFimCampanha(){const c=S.lb,cam=c.parts[c.campeao];aviso("🏆 "+cam.nome+" ("+cam.pais+") é o campeão da Libertadores!")}
function lbTituloFase(){
  const c=S.lb,f=c.fase;
  if(f==="grupos")return"Libertadores · Fase de grupos · Rodada "+(c.rodada+1)+"/6";
  const n={oitavas:"Oitavas",quartas:"Quartas",semi:"Semifinal",final:"Final"}[f]||f;
  const p=(f!=="final"&&c.eliminatoria)?(c.eliminatoria.perna===1?" · Ida":" · Volta"):"";
  return"Libertadores · "+n+p;
}
// ----- jogo ao vivo da Libertadores (mesmo motor da Champions, universo temporário) -----
function lbComecaMeuJogo(){
  const c=S.lb,g=lbMeuJogo();if(!g)return aviso("Seu clube não joga nesta data da Libertadores.");
  const ia=g[0],ib=g[1],PA=c.parts[ia],PB=c.parts[ib];
  const CA=clCriaClubeJogavel(PA),CB=clCriaClubeJogavel(PB);
  S._clbak={clubes:S.clubes,meu:S.meu,fixt:S.fixt,rodada:S.rodada,ids:S.clubes.map(c=>c.id)};
  const meuEhA=ia===c.meu;
  S.clubes=[CA,CB];CA.id=0;CB.id=1;S.meu=meuEhA?0:1;S.fixt=[[[0,1]]];S.rodada=0;
  S.clAoVivo={ia,ib,meuEhA,lib:true};
  est(CA);est(CB);if(criaLive()===false)return;
  S.live.outras=[];S.live.emCL=true;S.live.tela="lista";
  S.aba="live";render();somApito();playLive();
}
function fimLiveLB(){
  const L=S.live,j=L.jogos[0],ai=S.clAoVivo,eu=S.clubes[S.meu];
  S.pos=posJogo(j);S.pos.tituloCompleto=lbTituloFase();
  guardaResultadosLB();
  const bak=S._clbak;
  S.clubes=bak.clubes;S.meu=bak.meu;S.fixt=bak.fixt;S.rodada=bak.rodada;S._clbak=null;if(bak.ids)S.clubes.forEach((c,i)=>{c.id=bak.ids[i]});S.clAoVivo=null;
  const rest=S.clubes[S.meu];
  registraNotasDoPos(rest,ai.meuEhA);energiaPosJogo(rest,true);
  rest.elenco.forEach(x=>{if(x.lesao>0)x.tit=false});try{garante11(rest,true)}catch(e){}
  if(ai.meuEhA&&S.pos)recebeBilheteria('lb',1.3);
  const g1=ai.meuEhA?j.ga:j.gb,g2=ai.meuEhA?j.gb:j.ga,adv=ai.meuEhA?ai.ib:ai.ia;
  try{premiaJogo('lb',g1>g2?1:g1===g2?0:-1,S.lb&&S.lb.fase);if(S.lb&&S.lb.fase){premiaFase('lb',S.lb.fase)}}catch(e){}
  limpaPartidaEstado();S.live=null;S.aba=S.pos?"pos":"home";S.subs=0;fechaDataCopa(ai,g1,g2);
  lbJogaData({adv,g1,g2});
  if(S.lb.fase==="fim")lbFimCampanha();
  registraForma(g1>g2?'V':g1===g2?'E':'D');
  save();render();
}
function guardaResultadosLB(){
  const L=S.live,j=L.jogos[0],c=S.lb,ai=S.clAoVivo;
  const meuJ={a:c.parts[ai.ia].nome,b:c.parts[ai.ib].nome,ca:c.parts[ai.ia].cor,cb:c.parts[ai.ib].cor,ga:j.ga,gb:j.gb,meu:true};
  const outros=lbJogosDaData().filter(g=>!(g[0]===ai.ia&&g[1]===ai.ib)).map(g=>{const r=lbSimula(g[0],g[1]);return{a:c.parts[g[0]].nome,b:c.parts[g[1]].nome,ca:c.parts[g[0]].cor,cb:c.parts[g[1]].cor,ga:r.ga,gb:r.gb,pre:[g[0],g[1],r.ga,r.gb]}});
  S._lbPre=outros.map(o=>o.pre);
  const dados={};Object.keys(LIGAS).forEach(pa=>{dados[pa]=resultadosPais(pa)});
  dados["Libertadores"]=[{div:0,nome:lbTituloFase(),jogos:[meuJ,...outros]}];
  S.resultados={rodada:S.rodada+1,pais:"Libertadores",dados};S.filtroPais="Libertadores";
}
function abaLB(chave,nomeLiga,nomeLongo){
  chave=chave||"lbAba";nomeLiga=nomeLiga||"Libertadores";nomeLongo=nomeLongo||"Copa Libertadores";
  if(!S.lb)return`<div class='card'>A ${nomeLiga} começa na próxima temporada.</div>`;
  const c=S.lb,sou=c.meu>=0,aba=S[chave]||"grupos";
  const nome=i=>{const x=c.parts[i];return`${escudo(x,14)} ${x.nome}`};
  let h=`<div class="hd"><div class="top"><b>🏆 ${nomeLongo}</b><span>${c.fase==="fim"?"Encerrada":lbTituloFase().replace("Libertadores · ","")}</span></div></div>`;
  h+=`<div class="row" style="margin:8px 0"><button class="${aba==='grupos'?'':'s'} sm" onclick="setAba('${chave}','grupos')">Grupos</button><button class="${aba==='jogos'?'':'s'} sm" onclick="setAba('${chave}','jogos')">Jogos</button><button class="${aba==='ko'?'':'s'} sm" onclick="setAba('${chave}','ko')">Mata-mata</button><button class="${aba==='hist'?'':'s'} sm" onclick="setAba('${chave}','hist')">Histórico</button></div>`;
  if(aba==="grupos"){
    for(let g=0;g<8;g++){
      const t=lbTabelaGrupo(g);
      h+=`<div class="card"><div class="tag">Grupo ${String.fromCharCode(65+g)}</div><table style="margin-top:6px"><tr><th>#</th><th>Clube</th><th>P</th><th>J</th><th>SG</th></tr>`;
      t.forEach((x,i)=>{h+=`<tr style="background:${x.i===c.meu?'#245a3f':''}"><td style="border-left:3px solid ${i<2?'#34d98b':'#ff5d6c'};padding-left:4px">${i+1}</td><td>${escudo(x,14)} ${x.nome}${x.pelaCopa?' 🏅':''} <small class="mu">${x.pais.slice(0,3).toUpperCase()}</small></td><td><b>${x.pts}</b></td><td>${x.j}</td><td>${x.gp-x.gc}</td></tr>`});
      h+=`</table></div>`;
    }
  }else if(aba==="jogos"){
    const lista=c.fase==="fim"?[]:lbJogosDaData();
    h+=`<div class="card"><h3>${lbTituloFase().replace("Libertadores · ","")}</h3>`+(lista.map(([a,b])=>`<div class="row" style="padding:5px 0;border-top:1px solid var(--bd);${(a===c.meu||b===c.meu)?'background:#245a3f66;':''}"><span style="font-size:12px">${nome(a)}</span><b>x</b><span style="font-size:12px">${nome(b)}</span></div>`).join("")||"<div class='mu'>Sem jogos.</div>")+`</div>`;
    if(c.ultimosRes&&c.ultimosRes.length)h+=`<div class="card"><h3>Últimos resultados</h3>`+c.ultimosRes.map(r=>`<div class="row" style="padding:4px 0;border-top:1px solid var(--bd)"><span style="font-size:12px">${nome(r.a)}</span><b>${r.ga} x ${r.gb}</b><span style="font-size:12px">${nome(r.b)}</span></div>`).join("")+`</div>`;
  }else if(aba==="ko"){
    if(!c.eliminatoria)h+=`<div class="card">O mata-mata começa depois da fase de grupos.</div>`;
    else{const e=c.eliminatoria;
      h+=`<div class="card"><h3>${({oitavas:"Oitavas",quartas:"Quartas",semi:"Semifinais",final:"Final"})[c.fase]||"Mata-mata"}</h3>`+e.jogos.map((j,k)=>{const ag=e.agg[k];return`<div class="row" style="padding:6px 0;border-top:1px solid var(--bd);${(j[0]===c.meu||j[1]===c.meu)?'background:#245a3f66;':''}"><span style="font-size:12px">${nome(j[0])}</span><b>${ag?ag[0]+' x '+ag[1]:'x'}</b><span style="font-size:12px">${nome(j[1])}</span></div>`}).join("")+`</div>`;}
  }else{
    h+=`<div class="card"><h3>Campeões</h3>${(S[c.chaveHist||'lbHist']||[]).map(x=>`<div class="ln2 row"><span>Temp. ${x.temp}</span><b>🏆 ${x.campeao} (${x.pais})</b></div>`).join("")||"<div class='mu'>Nenhuma edição concluída.</div>"}</div>`;
  }
  h+=sou&&c.fase!=="fim"?`<div class="card"><b>Seu clube está na ${nomeLiga}.</b><div class="mu" style="font-size:12px">A ${nomeLiga} é jogada entre as rodadas do campeonato.</div></div>`:(!sou?`<div class="card mu">Seu clube não está na ${nomeLiga} nesta temporada.</div>`:"");
  return h;
}


// ===== COPA NACIONAL (todas as divisões · jogo único · mata-mata) =====
function cnMonta(){
  // todos os clubes das 3 divisões do meu país, pela divisão ATUAL; os da minha divisão usam os objetos reais
  garanteDivAtual();
  const lista=[];
  LIGAS[S.pais].forEach((_,dv)=>{
    clubesDaDivisao(S.pais,dv).forEach(c=>{
      const meuObj=(dv===S.div)?S.clubes.find(x=>x.nome===c[0]):null;
      lista.push({nome:c[0],sig:c[1],cor:c[2],cor2:c[3],pais:S.pais,div:dv,real:!!meuObj,idLocal:meuObj?meuObj.id:null,
        forca:meuObj?meuObj.forca:forcaClubeNome(c[0]),pts:0,j:0,v:0,e:0,d:0,gp:0,gc:0});
    });
  });
  return lista;
}
function cnInicia(){
  const parts=cnMonta();
  S.cn={temp:S.temp,fase:0,parts,eliminatoria:null,campeao:null,nomeFase:"",ultimaFase:"",
        meu:parts.findIndex(c=>ehMeuClube(c)),jogouHoje:false,preliminares:false,
        ultimosRes:[],vivos:parts.map((c,i)=>i)};
  cnPlanejaProximaFase();
}
// planeja a próxima fase com base em quem ainda está vivo
function cnPlanejaProximaFase(){
  const c=S.cn,n=c.vivos.length;
  if(n===1){c.campeao=c.vivos[0];c.nomeFase="fim";c.eliminatoria=null;
    const cam=c.parts[c.campeao];S.cnHist=(S.cnHist||[]);S.cnHist.push({temp:S.temp,campeao:cam.nome,pais:S.pais});S.cnCampeaoUltimo={nome:cam.nome,sig:cam.sig,cor:cam.cor,cor2:cam.cor2,forca:cam.forca,div:cam.div,id:(cam.real&&cam.div===0&&S.div===0)?cam.idLocal:null,real:!!cam.real,pais:S.pais,temp:S.temp};return}
  const alvo=(()=>{let a=1;while(a*2<=n)a*=2;return a})();
  let pares=[],folga=[],nome="";
  if(n===alvo){ // fase já é potência de 2: todos jogam
    // sorteio: cruza fortes com fracos
    const ord=[...c.vivos].sort(()=>R()-.5);
    for(let k=0;k<ord.length;k+=2)pares.push([ord[k],ord[k+1]]);
    nome=({32:"32 avos de final",16:"Oitavas de final",8:"Quartas de final",4:"Semifinal",2:"Final"})[n]||(n+" clubes");
  }else{
    // preliminar: reduz até 'alvo'. Quem joga: os mais fracos entre as divisões 2 e 3
    const precisa=n-alvo;
    const el=c.vivos.filter(i=>c.parts[i].div>0).sort((a,b)=>(c.parts[b].div-c.parts[a].div)||(c.parts[a].forca-c.parts[b].forca));
    const jogos=Math.min(precisa,Math.floor(el.length/2));
    const sel=el.slice(0,jogos*2).sort(()=>R()-.5);
    for(let k=0;k<jogos;k++)pares.push([sel[2*k],sel[2*k+1]]);
    const jogam=new Set(sel);folga=c.vivos.filter(i=>!jogam.has(i));
    nome=((c.prelimJogadas||0)===0)?"1ª fase":"2ª fase";
  }
  c.eliminatoria={pares,folga,pendente:true};c.nomeFase=nome;
}
function cnSouParticipante(){return S.cn&&S.cn.meu>=0&&S.cn.vivos.includes(S.cn.meu)&&S.cn.nomeFase!=="fim"}
function cnMeuJogo(){const c=S.cn;if(!c||!c.eliminatoria)return null;return c.eliminatoria.pares.find(g=>g[0]===c.meu||g[1]===c.meu)||null}
function cnDatas(){
  // total de datas = nº de fases restantes aproximado: 5 base + preliminares; planeja 7 datas e usa as necessárias
  return datasCopa(S.fixt.length,7,.06,.66);
}
function cnProximaData(){return agendaHoje()==="cn"&&S.cn&&!(S.cn.fase==="fim"||S.cn.nomeFase==="fim")?"hoje":null}
function cnSimula(ia,ib){const A=S.cn.parts[ia],B=S.cn.parts[ib];const [ga,gb]=simRapido(A.forca+3,B.forca);return{ga,gb}}
function cnJogaData(meuRes){
  const c=S.cn,e=c.eliminatoria,res=[],venc=[];
  e.pares.forEach(([a,b])=>{
    let ga,gb;
    if(meuRes&&((a===c.meu&&b===meuRes.adv)||(b===c.meu&&a===meuRes.adv))){ga=a===c.meu?meuRes.g1:meuRes.g2;gb=a===c.meu?meuRes.g2:meuRes.g1}
    else{const pr=(S._cnPre||[]).find(x=>x[0]===a&&x[1]===b);const r=pr?{ga:pr[2],gb:pr[3]}:cnSimula(a,b);ga=r.ga;gb=r.gb}
    let w=ga>gb?a:gb>ga?b:null,pen="";
    if(w===null){const fa=c.parts[a].forca,fb=c.parts[b].forca;w=R()<fa/(fa+fb)?a:b;pen=" (pên.)"}
    venc.push(w);res.push({a,b,ga,gb,w,pen,meu:(a===c.meu||b===c.meu)});
  });
  S._cnPre=null;c.ultimosRes=res;c.ultimaFase=c.nomeFase;
  // próximos vivos = folga + vencedores
  c.vivos=[...e.folga,...venc];
  const eraPrelim=(()=>{let a=1;while(a*2<=c.vivos.length+e.pares.length)a*=2;return(c.vivos.length+e.pares.length)!==a})();
  if(eraPrelim)c.prelimJogadas=(c.prelimJogadas||0)+1;
  c.fase++;c.preliminares=true;
  cnPlanejaProximaFase();
  return res;
}
function cnSimulaData(){
  cnJogaData(null);
  if(S.cn.nomeFase==="fim")cnFimCampanha();
}
function cnFimCampanha(){const c=S.cn,cam=c.parts[c.campeao];const vg=VAGA_COPA[S.pais];aviso("🏆 "+cam.nome+" é o campeão da Copa nacional!"+(vg==="lb"?"\nGanha vaga na Libertadores da próxima temporada.":vg==="cl"?"\nGanha vaga na Champions League da próxima temporada.":""))}
function cnCriaJogavel(pt){return clubeParaJogo(pt)}
function cnComecaMeuJogo(){
  const c=S.cn,g=cnMeuJogo();if(!g)return aviso("Seu clube não joga nesta data da Copa.");
  const ia=g[0],ib=g[1],PA=c.parts[ia],PB=c.parts[ib];
  const CA=cnCriaJogavel(PA),CB=cnCriaJogavel(PB);
  S._clbak={clubes:S.clubes,meu:S.meu,fixt:S.fixt,rodada:S.rodada,ids:S.clubes.map(c=>c.id)};
  const meuEhA=ia===c.meu;
  S.clubes=[CA,CB];CA.id=0;CB.id=1;S.meu=meuEhA?0:1;S.fixt=[[[0,1]]];S.rodada=0;
  S.clAoVivo={ia,ib,meuEhA,copa:true};
  est(CA);est(CB);if(criaLive()===false)return;
  S.live.outras=[];S.live.emCL=true;S.live.tela="lista";
  S.aba="live";render();somApito();playLive();
}
function fimLiveCN(){
  const L=S.live,j=L.jogos[0],ai=S.clAoVivo;
  const c=S.cn;
  S.pos=posJogo(j);S.pos.tituloCompleto="Copa nacional · "+c.nomeFase;
  // resultados dos outros jogos da fase
  const outros=c.eliminatoria.pares.filter(g=>!(g[0]===ai.ia&&g[1]===ai.ib)).map(g=>{const r=cnSimula(g[0],g[1]);return{a:c.parts[g[0]].nome,b:c.parts[g[1]].nome,ca:c.parts[g[0]].cor,cb:c.parts[g[1]].cor,ga:r.ga,gb:r.gb,pre:[g[0],g[1],r.ga,r.gb]}});
  S._cnPre=outros.map(o=>o.pre);
  const meuJ={a:c.parts[ai.ia].nome,b:c.parts[ai.ib].nome,ca:c.parts[ai.ia].cor,cb:c.parts[ai.ib].cor,ga:j.ga,gb:j.gb,meu:true};
  const dados={};Object.keys(LIGAS).forEach(pa=>{dados[pa]=resultadosPais(pa)});
  dados["Copa nacional"]=[{div:0,nome:"Copa nacional · "+c.nomeFase,jogos:[meuJ,...outros]}];
  S.resultados={rodada:S.rodada+1,pais:"Copa nacional",dados};S.filtroPais="Copa nacional";
  // restaura universo da liga
  const bak=S._clbak;
  S.clubes=bak.clubes;S.meu=bak.meu;S.fixt=bak.fixt;S.rodada=bak.rodada;S._clbak=null;if(bak.ids)S.clubes.forEach((c,i)=>{c.id=bak.ids[i]});S.clAoVivo=null;
  const rest=S.clubes[S.meu];
  registraNotasDoPos(rest,ai.meuEhA);energiaPosJogo(rest,true);
  rest.elenco.forEach(x=>{if(x.lesao>0)x.tit=false});try{garante11(rest,true)}catch(e){}
  if(ai.meuEhA&&S.pos)recebeBilheteria('cn',1.1);
  const g1=ai.meuEhA?j.ga:j.gb,g2=ai.meuEhA?j.gb:j.ga,adv=ai.meuEhA?ai.ib:ai.ia;
  try{premiaJogo('cn',g1>g2?1:g1===g2?0:-1,S.cn&&S.cn.fase);if(S.cn&&S.cn.fase){premiaFase('cn',S.cn.fase)}}catch(e){}
  limpaPartidaEstado();S.live=null;S.aba=S.pos?"pos":"home";S.subs=0;fechaDataCopa(ai,g1,g2);
  const eliminado=cnJogaDataResultado({adv,g1,g2});
  registraForma(g1>g2?'V':g1===g2?'E':'D');
  save();render();
  if(S.cn.nomeFase==="fim")cnFimCampanha();
}
function cnJogaDataResultado(m){cnJogaData(m)}
function abaCN(){
  if(!S.cn)return"<div class='card'>A Copa nacional começa na próxima temporada.</div>";
  const c=S.cn,aba=S.cnAba||"jogos";
  const nome=i=>{const x=c.parts[i];return`${escudo(x,14)} ${x.nome} <small class="mu">${x.div+1}ª div</small>`};
  let h=`<div class="hd"><div class="top"><b>🏆 Copa nacional</b><span>${c.nomeFase==="fim"?"Encerrada":c.nomeFase}</span></div></div>`;
  h+=`<div class="row" style="margin:8px 0"><button class="${aba==='jogos'?'':'s'} sm" onclick="S.cnAba='jogos';render()">Próxima fase</button><button class="${aba==='res'?'':'s'} sm" onclick="S.cnAba='res';render()">Resultados</button><button class="${aba==='vivos'?'':'s'} sm" onclick="S.cnAba='vivos';render()">Classificados</button><button class="${aba==='hist'?'':'s'} sm" onclick="S.cnAba='hist';render()">Histórico</button></div>`;
  if(aba==="jogos"){
    if(c.nomeFase==="fim"||!c.eliminatoria)h+=`<div class="card"><b>Copa encerrada.</b><div class="mu">Campeão: ${c.campeao!=null?c.parts[c.campeao].nome:'—'}</div></div>`;
    else{
      h+=`<div class="card"><h3>${c.nomeFase}</h3><div class="tag">${c.eliminatoria.pares.length} jogos${c.eliminatoria.folga.length?" · "+c.eliminatoria.folga.length+" clubes já classificados":""}</div>`;
      h+=c.eliminatoria.pares.map(([a,b])=>`<div class="row" style="padding:5px 0;border-top:1px solid var(--bd);${(a===c.meu||b===c.meu)?'background:#245a3f66;':''}"><span style="font-size:12px">${nome(a)}</span><b>x</b><span style="font-size:12px">${nome(b)}</span></div>`).join("")+`</div>`;
    }
  }else if(aba==="res"){
    h+=`<div class="card"><h3>${c.ultimaFase||"Resultados"}</h3>`+((c.ultimosRes||[]).map(r=>`<div class="row" style="padding:4px 0;border-top:1px solid var(--bd)"><span style="font-size:12px">${nome(r.a)}</span><b>${r.ga} x ${r.gb}${r.pen||""}</b><span style="font-size:12px">${nome(r.b)}</span></div>`).join("")||"<div class='mu'>Nenhum jogo ainda.</div>")+`</div>`;
  }else if(aba==="vivos"){
    h+=`<div class="card"><h3>Ainda na Copa (${c.vivos.length})</h3>`+c.vivos.map(i=>`<div style="padding:3px 0;font-size:13px;${i===c.meu?'color:#ffd45e;font-weight:700':''}">${nome(i)}</div>`).join("")+`</div>`;
  }else{
    h+=`<div class="card"><h3>Campeões</h3>${(S.cnHist||[]).map(x=>`<div class="ln2 row"><span>Temp. ${x.temp}</span><b>🏆 ${x.campeao}</b></div>`).join("")||"<div class='mu'>Nenhuma edição concluída.</div>"}</div>`;
  }
  const sou=c.meu>=0,vivo=sou&&c.vivos.includes(c.meu);
  const vg=VAGA_COPA[S.pais];
  h+=`<div class="card"><div class="tag">Prêmio</div><div style="font-size:13px;margin-top:4px">${vg==="lb"?"🌎 O campeão ganha vaga na Libertadores da próxima temporada.":vg==="cl"?"⭐ O campeão ganha vaga na Champions League da próxima temporada.":"Seu país não tem torneio continental no jogo; o título é só pelo prestígio."}</div></div>`;
  h+=c.nomeFase==="fim"?"":vivo?`<div class="card"><b>Seu clube está na Copa.</b><div class="mu" style="font-size:12px">A Copa é jogada entre as rodadas do campeonato.</div></div>`:`<div class="card mu">${sou?"Seu clube foi eliminado da Copa.":"Seu clube não está na Copa."}</div>`;
  return h;
}


// ===== VAGA PELA COPA NACIONAL =====
const VAGA_COPA={Brasil:"lb",Argentina:"lb",Colômbia:"lb",Chile:"lb",Uruguai:"lb",
  Inglaterra:"cl",Espanha:"cl",Itália:"cl",Alemanha:"cl",França:"cl",Portugal:"cl",Holanda:"cl",Bélgica:"cl",Turquia:"cl",Escócia:"cl",Rússia:"cl"};
// O campeão da Copa do país ganha vaga no torneio continental. Se já estava entre os classificados pela liga, nada muda;
// se estava fora, ocupa a última vaga da liga (o total de vagas continua o mesmo).
function aplicaVagaCopa(ordem,n,campeao){
  const topo=ordem.slice(0,n);
  if(!campeao)return topo;
  if(topo.some(c=>c.nome===campeao.nome))return topo;
  return[...topo.slice(0,Math.max(0,n-1)),{nome:campeao.nome,sig:campeao.sig,cor:campeao.cor,cor2:campeao.cor2,forca:campeao.forca,id:campeao.id,pelaCopa:true}];
}
// campeão da Copa de um país (apenas o do meu país é conhecido; para os outros países, sorteia um clube da 1ª divisão)
function campeaoCopaDe(pais){
  if(pais===S.pais&&S.cnCampeaoUltimo&&S.cnCampeaoUltimo.pais===pais&&S.cnCampeaoUltimo.temp===S.temp-1){
    const c=S.cnCampeaoUltimo;return{nome:c.nome,sig:c.sig,cor:c.cor,cor2:c.cor2,forca:c.forca,id:c.id};
  }
  if(pais===S.pais)return null;                                    // primeira temporada: ainda não houve Copa
  const rec=S.campeoesCopa&&S.campeoesCopa[pais];                  // {temp,nome} guardado ao fim da temporada
  if(!rec||rec.temp!==S.temp-1)return null;
  const ch=chaveFixa(pais,rec.nome);if(!ch)return null;
  const info=LIGAS[pais][ch.div][ch.idx];
  return{nome:rec.nome,sig:info[1],cor:info[2],cor2:info[3],forca:Math.round(forcaParaLiga(pais,ch.div,rec.nome)),id:null,idx:ch.idx,div:ch.div};
}

// ===== LIGA EUROPA (36 clubes · fase de liga · mata-mata) e COPA SUL-AMERICANA (32 clubes · grupos) =====
const EL_VAGAS={"Inglaterra": 4, "Espanha": 4, "Itália": 4, "Alemanha": 3, "França": 4, "Portugal": 3, "Holanda": 3, "Bélgica": 3, "Turquia": 3, "Escócia": 2, "Rússia": 3};
const SA_VAGAS={"Brasil": 6, "Argentina": 5, "Colômbia": 3, "Chile": 3, "Uruguai": 3};
const SA_EXTRA={"Paraguai": [3, ["Olimpia", "Cerro Porteño", "Libertad", "Guaraní", "Nacional (PAR)", "Sol de América"], "#111111", "#ffffff"], "Equador": [3, ["LDU Quito", "Barcelona SC", "Independiente del Valle", "Emelec", "Aucas", "El Nacional"], "#1e3a8a", "#ffffff"], "Peru": [2, ["Universitario", "Alianza Lima", "Sporting Cristal", "Melgar", "Cusco FC"], "#7a1d1d", "#ffffff"], "Bolívia": [2, ["Bolívar", "The Strongest", "Always Ready", "Blooming"], "#0d6b9e", "#ffffff"], "Venezuela": [2, ["Caracas FC", "Deportivo Táchira", "Carabobo", "Monagas"], "#8e1b2b", "#f5c542"]};
// Vagas = posições seguintes às da Champions/Libertadores (n_cont+1 .. n_cont+n)
function vagasSeguintes(ordem,nCont,n,excluir){const ex=new Set((excluir||[]).map(c=>c.nome));return ordem.filter((c,i)=>i>=nCont&&!ex.has(c.nome)).slice(0,n)}
// ------- Liga Europa: copia o estado da Champions (mesma estrutura S.el) -------
function elParticipantes(){
  const lista=[];
  Object.keys(EL_VAGAS).forEach(pa=>{
    const n=EL_VAGAS[pa],nc=CL_VAGAS[pa]||0;let ordem;
    if(pa===S.pais){
      const fonte=fontePrimeiraDiv();
      const naCL=aplicaVagaCopa(fonte,nc,VAGA_COPA[pa]==="cl"?campeaoCopaDe(pa):null);
      ordem=vagasSeguintes(fonte,nc,n,naCL);
    }else{
      const base=classificacaoMundo(pa,0);
      const naCL=aplicaVagaCopa(base,nc,VAGA_COPA[pa]==="cl"?campeaoCopaDe(pa):null);
      ordem=vagasSeguintes(base,nc,n,naCL);
    }
    ordem.forEach((c,i)=>{const o=clCriaClube(c.nome,c.sig,c.cor,c.cor2,forcaPart(c,pa,0),pa,c.id!==null&&c.id!==undefined,c.id);o.div=0;o.idxMundo=c.idx;lista.push(o)});
  });
  return lista.slice(0,36);
}
function elInicia(){
  const parts=elParticipantes();
  while(parts.length<36){const q=parts.length;parts.push(clCriaClube("Clube "+(q+1),"E"+(q+1),"#445566","#ffffff",60,"Europa",false,null))}
  S.el={chaveHist:'elHist',temp:S.temp,fase:"liga",rodada:0,parts,cal:clConstroiCalendario(parts.length),eliminatoria:null,campeao:null,
        meu:parts.findIndex(c=>ehMeuClube(c)),hist:[],jogouHoje:false};
}
// Reaproveita as funções da Champions trocando temporariamente S.cl por S.el (mesma estrutura de dados)
function comEL(fn){const bak=S.cl;S.cl=S.el;try{return fn()}finally{S.el=S.cl;S.cl=bak}}
function elSouParticipante(){return S.el&&S.el.meu>=0}
function elDatas(){const d=datasCopa(S.fixt.length,13,.09,.92);return{liga:d.slice(0,8),ko:{repescagem:d[8],oitavas:d[9],quartas:d[10],semi:d[11],final:d[12]}}}
function elProximaData(){return agendaHoje()==="el"&&S.el&&!(S.el.fase==="fim"||S.el.nomeFase==="fim")?"hoje":null}
function elSimulaData(){comEL(()=>{if(S.cl.fase==="liga")clJogaRodadaLiga(null);else clJogaMataMata(null)});if(S.el.fase==="fim")elFimCampanha()}
function elFimCampanha(){const c=S.el,cam=c.parts[c.campeao];aviso("🏆 "+cam.nome+" ("+cam.pais+") é o campeão da Liga Europa!")}
function elMeuJogo(){return comEL(()=>clMeusJogos())}
function elTituloFase(){return comEL(()=>clTituloFase()).replace("Champions League","Liga Europa")}
function elComecaMeuJogo(){
  const c=S.el,g=elMeuJogo();if(!g)return aviso("Seu clube não joga nesta data da Liga Europa.");
  const ia=g[0],ib=g[1],PA=c.parts[ia],PB=c.parts[ib];
  const CA=clCriaClubeJogavel(PA),CB=clCriaClubeJogavel(PB);
  S._clbak={clubes:S.clubes,meu:S.meu,fixt:S.fixt,rodada:S.rodada,ids:S.clubes.map(c=>c.id)};
  const meuEhA=ia===c.meu;
  S.clubes=[CA,CB];CA.id=0;CB.id=1;S.meu=meuEhA?0:1;S.fixt=[[[0,1]]];S.rodada=0;
  S.clAoVivo={ia,ib,meuEhA,eu:true};
  est(CA);est(CB);if(criaLive()===false)return;
  S.live.outras=[];S.live.emCL=true;S.live.tela="lista";
  S.aba="live";render();somApito();playLive();
}
function fimLiveEL(){
  const L=S.live,j=L.jogos[0],ai=S.clAoVivo,c=S.el;
  S.pos=posJogo(j);S.pos.tituloCompleto=elTituloFase();
  // resultados dos outros jogos
  const lista=comEL(()=>{const cc=S.cl;return cc.fase==="liga"?(cc.cal[cc.rodada]||[]):(cc.eliminatoria?cc.eliminatoria.jogos:[])});
  const outros=lista.filter(g=>!(g[0]===ai.ia&&g[1]===ai.ib)).map(g=>{const r=comEL(()=>clSimula(g[0],g[1]));return{a:c.parts[g[0]].nome,b:c.parts[g[1]].nome,ca:c.parts[g[0]].cor,cb:c.parts[g[1]].cor,ga:r.ga,gb:r.gb,pre:[g[0],g[1],r.ga,r.gb]}});
  S._clPre=outros.map(o=>o.pre);
  const meuJ={a:c.parts[ai.ia].nome,b:c.parts[ai.ib].nome,ca:c.parts[ai.ia].cor,cb:c.parts[ai.ib].cor,ga:j.ga,gb:j.gb,meu:true};
  const dados={};Object.keys(LIGAS).forEach(pa=>{dados[pa]=resultadosPais(pa)});
  dados["Liga Europa"]=[{div:0,nome:elTituloFase(),jogos:[meuJ,...outros]}];
  S.resultados={rodada:S.rodada+1,pais:"Liga Europa",dados};S.filtroPais="Liga Europa";
  const bak=S._clbak;
  S.clubes=bak.clubes;S.meu=bak.meu;S.fixt=bak.fixt;S.rodada=bak.rodada;S._clbak=null;if(bak.ids)S.clubes.forEach((c,i)=>{c.id=bak.ids[i]});S.clAoVivo=null;
  const rest=S.clubes[S.meu];
  registraNotasDoPos(rest,ai.meuEhA);energiaPosJogo(rest,true);
  rest.elenco.forEach(x=>{if(x.lesao>0)x.tit=false});try{garante11(rest,true)}catch(e){}
  if(ai.meuEhA&&S.pos)recebeBilheteria('el',1.2);
  const g1=ai.meuEhA?j.ga:j.gb,g2=ai.meuEhA?j.gb:j.ga,adv=ai.meuEhA?ai.ib:ai.ia;
  try{premiaJogo('el',g1>g2?1:g1===g2?0:-1,S.el&&S.el.fase);if(S.el&&S.el.fase){premiaFase('el',S.el.fase)}}catch(e){}
  limpaPartidaEstado();S.live=null;S.aba=S.pos?"pos":"home";S.subs=0;fechaDataCopa(ai,g1,g2);
  comEL(()=>{if(S.cl.fase==="liga")clJogaRodadaLiga({adv,g1,g2});else clJogaMataMata({adv,g1,g2})});
  if(S.el.fase==="fim")elFimCampanha();
  registraForma(g1>g2?'V':g1===g2?'E':'D');save();render();
}
function abaEL(){
  const bak=S.cl;S.cl=S.el;let h;
  try{h=abaCL("elAba","Liga Europa","UEFA Europa League")}finally{S.el=S.cl;S.cl=bak}
  return h;
}
// ------- Copa Sul-Americana: copia o estado da Libertadores (S.sa) -------
function saParticipantes(){
  const L=[];
  Object.keys(SA_VAGAS).forEach(pa=>{
    const n=SA_VAGAS[pa],nc=LB_VAGAS[pa]||0;let ordem;
    if(pa===S.pais){
      const fonte=fontePrimeiraDiv();
      const naLB=aplicaVagaCopa(fonte,nc,VAGA_COPA[pa]==="lb"?campeaoCopaDe(pa):null);
      ordem=vagasSeguintes(fonte,nc,n,naLB);
    }else{
      const base=classificacaoMundo(pa,0);
      const naLB=aplicaVagaCopa(base,nc,VAGA_COPA[pa]==="lb"?campeaoCopaDe(pa):null);
      ordem=vagasSeguintes(base,nc,n,naLB);
    }
    ordem.forEach((c,i)=>{const o=clCriaClube(c.nome,c.sig,c.cor,c.cor2,forcaPart(c,pa,0),pa,c.id!==null&&c.id!==undefined,c.id);o.div=0;o.idxMundo=c.idx;L.push(o)});
  });
  Object.keys(SA_EXTRA).forEach(pa=>{
    const [n,nomes,c1,c2]=SA_EXTRA[pa];
    // usa os clubes que NÃO foram para a Libertadores (os últimos da lista)
    [...nomes].reverse().slice(0,n).forEach((nome,i)=>L.push(clCriaClube(nome,lbSigla(nome),c1,c2,forcaGerado(nome,pa),pa,false,null)));
  });
  return L.slice(0,32);
}
function saInicia(){
  const bak=S.lb;
  // reaproveita a montagem de grupos/calendário da Libertadores
  const parts=saParticipantes();
  const ord=parts.map((c,i)=>i).sort((a,b)=>parts[b].forca-parts[a].forca);
  const potes=[0,1,2,3].map(k=>ord.slice(k*8,k*8+8).sort(()=>R()-.5));
  const grupos=[];for(let g=0;g<8;g++)grupos.push([potes[0][g],potes[1][g],potes[2][g],potes[3][g]]);
  const rod=[[[0,3],[1,2]],[[0,2],[3,1]],[[0,1],[2,3]]],cal=[];
  rod.forEach(r=>cal.push(r));rod.forEach(r=>cal.push(r.map(([a,b])=>[b,a])));
  S.sa={chaveHist:'saHist',temp:S.temp,fase:"grupos",rodada:0,parts,grupos,cal,eliminatoria:null,campeao:null,jogouHoje:false,
        meu:parts.findIndex(c=>ehMeuClube(c)),hist:[],pernas:1};
}
function comSA(fn){const bak=S.lb;S.lb=S.sa;try{return fn()}finally{S.sa=S.lb;S.lb=bak}}
function saSouParticipante(){return S.sa&&S.sa.meu>=0}
function saDatas(){const d=datasCopa(S.fixt.length,13,.11,.86);return{grupos:d.slice(0,6),ko:{oitavas:d[6],quartas:d[8],semi:d[10],final:d[12]},volta:{oitavas:d[7],quartas:d[9],semi:d[11]}}}
function saProximaData(){return agendaHoje()==="sa"&&S.sa&&!(S.sa.fase==="fim"||S.sa.nomeFase==="fim")?"hoje":null}
function saSimulaData(){comSA(()=>{if(S.lb.fase==="final")S.lb.eliminatoria.perna=1;lbJogaData(null)});if(S.sa.fase==="fim")saFimCampanha()}
function saFimCampanha(){const c=S.sa,cam=c.parts[c.campeao];aviso("🏆 "+cam.nome+" ("+cam.pais+") é o campeão da Copa Sul-Americana!")}
function saMeuJogo(){return comSA(()=>lbMeuJogo())}
function saTituloFase(){return comSA(()=>lbTituloFase()).replace("Libertadores","Sul-Americana")}
function saComecaMeuJogo(){
  const c=S.sa,g=saMeuJogo();if(!g)return aviso("Seu clube não joga nesta data da Sul-Americana.");
  const ia=g[0],ib=g[1],PA=c.parts[ia],PB=c.parts[ib];
  const CA=clCriaClubeJogavel(PA),CB=clCriaClubeJogavel(PB);
  S._clbak={clubes:S.clubes,meu:S.meu,fixt:S.fixt,rodada:S.rodada,ids:S.clubes.map(c=>c.id)};
  const meuEhA=ia===c.meu;
  S.clubes=[CA,CB];CA.id=0;CB.id=1;S.meu=meuEhA?0:1;S.fixt=[[[0,1]]];S.rodada=0;
  S.clAoVivo={ia,ib,meuEhA,sa:true};
  est(CA);est(CB);if(criaLive()===false)return;
  S.live.outras=[];S.live.emCL=true;S.live.tela="lista";
  S.aba="live";render();somApito();playLive();
}
function fimLiveSA(){
  const L=S.live,j=L.jogos[0],ai=S.clAoVivo,c=S.sa;
  S.pos=posJogo(j);S.pos.tituloCompleto=saTituloFase();
  const lista=comSA(()=>lbJogosDaData());
  const outros=lista.filter(g=>!(g[0]===ai.ia&&g[1]===ai.ib)).map(g=>{const r=comSA(()=>lbSimula(g[0],g[1]));return{a:c.parts[g[0]].nome,b:c.parts[g[1]].nome,ca:c.parts[g[0]].cor,cb:c.parts[g[1]].cor,ga:r.ga,gb:r.gb,pre:[g[0],g[1],r.ga,r.gb]}});
  S._lbPre=outros.map(o=>o.pre);
  const meuJ={a:c.parts[ai.ia].nome,b:c.parts[ai.ib].nome,ca:c.parts[ai.ia].cor,cb:c.parts[ai.ib].cor,ga:j.ga,gb:j.gb,meu:true};
  const dados={};Object.keys(LIGAS).forEach(pa=>{dados[pa]=resultadosPais(pa)});
  dados["Sul-Americana"]=[{div:0,nome:saTituloFase(),jogos:[meuJ,...outros]}];
  S.resultados={rodada:S.rodada+1,pais:"Sul-Americana",dados};S.filtroPais="Sul-Americana";
  const bak=S._clbak;
  S.clubes=bak.clubes;S.meu=bak.meu;S.fixt=bak.fixt;S.rodada=bak.rodada;S._clbak=null;if(bak.ids)S.clubes.forEach((c,i)=>{c.id=bak.ids[i]});S.clAoVivo=null;
  const rest=S.clubes[S.meu];
  registraNotasDoPos(rest,ai.meuEhA);energiaPosJogo(rest,true);
  rest.elenco.forEach(x=>{if(x.lesao>0)x.tit=false});try{garante11(rest,true)}catch(e){}
  if(ai.meuEhA&&S.pos)recebeBilheteria('cn',1.1);
  const g1=ai.meuEhA?j.ga:j.gb,g2=ai.meuEhA?j.gb:j.ga,adv=ai.meuEhA?ai.ib:ai.ia;
  try{premiaJogo('sa',g1>g2?1:g1===g2?0:-1,S.sa&&S.sa.fase);if(S.sa&&S.sa.fase){premiaFase('sa',S.sa.fase)}}catch(e){}
  limpaPartidaEstado();S.live=null;S.aba=S.pos?"pos":"home";S.subs=0;fechaDataCopa(ai,g1,g2);
  comSA(()=>lbJogaData({adv,g1,g2}));
  if(S.sa.fase==="fim")saFimCampanha();
  registraForma(g1>g2?'V':g1===g2?'E':'D');save();render();
}
function abaSA(){
  const bak=S.lb;S.lb=S.sa;let h;
  try{h=abaLB("saAba","Sul-Americana","Copa Sul-Americana")}finally{S.sa=S.lb;S.lb=bak}
  return h;
}
function setAba(k,v){S[k]=v;render()}


// ===== AGENDA DA TEMPORADA (uma competição por data) =====
const MESES=["Janeiro","Fevereiro","Março","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"];
const DIAS_SEM=["Dom","Seg","Ter","Qua","Qui","Sex","Sáb"];
const COMP_INFO={liga:{n:"Campeonato",ic:"⚽"},cn:{n:"Copa nacional",ic:"🏆"},cl:{n:"Champions League",ic:"⭐"},el:{n:"Liga Europa",ic:"🟧"},lb:{n:"Libertadores",ic:"🌎"},sa:{n:"Sul-Americana",ic:"🟩"},mund:{n:"Mundial de Clubes",ic:"🌍"}};
// Quais competições o meu país/divisão disputa nesta temporada
function agendaCompetidores(){
  const k=[];
  if(S.cn)k.push("cn");
  if(S.cl&&S.cl.meu>=0)k.push("cl");
  if(S.el&&S.el.meu>=0)k.push("el");
  if(S.lb&&S.lb.meu>=0)k.push("lb");
  if(S.sa&&S.sa.meu>=0)k.push("sa");
  return k;
}
// Nº de datas que cada competição precisa (para o MEU clube; as demais são simuladas em segundo plano nas mesmas datas)
function agendaCopasTodas(){
  // todas as competições existentes entram na linha do tempo (as em que não jogo são simuladas na hora)
  const k=[];
  if(S.cn)k.push("cn");if(S.cl)k.push("cl");if(S.el)k.push("el");if(S.lb)k.push("lb");if(S.sa)k.push("sa");
  return k;
}
function agendaMonta(){
  const T=S.fixt.length;
  const n={cn:S.cn?cnTotalFases():0,cl:S.cl?13:0,el:S.el?13:0,lb:S.lb?13:0,sa:S.sa?13:0};
  // só ocupam datas do usuário as competições em que o clube joga: as outras não precisam de data própria
  const meus=agendaCompetidores();
  const comps=meus.filter(k=>n[k]>0);
  const janela={cn:[.06,.66],sa:[.11,.86],lb:[.10,.82],el:[.09,.92],cl:[.08,.98]};
  const total=T+comps.reduce((q,k)=>q+n[k],0);
  const slots=new Array(total).fill(null);
  const alvos=[];
  comps.forEach(k=>{
    const N=n[k],a=janela[k][0],b=janela[k][1];
    const ini=Math.max(0,Math.round(total*a)),fim=Math.min(total-1,Math.round(total*b));
    for(let j=0;j<N;j++)alvos.push({pos:N>1?Math.round(ini+(fim-ini)*j/(N-1)):ini,k,j});
  });
  alvos.sort((x,y)=>x.pos-y.pos||x.j-y.j);
  alvos.forEach(a=>{
    let p=a.pos;while(p<total&&slots[p])p++;
    if(p>=total){p=a.pos;while(p>=0&&slots[p])p--}
    if(p>=0)slots[p]={comp:a.k,idx:a.j};
  });
  let lg=0;for(let i=0;i<total;i++)if(!slots[i])slots[i]={comp:"liga",idx:lg++};
  // garante ordem interna crescente de cada competição (idx)
  const cont={};slots.forEach(sl=>{cont[sl.comp]=cont[sl.comp]||0;sl.idx=cont[sl.comp]++});
  // calendário: temporada de 12 meses começando em 1º de agosto, 2 datas por semana (qua e dom) ao longo do ano
  S.agenda=slots.map((sl,i)=>{
    const diaAno=Math.floor(i*(300/Math.max(1,total-1)));       // distribui em ~300 dias (ago → mai)
    const dt=new Date(2026+(S.temp-1)+0,7,1+diaAno);
    return{comp:sl.comp,idx:sl.idx,mes:dt.getMonth(),dia:dt.getDate(),ano:dt.getFullYear(),dow:dt.getDay(),res:null,adv:null,casa:null};
  });
  S.dia=0;
}
function cnTotalFases(){ // quantas datas a Copa nacional ocupa para o meu clube nesta temporada
  if(!S.cn)return 0;
  const n=S.cn.parts.length;let alvo=1;while(alvo*2<=n)alvo*=2;
  let vivos=n,fracos=S.cn.parts.filter(p=>p.div>0).length,f=0;
  while(vivos>alvo){const j=Math.min(vivos-alvo,Math.floor(fracos/2));if(j<=0)break;vivos-=j;fracos-=j;f++}
  return f+Math.round(Math.log2(alvo));
}
function agendaAtual(){return S.agenda?S.agenda[S.dia]:null}
function agendaAvanca(){
  const mesAntes=(S.agenda&&S.agenda[S.dia])?S.agenda[S.dia].mes:null;
  if(S.agenda&&S.dia<S.agenda.length)S.dia++;
  try{
    const mesDepois=(S.agenda&&S.agenda[S.dia])?S.agenda[S.dia].mes:null;
    if(mesAntes!=null&&mesDepois!==mesAntes)cobraMes();                 // v52: virou o mês → paga a folha
    else if(mesAntes!=null&&mesDepois==null)cobraMes();                  // acabou o calendário: paga o último mês
  }catch(e){}
  try{gramadoRecupera()}catch(e){}
  try{ // o elenco real já recupera até a nova data (a tela de elenco mostra o valor certo antes do próximo jogo)
    const real=S._clbak?S._clbak.clubes[S._clbak.meu]:S.clubes[S.meu];
    if(real&&S.agenda&&S.dia<S.agenda.length)recuperaParaProximoJogo(real);
  }catch(e){}
}
function agendaRegistra(res,adv,casa){const d=S.agenda&&S.agenda[S.dia];if(d){d.res=res;d.adv=adv;d.casa=casa}}


function agendaHoje(){const d=agendaAtual();return d?d.comp:null}
// Competições em que o MEU clube não joga (ou já está eliminado) avançam sozinhas, na mesma cadência da agenda.
function agendaSimulaOutras(){
  // data de referência para as competições de fora: usa a posição relativa na temporada (0..1)
  if(!S.agenda)return;
  const prog=S.dia/S.agenda.length;
  try{copaMundoAvanca(prog)}catch(err){}
  const meus=new Set(agendaCompetidores());
  const tentativas=[["cl",S.cl,()=>clSimulaData(),.08,.98,13],["el",S.el,()=>elSimulaData(),.09,.92,13],["lb",S.lb,()=>lbSimulaData(),.10,.82,13],["sa",S.sa,()=>saSimulaData(),.11,.86,13]];
  tentativas.forEach(([k,e,sim,a,b,N])=>{
    if(!e||meus.has(k))return;                    // as minhas competições têm datas próprias na agenda
    const fim=e.fase==="fim";if(fim)return;
    const feitos=e._sim||0;
    const alvo=Math.min(N,Math.floor(N*Math.max(0,(prog-a))/(b-a))+ (prog>=b?N:0));
    if(feitos<alvo){e._sim=feitos+1;try{sim()}catch(err){}}
  });
}


function fechaDataCopa(ai,g1,g2){
  // descobre o nome do adversário a partir do torneio em andamento (ai.copa|lib|eu|sa|nenhum=Champions)
  const t=ai.copa?S.cn:ai.lib?S.lb:ai.eu?S.el:ai.sa?S.sa:S.cl;
  let nomeAdv="";
  try{nomeAdv=(ai.meuEhA?t.parts[ai.ib]:t.parts[ai.ia]).nome}catch(e){}
  agendaRegistra(g1+" x "+g2,nomeAdv,ai.meuEhA);
  agendaAvanca();
}


function agendaTexto(){
  const d=agendaAtual();
  if(!d)return"Fim da temporada";
  return`${d.dia} ${MESES[d.mes].slice(0,3)} · ${COMP_INFO[d.comp].ic} ${COMP_INFO[d.comp].n} · jogo ${Math.min(S.dia+1,S.agenda.length)}/${S.agenda.length}`;
}


// Informações do próximo jogo do MEU clube, seja de liga ou de copa
function proximoJogoInfo(){
  const d=agendaAtual();if(!d)return null;
  const comp=d.comp;let adv=null,casa="",titulo="";
  if(comp==="liga"){
    const pr=S.fixt[S.rodada]&&S.fixt[S.rodada].find(([a,b])=>a===S.meu||b===S.meu);
    if(pr){adv=S.clubes[pr[0]===S.meu?pr[1]:pr[0]];casa=pr[0]===S.meu?"Em casa":"Fora"}
    titulo=`${LIGANOME[S.pais][S.div]} · ${S.rodada+1}ª rodada`;
    return{comp,adv:adv?{nome:adv.nome,cor:adv.cor,cor2:adv.cor2,escudo:adv.escudo,forca:Math.round(forcaTime(adv,"Equilibrada"))}:null,casa,titulo,folga:!adv};
  }
  if(comp==="mund"){
    const g=S.mundial?mundialMeuJogo():null;
    if(g){const eu=nomeMeuClube(),o=g[0].nome===eu?g[1]:g[0];return{comp,adv:{nome:o.nome,cor:o.cor,cor2:o.cor2,escudo:null,forca:o.forca},casa:"Campo neutro",titulo:mundialTitulo(),folga:false}}
    return{comp,adv:null,casa:"",titulo:"Mundial de Clubes",folga:true};
  }
  const t={cn:S.cn,cl:S.cl,el:S.el,lb:S.lb,sa:S.sa}[comp];
  if(!t)return{comp,adv:null,casa:"",titulo:COMP_INFO[comp].n,folga:true};
  let g=null;
  try{
    if(comp==="cn")g=cnMeuJogo();
    else if(comp==="cl")g=clMeusJogos();
    else if(comp==="el")g=elMeuJogo();
    else if(comp==="lb")g=lbMeuJogo();
    else if(comp==="sa")g=saMeuJogo();
  }catch(e){g=null}
  const faseTxt=comp==="cn"?(t.nomeFase||""):comp==="cl"?clTituloFase().replace("Champions League · ",""):comp==="el"?elTituloFase().replace("Liga Europa · ",""):comp==="lb"?lbTituloFase().replace("Libertadores · ",""):saTituloFase().replace("Sul-Americana · ","");
  if(g){
    const meuIdx=t.meu;const oIdx=g[0]===meuIdx?g[1]:g[0];const o=t.parts[oIdx];
    adv={nome:o.nome,cor:o.cor,cor2:o.cor2,escudo:null,forca:o.forca};casa=g[0]===meuIdx?"Em casa":"Fora";
  }
  return{comp,adv,casa,titulo:`${COMP_INFO[comp].n} · ${faseTxt}`,folga:!adv};
}



// Adversário (e mando) de uma data da agenda: liga = calendário de rodadas; copas = só o adversário já conhecido
function adversarioDaData(d){
  if(!d)return null;
  if(d.res&&d.adv)return{nome:d.adv,casa:!!d.casa,res:d.res,fixo:true};
  if(d.comp==="liga"){
    const r=S.fixt&&S.fixt[d.idx];if(!r)return null;
    const par=r.find(([a,b])=>a===S.meu||b===S.meu);if(!par)return{nome:"Folga",casa:true,folga:true};
    const adv=S.clubes[par[0]===S.meu?par[1]:par[0]];
    return adv?{nome:adv.nome,sig:adv.sig,cor:adv.cor,cor2:adv.cor2,casa:par[0]===S.meu}:null;
  }
  if(d.comp==="mund"&&S.mundial&&S.mundial.temp===S.temp){const g=mundialMeuJogo();if(g&&d.idx===Math.min(S.mundial.etapa,6)){const eu=nomeMeuClube(),o=g[0].nome===eu?g[1]:g[0];return{nome:o.nome,sig:o.sig,cor:o.cor,cor2:o.cor2,casa:true}}}
  return null;
}

function abaCal(){
  if(!S.agenda)return"<div class='card'>Sem calendário.</div>";
  // mês exibido: padrão = mês da data atual
  const atual=agendaAtual();
  if(S.calMes==null||S.calAno==null){
    if(atual){S.calMes=atual.mes;S.calAno=atual.ano}else{const u=S.agenda[S.agenda.length-1];S.calMes=u.mes;S.calAno=u.ano}
  }
  const mes=S.calMes,ano=S.calAno;
  const jogos=S.agenda.map((d,i)=>({...d,i})).filter(d=>d.mes===mes&&d.ano===ano);
  const porDia={};jogos.forEach(d=>{porDia[d.dia]=d});
  const primeiro=new Date(ano,mes,1).getDay(),dias=new Date(ano,mes+1,0).getDate();
  let h=topoAba("📅","Calendário da temporada "+S.temp,"Seus jogos, mês a mês",[[Math.min(S.dia,S.agenda.length),"Jogados"],[Math.max(0,S.agenda.length-S.dia),"Restantes"],[S.agenda.length,"Total"]]);
  h+=`<div class="calnav"><button class="sm s" onclick="calMuda(-1)">‹</button><b style="font-size:16px">${MESES[mes]} ${ano}</b><button class="sm s" onclick="calMuda(1)">›</button></div>`;
  h+=`<div class="leg">${Object.keys(COMP_INFO).filter(k=>S.agenda.some(d=>d.comp===k)).map(k=>`<span>${COMP_INFO[k].ic} ${COMP_INFO[k].n}</span>`).join("")}</div>`;
  h+=`<div class="cal">${DIAS_SEM.map(x=>`<div class="h">${x}</div>`).join("")}`;
  for(let i=0;i<primeiro;i++)h+=`<div class="d vz"></div>`;
  for(let dia=1;dia<=dias;dia++){
    const d=porDia[dia];
    if(!d){h+=`<div class="d"><span class="n">${dia}</span></div>`;continue}
    const eh=d.i===S.dia,feito=d.i<S.dia;
    const av=adversarioDaData(d);
    const sg=av?(av.sig||av.nome.slice(0,3).toUpperCase()):'';
    const meu=d.res?`<span class="tx rs">${d.res}</span><span class="tx">${d.casa?'x':'@'} ${sg||(d.adv||'').slice(0,3).toUpperCase()}</span>`:(av&&!av.folga?`<span class="tx adv">${av.casa?'vs':'@'} ${sg}</span>`:`<span class="tx cp">${COMP_INFO[d.comp].n.split(' ')[0]}</span>`);
    h+=`<div class="d jg ${eh?'hoje':''} ${feito?'feito':''}" onclick="calDetalhe(${d.i})"><span class="n">${dia}</span><span class="ic">${COMP_INFO[d.comp].ic}</span>${meu}</div>`;
  }
  h+=`</div>`;
  // lista dos jogos do mês
  h+=`<div class="card" style="margin-top:10px"><h3>Jogos de ${MESES[mes]}</h3>`;
  h+=jogos.length?jogos.map(d=>{
    const eh=d.i===S.dia;
    const av=adversarioDaData(d);
    const meio=d.res?`<b class="rsL">${d.res}</b> <span>${d.casa?'vs':'@'} ${av&&av.cor?escudo(av,15)+' ':''}${d.adv}</span>`:(av&&!av.folga?`<span>${av.casa?'Em casa':'Fora'} · ${av.cor?escudo(av,15)+' ':''}<b>${av.nome}</b></span>`:`<span class="mu">${eh?'Hoje':'Adversário a definir'}</span>`);
    return`<div class="calL ${eh?'hoje':''}"><span class="calD"><b>${d.dia}/${String(d.mes+1).padStart(2,'0')}</b><small>${COMP_INFO[d.comp].ic} ${COMP_INFO[d.comp].n}</small></span><span class="calA">${meio}</span></div>`;
  }).join(""):`<div class="mu">Nenhum jogo neste mês.</div>`;
  h+=`</div>`;
  return h;
}
function calMuda(dm){
  let m=S.calMes+dm,a=S.calAno;
  if(m<0){m=11;a--}else if(m>11){m=0;a++}
  S.calMes=m;S.calAno=a;render();
}
function calDetalhe(i){
  const d=S.agenda[i];if(!d)return;
  const dt=`${d.dia}/${String(d.mes+1).padStart(2,'0')}/${d.ano}`;
  if(d.res)return aviso(`${dt}\n${COMP_INFO[d.comp].ic} ${COMP_INFO[d.comp].n}\n${d.res} ${d.casa?'contra':'fora, contra'} ${d.adv}`);
  aviso(`${dt}\n${COMP_INFO[d.comp].ic} ${COMP_INFO[d.comp].n}\n${i===S.dia?'É o próximo jogo.':i<S.dia?'Seu clube não jogou (foi simulado).':'Ainda não aconteceu.'}`);
}


function tituloAoVivo(){ // título da competição do jogo em andamento
  const ai=S.clAoVivo;
  if(S.live&&S.live.emCL&&ai){
    if(ai.mund)return mundialTitulo();
    if(ai.copa)return"Copa nacional · "+(S.cn?S.cn.nomeFase:"");
    if(ai.lib)return lbTituloFase();
    if(ai.eu)return elTituloFase();
    if(ai.sa)return saTituloFase();
    return clTituloFase();
  }
  return`${LIGANOME[S.pais][S.div]} · ${S.rodada+1}ª rodada`;
}


// ===== MERCADO GLOBAL (liga → clube → jogador) e EMPRÉSTIMOS =====
// Elencos de clubes de outras ligas são gerados SOB DEMANDA, de forma determinística (mesma semente => mesmo elenco).
function semente(str){let h=2166136261>>>0;for(let i=0;i<str.length;i++){h^=str.charCodeAt(i);h=Math.imul(h,16777619)>>>0}return h>>>0}
function rngSeed(seed){let a=seed>>>0;return function(){a=(a+0x6D2B79F5)>>>0;let t=a;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296}}
function elencoDe(pais,div,idx){return clubeMundo(pais,div,idx)}
function clubeExtDoJogador(j){return j._orig||null}   // {pais,div,idx} do clube dono
// ----- Interface -----
function abaMer(){
  garante();
  const m=S.merc||(S.merc={tela:"menu"});
  let h=topoAba("💱","Mercado","Contratar, vender e emprestar jogadores",[[R$(S.clubes[S.meu].caixa),"Caixa"],[(S.props||[]).length,"Propostas"],[(S.emprest||[]).length,"Empréstimos"]]);
  h+=pedidosSaidaHTML();
  if(S.props&&S.props.length){
    h+=`<div class="card"><h3>📨 Propostas recebidas</h3>`;
    S.props.forEach((p,i)=>{const c=S.clubes[p.clube];if(!c)return;h+=`<div style="padding:8px 0;border-top:1px solid var(--bd)">${escudo(c,16)} <b>${c.nome}</b> oferece <b class="g">${R$(p.valor)}</b> por <b>${p.nome}</b>
    <div class="row" style="margin-top:6px"><button class="sm" onclick="aceitaProp(${i})">Aceitar</button><button class="sm s" onclick="contraProp(${i})">Contraproposta</button><button class="sm s" onclick="recusaProp(${i})">Recusar</button></div></div>`});
    h+=`</div>`;
  }
  // empréstimos ativos
  const emp=(S.emprest||[]);
  if(emp.length){
    h+=`<div class="card"><h3>🔁 Empréstimos ativos</h3>`;
    emp.forEach((e,i)=>{h+=`<div style="padding:6px 0;border-top:1px solid var(--bd)"><div class="row"><span><b>${e.nome}</b> <small class="mu">${e.sentido==="entrada"?"(vindo de "+e.clube+")":"(cedido a "+e.clube+")"}</small></span><span class="tag">volta em ${e.ate}</span></div>${e.sentido==="entrada"&&e.compra?`<div class="row" style="margin-top:4px"><small class="mu">Opção de compra: ${R$(e.compra)}</small><button class="sm" onclick="exerceCompra(${i})">Comprar</button></div>`:''}</div>`});
    h+=`</div>`;
  }
  h+=`<div class="row" style="margin:8px 0"><button class="${m.tela==='menu'||m.tela==='venda'?'':'s'} sm" onclick="S.merc={tela:'menu'};render()">À venda</button><button class="${m.tela==='liga'||m.tela==='clube'?'':'s'} sm" onclick="S.merc={tela:'liga'};render()">🌍 Buscar por liga</button><button class="${m.tela==='busca'?'':'s'} sm" onclick="S.merc={tela:'busca'};render()">🔎 Buscar</button><button class="${m.tela==='livres'?'':'s'} sm" onclick="S.merc={tela:'livres'};render()">🆓 Livres (${(S.livres||[]).length})</button><button class="s sm" onclick="S.merc={tela:'meus'};render()">Meu elenco (emprestar)</button></div>`;
  if(m.tela==="livres"){
    h+=livresHTML();
  }else if(m.tela==="busca"){
    h+=buscaHTML();
  }else if(m.tela==="liga"){
    h+=`<div class="card"><h3>Escolha o país</h3>`+Object.keys(LIGAS).map(pa=>`<div class="clube" onclick="S.merc={tela:'div',pais:'${pa}'};render()"><span>🌍 ${pa}</span><span class="tag">${LIGANOME[pa][0]}</span></div>`).join("")+`</div>`;
  }else if(m.tela==="div"){
    h+=`<button class="s sm" onclick="S.merc={tela:'liga'};render()">← Países</button><div class="card"><h3>${m.pais}</h3>`+LIGAS[m.pais].map((d,i)=>`<div class="clube" onclick="S.merc={tela:'clubes',pais:'${m.pais}',div:${i}};render()"><span>${LIGANOME[m.pais][i]}</span><span class="tag">${clubesNaDivisao(m.pais,i).length} clubes</span></div>`).join("")+`</div>`;
  }else if(m.tela==="clubes"){
    h+=`<button class="s sm" onclick="S.merc={tela:'div',pais:'${m.pais}'};render()">← Divisões</button><div class="card"><h3>${LIGANOME[m.pais][m.div]}</h3>`+clubesNaDivisao(m.pais,m.div).map(c=>{
      const ch=chaveFixa(m.pais,c[0]);if(!ch)return"";
      const meu=(m.pais===S.pais&&S.clubes[S.meu]&&S.clubes[S.meu].nome===c[0]);
      return`<div class="clube" ${meu?'style="opacity:.5"':`onclick="S.merc={tela:'clube',pais:'${m.pais}',div:${ch.div},idx:${ch.idx}};render()"`}><span>${escudo({nome:c[0],cor:c[2],cor2:c[3]},20)} ${c[0]}</span><span class="tag">${meu?'seu clube':c[1]}</span></div>`}).join("")+`</div>`;
  }else if(m.tela==="clube"){
    const cl=elencoDe(m.pais,m.div,m.idx);
    h+=`<button class="s sm" onclick="S.merc={tela:'clubes',pais:'${m.pais}',div:${divDoClube(m.pais,cl.nome)!=null?divDoClube(m.pais,cl.nome):m.div}};render()">← Clubes</button><div class="card"><h3>${escudo(cl,20)} ${cl.nome}</h3><div class="tag">${LIGANOME[m.pais][m.div]} · ${iconeFama(cl.nome)} ${nomeFama(cl.nome)}</div>
    <table style="margin-top:8px"><tr><th>Pos</th><th>Nome</th><th>F</th><th>Id</th><th>Valor</th><th></th></tr>`+
    [...cl.elenco].sort((a,b)=>POS_ORD(a.pos)-POS_ORD(b.pos)||b.f-a.f).map(j=>`<tr><td><span class="tag">${j.pos}</span></td><td>${j.nome}${j.emprestado?' 🔁':''}</td><td class="y">${j.f}</td><td>${j.idade}</td><td>${R$(Math.round(j.val))}</td><td><button class="sm" onclick="abreNegocio('${m.pais}',${m.div},${m.idx},'${j.id}')">Negociar</button>${(cl.id!=null&&!cl.ext&&m.pais===S.pais&&S.clubes[cl.id]===cl&&cl.id!==S.meu)?` <button class="sm s" onclick="abrePermuta(${cl.id},'${j.id}')">🔄</button>`:''}</td></tr>`).join("")+`</table></div>`;
  }else if(m.tela==="meus"){
    const eu=S.clubes[S.meu];
    h+=`<div class="card"><h3>Emprestar jogador do meu elenco</h3><small class="mu">Escolha um jogador, depois o clube que vai recebê-lo (1 ano).</small><table style="margin-top:6px"><tr><th>Pos</th><th>Nome</th><th>F</th><th></th></tr>`+
    eu.elenco.filter(j=>!j.emprestado).sort((a,b)=>POS_ORD(a.pos)-POS_ORD(b.pos)).map(j=>`<tr><td><span class="tag">${j.pos}</span></td><td>${j.nome}</td><td class="y">${j.f}</td><td><button class="sm s" onclick="emprestaMeu('${j.id}')">Emprestar</button></td></tr>`).join("")+`</table></div>`;
  }else{
    const itens=(S.mercado||[]).map((it,k)=>{
      try{
        if(it.t==="raro"){const j=it.j;return{k,tipo:"raro",j,pos:j.pos,nome:j.nome,f:j.f,idade:j.idade,hab:j.hab,preco:Math.round(j.val),origem:j.origem+" · "+j.paisOrigem,cor:"#f5c542"}}
        if(it.t==="mundo"){const c=clubeMundo(it.pais,it.div,it.idx),j=c.elenco.find(x=>x.id===it.id);if(!j)return null;return{k,tipo:"mundo",j,c,it,pos:j.pos,nome:j.nome,f:j.f,idade:j.idade,hab:j.hab,preco:Math.round(precoPedido(c,j)),origem:c.nome+" · "+it.pais,cor:c.cor}}
        const c=S.clubes.find(x=>x.id===(it.clubeId!=null?it.clubeId:it.clubeId));const j=c&&c.elenco.find(x=>x.id===it.id);if(!j)return null;
        return{k,tipo:"liga",j,c,it,pos:j.pos,nome:j.nome,f:j.f,idade:j.idade,hab:j.hab,preco:Math.round(precoPedido(c,j)),origem:c.nome+" · "+S.pais,cor:c.cor}
      }catch(e){return null}
    }).filter(Boolean);
    const filtro=S.mercFiltro||"todos";
    const lst=itens.filter(x=>filtro==="todos"||(filtro==="raros"&&x.tipo==="raro")||(filtro==="liga"&&x.tipo==="liga")||(filtro==="mundo"&&x.tipo!=="liga"));
    h+=`<div class="elOrd">${[["todos","Todos"],["raros","⭐ Raros"],["liga","Minha liga"],["mundo","Mundo"]].map(([k,n])=>`<button class="${filtro===k?'on':''}" onclick="S.mercFiltro='${k}';render()">${n}</button>`).join("")}</div>`;
    h+=`<div class="card"><div class="tag" style="margin-bottom:6px">Jogadores à venda · ${lst.length}</div>`;
    h+=lst.length?lst.map(x=>`<div class="mkL ${x.tipo==='raro'?'raro':''}"><span class="elP" style="background:${({GOL:'#f5c542',ZAG:'#4aa3ff',LD:'#4aa3ff',LE:'#4aa3ff',VOL:'#3ddc84',MEI:'#3ddc84',PE:'#ff7a59',ATA:'#ff5d5d'})[x.pos]||'#888'}">${x.pos}</span>
      <span class="mkN"><b>${x.nome}${x.tipo==='raro'?' ⭐':''}</b><small>${papelDe(x.j)} · ${x.idade} anos · ${(x.hab||[]).map(sig).join(' · ')}</small><small class="mkO">${x.origem}</small></span>
      <span class="mkP"><b>F${x.f}</b><small>${R$(x.preco)}</small><button class="sm" onclick="${x.tipo==='raro'?`compraRaro(${x.k})`:x.tipo==='mundo'?`abreNegocio('${x.it.pais}',${x.it.div},${x.it.idx},'${x.j.id}')`:`abreNegocio('${S.pais}',${S.div},${x.c.id},'${x.j.id}')`}">${x.tipo==='raro'?'Comprar':'Negociar'}</button></span></div>`).join(""):'<div class="mu" style="padding:8px">Nenhum jogador neste filtro.</div>';
    h+=`</div>`;
  }
  return h;
}


// ----- Negociação de qualquer jogador -----
function acharJogadorExt(pais,div,idx,id){
  const cl=elencoDe(pais,div,idx);const j=cl.elenco.find(x=>x.id===id);return{cl,j}
}
// quão "intocável" é o jogador no clube dele (0 = reserva sem importância; 1 = craque do time)
function importancia(cl,j){
  const ord=[...cl.elenco].sort((a,b)=>b.f-a.f);
  const rank=ord.findIndex(x=>x.id===j.id);
  const r=1-rank/Math.max(1,ord.length-1);          // 1 = melhor do elenco
  const goleiroUnico=(j.pos==="GOL"&&cl.elenco.filter(x=>x.pos==="GOL").sort((a,b)=>b.f-a.f)[0].id===j.id)?.15:0;
  return Math.max(0,Math.min(1,r*0.85+goleiroUnico));
}
function precoPedido(cl,j){ // valor pedido pelo clube dono
  const imp=importancia(cl,j);
  return Math.round(j.val*(1.0+imp*0.7));            // craque custa até 70% a mais que o valor de mercado
}
function chanceCompra(cl,j,oferta){
  const pedido=precoPedido(cl,j);const ratio=oferta/pedido;
  let ch=ratio>=1.15?1:ratio>=1?.8:ratio>=.9?.45:ratio>=.8?.15:.02;
  // jogador com contrato longo e muito importante: o clube resiste mais
  ch*=1-importancia(cl,j)*0.35*Math.min(1,(j.ct||1)/4);
  return Math.max(.01,Math.min(1,ch));
}
function abreNegocio(pais,div,idx,id){
  const {cl,j}=acharJogadorExt(pais,div,idx,id);if(!j)return aviso("Jogador não encontrado.");
  const pedido=precoPedido(cl,j);const imp=importancia(cl,j);
  const nivel=imp>.8?"Peça-chave":imp>.5?"Titular":imp>.25?"Rodízio":"Reserva";
  modal(`<h3>${j.nome}</h3><div class="tag">${j.pos} · F${j.f} · ${j.idade} anos</div>
  <div class="ln2 row"><span>Clube</span><b>${escudo(cl,14)} ${cl.nome}</b></div>
  <div class="ln2 row"><span>Importância no clube</span><b>${nivel}</b></div>
  <div class="ln2 row"><span>Valor de mercado</span><b>${R$(Math.round(j.val))}</b></div>
  <div class="ln2 row"><span>Contrato</span><b>${j.ct||1} ano(s)</b></div>
  <div class="ln2 row"><span>Preço pedido</span><b class="y">${R$(pedido)}</b></div>
  <div class="row" style="margin-top:12px"><button onclick="fechaDlg();negociaCompraExt('${pais}',${div},${idx},'${id}')">💰 Comprar</button><button class="s" onclick="fechaDlg();negociaEmprestimoExt('${pais}',${div},${idx},'${id}')">🔁 Emprestar</button></div>
  <button class="s big" onclick="fechaDlg()">Fechar</button>`);
}
function marcaAlterado(cl){if(cl&&cl.ext){cl.mexido=true;cl.compacto=false;if(!S.ext)S.ext={};S.ext[chaveClube(cl.pais,cl.div,cl.idx)]=cl}}
function removeDoClubeExt(cl,j){cl.elenco=cl.elenco.filter(x=>x.id!==j.id);marcaAlterado(cl)}


// ===== BUSCA DE JOGADORES NO MUNDO (filtros) =====
// S.busca = {fMin,fMax,iMin,iMax,pMin,pMax,pos,pais,hab,ordem}; resultados guardados em S._resBusca (não salva)
const BUSCA_PADRAO={fMin:"",fMax:"",iMin:"",iMax:"",pMin:"",pMax:"",pos:"",pais:"",hab:"",ordem:"f"};

// Congela a identidade de todos os clubes do mundo (uma única vez por jogo). Em lotes para não travar o celular.
function congelaMundoEmLotes(onFim){
  if(!S.mundo)S.mundo={};
  if(S.mundoCongelado){if(onFim)onFim();return}
  const lista=[];
  Object.keys(LIGAS).forEach(pais=>LIGAS[pais].forEach((lst,dv)=>lst.forEach((c,idx)=>{
    if(pais===S.pais&&S.clubes.find(x=>x.nome===c[0]))return;
    lista.push({pais,dv,idx});
  })));
  let pos=0;const TOTAL=lista.length,LOTE=30;
  (function passo(){
    const fim=Math.min(TOTAL,pos+LOTE);
    for(;pos<fim;pos++){
      const {pais,dv,idx}=lista[pos];
      try{
        const k=chaveClube(pais,dv,idx);
        if(S.ext&&S.ext[k]&&S.ext[k].mexido)continue;
        if(!S.mundo[k])S.mundo[k]=criaEstadoMundo(k,picoClube(pais,dv,idx));
        else if(S.mundo[k].c.some(t=>t[7]==null)){            // save antigo: congela a identidade que o código gera agora
          const base=baseMundo(k,S.mundo[k].pico);
          S.mundo[k].c.forEach((t,i)=>{if(t[7]==null){const b=(t[5]||0)===0?base[i]:jogadorDeGeracao(k,i,t[5],S.mundo[k].pico);t[6]=idParaNum(b.id);t[7]=empacotaIdent(b)}});
        }
      }catch(e){}
    }
    S._prog={feito:pos,total:TOTAL,msg:"Preparando o mundo"};
    if(pos<TOTAL){atualizaProgBusca();setTimeout(passo,0);return}
    S.mundoCongelado=true;S._prog=null;
    try{save()}catch(e){}
    if(onFim)onFim();
  })();
}

function buscaJogadores(onFim){
  const B=Object.assign({},BUSCA_PADRAO,S.busca||{});
  const num=v=>v===""||v==null||isNaN(+v)?null:+v;
  const fMin=num(B.fMin),fMax=num(B.fMax),iMin=num(B.iMin),iMax=num(B.iMax);
  const pMin=num(B.pMin)!=null?num(B.pMin)*1e6:null,pMax=num(B.pMax)!=null?num(B.pMax)*1e6:null;
  const cand=[];
  Object.keys(LIGAS).forEach(pais=>{
    if(B.pais&&B.pais!==pais)return;
    LIGAS[pais].forEach((lst,dv)=>lst.forEach((c,idx)=>{
      if(pais===S.pais&&S.clubes.find(x=>x.nome===c[0]))return;
      const k=chaveClube(pais,dv,idx);
      let linhas;
      if(S.ext&&S.ext[k]&&S.ext[k].mexido)linhas=S.ext[k].elenco.map((j,slot)=>[j.idade,Math.round(j.f*10),j.pot,0,0,0,null,null,j.pos,j.id]);   // clube alterado
      else{const e=S.mundo&&S.mundo[k];if(!e)return;linhas=e.c.map((t,slot)=>[t[0],t[1],t[2],0,0,0,t[6],t[7],POS22[slot],null])}                   // só números
      const mk=fatorMercado(pais,dv);
      linhas.forEach((t,slot)=>{
        const idade=t[0],f=Math.round(t[1]/10),pot=t[2];
        if(fMin!=null&&f<fMin)return;if(fMax!=null&&f>fMax)return;
        if(iMin!=null&&idade<iMin)return;if(iMax!=null&&idade>iMax)return;
        if(B.pos&&t[8]!==B.pos)return;
        const preco=valorDe(f,idade,pot,mk);
        if(pMin!=null&&preco<pMin)return;if(pMax!=null&&preco>pMax)return;
        if(B.hab&&t[7]!=null){const d=desempacotaIdent(t[7]);if(!d.hab.includes(B.hab))return}
        cand.push({pais,dv,idx,slot,f,idade,preco});
      });
    }));
  });
  cand.forEach((x,i)=>{x.n=i});                                                   // posição original: desempate estável
  window._resBusca={cand,total:cand.length,pagina:0,ordem:B.ordem||"f",cache:{}};  // lista COMPLETA (números); fora do save
  ordenaBusca();
  if(onFim)onFim();
}
// ordena a lista inteira (sem refazer a busca) e volta à página 1
function ordenaBusca(modo){
  const R=window._resBusca;if(!R)return;
  if(modo)R.ordem=modo;
  const o=R.ordem;
  const chave={f:(a,b)=>b.f-a.f||a.idade-b.idade||a.n-b.n,
    idade:(a,b)=>a.idade-b.idade||b.f-a.f||a.n-b.n,
    preco:(a,b)=>a.preco-b.preco||b.f-a.f||a.n-b.n,
    precoDesc:(a,b)=>b.preco-a.preco||b.f-a.f||a.n-b.n}[o]||((a,b)=>b.f-a.f||a.n-b.n);
  R.cand.sort(chave);R.pagina=0;R.cache={};
  if(S.busca)S.busca.ordem=o;
}
const BUSCA_POR_PAGINA=20;
function paginaBusca(p){
  const R=window._resBusca;if(!R)return;
  const tot=Math.max(1,Math.ceil(R.total/BUSCA_POR_PAGINA));
  R.pagina=Math.max(0,Math.min(tot-1,p));
  render();
  const el=document.getElementById("buscaTopo");if(el)el.scrollIntoView({block:"start"});
}
// monta por inteiro SÓ os jogadores da página atual (e guarda na memória enquanto a busca durar)
function jogadoresDaPagina(){
  const R=window._resBusca;if(!R)return[];
  const ini=R.pagina*BUSCA_POR_PAGINA,fatia=R.cand.slice(ini,ini+BUSCA_POR_PAGINA),out=[];
  fatia.forEach(x=>{
    const ck=x.pais+"|"+x.dv+"|"+x.idx+"|"+x.slot;
    if(R.cache[ck]){out.push(R.cache[ck]);return}
    try{
      const cl=clubeMundo(x.pais,x.dv,x.idx);const j=cl.elenco[x.slot];if(!j)return;
      const it={pais:x.pais,div:x.dv,idx:x.idx,nome:cl.nome,j:{id:j.id,nome:j.nome,pos:j.pos,f:j.f,idade:j.idade,hab:j.hab,papel:papelDe(j),emprestado:!!j.emprestado},preco:Math.round(precoPedido(cl,j))};
      R.cache[ck]=it;out.push(it);
    }catch(e){}
  });
  return out;
}
function buscaCampo(k,rot,ph){const B=Object.assign({},BUSCA_PADRAO,S.busca||{});return`<label class="bsC"><span>${rot}</span><input type="number" inputmode="numeric" value="${B[k]}" placeholder="${ph||''}" oninput="(S.busca=S.busca||{}).${k}=this.value"></label>`}
function buscaHTML(){
  const B=Object.assign({},BUSCA_PADRAO,S.busca||{});
  const hab=Object.keys(HAB_SIGLA);
  let h=`<div class="card"><div class="tag" style="margin-bottom:8px">🔎 Pesquisar jogadores no mundo todo</div>
    <div class="bsG">${buscaCampo("fMin","Força mín.","ex.: 40")}${buscaCampo("fMax","Força máx.","ex.: 60")}${buscaCampo("iMin","Idade mín.","ex.: 18")}${buscaCampo("iMax","Idade máx.","ex.: 25")}${buscaCampo("pMin","Passe mín. (R$ mi)","ex.: 1")}${buscaCampo("pMax","Passe máx. (R$ mi)","ex.: 10")}</div>
    <div class="bsG"><label class="bsC"><span>Posição</span><select onchange="(S.busca=S.busca||{}).pos=this.value"><option value="">Todas</option>${["GOL","ZAG","LD","LE","VOL","MEI","PE","ATA"].map(p=>`<option ${B.pos===p?'selected':''}>${p}</option>`).join("")}</select></label>
      <label class="bsC"><span>País</span><select onchange="(S.busca=S.busca||{}).pais=this.value"><option value="">Todos</option>${Object.keys(LIGAS).map(p=>`<option ${B.pais===p?'selected':''}>${p}</option>`).join("")}</select></label>
      <label class="bsC"><span>Habilidade</span><select onchange="(S.busca=S.busca||{}).hab=this.value"><option value="">Qualquer</option>${hab.map(x=>`<option ${B.hab===x?'selected':''}>${x}</option>`).join("")}</select></label>
      <label class="bsC"><span>Ordenar por</span><select onchange="(S.busca=S.busca||{}).ordem=this.value">${[["f","Maior força"],["idade","Mais jovem"],["preco","Menor preço"],["precoDesc","Maior preço"]].map(([k,n])=>`<option value="${k}" ${B.ordem===k?'selected':''}>${n}</option>`).join("")}</select></label></div>
    <div class="row" style="margin-top:8px"><button onclick="rodaBusca()">🔎 Pesquisar</button><button class="s" onclick="S.busca=null;window._resBusca=null;window._buscaId=(window._buscaId||0)+1;S._prog=null;render()">Limpar</button></div></div>`;
  const R=window._resBusca;
  if(S._prog){h+=`<div class="card" id="buscaProg"><div class="cmBar"><i style="width:0%"></i></div><b style="font-size:12px">Pesquisando… 0%</b><div class="mu" style="font-size:11px;margin-top:4px">Preparando os jogadores do mundo (só na primeira vez). Depois as buscas são instantâneas.</div></div>`}
  if(R){
    const tot=Math.max(1,Math.ceil(R.total/BUSCA_POR_PAGINA)),pg=R.pagina,ini=pg*BUSCA_POR_PAGINA;
    const lista=jogadoresDaPagina();
    const orde=[["preco","preco","💰 Menor valor"],["precoDesc","precoDesc","💎 Maior valor"],["f","f","💪 Força"],["idade","idade","🎂 Idade"]];
    h+=`<div id="buscaTopo"></div><div class="elOrd">${orde.map(([id,m,n])=>`<button class="${R.ordem===m?'on':''}" onclick="ordenaBusca('${m}');render()">${n}</button>`).join("")}</div>`;
    h+=`<div class="card"><div class="tag" style="margin-bottom:6px">${R.total.toLocaleString("pt-BR")} jogador(es) encontrado(s)${R.total?` · ${ini+1} a ${Math.min(R.total,ini+BUSCA_POR_PAGINA)} · página ${pg+1} de ${tot}`:''}</div>`;
    h+=lista.length?lista.map(x=>`<div class="mkL"><span class="elP" style="background:${({GOL:'#f5c542',ZAG:'#4aa3ff',LD:'#4aa3ff',LE:'#4aa3ff',VOL:'#3ddc84',MEI:'#3ddc84',PE:'#ff7a59',ATA:'#ff5d5d'})[x.j.pos]||'#888'}">${x.j.pos}</span>
      <span class="mkN"><b>${x.j.nome}</b><small>${x.j.papel||''} · ${x.j.idade} anos · ${(x.j.hab||[]).map(sig).join(' · ')}</small><small class="mkO">${x.nome} · ${x.pais}</small></span>
      <span class="mkP"><b>F${x.j.f}</b><small>${R$(x.preco)}</small><button class="sm" onclick="abreNegocio('${x.pais}',${x.div},${x.idx},'${x.j.id}')">Negociar</button></span></div>`).join(""):'<div class="mu" style="padding:8px">Nenhum jogador com esses filtros. Tente ampliar as faixas.</div>';
    h+=`</div>`;
    if(tot>1)h+=paginadorHTML(pg,tot);
  }
  return h;
}

function paginadorHTML(pg,tot){
  const nums=new Set([0,1,tot-2,tot-1,pg-1,pg,pg+1]);
  const lista=[...nums].filter(n=>n>=0&&n<tot).sort((a,b)=>a-b);
  let btns="",ant=-1;
  lista.forEach(n=>{if(ant>=0&&n-ant>1)btns+=`<span class="pgE">…</span>`;btns+=`<button class="${n===pg?'on':''}" onclick="paginaBusca(${n})">${n+1}</button>`;ant=n});
  return`<div class="pgR"><button ${pg===0?'disabled':''} onclick="paginaBusca(0)">«</button><button ${pg===0?'disabled':''} onclick="paginaBusca(${pg-1})">‹</button>${btns}<button ${pg>=tot-1?'disabled':''} onclick="paginaBusca(${pg+1})">›</button><button ${pg>=tot-1?'disabled':''} onclick="paginaBusca(${tot-1})">»</button></div>
  <div class="pgI"><span>Ir para a página</span><input type="number" inputmode="numeric" min="1" max="${tot}" placeholder="1-${tot}" onkeydown="if(event.key==='Enter')paginaBusca((parseInt(this.value)||1)-1)"><button onclick="paginaBusca((parseInt(this.previousElementSibling.value)||1)-1)">Ir</button></div>`;
}

function rodaBusca(){
  window._resBusca=null;
  const iniciaBusca=()=>{try{buscaJogadores(()=>{S._prog=null;render()})}catch(e){S._prog=null;window._resBusca={cand:[],total:0,pagina:0,ordem:"f",cache:{}};aviso("Não consegui concluir a busca: "+e.message);render()}};
  if(!S.mundoCongelado){S._prog={feito:0,total:1};render();setTimeout(()=>congelaMundoEmLotes(()=>{render();iniciaBusca()}),40)}
  else{toast("Pesquisando…");setTimeout(iniciaBusca,20)}
}
function atualizaProgBusca(){
  const el=document.getElementById("buscaProg");if(!el||!S._prog)return;
  const pc=Math.round(S._prog.feito/Math.max(1,S._prog.total)*100);
  el.querySelector("i").style.width=pc+"%";el.querySelector("b").textContent=(S._prog.msg||"Pesquisando")+"… "+pc+"%";
}


function compraRaro(k){
  const it=(S.mercado||[])[k];if(!it||it.t!=="raro")return;const j=it.j,eu=S.clubes[S.meu];
  if(elencoCheio(eu))return avisoCheio();
  const pedido=Math.round(j.val);
  pergunta(`Oferta por ${j.nome} (em mil R$).\nVem de: ${j.origem} (${j.paisOrigem}).\nPreço pedido: ${Math.round(pedido/1000)} mil`,Math.round(pedido*.95/1000),o=>{
    const v=parseFloat(o)*1000;if(!v)return;
    if(v>eu.caixa)return aviso("Caixa insuficiente.");
    if(v<pedido*.85)return aviso(`${j.origem} recusou: a oferta está muito abaixo do pedido.`);
    if(v<pedido&&R()>.55)return aviso(`${j.origem} recusou a oferta por ${j.nome}.`);
    const sal=Math.round(j.sal*1000*rnd(100,125)/100);
    pergunta(`${j.origem} aceitou!\nSalário: ${R$(sal)}/mês.\nContrato (1 a 5 anos):`,3,a=>{
      const an=Math.max(1,Math.min(5,parseInt(a)||3));
      confirma(`Fechar: ${j.nome} por ${R$(v)}, ${an} ano(s)?`,()=>{
        eu.caixa-=v;finDesp('Compra de jogadores',v);
        const novo={...j,ct:an,en:100,tit:false,gols:0,raro:false};delete novo.origem;delete novo.paisOrigem;
        novo.mk=fatorMercado(S.pais,S.div);novo.val=valorDe(novo.f,novo.idade,novo.pot,novo.mk);novo.sal=Math.round(sal/1000);
        jogadorNovoNoClube(novo);eu.elenco.push(novo);S.mercado.splice(k,1);auto(eu,true);save();render();toast(novo.nome+" é seu!");
      });
    });
  });
}
function negociaCompraExt(pais,div,idx,id){
  const {cl,j}=acharJogadorExt(pais,div,idx,id);if(!j)return;
  const eu=S.clubes[S.meu];
  if(elencoCheio(eu))return avisoCheio();
  const pedido=precoPedido(cl,j);
  pergunta(`Oferta por ${j.nome} (em mil R$).\nPreço pedido: ${Math.round(pedido/1000)} mil`,Math.round(pedido*.9/1000),o=>{
    const v=parseFloat(o)*1000;if(!v)return;
    if(v>eu.caixa)return aviso("Caixa insuficiente.");
    if(R()>chanceCompra(cl,j,v))return aviso(`${cl.nome} recusou a oferta por ${j.nome}.`);
    const sal=Math.round(j.sal*1000*rnd(100,130)/100);
    pergunta(`${cl.nome} aceitou!\nSalário: ${R$(sal)}/mês.\nContrato (1 a 5 anos):`,3,a=>{
      const an=Math.max(1,Math.min(5,parseInt(a)||3));
      confirma(`Fechar: ${j.nome} por ${R$(v)}, ${an} ano(s)?`,()=>{
        eu.caixa-=v;finDesp('Compra de jogadores',v);removeDoClubeExt(cl,j);
        const novo={...j,ct:an,en:100,tit:false,gols:0};delete novo.px;delete novo.py;delete novo._slot;delete novo._role;
        jogadorNovoNoClube(novo);eu.elenco.push(novo);if(cl.id!=null&&!cl.ext){cl.caixa+=v}
        S.merc={tela:'clubes',pais,div,idx};auto(eu,true);save();render();toast(j.nome+" é seu!");
      });
    });
  });
}
// ----- Empréstimo com opção de compra -----
function taxaEmprestimo(cl,j){return Math.round(j.val*(0.06+importancia(cl,j)*0.10))}   // 6% a 16% do valor
function precoOpcao(cl,j){return Math.round(precoPedido(cl,j)*0.9)}
function chanceEmprestimo(cl,j,taxa){
  const t0=taxaEmprestimo(cl,j),ratio=taxa/t0;
  let ch=ratio>=1.3?.95:ratio>=1?.7:ratio>=.8?.3:.05;
  ch*=1-importancia(cl,j)*0.55;                   // clube raramente empresta seu craque
  if(j.idade<=21)ch*=.7;                          // joia jovem: clube resiste
  return Math.max(.01,Math.min(.97,ch));
}
function negociaEmprestimoExt(pais,div,idx,id){
  const {cl,j}=acharJogadorExt(pais,div,idx,id);if(!j)return;
  const eu=S.clubes[S.meu];
  if(elencoCheio(eu))return avisoCheio();
  const t0=taxaEmprestimo(cl,j);
  pergunta(`Empréstimo de ${j.nome} por 1 ano.\nTaxa de empréstimo sugerida: ${Math.round(t0/1000)} mil.\nOferta de taxa (em mil R$):`,Math.round(t0/1000),o=>{
    const taxa=parseFloat(o)*1000;if(!taxa)return;
    if(taxa>eu.caixa)return aviso("Caixa insuficiente.");
    if(R()>chanceEmprestimo(cl,j,taxa))return aviso(`${cl.nome} recusou emprestar ${j.nome}.`);
    const opcao=precoOpcao(cl,j);
    confirma(`${cl.nome} aceitou emprestar ${j.nome} por 1 ano.\nTaxa: ${R$(taxa)}\nVocê paga o salário dele.\nOpção de compra no fim: ${R$(opcao)}`,()=>{
      eu.caixa-=taxa;finDesp('Empréstimos de jogadores',taxa);removeDoClubeExt(cl,j);
      const novo={...j,en:100,tit:false,emprestado:true,donoPais:pais,donoDiv:div,donoIdx:idx,donoNome:cl.nome};
      delete novo.px;delete novo.py;delete novo._slot;delete novo._role;
      jogadorNovoNoClube(novo);eu.elenco.push(novo);
      if(!S.emprest)S.emprest=[];
      S.emprest.push({jid:novo.id,nome:novo.nome,sentido:"entrada",clube:cl.nome,pais,div,idx,compra:opcao,ate:"fim da temporada",temp:S.temp});
      S.merc={tela:'clubes',pais,div,idx};auto(eu,true);save();render();toast(j.nome+" chegou por empréstimo");
    });
  });
}
function exerceCompra(i){
  const e=(S.emprest||[])[i];if(!e||e.sentido!=="entrada")return;
  const eu=S.clubes[S.meu],j=eu.elenco.find(x=>x.id===e.jid);if(!j)return aviso("Jogador não está mais no elenco.");
  if(eu.caixa<e.compra)return aviso("Caixa insuficiente para exercer a opção de compra.");
  confirma(`Comprar ${j.nome} definitivamente por ${R$(e.compra)}?`,()=>{
    eu.caixa-=e.compra;finDesp('Compra de jogadores',e.compra);j.emprestado=false;delete j.donoPais;delete j.donoDiv;delete j.donoIdx;delete j.donoNome;j.ct=3;
    S.emprest.splice(i,1);save();render();toast(j.nome+" é seu definitivamente");
  });
}
// ----- Emprestar jogador MEU para outro clube -----
function emprestaMeu(id){
  const eu=S.clubes[S.meu],j=eu.elenco.find(x=>x.id===id);if(!j)return;
  if(eu.elenco.length<=16)return aviso("Elenco mínimo: 16 jogadores.");
  // propõe 3 clubes da mesma liga com interesse (os que mais precisam da posição)
  const alvos=S.clubes.filter(c=>c.id!==S.meu).sort(()=>R()-.5).slice(0,3);
  const ofertas=alvos.map(c=>({c,taxa:Math.round(j.val*(0.05+R()*0.08)),compra:Math.round(j.val*(1.0+R()*0.3))}));
  window._ofs=ofertas;window._jid=id;
  modal(`<h3>Emprestar ${j.nome}</h3><div class="mu" style="font-size:12px;margin-bottom:8px">Clubes interessados (1 ano). Você recebe a taxa; o salário passa a ser deles.</div>`+
    ofertas.map((o,k)=>`<div class="clube" onclick="confirmaEmprestaMeu(${k})"><span>${escudo(o.c,18)} ${o.c.nome}</span><span class="tag">${R$(o.taxa)}</span></div>`).join("")+
    `<button class="s big" onclick="fechaDlg()">Cancelar</button>`);
}
function confirmaEmprestaMeu(k){
  fechaDlg();
  const o=window._ofs[k],eu=S.clubes[S.meu],j=eu.elenco.find(x=>x.id===window._jid);if(!j)return;
  confirma(`Emprestar ${j.nome} ao ${o.c.nome} por 1 ano?\nVocê recebe ${R$(o.taxa)}.\nOpção de compra deles: ${R$(o.compra)}.`,()=>{
    eu.caixa+=o.taxa;finRec('Empréstimo de jogadores',o.taxa);
    eu.elenco=eu.elenco.filter(x=>x.id!==j.id);
    const cp={...j,emprestado:true,donoNome:eu.nome,donoMeu:true,tit:false};delete cp.px;delete cp.py;delete cp._slot;delete cp._role;
    o.c.elenco.push(cp);
    if(!S.emprest)S.emprest=[];
    S.emprest.push({jid:j.id,nome:j.nome,sentido:"saida",clube:o.c.nome,clubeId:o.c.id,compra:o.compra,ate:"fim da temporada",temp:S.temp,jogador:{...j}});
    auto(eu,true);save();render();toast(j.nome+" foi emprestado");
  });
}
// ----- Fim da temporada: o empréstimo termina -----
function resolveEmprestimos(){
  if(!S.emprest||!S.emprest.length)return;
  const eu=S.clubes[S.meu],avisos=[];
  S.emprest.forEach(e=>{
    if(e.sentido==="entrada"){
      // jogador volta ao clube dono (se não foi comprado)
      const j=eu.elenco.find(x=>x.id===e.jid);
      if(j&&j.emprestado){
        eu.elenco=eu.elenco.filter(x=>x.id!==e.jid);
        const dono=(()=>{try{return elencoDe(e.pais,e.div,e.idx)}catch(err){return null}})();
        const volta={...j,emprestado:false,tit:false};["donoPais","donoDiv","donoIdx","donoNome"].forEach(k=>delete volta[k]);delete volta.px;delete volta.py;delete volta._slot;delete volta._role;
        if(dono){dono.elenco.push(volta);marcaAlterado(dono)}
        avisos.push(j.nome+" voltou ao "+e.clube);
      }
    }else{
      // jogador meu volta de um clube da minha liga (ou, se o clube foi extinto, recria)
      const cl=S.clubes.find(c=>c.id===e.clubeId||c.nome===e.clube);
      if(cl){
        const j=cl.elenco.find(x=>x.id===e.jid);
        if(j){cl.elenco=cl.elenco.filter(x=>x.id!==e.jid);}
      }
      const orig=e.jogador;
      if(orig&&!eu.elenco.find(x=>x.id===e.jid)){const v={...orig,emprestado:false,tit:false,ct:Math.max(1,(orig.ct||1))};delete v.px;delete v.py;delete v._slot;delete v._role;eu.elenco.push(v);avisos.push(orig.nome+" voltou do empréstimo no "+e.clube)}
    }
  });
  S.emprest=[];
  if(avisos.length)setTimeout(()=>aviso("🔁 Fim dos empréstimos:\n"+avisos.join("\n")),400);
}


// ===== ELENCOS FIXOS · HABILIDADES · EVOLUÇÃO · ESTRELAS =====
// Mundo fixo: toda a geração usa uma semente guardada no jogo (S.seed). Mesmo clube + mesma semente = mesmo elenco, sempre.
function novaSemente(){return Math.floor(Math.random()*4294967295)>>>0}
function rngClube(chave){return rngSeed(semente(chave+"|"+(S&&S.seed!=null?S.seed:0)))}
const PICO_LIGA={Inglaterra:61,Espanha:60,Itália:59,Alemanha:59,França:57,Portugal:55,Holanda:55,Bélgica:53,Turquia:53,Escócia:51,Rússia:52,Brasil:47,Argentina:46,Colômbia:43,Chile:42,Uruguai:41,México:44,"Estados Unidos":42,Japão:43,"Arábia Saudita":45};   // v38: Europa ≈ 20 pontos acima da América do Sul
const DESCE_DIV=[0,10,20];                       // v38: 2ª div. 10 pontos abaixo; 3ª div. 20 abaixo da 1ª
function picoDe(pais,div){const d=(DESCE_DIV[div]!=null?DESCE_DIV[div]:20);return Math.max(26,(PICO_LIGA[pais]||47)-d)}   // v39: o zero da 1ª divisão não pode virar 'reserva'
// Catálogo de habilidades por posição: ideal / boa / fraca
const HAB_POS={
 GOL:{ideal:[["Reflexos","Posicionamento"]],bom:[["Reflexos","Saída de bola"],["Posicionamento","Jogo aéreo"],["Pênaltis","Reflexos"]],fraco:[["Chute longo","Saída de bola"],["Jogo aéreo","Chute longo"]]},
 ZAG:{ideal:[["Desarme","Marcação"],["Cabeceio","Marcação"]],bom:[["Desarme","Cabeceio"],["Marcação","Passe longo"],["Cabeceio","Antecipação"]],fraco:[["Velocidade","Drible"],["Finalização","Passe"]]},
 LD:{ideal:[["Velocidade","Cruzamento"],["Marcação","Velocidade"]],bom:[["Cruzamento","Resistência"],["Desarme","Velocidade"]],fraco:[["Cabeceio","Finalização"],["Chute longo","Cabeceio"]]},
 LE:{ideal:[["Velocidade","Cruzamento"],["Marcação","Velocidade"]],bom:[["Cruzamento","Resistência"],["Desarme","Velocidade"]],fraco:[["Cabeceio","Finalização"],["Chute longo","Cabeceio"]]},
 VOL:{ideal:[["Desarme","Marcação"]],bom:[["Desarme","Passe"],["Marcação","Resistência"],["Passe","Chute longo"]],fraco:[["Finalização","Drible"],["Velocidade","Finalização"]]},
 MEI:{ideal:[["Passe","Finalização"],["Passe","Visão de jogo"]],bom:[["Passe","Drible"],["Finalização","Chute longo"],["Visão de jogo","Drible"]],fraco:[["Desarme","Marcação"],["Cabeceio","Marcação"]]},
 PE:{ideal:[["Velocidade","Drible"],["Cruzamento","Drible"]],bom:[["Velocidade","Finalização"],["Cruzamento","Passe"],["Drible","Finalização"]],fraco:[["Cabeceio","Marcação"],["Desarme","Marcação"]]},
 ATA:{ideal:[["Cabeceio","Finalização"]],bom:[["Velocidade","Finalização"],["Drible","Finalização"],["Velocidade","Passe"],["Finalização","Chute longo"]],fraco:[["Desarme","Marcação"],["Passe longo","Marcação"],["Cruzamento","Resistência"]]}
};
const HAB_GRUPO={Finalização:"gol",Cabeceio:"gol","Chute longo":"gol",Velocidade:"criar",Drible:"criar",Passe:"criar","Visão de jogo":"criar",Cruzamento:"criar","Passe longo":"criar","Saída de bola":"criar",
  Desarme:"defesa",Marcação:"defesa",Antecipação:"defesa",Reflexos:"goleiro",Posicionamento:"goleiro","Jogo aéreo":"goleiro",Pênaltis:"goleiro",Resistência:"energia"};

// ===== PAPÉIS (funções) DOS JOGADORES — características reais por posição (v36) =====
// Cada papel: [nome, [2 habilidades ideais], peso]. Perfis coerentes dominam; uma minoria sai com combinação ruim.
const PAPEIS={
 GOL:[["Goleiro de reflexos",["Reflexos","Posicionamento"],30],["Goleiro líbero",["Saída de bola","Posicionamento"],18],["Goleiro das alturas",["Jogo aéreo","Reflexos"],18],["Pegador de pênaltis",["Pênaltis","Reflexos"],12]],
 ZAG:[["Xerife",["Desarme","Marcação"],26],["Zagueiro aéreo",["Cabeceio","Marcação"],22],["Zagueiro de antecipação",["Antecipação","Desarme"],16],["Zagueiro construtor",["Passe longo","Marcação"],14]],
 LD:[["Lateral ofensivo",["Velocidade","Cruzamento"],26],["Lateral defensivo",["Marcação","Desarme"],26],["Ala incansável",["Resistência","Cruzamento"],18],["Lateral que finaliza",["Velocidade","Finalização"],8]],
 LE:[["Lateral ofensivo",["Velocidade","Cruzamento"],26],["Lateral defensivo",["Marcação","Desarme"],26],["Ala incansável",["Resistência","Cruzamento"],18],["Lateral que finaliza",["Velocidade","Finalização"],8]],
 VOL:[["Volante marcador",["Desarme","Marcação"],30],["Volante que sai jogando",["Desarme","Passe"],22],["Regista",["Passe longo","Passe"],14],["Volante de força",["Resistência","Marcação"],14]],
 MEI:[["Armador",["Passe","Visão de jogo"],26],["Meia finalizador",["Passe","Finalização"],22],["Meia driblador",["Drible","Passe"],18],["Meia de chute de longe",["Chute longo","Finalização"],12]],
 PE:[["Ponta veloz",["Velocidade","Drible"],28],["Ponta cruzador",["Cruzamento","Drible"],24],["Ponta finalizador",["Velocidade","Finalização"],20],["Ponta criador",["Cruzamento","Passe"],12]],
 ATA:[["Centroavante completo",["Cabeceio","Finalização"],26],["Matador",["Finalização","Chute longo"],20],["Atacante veloz",["Velocidade","Finalização"],20],["Atacante driblador",["Drible","Finalização"],14],["Atacante que passa e finaliza",["Passe","Finalização"],10]]
};
// habilidade-chave por posição (a que define a função) e complementos compatíveis (para o perfil 'bom')
const CHAVE_POS={GOL:["Reflexos","Posicionamento","Saída de bola","Jogo aéreo","Pênaltis"],ZAG:["Marcação","Desarme","Cabeceio","Antecipação","Passe longo"],LD:["Velocidade","Marcação","Cruzamento","Resistência","Desarme"],LE:["Velocidade","Marcação","Cruzamento","Resistência","Desarme"],VOL:["Desarme","Marcação","Passe","Passe longo","Resistência"],MEI:["Passe","Visão de jogo","Finalização","Drible","Chute longo"],PE:["Velocidade","Drible","Cruzamento","Finalização","Passe"],ATA:["Finalização","Cabeceio","Velocidade","Drible","Passe"]};
const COMPLEMENTO={GOL:["Reflexos","Posicionamento","Jogo aéreo","Saída de bola","Pênaltis"],ZAG:["Desarme","Marcação","Cabeceio","Antecipação","Passe longo"],LD:["Velocidade","Cruzamento","Marcação","Desarme","Resistência","Drible"],LE:["Velocidade","Cruzamento","Marcação","Desarme","Resistência","Drible"],VOL:["Desarme","Marcação","Passe","Passe longo","Resistência","Antecipação"],MEI:["Passe","Visão de jogo","Finalização","Drible","Chute longo","Passe longo"],PE:["Velocidade","Drible","Cruzamento","Finalização","Passe"],ATA:["Finalização","Cabeceio","Velocidade","Drible","Chute longo","Passe"]};
// combinações ruins (o jogador "fora do perfil"): ainda existem, mas são minoria
const PAPEIS_RUINS={
 GOL:[["Goleiro de linha",["Chute longo","Saída de bola"]]],
 ZAG:[["Zagueiro driblador",["Velocidade","Drible"]],["Zagueiro finalizador",["Finalização","Passe"]]],
 LD:[["Lateral improvisado",["Cabeceio","Finalização"]]],LE:[["Lateral improvisado",["Cabeceio","Finalização"]]],
 VOL:[["Volante improvisado",["Finalização","Drible"]],["Volante sem marcação",["Velocidade","Finalização"]]],
 MEI:[["Meia que só marca",["Desarme","Marcação"]],["Meia cabeceador",["Cabeceio","Marcação"]]],
 PE:[["Ponta sem drible",["Cabeceio","Marcação"]],["Ponta lento",["Desarme","Marcação"]]],
 ATA:[["Atacante limitado",["Cabeceio","Passe"]],["Atacante sem finalização",["Velocidade","Passe"]],["Atacante lento",["Passe longo","Marcação"]]]
};
// sorteio com 2 números do gerador (mesmo consumo do sistema anterior → o resto do elenco não muda)
function sorteiaHab(pos,rg){
  const a=rg(),b=rg();
  const ruins=PAPEIS_RUINS[pos]||PAPEIS_RUINS.MEI;
  if(a<.14){const p=ruins[Math.floor(b*ruins.length)];return{hab:p[1].slice(),cat:"fraco",papel:p[0]}}
  const lst=PAPEIS[pos]||PAPEIS.MEI;
  const tot=lst.reduce((q,x)=>q+x[2],0);
  const x=((a-.14)/.86)*tot;                       // reaproveita 'a' para escolher o papel
  let acc=0,p=lst[lst.length-1];
  for(const it of lst){acc+=it[2];if(x<=acc){p=it;break}}
  const ideal=b<.55;                               // 'b' decide ideal (55%) ou bom (45%)
  let hab=p[1].slice();
  if(!ideal){const ch=CHAVE_POS[pos]||[];const chave=p[1].slice().sort((x,y)=>(ch.indexOf(x)<0?9:ch.indexOf(x))-(ch.indexOf(y)<0?9:ch.indexOf(y)))[0];const pool=(COMPLEMENTO[pos]||[]).filter(h=>h!==chave).slice().sort();const u=(a*1e6)%1;hab=[chave,pool[Math.floor(u*pool.length)]]}
  return{hab,cat:ideal?"ideal":"bom",papel:p[0]};
}

// descobre o papel de um jogador que já tem habilidades (jogadores antigos, de reposição ou editados)
function papelDe(j){
  if(j.papel)return j.papel;
  const h=j.hab||[];
  const lst=(PAPEIS[j.pos]||[]).concat((PAPEIS_RUINS[j.pos]||[]).map(x=>[x[0],x[1],0]));
  let melhor=null,mp=0;
  lst.forEach(p=>{const m=p[1].filter(x=>h.includes(x)).length;if(m>mp){mp=m;melhor=p[0]}});
  return melhor||({GOL:"Goleiro",ZAG:"Zagueiro",LD:"Lateral",LE:"Lateral",VOL:"Volante",MEI:"Meia",PE:"Ponta",ATA:"Atacante"})[j.pos]||j.pos;
}
const FUNC_CURTA={GOL:"Goleiro",ZAG:"Zagueiro",LD:"Lateral dir.",LE:"Lateral esq.",VOL:"Volante",MEI:"Meia",PE:"Ponta",ATA:"Atacante"};

// valor da habilidade para a posição: ideal=+, fraca=-
function habBonus(j){
  if(!j.hab)return 0;
  const m={ideal:1,bom:0.4,fraco:-0.5}[j.habCat||"bom"];
  return m;
}
// ----- Estrelas -----
function estrelaNivel(j){const a=j.art||0;return a>=5?2:a>=3?1:0}   // 0 sem estrela · 1 amarela · 2 vermelha
function estrelaIcone(j){const n=estrelaNivel(j);return n===2?"🔴★":n===1?"🟡★":""}
// bônus EM JOGO (a força base não muda)
function bonusEstrela(j){const n=estrelaNivel(j);return n===2?4:n===1?2:0}
function poupaEnergia(j){const n=estrelaNivel(j);return n===2?.65:n===1?.8:1}       // fração da energia perdida
function eficHab(j){return estrelaNivel(j)===2?1.25:1}                                // habilidades mais eficazes
// ----- Jogador -----
function criaJogadorFixo(pos,alvoF,rg,idadeFixa,anoNasc,nac){
  const pick2=a=>a[Math.floor(rg()*a.length)];
  const idade=idadeFixa||(anoNasc?Math.max(16,new Date().getFullYear()-anoNasc):(17+Math.floor(rg()*20)));
  const f=Math.max(15,Math.min(100,Math.round(alvoF)));
  // potencial: raros chegam a 100; maioria perto da força atual para a idade
  const r=rg();
  let pot;
  if(idade>=30)pot=f;
  else if(r<.004)pot=92+Math.floor(rg()*9);
  else if(r<.04)pot=Math.min(100,f+14+Math.floor(rg()*16));
  else if(r<.25)pot=Math.min(100,f+6+Math.floor(rg()*12));
  else pot=Math.min(100,f+Math.floor(rg()*7));
  if(idade>=26)pot=Math.min(pot,f+Math.max(0,Math.floor((30-idade)*1.2)));
  const hb=sorteiaHab(pos,rg);
  return{id:"j"+Math.floor(rg()*1e9).toString(36)+Math.floor(rg()*1e9).toString(36),nome:pick2(SILABAS1)+pick2(SILABAS2)+" "+pick2(SOBRE),pos,f,pot,idade,
    sal:salarioDe(f),val:valorDe(f,idade,pot),gols:0,art:0,lesao:0,tit:false,ct:1+Math.floor(rg()*4),hum:30+Math.floor(rg()*40),en:100,hab:hb.hab,habCat:hb.cat,papel:hb.papel,nac:nac||""};
}
// ===== PRECIFICAÇÃO (v38) =====
// Valor de mercado (R$) de um jogador de 26 anos de LIGA FORTE (Europa): F30 ≈ 0,6 mi · F40 ≈ 3,5 mi · F50 ≈ 12 mi · F60 ≈ 30 mi · F70 ≈ 70 mi · F80 ≈ 140 mi · F100 ≈ 350 mi.
// O mercado de cada liga multiplica o valor (fator de país × fator de divisão): o mesmo F50 custa 12 mi na Inglaterra, ~8 mi no Brasil e ~6,6 mi na Colômbia.
const VAL_PTS=[[15,.15e6],[25,.25e6],[30,.6e6],[35,1.5e6],[40,3.5e6],[45,7e6],[50,12e6],[55,20e6],[60,30e6],[65,45e6],[70,70e6],[80,140e6],[90,230e6],[100,350e6]];
function valorBase(f){
  f=Math.max(15,Math.min(100,f));
  for(let i=0;i<VAL_PTS.length-1;i++){const [a,va]=VAL_PTS[i],[b,vb]=VAL_PTS[i+1];if(f>=a&&f<=b)return Math.exp(Math.log(va)+(f-a)/(b-a)*(Math.log(vb)-Math.log(va)))}
  return VAL_PTS[VAL_PTS.length-1][1];
}
const MERCADO_PAIS={Inglaterra:1,Espanha:1,Itália:1,Alemanha:1,França:1,Portugal:.9,Holanda:.9,Bélgica:.85,Turquia:.85,Escócia:.8,Rússia:.85,Brasil:.7,Argentina:.7,Colômbia:.55,Chile:.55,Uruguai:.55,México:.6,"Estados Unidos":.6,Japão:.6,"Arábia Saudita":.7};
const MERCADO_DIV=[1,.6,.35];
function fatorMercado(pais,div){return(MERCADO_PAIS[pais]||.6)*(MERCADO_DIV[div]!=null?MERCADO_DIV[div]:.35)}

// fator de mercado do clube, lido da chave usada para gerar o elenco ("Brasil|0|3", "Inglaterra|1|7" ou "gen|Olimpia")
function mkDaChave(chave){
  const p=String(chave).split("|");
  if(p[0]==="gen")return .5;
  if(LIGAS[p[0]]&&p[1]!=null&&!isNaN(+p[1]))return fatorMercado(p[0],+p[1]);
  return .6;
}
function valorDe(f,idade,pot,mk){
  const ida=idade<=19?1.5:idade<=22?1.3:idade<=25?1.1:idade<=29?1:idade<=31?.75:idade<=33?.5:.3;
  const promessa=1+Math.min(.8,Math.max(0,(pot||f)-f)/40)*(idade<=26?1:.3);
  return Math.round(valorBase(f)*ida*promessa*(mk==null?1:mk)/10000)*10000;
}
// Salário em milhares de R$/mês: cerca de 2% do valor-base por mês, também ajustado pelo mercado da liga (mínimo R$ 8 mil).
function salarioDe(f,mk){return Math.max(8,Math.round(valorBase(f)*0.02*(mk==null?1:mk)/1000))}
const POS22=["GOL","GOL","ZAG","ZAG","ZAG","ZAG","LD","LE","VOL","VOL","MEI","MEI","MEI","ATA","ATA","ATA","PE","ZAG","MEI","ATA","LD","LE"];
// Elenco de um clube: craque no topo, titulares um pouco abaixo, reservas abaixo.
function geraElencoFixo(chave,pico){
  const rg=rngClube(chave);
  const el=POS22.map((pos,i)=>{
    let alvo;
    if(i<4)alvo=pico-Math.floor(rg()*5);                 // 4 jogadores de ponta
    else if(i<13)alvo=pico-4-Math.floor(rg()*8);
    else alvo=pico-8-Math.floor(rg()*9);
    // jovem de potencial raro aparece de vez em quando mais baixo (será o craque do futuro)
    const idadeBase=(i%7===0)?(17+Math.floor(rg()*4)):null;
    const jf=criaJogadorFixo(pos,alvo,rg,idadeBase);jf.num=NUM_SLOT[i];jf.mk=mkDaChave(chave);jf.val=valorDe(jf.f,jf.idade,jf.pot,jf.mk);jf.sal=salarioDe(jf.f,jf.mk);return jf;
  });
  return el;
}


function forcaMedia(c){const f=c.elenco.map(x=>x.f).sort((a,b)=>b-a).slice(0,11);return Math.round(f.reduce((q,x)=>q+x,0)/Math.max(1,f.length))}
// Elenco determinístico de QUALQUER clube do mundo (liga, divisão, posição). Cacheado em S.ext para sobreviver ao salvamento quando alterado.
function clubeMundo(pais,div,idx){
  if(pais===S.pais&&div===S.div&&S.clubes[idx]&&clubesDaDivisao(pais,div)[idx]&&S.clubes[idx].nome===clubesDaDivisao(pais,div)[idx][0])return S.clubes[idx];
  const info=LIGAS[pais][div][idx];
  const dono=(pais===S.pais)?S.clubes.find(c=>c.nome===info[0]):null;     // clube do meu país que está na minha divisão (pode ter mudado de posição)
  if(dono)return dono;
  if(!S.ext)S.ext={};
  const k=chaveClube(pais,div,idx);
  if(S.ext[k])return S.ext[k];                                            // clube ALTERADO (compra/empréstimo): elenco completo
  if(!S._mem)S._mem={};
  if(S._mem[k])return S._mem[k];                                          // já montado nesta sessão
  if(!S.mundo)S.mundo={};
  const pico=picoClube(pais,div,idx);
  if(!S.mundo[k])S.mundo[k]=criaEstadoMundo(k,pico);
  const c={ext:true,compacto:true,pais,div,idx,nome:info[0],sig:info[1],cor:info[2],cor2:info[3],forca:0,elenco:elencoDoMundo(k,pico,S.mundo[k])};
  c.forca=forcaMedia(c);
  c.form=c.form||"4-4-2";
  try{auto(c)}catch(e){}
  S._mem[k]=c;return c;
}


// Clube jogável de qualquer participante de copa: o MESMO elenco fixo sempre (mundo único e persistente)
function clubeParaJogo(pt){
  if(ehMeuClube(pt))return S.clubes[S.meu];
  { const dono=(pt.pais===S.pais)?S.clubes.find(c=>c.nome===pt.nome):null; if(dono)return dono; }
  // procura o clube nas ligas do jogo pelo nome (para usar o elenco fixo oficial dele)
  let achado=null;
  if(pt.pais&&LIGAS[pt.pais]){
    for(let dv=0;dv<LIGAS[pt.pais].length&&!achado;dv++){
      const i=LIGAS[pt.pais][dv].findIndex(c=>c[0]===pt.nome);
      if(i>=0)achado=clubeMundo(pt.pais,dv,i);
    }
  }
  if(!achado&&pt.div!=null&&pt.pais==null&&S.pais){ // participante da Copa nacional (liga do usuário)
    const i=LIGAS[S.pais][pt.div].findIndex(c=>c[0]===pt.nome);
    if(i>=0)achado=clubeMundo(S.pais,pt.div,i);
  }
  if(!achado){ // clubes gerados (Paraguai, Equador etc.): elenco fixo por nome
    const k="gen|"+pt.nome;
    if(!S.ext)S.ext={};
    if(!S.ext[k]){
      const pk=Math.max(30,(PICO_LIGA[pt.pais]||40)-Math.floor(rngClube(k+'|p')()*8));
      const c={ext:true,gen:true,pais:pt.pais||"",nome:pt.nome,sig:pt.sig,cor:pt.cor,cor2:pt.cor2,forca:0,elenco:geraElencoFixo(k,pk)};
      c.forca=forcaMedia(c);S.ext[k]=c;
    }
    achado=S.ext[k];
  }
  if(!achado.form)achado.form="4-4-2";
  if(!achado.elenco.some(x=>x.tit))auto(achado);
  achado.escudo=achado.escudo||null;achado.caixa=achado.caixa||0;
  if(achado.id==null)achado.id=1000+(achado.idx||0);
  return achado;
}


// ===== EVOLUÇÃO DE FORÇA (gradual, teto 100) E ARTILHEIRO DA LIGA =====
function crescimentoJog(j,rg,soMaturacao){
  const f=j.f,pot=j.pot||f,id=j.idade;
  if(id<=28){                                        // evolui até os 28
    const falta=Math.max(0,pot-f);
    const frac=fracAnualIdade(id);
    if(soMaturacao){                                  // v57: o grosso já veio jogando; aqui só a maturação + o treino de quem jogou pouco
      const treino=j.jogou?0:falta*frac*.45;
      const g=falta*frac*(1-EVO_PARTE_JOGOS)+(rg()*1.2-0.5)*.5+(j.jogou?0.15:0)+treino+Math.min(j._fama||0,falta)*.25;
      return Math.max(-.5,Math.min(falta,g));
    }
    const g=falta*frac+(rg()*1.2-0.5)+(j.jogou?0.25:0)+Math.min(j._fama||0,falta);
    return Math.max(-0.5,Math.min(falta,g));
  }
  return -(0.5+0.35*(id-29))+(rg()*0.8-0.4);         // aos 29 já só perde (−0,5 aos 29 … −3,5 aos 38)
}
function evoluiElenco(c,chave){
  const rg=rngClube("evo|"+chave+"|"+S.temp);
  const bf=bonusFamaEvolucao(c.nome);
  c.elenco.forEach(j=>{
    j.idade++;j._fama=bf;
    const g=crescimentoJog(j,rg,!!(S.clubes&&S.clubes.includes(c)));          // v57: clubes da MINHA liga (você e a IA) já evoluíram durante a temporada: aqui só a maturação. Clubes só do mundo-completo (elenco alterado) recebem o total
    j.fReal=(j.fReal!=null?j.fReal:j.f)+g;             // guarda a parte fracionária (ganho gradual)
    j.f=Math.max(15,Math.min(100,Math.round(j.fReal)));
    j.fReal=Math.max(15,Math.min(100,j.fReal));
    j.val=valorDe(j.f,j.idade,j.pot,j.mk);j.sal=salarioDe(j.f,j.mk);
    if(j.idade>=29&&j.pot>j.f)j.pot=j.f;                // v49: a partir dos 29 não há mais o que crescer
    j.en=100;j.gols=0;j.golsLiga=0;j.assistCarr=(j.assistCarr||0)+(j.assistLiga||0);j.assistLiga=0;j.jogou=false;j.ac=0;j.vm=0;
  });
  c.elenco=c.elenco.filter(j=>j.idade<39);
  c.forca=forcaMedia(c);
}
// Artilheiro da liga: o jogador com mais gols da temporada na MINHA divisão ganha +1 artilharia
function fechaArtilharia(){
  const todos=S.clubes.flatMap(c=>c.elenco.map(j=>({j,c}))).filter(o=>(o.j.golsLiga||0)>0).sort((a,b)=>(b.j.golsLiga||0)-(a.j.golsLiga||0));
  if(!todos.length)return null;
  const topo=todos[0];
  topo.j.art=(topo.j.art||0)+1;
  const antes=Math.max(0,(topo.j.art||1)-1),nivelAntes=antes>=5?2:antes>=3?1:0,nivelDepois=estrelaNivel(topo.j);
  const aviso_=nivelDepois>nivelAntes?(nivelDepois===2?`🔴★ ${topo.j.nome} (${topo.c.nome}) virou ESTRELA VERMELHA: 5 artilharias!`:`🟡★ ${topo.j.nome} (${topo.c.nome}) virou ESTRELA AMARELA: 3 artilharias!`):null;
  try{const asm=S.clubes.flatMap(c=>c.elenco.map(j=>({j,c}))).filter(o=>(o.j.assistLiga||0)>0).sort((a,b)=>(b.j.assistLiga||0)-(a.j.assistLiga||0))[0];
    if(asm){if(!S.astHist)S.astHist=[];S.astHist.push({temp:S.temp,pais:S.pais,div:S.div,nome:asm.j.nome,clube:asm.c.nome,a:asm.j.assistLiga||0});S.astHist=S.astHist.filter(x=>S.temp-x.temp<8)}}catch(e){}
  S.artHist=(S.artHist||[]);S.artHist.push({temp:S.temp,div:S.div,pais:S.pais,nome:topo.j.nome,clube:topo.c.nome,gols:topo.j.golsLiga||0,art:topo.j.art});
  return aviso_;
}


function bonusHabTime(c,grupos){
  const tit=c.elenco.filter(x=>x.tit);if(!tit.length)return 0;
  let soma=0;
  tit.forEach(x=>{(x.hab||[]).forEach(h=>{if(grupos.includes(HAB_GRUPO[h])){soma+= (x.habCat==="ideal"?1:x.habCat==="bom"?0.5:-0.3)*eficHab(x)}})});
  return soma/tit.length*3;          // ~ +3 pontos de força para um time só com habilidades ideais
}


function habHTML(j){
  if(!j.hab)return"";
  return j.hab.map(h=>`<span class="hb ${j.habCat||'bom'}">${h}</span>`).join("");
}
function estrelaHTML(j){const n=estrelaNivel(j);return n===2?'<span class="est2" title="Estrela vermelha">★</span>':n===1?'<span class="est1" title="Estrela amarela">★</span>':""}


// Ranking de força dos clubes de OUTROS países nesta temporada: determinístico (semente do jogo + temporada).
// O "ranking de tradição" é a ordem do cadastro (clubes grandes primeiro); a semente embaralha um pouco.
function classificacaoMundo(pais,div){
  // 1ª divisão do país: tabela final REAL da temporada passada (S.tabFinalMundo). Na 1ª temporada: pela força dos elencos.
  const fim=S.tabFinalMundo&&S.tabFinalMundo[pais];
  const mk=(nome,i)=>{
    const ch=chaveFixa(pais,nome);const info=ch?LIGAS[pais][ch.div][ch.idx]:[nome,"",'#445566','#fff'];
    return{nome,sig:info[1],cor:info[2],cor2:info[3],id:null,idx:ch?ch.idx:null,div:ch?ch.div:0,pais,sc:1000-i};
  };
  if(div===0&&fim&&fim.length)return fim.map(mk);
  const lista=clubesNaDivisao(pais,div);
  const rg=rngClube("class|"+pais+"|"+div+"|"+S.temp);
  return lista.map((c,i)=>{
    const ch=chaveFixa(pais,c[0]);
    const fz=ch?forcaParaLiga(pais,div,c[0]):40;
    return{nome:c[0],sig:c[1],cor:c[2],cor2:c[3],id:null,idx:ch?ch.idx:i,div:ch?ch.div:div,pais,sc:fz+rg()*3};
  }).sort((a,b)=>b.sc-a.sc);
}
function forcaClubeMundo(o){ // força real do elenco fixo do clube (para os torneios)
  try{return clubeMundo(o.pais,o.div,o.idx).forca}catch(e){return 40}
}


// Força de um participante de copa = força REAL do elenco fixo dele (nunca um número solto).
function forcaPart(c,pa,div){
  if(c.id!=null&&S.clubes[c.id])return S.clubes[c.id].forca;           // clube da minha liga
  const dvFixa=(c.div!=null?c.div:(div||0));
  if(c.idx!=null&&LIGAS[pa]&&LIGAS[pa][dvFixa])return clubeMundo(pa,dvFixa,c.idx).forca;
  return Math.max(26,(PICO_LIGA[pa]||40)-8);
}
// Clubes "gerados" (Paraguai, Equador...): força pelo elenco fixo, calculado na hora em que são abertos
function forcaGerado(nome,pa){
  const k="gen|"+nome;
  const pk=Math.max(30,(PICO_LIGA[pa]||40)-Math.floor(rngClube(k+'|p')()*8));
  const el=geraElencoFixo(k,pk);
  return forcaMedia({elenco:el});
}


// Jogos salvos em versões antigas: completa semente, habilidades e potencial SEM trocar jogadores.
function migraJogo(){
  if(!S)return;
  garanteDivAtual();
  if(S.seed==null)S.seed=novaSemente();
  const rg=rngClube("migra|"+(S.temp||1));
  const completa=j=>{
    if(!j.hab){const hb=sorteiaHab(j.pos,rg);j.hab=hb.hab;j.habCat=hb.cat;j.papel=hb.papel}if(!j.papel)j.papel=papelDe(j);
    if(j.pot==null)j.pot=Math.min(100,j.f+(j.idade<=24?Math.floor(rg()*12):j.idade<=28?Math.floor(rg()*5):0));
    if(j.art==null)j.art=0;if(j.golsLiga==null)j.golsLiga=0;
  };
  S.clubes.forEach(c=>c.elenco.forEach(completa));
  if(S.ext)Object.keys(S.ext).forEach(k=>{if(S.ext[k]&&S.ext[k].elenco)S.ext[k].elenco.forEach(completa)});
  // mercado antigo guardava jogadores soltos: converte para referências ou refaz
  if(S.mercado&&S.mercado.length&&S.mercado[0].nome){try{geraMercado()}catch(e){S.mercado=[]}}
}


// ================= FASE 0 · MIGRAÇÃO VERSIONADA DE SAVE =================
// Antes desta versão o save NÃO tinha campo de versão: a única checagem era "tem pais e div?".
// Agora todo save carrega S._v. Saves antigos (v1) sobem para v2 preservando 100% do conteúdo.
// Regra de ouro: migração só ADICIONA campos. Nunca remove, nunca renomeia, nunca reinterpreta.
function migraSaveVersao(vAntes){
  if(!S)return 0;
  const de=(vAntes==null?1:vAntes)|0;
  if(de<2){
    if(S.seed==null)S.seed=novaSemente();   // semente do mundo já existia; agora é garantida
    S._migradoEm=Date.now();                // marca d'água da primeira subida para v2
    S._v=2;
  }
  S._v=SAVE_VER;
  return S._v;
}

// ================= FASE 0 · PARTIDA DETERMINÍSTICA =================
// Envelope para simular uma partida a partir de uma semente derivada do ID da partida.
// AINDA NÃO é chamado pelo fluxo de agenda (isso é Fase 7): existe para que a partir de
// agora qualquer simulação nova já nasça reproduzível. simula() continua idêntico — este
// envelope apenas o executa dentro de comSeed().
function seedPartida(idPartida){
  return "P|"+String(idPartida==null?"":idPartida)+"|"+((S&&S.seed)!=null?S.seed:0)+"|"+((S&&S.temp)||1)+"|"+((S&&S.rodada)||0);
}
function hashResultado(r){
  const t=[r.ga,r.gb,(r.ea||[]).join(","),(r.eb||[]).join(",")].join("#");
  return "r"+semente(t).toString(36);
}
function simulaComSeed(idPartida,a,b,meuA,meuB){
  const sd=seedPartida(idPartida);
  const r=comSeed(sd,function(){return simula(a,b,meuA,meuB)});
  r.seed=sd;r.hash=hashResultado(r);
  return r;   // chame UMA vez por partida (simula marca gols nos jogadores)
}

// ================= FASE 0 · DIAGNÓSTICO =================
const MPF0={
  versao:"fase0-1.0",
  saveVer:SAVE_VER,
  verificar:function mpf0TesteDeterminismo(){
    const f=function(){const a=[];for(let i=0;i<10;i++)a.push(rnd(1,100000));return a.join(",")};
    const a=comSeed("teste|alpha",f),b=comSeed("teste|alpha",f),c=comSeed("teste|beta",f);
    const iguais=a===b,difere=a!==c;
    return{ok:(iguais&&difere),igual:iguais,diferente:difere,amostra:a.slice(0,24)};
  },
  estado:function(){return{versao:RNG_CTX?"semeado":"livre",seed:RNG_NOME,usos:RNG_USOS}}
};

// ===== JANELA DE ESCALAÇÃO DURANTE O JOGO (tempo parado) =====
// Só o treinador humano (clube com tecReal) tem direito à janela. Hoje: o clube do usuário.
function souTecReal(clubeIdx){return clubeIdx===S.meu}          // preparado: no futuro, outros humanos entram aqui
function abreJanelaEscala(motivo){
  const L=S.live;if(!L)return;
  if(L.janela)return;                                           // já está aberta
  L.janela=motivo||"manual";L.pausaTec=true;                    // o tempo para
  S.selId=null;
  const jg=L.jogos.find(g=>g.a===S.meu||g.b===S.meu);
  if(jg)L.ver=L.jogos.indexOf(jg);
  renderJanela();
}
function fechaJanelaEscala(){
  const L=S.live;if(!L)return;
  const el=document.getElementById("janelaEscala");if(el)el.remove();
  const era=L.janela;L.janela=null;L.pausaTec=false;S.selId=null;DR=null;
  try{if(vagasLesaoAbertas().length||S.clubes[S.meu].elenco.some(x=>x.lesionadoJogo&&!x.tit))iaCompletaTime(S.clubes[S.meu])}catch(e){}   // vaga de lesão ainda aberta: o melhor reserva da posição entra
  if(era==="penalti"&&L.penReq){try{const jg=L.jogos[L.penReq.jogoIdx];if(jg)resolvePenalti(jg,L.penReq.sA,S.cobPen)}catch(e){}L.penReq=null}   // saída por outro caminho: cobra com o cobrador da Tática
  if(era==='intervalo'&&!L.apitou2){L.apitou2=true}   // o 2º tempo recomeça sem apito (só: início, intervalo, fim e vermelho do seu time)
  renderLive();
}
function tituloJanela(motivo){
  return motivo==="intervalo"?"⏸ Intervalo — ajuste o time":motivo==="vermelho"?"🟥 Expulsão — reorganize o time":motivo==="lesao"?"🤕 Lesão — faça a substituição":motivo==="penalti"?"⚽ Pênalti — escolha o cobrador":"📋 Escalação e substituições";
}
function renderJanela(){
  const L=S.live;if(!L||!L.janela)return;
  const jg=L.jogos.find(g=>g.a===S.meu||g.b===S.meu);if(!jg)return;
  const eu=S.clubes[S.meu],A=S.clubes[jg.a],B=S.clubes[jg.b],op=jg.a===S.meu?B:A;
  let el=document.getElementById("janelaEscala");
  if(!el){el=document.createElement("div");el.id="janelaEscala";document.body.appendChild(el)}
  el.style.cssText="position:fixed;inset:0;z-index:900;background:linear-gradient(#0c2415,#071a0f);overflow:auto;-webkit-overflow-scrolling:touch;padding:10px 10px 90px";
  const dif=jg.a===S.meu?`${jg.ga} x ${jg.gb}`:`${jg.gb} x ${jg.ga}`;
  const expul=eu.elenco.filter(x=>x.expulso).length;
  el.innerHTML=`
   <div class="hd"><div class="top"><b>${tituloJanela(L.janela)}</b><span>${L.min}' · ${jg.a===S.meu?eu.nome:op.nome} ${jg.ga} x ${jg.gb} ${jg.a===S.meu?op.nome:eu.nome}</span></div>
   ${L.janela==="lesao"?lesaoAvisoHTML():''}
   ${L.janela==="vermelho"?`<div class="hint" style="margin:6px 0 0;background:linear-gradient(90deg,#7f1d1d,#b91c1c)">${expul} jogador(es) expulso(s): seu time joga com ${eu.elenco.filter(x=>x.tit&&!x.expulso).length}. Reorganize e toque em Voltar ao jogo.</div>`:''}
   </div>
   ${L.janela==="penalti"?painelPenaltiHTML():''}
   <div class="escola"><div>${campoHTML(eu,'live')}
    <div class="hint" id="dicaToque" style="margin-top:6px">Toque num titular e num reserva para substituir. Arraste para mover de posição.</div></div>
   <div class="painelD">
    <div class="advbar"><span>Adversário: <b>${escudo(op,16)} ${op.nome}</b></span><span class="tag">Subs ${S.subs}/5</span></div>
    ${L.janela==='lesao'?`<div class="hint" style="margin:6px 0;background:#3a2200">🏥 <b>Toque em um reserva</b> abaixo para ele ocupar a vaga do lesionado (a troca <b>não gasta</b> uma das 5 substituições). Se preferir, toque em <b>Voltar ao jogo</b>: o melhor reserva da posição entra sozinho.</div>`:''}
    <div class="tag">Banco de reservas</div>${bancoHTML(eu)}
    <div class="ctl">
     <div><label>Estilo de jogo</label><select onchange="S.tatica=this.value">${["Defensiva","Equilibrada","Ofensiva","Contra-ataque"].map(f=>`<option ${f===S.tatica?'selected':''}>${f}</option>`).join("")}</select></div>
     <div><label>Marcação</label><select onchange="S.marc=this.value">${["Leve","Normal","Forte"].map(f=>`<option ${f===S.marc?'selected':''}>${f}</option>`).join("")}</select></div>
     <div><label>Concentrar ataques</label><select onchange="S.conc=this.value">${["Pelo meio","Pelas pontas"].map(f=>`<option ${f===S.conc?'selected':''}>${f}</option>`).join("")}</select></div>
    </div>
    <div class="row" style="margin-top:10px"><button class="s" onclick="autoBotao(true)">🔄 Seleção automática</button><button class="s" onclick="resetPos(S.clubes[S.meu]);renderJanela()">↺ Posições</button></div>
   </div></div>
   <div style="position:fixed;left:0;right:0;bottom:0;padding:10px;background:linear-gradient(transparent,#071a0f 35%);z-index:901">${L.janela==="penalti"?'<button class="big" onclick="cobraPenaltiMeu()">⚽ Cobrar o pênalti</button>':'<button class="big" onclick="fechaJanelaEscala()">▶ Voltar ao jogo</button>'}</div>`;
  posRender();
}


function mudaVel(){const L=S.live;if(!L)return;L.vel=L.vel===1?2:L.vel===2?3:1;S.velPref=L.vel;playLive();renderLive()}
function pulaFim(){
  const L=S.live;if(!L)return;
  confirma("Pular direto para o fim da partida?",()=>{
    try{speechSynthesis.cancel()}catch(e){}
    // se havia um pênalti esperando o cobrador, resolve já com o cobrador escolhido na Tática (ou o melhor)
    if(L.penReq){try{const jg=L.jogos[L.penReq.jogoIdx];if(jg)resolvePenalti(jg,L.penReq.sA,S.cobPen)}catch(e){}L.penReq=null}
    try{iaCompletaTime(S.clubes[S.meu])}catch(e){}
    L.pausaTec=false;L.janela=null;L.pulando=true;const el=document.getElementById("janelaEscala");if(el)el.remove();
    let g=0;while(S.live&&S.live.min<90&&g++<400)tick();
    if(S.live)S.live.pulando=false;
  });
}


function limpaPartidaEstado(){
  (S.clubes||[]).forEach(c=>c.elenco.forEach(j=>{j.amarelos=0})); // chamada no fim de QUALQUER partida (liga ou copa)
  const el=document.getElementById("janelaEscala");if(el)el.remove();
  const todos=[];
  (S.clubes||[]).forEach(c=>todos.push(...c.elenco));
  if(S._clbak&&S._clbak.clubes)S._clbak.clubes.forEach(c=>todos.push(...c.elenco));
  // 1) quem estava suspenso e NÃO jogou esta partida já cumpriu: libera
  todos.forEach(j=>{if(j.suspenso>0&&!j.expulso&&!j.acSusp)j.suspenso=Math.max(0,j.suspenso-1)});
  // 2) quem foi expulso agora fica suspenso para a próxima partida
  todos.forEach(j=>{if(j.expulso){j.suspenso=1;j.expulso=false;j.motSusp='V'}});
  // 3) 3 amarelos acumulados na temporada = 1 jogo de suspensão (o contador recomeça)
  todos.forEach(j=>{if((j.ac||0)>=3&&!(j.suspenso>0)){j.suspenso=1;j.ac=0;j.acSusp=true;j.motSusp='A'}else if((j.ac||0)>=3){j.ac=0}});
  todos.forEach(j=>{j._acNovo=false;j._vmNovo=false;j.acSusp=false});
  S.expulsaoPendente=false;
}


// ===== JANELA SOMENTE LEITURA (times que NÃO são meus) =====
function campoLeitura(c){ // mesmo desenho do campo, sem eventos de toque/arraste
  posPadrao(c);
  const tit=c.elenco.filter(x=>x.tit&&!x.expulso);
  let h=`<div class="pitch" style="touch-action:auto">${LINHAS_CAMPO}`;
  tit.forEach(j=>{const e=Math.round(j.en==null?100:j.en);
    h+=`<div class="pl" style="left:${j.px}%;top:${j.py}%;cursor:default;touch-action:auto">${camisaSVG(c,j.pos==="GOL",false,numDe(j))}<span>${nomeCurto(j)} ${estrelaHTML(j)}</span><small>${j.pos[0]} · F:${j.f} E:${e}%${j.lesao>0?' 🤕'+j.lesao+'j':''}</small></div>`});
  return h+`</div>`;
}
function bancoLeitura(c){
  const res=c.elenco.filter(x=>!x.tit&&!x.expulso).sort((a,b)=>POS_ORD(a.pos)-POS_ORD(b.pos)||b.f-a.f);
  return `<div class="bancoF">`+res.map(j=>{const e=Math.round(j.en==null?100:j.en);return`<div class="bj ${j.lesao>0?'lz':''}" style="cursor:default">${camisaSVG(c,j.pos==="GOL",false,numDe(j))}<span>${nomeCurto(j)}</span><small>${j.pos[0]} · F:${j.f} E:${e}%</small></div>`}).join("")+`</div>`;
}
// clube de qualquer jogo da lista: da minha liga (S.clubes) ou do mundo (elenco fixo)
function clubeDoJogoVer(info){
  if(info.idx!=null&&S.clubes[info.idx]&&info.proprio)return S.clubes[info.idx];
  if(info.pais!=null&&info.div!=null&&info.i!=null)return clubeMundo(info.pais,info.div,info.i);
  return null;
}
function abreVerTime(pais,div,idx,doJogoLiveIdx){
  const L=S.live;
  // pausa o tempo enquanto consulta
  if(L){L.janelaVer=true;L.pausaTec=true}
  const c=(pais===S.pais&&div===S.div&&S.clubes[idx])?S.clubes[idx]:clubeMundo(pais,div,idx);
  if(!c){if(L){L.janelaVer=false;L.pausaTec=false}return aviso("Elenco indisponível.")}
  if(!c.elenco.some(x=>x.tit))auto(c);
  let el=document.getElementById("janelaVer");if(el)el.remove();
  el=document.createElement("div");el.id="janelaVer";
  el.style.cssText="position:fixed;inset:0;z-index:920;background:linear-gradient(#0c2415,#071a0f);overflow:auto;-webkit-overflow-scrolling:touch;padding:10px 10px 90px";
  const media=forcaMedia(c);
  el.innerHTML=`<div class="hd"><div class="top"><b>👁 ${escudo(c,18)} ${c.nome}</b><span>${c.form||'4-4-2'}</span></div>
    <div class="hint" style="margin:6px 0 0;background:linear-gradient(90deg,#334155,#475569)">Somente leitura — você não é o técnico deste time.</div></div>
    <div class="escola"><div>${campoLeitura(c)}</div>
    <div class="painelD"><div class="advbar"><span>Prestígio: <b>${iconeFama(c.nome)} ${nomeFama(c.nome)}</b></span><span class="tag">${c.sig||''}</span></div>
      <div class="tag">Banco de reservas</div>${bancoLeitura(c)}
      <div class="tag" style="margin-top:8px">Titulares e habilidades</div>
      <table class="tl">${c.elenco.filter(x=>x.tit&&!x.expulso).map(j=>`<tr><td>${j.pos[0]}</td><td>${j.nome} ${estrelaHTML(j)}</td><td class="y">${j.f}</td><td>${habHTML(j)}</td></tr>`).join("")}</table>
    </div></div>
    <div style="position:fixed;left:0;right:0;bottom:0;padding:10px;background:linear-gradient(transparent,#071a0f 35%);z-index:921"><button class="big" onclick="fechaVerTime()">✕ Fechar</button></div>`;
  document.body.appendChild(el);
}
function fechaVerTime(){
  const el=document.getElementById("janelaVer");if(el)el.remove();
  const L=S.live;if(L){L.janelaVer=false;if(!L.janela)L.pausaTec=false}
  if(L)renderLive();
}


function abreVerJogoLiga(n){ // jogo de outro time da MINHA divisão: mostra os dois lados em leitura
  const L=S.live;if(!L)return;
  const g=L.jogos[n];if(!g)return;
  L.ver=n;
  escolhaVerLado(g.a,g.b);
}
function escolhaVerLado(a,b){
  const A=S.clubes[a],B=S.clubes[b];
  L_pausaConsulta();
  modal(`<h3>Ver escalação</h3><div class="mu" style="font-size:12px;margin:4px 0 10px">Somente leitura — você não é o técnico destes times.</div>
    <div class="clube" onclick="fechaDlg();abreVerTime(S.pais,S.div,${a})"><span>${escudo(A,20)} ${A.nome}</span><span class="tag">ver</span></div>
    <div class="clube" onclick="fechaDlg();abreVerTime(S.pais,S.div,${b})"><span>${escudo(B,20)} ${B.nome}</span><span class="tag">ver</span></div>
    <button class="s big" onclick="fechaDlg();L_retomaConsulta()">Cancelar</button>`);
}
function L_pausaConsulta(){const L=S.live;if(L){L.pausaTec=true}}
function L_retomaConsulta(){const L=S.live;if(L&&!L.janela&&!L.janelaVer)L.pausaTec=false}


function escolhaVerMundo(pais,div,ia,ib){
  const A=clubeMundo(pais,div,ia),B=clubeMundo(pais,div,ib);
  L_pausaConsulta();
  modal(`<h3>Ver escalação</h3><div class="mu" style="font-size:12px;margin:4px 0 10px">Somente leitura — você não é o técnico destes times.</div>
    <div class="clube" onclick="fechaDlg();abreVerTime('${pais}',${div},${ia})"><span>${escudo(A,20)} ${A.nome}</span><span class="tag">${iconeFama(A.nome)} ${nomeFama(A.nome)}</span></div>
    <div class="clube" onclick="fechaDlg();abreVerTime('${pais}',${div},${ib})"><span>${escudo(B,20)} ${B.nome}</span><span class="tag">${iconeFama(B.nome)} ${nomeFama(B.nome)}</span></div>
    <button class="s big" onclick="fechaDlg();L_retomaConsulta()">Cancelar</button>`);
}


// ===== ACESSO E REBAIXAMENTO =====
// S.divAtual[nome do clube] = divisão atual (só para o país do jogador). Começa igual a LIGAS.
function divAtualDe(nome){return S.divAtual?S.divAtual[nome]:undefined}
function garanteDivAtual(){
  if(S.divAtual)return;
  S.divAtual={};
  (LIGAS[S.pais]||[]).forEach((lst,dv)=>lst.forEach(c=>{S.divAtual[c[0]]=dv}));
}
// lista [ [nome,sig,cor1,cor2], ... ] dos clubes de uma divisão do MEU país, segundo a divisão atual
function clubesDaDivisao(pais,div){
  if(pais!==S.pais||!S.divAtual)return LIGAS[pais][div];
  const out=[];
  LIGAS[pais].forEach(lst=>lst.forEach(c=>{if(S.divAtual[c[0]]===div)out.push(c)}));
  return out;
}
// posição (pais|div|idx) de cada clube na lista FIXA LIGAS: o elenco é guardado por esta chave e NUNCA muda de dono
function chaveFixa(pais,nome){
  for(let dv=0;dv<LIGAS[pais].length;dv++){const i=LIGAS[pais][dv].findIndex(c=>c[0]===nome);if(i>=0)return{div:dv,idx:i}}
  return null;
}
// Elenco de um clube do meu país pelo NOME (independe da divisão atual)
function clubePorNome(nome){
  const m=S.clubes.find(c=>c.nome===nome);if(m)return m;
  const ch=chaveFixa(S.pais,nome);if(!ch)return null;
  return clubeMundo(S.pais,ch.div,ch.idx);
}
function forcaClubeNome(nome){const c=clubePorNome(nome);return c?c.forca:40}
// Simula a temporada de uma divisão que o jogador não disputa (todos contra todos, ida e volta, com a força real do elenco)
function simulaDivisao(nomes,rg){
  const pts={},sg={};nomes.forEach(n=>{pts[n]=0;sg[n]=0});
  const f={};nomes.forEach(n=>{f[n]=forcaClubeNome(n)});
  for(let i=0;i<nomes.length;i++)for(let k=0;k<nomes.length;k++){
    if(i===k)continue;const a=nomes[i],b=nomes[k];
    const ma=Math.max(.25,(f[a]+3-f[b])/22+1.35),mb=Math.max(.25,(f[b]-f[a]-3)/22+1.0);
    const g=(m)=>{let L=Math.exp(-m),q=0,pr=1;do{q++;pr*=rg()}while(pr>L);return q-1};
    const ga=g(ma),gb=g(mb);
    if(ga>gb)pts[a]+=3;else if(ga<gb)pts[b]+=3;else{pts[a]++;pts[b]++}
    sg[a]+=ga-gb;sg[b]+=gb-ga;
  }
  return[...nomes].sort((x,y)=>pts[y]-pts[x]||sg[y]-sg[x]||(rg()-.5));
}
// Executado no fim da temporada. tabelaMinha: nomes na ordem final da MINHA divisão.
function aplicaAcessoRebaixamento(tabelaMinha){
  garanteDivAtual();
  const nDiv=LIGAS[S.pais].length;
  const tabelas=[];
  for(let dv=0;dv<nDiv;dv++){
    const nomes=clubesDaDivisao(S.pais,dv).map(c=>c[0]);
    if(dv===S.div)tabelas[dv]=tabelaMinha.slice();
    else tabelas[dv]=simulaDivisao(nomes,rngClube("acesso|"+S.pais+"|"+dv+"|"+S.temp));
  }
  const movs=[];                       // {nome,de,para}
  const k=[];
  for(let i=0;i<nDiv-1;i++)k[i]=Math.min(4,Math.floor(tabelas[i].length/4),Math.floor(tabelas[i+1].length/4));
  const novo=tabelas.map(t=>t.slice());
  for(let i=0;i<nDiv-1;i++){
    const kk=k[i];if(kk<=0)continue;
    const cai=tabelas[i].slice(-kk),sobe=tabelas[i+1].slice(0,kk);
    cai.forEach(n=>movs.push({nome:n,de:i,para:i+1}));
    sobe.forEach(n=>movs.push({nome:n,de:i+1,para:i}));
  }
  movs.forEach(m=>{S.divAtual[m.nome]=m.para});
  S.ultimosMov=movs;
  // classificação final da 1ª divisão (antes dos movimentos), por nome: decide as vagas continentais
  S.tabFinal=tabelas[0].map(nome=>{const info=infoPorNome(nome);return{nome,sig:info.sig,cor:info.cor,cor2:info.cor2,forca:forcaClubeNome(nome),id:null,idx:info.idx,div:info.div}});
  return movs;
}


// Reorganiza S.clubes para a divisão em que o meu clube vai jogar na próxima temporada.
// Cada clube leva consigo elenco, caixa, estádio, técnico, formação e escudo.
function reconstroiMinhaLiga(novaDiv,nomeMeu){
  garanteDivAtual();
  const nomes=clubesDaDivisao(S.pais,novaDiv).map(c=>c[0]);
  const velhos={};S.clubes.forEach(c=>{velhos[c.nome]=c});
  const novos=nomes.map((nome,i)=>{
    let c=velhos[nome];
    if(!c){ // clube que veio de outra divisão: usa o elenco fixo do mundo e vira um clube "da liga"
      const ch=chaveFixa(S.pais,nome);
      const mundo=clubeMundo(S.pais,ch.div,ch.idx);
      const info=LIGAS[S.pais][ch.div][ch.idx];
      c=Object.assign({},mundo);
      delete c.ext;delete c.pais;delete c.div;delete c.idx;
      c.sig=info[1];c.cor=info[2];c.cor2=info[3];
      c.escudo=c.escudo||null;
      c.caixa=Math.round((2+((semente(nome+"|cx")>>>0)%9))*1000000/(1+novaDiv*0.8));
      // o clube sai do cache do mundo: seu elenco passa a viver em S.clubes
      if(S.ext)delete S.ext[S.pais+"|"+ch.div+"|"+ch.idx];
    }
    c.id=i;
    c.pts=c.j=c.v=c.e=c.d=c.gp=c.gc=0;
    return c;
  });
  // clubes que saíram da minha liga voltam ao cache do mundo (sem perder elenco)
  S.clubes.forEach(c=>{
    if(nomes.includes(c.nome))return;
    const ch=chaveFixa(S.pais,c.nome);if(!ch)return;
    if(!S.ext)S.ext={};
    const copia=Object.assign({},c,{ext:true,pais:S.pais,div:ch.div,idx:ch.idx});
    S.ext[S.pais+"|"+ch.div+"|"+ch.idx]=copia;
  });
  S.clubes=novos;
  S.div=novaDiv;
  S.meu=novos.findIndex(c=>c.nome===nomeMeu);
  S.ing=15000/(1+novaDiv*.6);
  const n=novos.length;
  S.fixt=fixtures(n%2?n+1:n,n);
}


function infoPorNome(nome){ // dados de cadastro de um clube do meu país, pelo nome
  const ch=chaveFixa(S.pais,nome);
  if(!ch)return{sig:"",cor:"#445566",cor2:"#fff",idx:null,div:0};
  const c=LIGAS[S.pais][ch.div][ch.idx];
  return{sig:c[1],cor:c[2],cor2:c[3],idx:ch.idx,div:ch.div};
}


// Classificação da 1ª divisão do meu país (por nome) usada para as vagas continentais.
//  - depois da 1ª temporada: a tabela final guardada (S.tabFinal, sempre da 1ª divisão)
//  - na 1ª temporada, se eu jogo a 1ª divisão: ordena pela força dos elencos
//  - na 1ª temporada, se eu jogo outra divisão: usa a ordem determinística do mundo
function fontePrimeiraDiv(){
  if(S.tabFinal)return S.tabFinal;
  garanteDivAtual();
  const nomes=clubesDaDivisao(S.pais,0).map(c=>c[0]);
  return nomes.map(nome=>{const info=infoPorNome(nome);return{nome,sig:info.sig,cor:info.cor,cor2:info.cor2,forca:forcaClubeNome(nome),id:(S.div===0?(S.clubes.find(c=>c.nome===nome)||{}).id:null),idx:info.idx,div:info.div}})
              .sort((a,b)=>b.forca-a.forca);
}


function nomeMeuClube(){const c=S.clubes[S.meu];return c?c.nome:""}
function ehMeuClube(pt){return !!pt&&pt.nome===nomeMeuClube()&&(pt.pais===S.pais||pt.pais==null)}


// ===== MUNDO COMPACTO =====
// S.mundo[chave] = { c: [[idade,f10,pot,art,golsLiga,gen] x 22], pico, e?:{...extras} }  (só o que muda)
// Nome, posição e habilidades NÃO são guardados: vêm da semente + posição no elenco + geração (gen).
function chaveClube(pais,div,idx){return pais+"|"+div+"|"+idx}
function picoClube(pais,div,idx){return picoDe(pais,div)-Math.floor(rngClube(chaveClube(pais,div,idx)+'|p')()*8)}
function baseMundo(chave,pico){ // elenco original (gen 0), sempre igual para a mesma semente
  return geraElencoFixo(chave,pico);
}
function jogadorDeGeracao(chave,i,gen,pico){ // jovem de reposição determinístico
  const rg=rngClube(chave+"|rep|"+i+"|"+gen);
  const jr=criaJogadorFixo(POS22[i],pico-12-Math.floor(rg()*9),rg,17+Math.floor(rg()*3));jr.pot=Math.min(95,jr.f+Math.floor(rg()*23));jr.mk=mkDaChave(chave);jr.val=valorDe(jr.f,jr.idade,jr.pot,jr.mk);jr.sal=salarioDe(jr.f,jr.mk);return jr;
}
function compactaElenco(elenco){return elenco.map(j=>[j.idade,Math.round((j.fReal!=null?j.fReal:j.f)*10),j.pot,j.art||0,j.golsLiga||0,j.gen||0,idParaNum(j.id),empacotaIdent(j)])}

// ===== IDENTIDADE CONGELADA (v43) =====
// Cada jogador do mundo guarda, no save, um id curto (t[6]) e UM inteiro (t[7]) que empacota: nome (sílaba1, sílaba2, sobrenome),
// 2 habilidades, categoria (ideal/bom/fraco), contrato e moral. Assim os jogadores NUNCA mudam ao reabrir o jogo ou trocar de versão.
const HAB_LISTA=["Finalização","Cabeceio","Chute longo","Velocidade","Drible","Passe","Visão de jogo","Cruzamento","Passe longo","Saída de bola","Desarme","Marcação","Antecipação","Reflexos","Posicionamento","Jogo aéreo","Pênaltis","Resistência"];
const CAT_LISTA=["ideal","bom","fraco"];
function empacotaIdent(j){
  const s1=Math.max(0,SILABAS1.indexOf(j.nome.split(" ")[0].slice(0,2))),n=j.nome;
  // o nome é "Sil1"+"Sil2"+" "+"Sobrenome": recupera os 3 índices pela própria tabela
  const partes=n.split(" ");const sob=Math.max(0,SOBRE.indexOf(partes[partes.length-1]));
  let i1=-1,i2=-1;const junto=partes[0];
  for(let a=0;a<SILABAS1.length&&i1<0;a++){if(!junto.startsWith(SILABAS1[a]))continue;const resto=junto.slice(SILABAS1[a].length);const b=SILABAS2.indexOf(resto);if(b>=0){i1=a;i2=b}}
  if(i1<0){i1=0;i2=0}
  const h1=Math.max(0,HAB_LISTA.indexOf((j.hab||[])[0])),h2=Math.max(0,HAB_LISTA.indexOf((j.hab||[])[1]));
  const cat=Math.max(0,CAT_LISTA.indexOf(j.habCat||"bom"));
  const ct=Math.max(1,Math.min(4,j.ct||1)),hum=Math.max(0,Math.min(63,(j.hum||40)-30));
  // nome: i1(20) i2(20) sob(18) · hab: h1(18) h2(18) · cat(3) · ct(5) · hum(64)
  return(((((((i1*20+i2)*18+sob)*18+h1)*18+h2)*3+cat)*5+ct)*64+hum);
}
function desempacotaIdent(v){
  const hum=v%64;v=Math.floor(v/64);const ct=v%5;v=Math.floor(v/5);const cat=v%3;v=Math.floor(v/3);
  const h2=v%18;v=Math.floor(v/18);const h1=v%18;v=Math.floor(v/18);const sob=v%18;v=Math.floor(v/18);const i2=v%20;v=Math.floor(v/20);const i1=v%20;
  return{nome:SILABAS1[i1]+SILABAS2[i2]+" "+SOBRE[sob],hab:[HAB_LISTA[h1],HAB_LISTA[h2]],habCat:CAT_LISTA[cat],ct:ct||1,hum:hum+30};
}
// converte um id "jXXXX" (string) em número curto estável e de volta: guardamos o inteiro, o id do jogo é "j"+base36
function idParaNum(id){let h=0;for(let i=0;i<id.length;i++)h=(Math.imul(h,31)+id.charCodeAt(i))>>>0;return h}
function numParaId(n){return"j"+n.toString(36)}

function criaEstadoMundo(chave,pico){return{pico,c:compactaElenco(baseMundo(chave,pico))}}
function elencoDoMundo(chave,pico,estado){ // reconstrói os 22 jogadores a partir do estado compacto
  const precisaBase=estado.c.some(t=>t[7]==null||(t[5]||0)===0);
  const base=precisaBase?baseMundo(chave,pico):null;
  return estado.c.map((t,i)=>{
    const gen=t[5]||0;
    const j=(gen===0&&base)?Object.assign({},base[i]):(gen>0?jogadorDeGeracao(chave,i,gen,pico):Object.assign({},base?base[i]:{}));
    if(t[7]!=null){                                   // identidade congelada: manda sobre o gerador
      const d=desempacotaIdent(t[7]);j.nome=d.nome;j.hab=d.hab;j.habCat=d.habCat;j.ct=d.ct;j.hum=d.hum;
      j.id=numParaId(t[6]);j.pos=POS22[i];j.papel=null;j.papel=papelDe(j);
    }else{                                            // save antigo: congela agora (próximo save grava)
      t[6]=idParaNum(j.id);t[7]=empacotaIdent(j);
    }
    j.idade=t[0];j.fReal=t[1]/10;j.f=Math.round(t[1]/10);j.pot=t[2];j.art=t[3];j.golsLiga=t[4];j.assistLiga=0;j.gen=gen;j.gols=0;j.num=NUM_SLOT[i];
    j.mk=mkDaChave(chave);j.val=valorDe(j.f,j.idade,j.pot,j.mk);j.sal=salarioDe(j.f,j.mk);
    return j;
  });
}


function compactaElencoComGen(elenco,anterior){
  // enquanto o clube é "compacto", o elenco tem 22 jogadores na mesma ordem dos slots; a identidade congelada é preservada
  return elenco.map((j,i)=>{const a=anterior[i]||[];return[j.idade,Math.round((j.fReal!=null?j.fReal:j.f)*10),j.pot,j.art||0,j.golsLiga||0,(a[5]||0)||j.gen||0,a[6]!=null?a[6]:idParaNum(j.id),a[7]!=null?a[7]:empacotaIdent(j)]});
}


// ===== EVOLUÇÃO DO MUNDO INTEIRO (direto no estado compacto) =====
function crescimentoCompacto(idade,f,pot,rg){
  if(idade<=28){
    const falta=Math.max(0,pot-f),frac=fracAnualIdade(idade);
    // v57: 75% do ano já foi pago ao longo das rodadas (evoluiMundoFatia); aqui só a maturação + ruído menor
    const g=falta*frac*(1-EVO_PARTE_JOGOS)+(rg()*1.2-0.5)*.5;
    return Math.max(-0.5,Math.min(falta,g));
  }
  return -(0.5+0.35*(idade-29))+(rg()*0.8-0.4);
}
// Evolui UM clube compacto (estado) para a próxima temporada. Retorna nº de aposentadorias.
function evoluiEstadoMundo(chave,est){
  const rg=rngClube("evo|"+chave+"|"+S.temp);
  let aposent=0;
  const pp=chave.split("|"),inf=(LIGAS[pp[0]]&&LIGAS[pp[0]][+pp[1]])?LIGAS[pp[0]][+pp[1]][+pp[2]]:null;
  const bfm=bonusFamaEvolucao(inf?inf[0]:"");
  est.c=est.c.map((t,i)=>{
    let idade=t[0]+1,f=t[1]/10,pot=t[2],art=t[3],gen=t[5]||0;
    f=Math.max(15,Math.min(100,f+crescimentoCompacto(idade,f,pot,rg)+(idade<=28?Math.min(bfm,Math.max(0,pot-f)):0)));
    if(idade>=29&&pot>Math.round(f))pot=Math.round(f);
    if(idade>=39){ // aposenta: entra um jovem da base, gerado pela semente (geração +1 no mesmo slot)
      gen+=1;aposent++;
      const j=jogadorDeGeracao(chave,i,gen,est.pico);
      return[j.idade,Math.round(j.f*10),j.pot,0,0,gen,idParaNum(j.id),empacotaIdent(j)];
    }
    return[idade,Math.round(f*10),pot,art,0,gen,t[6]!=null?t[6]:null,t[7]!=null?t[7]:null];       // golsLiga zera a cada temporada; identidade preservada
  });
  return aposent;
}
// Evolui todos os clubes do mundo que existem em S.mundo e todos os que ainda não foram abertos (criados sob demanda e já evoluídos)
function evoluiMundoTodo(){
  if(!S.mundo)S.mundo={};
  let n=0;
  Object.keys(LIGAS).forEach(pais=>LIGAS[pais].forEach((lst,dv)=>lst.forEach((c,idx)=>{
    if(pais===S.pais&&S.clubes.find(x=>x.nome===c[0]))return;           // clubes da minha liga evoluem pelo caminho normal
    const k=chaveClube(pais,dv,idx);
    if(S.ext&&S.ext[k]&&S.ext[k].mexido){evoluiElenco(S.ext[k],k);n++;return}   // clube alterado: elenco completo
    if(!S.mundo[k])S.mundo[k]=criaEstadoMundo(k,picoClube(pais,dv,idx));
    // se existe na memória (montado nesta sessão), sincroniza antes de evoluir
    if(S._mem&&S._mem[k]&&S._mem[k].compacto)S.mundo[k].c=compactaElencoComGen(S._mem[k].elenco,S.mundo[k].c);
    evoluiEstadoMundo(k,S.mundo[k]);n++;
  })));
  S._mem={};                                                              // descarta o cache: será remontado já evoluído
  S.mundoTemp=S.temp;S._evoMundoG=null;
  return n;
}


// ===== LIGAS VIVAS DO MUNDO (etapa 2) =====
// S.ligas["pais|div"] = { k:rodadas jogadas, R:total, nomes:[clubes], tab:{nome:[pts,j,v,e,d,gp,gc]}, gols:{"nome#slot":gols}, ultimos:[[a,b,ga,gb],...] }
// Tudo guardado em arrays curtos (compacto). Os gols vão para o SLOT do jogador (posição no elenco), sem montar nomes.
const PESO_POS={ATA:5,PE:2.5,MEI:2.5,VOL:1,ZAG:.4,LD:.4,LE:.4,GOL:0};
function rodadasDe(n){return n%2===0?2*(n-1):2*n}
function chaveLiga(pais,div){return pais+"|"+div}
// calendário todos-contra-todos (algoritmo do círculo), ida e volta. Devolve rodadas [[ia,ib],...]
function calendarioLiga(n){
  const m=n%2?n+1:n,t=[...Array(m).keys()],R=[];
  for(let r=0;r<m-1;r++){
    const jogos=[];
    for(let i=0;i<m/2;i++){const a=t[i],b=t[m-1-i];if(a<n&&b<n)jogos.push([a,b])}
    R.push(jogos);t.splice(1,0,t.pop());
  }
  return R.concat(R.map(r=>r.map(([a,b])=>[b,a])));
}
function criaLigaViva(pais,div){
  const nomes=clubesNaDivisao(pais,div).map(c=>c[0]);
  const tab={};nomes.forEach(n=>{tab[n]=[0,0,0,0,0,0,0]});
  return{k:0,R:rodadasDe(nomes.length),nomes,tab,gols:{},ass:{},ultimos:[],temp:S.temp};
}
function garanteLigasVivas(){
  if(!S.ligas)S.ligas={};
  Object.keys(LIGAS).forEach(pais=>LIGAS[pais].forEach((_,div)=>{
    const k=chaveLiga(pais,div);
    if(pais===S.pais&&div===S.div)return;                     // a MINHA divisão é simulada pelo motor normal
    if(!S.ligas[k]||S.ligas[k].temp!==S.temp)S.ligas[k]=criaLigaViva(pais,div);
  }));
}
// pesos de gol por slot do elenco compacto: usa a força de cada slot (quem é melhor faz mais gols)
function pesosDeGol(pais,div,nome){
  const ch=chaveFixa(pais,nome);if(!ch)return POS22.map(p=>PESO_POS[p]);
  const k=chaveClube(pais,ch.div,ch.idx);
  const est=S.mundo&&S.mundo[k];
  return POS22.map((pos,i)=>{
    const f=est?est.c[i][1]/10:50;
    return PESO_POS[pos]*Math.pow(Math.max(20,f)/60,2);
  });
}
function golDeSlot(pesos,r){
  let tot=0;for(let i=0;i<pesos.length;i++)tot+=pesos[i];
  if(tot<=0)return 13;
  let x=r*tot,acc=0;
  for(let i=0;i<pesos.length;i++){acc+=pesos[i];if(x<=acc)return i}
  return pesos.length-1;
}
function forcaParaLiga(pais,div,nome){
  // força real do elenco (estado compacto → média dos 11 melhores), sem montar nomes
  const ch=chaveFixa(pais,nome);if(!ch)return 45;
  const k=chaveClube(pais,ch.div,ch.idx);
  if(!S.mundo)S.mundo={};
  if(!S.mundo[k])S.mundo[k]=criaEstadoMundo(k,picoClube(pais,ch.div,ch.idx));
  if(S.ext&&S.ext[k]&&S.ext[k].mexido)return S.ext[k].forca;
  const f=S.mundo[k].c.map(t=>t[1]/10).sort((a,b)=>b-a).slice(0,11);
  return f.reduce((q,x)=>q+x,0)/11;
}
function jogaRodadaLiga(pais,div,rg){
  const L=S.ligas[chaveLiga(pais,div)];if(!L||L.k>=L.R)return;
  if(!L.cal)L.cal=calendarioLiga(L.nomes.length);      // calendário em memória (não é salvo: regenerado)
  const jogos=L.cal[L.k]||[];L.ultimos=[];
  jogos.forEach(([ia,ib])=>{
    const a=L.nomes[ia],b=L.nomes[ib];
    const fa=forcaParaLiga(pais,div,a)+3,fb=forcaParaLiga(pais,div,b);
    const gm=(m)=>{const lim=Math.exp(-m);let q=0,pr=1;do{q++;pr*=rg()}while(pr>lim);return q-1};
    const ga=gm(Math.max(.25,(fa-fb)/22+1.35)),gb=gm(Math.max(.25,(fb-fa)/22+1.0));
    const ta=L.tab[a],tb=L.tab[b];
    ta[1]++;tb[1]++;ta[5]+=ga;ta[6]+=gb;tb[5]+=gb;tb[6]+=ga;
    if(ga>gb){ta[0]+=3;ta[2]++;tb[4]++}else if(ga<gb){tb[0]+=3;tb[2]++;ta[4]++}else{ta[0]++;tb[0]++;ta[3]++;tb[3]++}
    [[a,ga],[b,gb]].forEach(([clube,g])=>{
      if(!g)return;const pw=pesosDeGol(pais,div,clube);
      let pa=null;
      for(let q=0;q<g;q++){const sl=golDeSlot(pw,rg());const kk=clube+"#"+sl;L.gols[kk]=(L.gols[kk]||0)+1;
        if(rg()<.68){                                               // v61: assistência de jogada (68% dos gols)
          if(!pa)pa=pesosDeAssist(pais,div,clube);
          const pz=pa.slice();pz[sl]=0;                              // o autor não assiste a si mesmo
          const sa=golDeSlot(pz,rg());const ka=clube+"#"+sa;
          if(!L.ass)L.ass={};L.ass[ka]=(L.ass[ka]||0)+1;
        }
      }
    });
    L.ultimos.push([ia,ib,ga,gb]);
  });
  L.k++;
}
// Avança TODAS as divisões do mundo (menos a minha) proporcionalmente ao progresso global (g de G passos)
function avancaMundo(g,G){
  garanteLigasVivas();
  const rg=rngClube("mundo|"+S.temp+"|"+g);
  Object.keys(S.ligas).forEach(k=>{
    const L=S.ligas[k];const [pais,div]=k.split("|");
    const alvo=Math.min(L.R,Math.ceil(g*L.R/G));
    while(L.k<alvo)jogaRodadaLiga(pais,+div,rg);
  });
  try{ if(S._evoMundoG!==g){ const prev=S._evoMundoG==null?0:S._evoMundoG; S._evoMundoG=g; if(g>prev) evoluiMundoFatia((g-prev)/Math.max(1,G)); } }catch(e){}   // v57: o mundo evolui ao longo da temporada
}
function tabelaDe(pais,div){ // classificação ordenada de qualquer divisão (minha ou do mundo), por nome
  if(pais===S.pais&&div===S.div){
    return S.clubes.map(c=>({nome:c.nome,pts:c.pts,j:c.j,v:c.v,e:c.e,d:c.d,gp:c.gp,gc:c.gc}))
      .sort((a,b)=>b.pts-a.pts||(b.gp-b.gc)-(a.gp-a.gc)||b.gp-a.gp);
  }
  if(!S.ligas||!S.ligas[chaveLiga(pais,div)]||S.ligas[chaveLiga(pais,div)].temp!==S.temp){try{garanteLigasVivas()}catch(e){}}
  const L=S.ligas&&S.ligas[chaveLiga(pais,div)];if(!L)return[];
  return L.nomes.map(n=>{const t=L.tab[n];return{nome:n,pts:t[0],j:t[1],v:t[2],e:t[3],d:t[4],gp:t[5],gc:t[6]}})
    .sort((a,b)=>b.pts-a.pts||(b.gp-b.gc)-(a.gp-a.gc)||b.gp-a.gp);
}


// Artilheiro de cada divisão do mundo: o slot com mais gols vira +1 artilharia (e pode virar estrela)
function fechaArtilhariaMundo(){
  const avisos=[];
  Object.keys(S.ligas||{}).forEach(k=>{
    const L=S.ligas[k];if(!L||!Object.keys(L.gols).length)return;
    let melhor=null,mg=-1;
    Object.keys(L.gols).forEach(kk=>{if(L.gols[kk]>mg||(L.gols[kk]===mg&&kk<melhor)){mg=L.gols[kk];melhor=kk}});
    const [clube,slot]=[melhor.slice(0,melhor.lastIndexOf("#")),+melhor.slice(melhor.lastIndexOf("#")+1)];
    try{ // v61: líder de assistências da liga fica no histórico (artHistMundo)
      let ma=null,mv=-1;Object.keys(L.ass||{}).forEach(kk=>{if(L.ass[kk]>mv||(L.ass[kk]===mv&&kk<ma)){mv=L.ass[kk];ma=kk}});
      if(ma&&mv>0){const [pa0,dv0]=k.split("|");const cl0=ma.slice(0,ma.lastIndexOf("#")),sl0=+ma.slice(ma.lastIndexOf("#")+1);const ch0=chaveFixa(pa0,cl0);
        if(ch0){const kc0=chaveClube(pa0,ch0.div,ch0.idx);let nm0="Jogador";try{nm0=nomeDoSlot(kc0,pa0,ch0.div,ch0.idx,sl0)}catch(e){}
          if(!S.astHist)S.astHist=[];S.astHist.push({temp:S.temp,pais:pa0,div:+dv0,nome:nm0,clube:cl0,a:mv});S.astHist=S.astHist.filter(x=>S.temp-x.temp<8)}}
    }catch(e){}
    const [pais]=k.split("|");const ch=chaveFixa(pais,clube);if(!ch)return;
    const kc=chaveClube(pais,ch.div,ch.idx);
    if(!S.mundo)S.mundo={};
    if(!S.mundo[kc])S.mundo[kc]=criaEstadoMundo(kc,picoClube(pais,ch.div,ch.idx));
    try{ // v61: artilheiro de cada liga do mundo no histórico (guarda 8 temporadas)
      let nmA="Jogador";try{nmA=nomeDoSlot(kc,pais,ch.div,ch.idx,slot)}catch(e){}
      if(!S.artHistMundo)S.artHistMundo=[];
      S.artHistMundo.push({temp:S.temp,pais,div:ch.div,nome:nmA,clube,gols:mg});
      S.artHistMundo=S.artHistMundo.filter(x=>S.temp-x.temp<8);
    }catch(e){}
    const alt=S.ext&&S.ext[kc]&&S.ext[kc].mexido;
    if(alt){const j=S.ext[kc].elenco[slot];if(j){const antes=j.art||0;j.art=antes+1}return}   // clube alterado: slot pode não ser o mesmo; ignora com segurança
    const t=S.mundo[kc].c[slot];if(!t)return;
    const antes=t[3];t[3]=antes+1;
    const niv=a=>a>=5?2:a>=3?1:0;
    if(niv(t[3])>niv(antes)){
      const nome=nomeDoSlot(kc,pais,ch.div,ch.idx,slot);
      avisos.push({pais,clube,nome,nivel:niv(t[3]),art:t[3],liga:LIGANOME[pais][ch.div]});
    }
  });
  return avisos;
}
function nomeDoSlot(kc,pais,div,idx,slot){
  const est=S.mundo[kc];const pico=est.pico;
  const gen=est.c[slot][5]||0;
  const j=gen===0?baseMundo(kc,pico)[slot]:jogadorDeGeracao(kc,slot,gen,pico);
  return j.nome;
}


// ===== DIVISÃO ATUAL DE TODOS OS PAÍSES (etapa 3) =====
// S.divMundo[pais][nome] = divisão atual do clube (0 = 1ª). O meu país usa S.divAtual (mesma ideia, já existente).
function garanteDivMundo(){
  if(!S.divMundo)S.divMundo={};
  Object.keys(LIGAS).forEach(pais=>{
    if(pais===S.pais)return;
    if(S.divMundo[pais])return;
    const m={};LIGAS[pais].forEach((lst,dv)=>lst.forEach(c=>{m[c[0]]=dv}));
    S.divMundo[pais]=m;
  });
}
function divDoClube(pais,nome){
  if(pais===S.pais){garanteDivAtual();return S.divAtual[nome]}
  garanteDivMundo();return S.divMundo[pais]?S.divMundo[pais][nome]:undefined;
}
// lista de clubes [nome,sig,cor,cor2] da divisão ATUAL de qualquer país
function clubesNaDivisao(pais,div){
  if(pais===S.pais)return clubesDaDivisao(pais,div);
  garanteDivMundo();
  const out=[];LIGAS[pais].forEach(lst=>lst.forEach(c=>{if(S.divMundo[pais][c[0]]===div)out.push(c)}));
  return out;
}
// Fim de temporada do MUNDO: usa as tabelas das ligas vivas para subir/cair em todos os países (menos o meu, que já tem a sua regra)
function acessoRebaixamentoMundo(){
  garanteDivMundo();
  const todos=[];
  Object.keys(LIGAS).forEach(pais=>{
    if(pais===S.pais)return;
    const nd=LIGAS[pais].length;
    const tabs=[];
    for(let dv=0;dv<nd;dv++){
      const t=tabelaDe(pais,dv);
      tabs[dv]=t.map(x=>x.nome);
    }
    const movs=[];
    for(let i=0;i<nd-1;i++){
      const kk=Math.min(4,Math.floor(tabs[i].length/4),Math.floor(tabs[i+1].length/4));
      if(kk<=0)continue;
      tabs[i].slice(-kk).forEach(n=>movs.push({nome:n,de:i,para:i+1,pais}));
      tabs[i+1].slice(0,kk).forEach(n=>movs.push({nome:n,de:i+1,para:i,pais}));
    }
    movs.forEach(m=>{S.divMundo[pais][m.nome]=m.para});
    // classificação final da 1ª divisão (antes dos movimentos): alimenta as vagas continentais
    if(!S.tabFinalMundo)S.tabFinalMundo={};
    S.tabFinalMundo[pais]=tabs[0].slice();
    movs.forEach(m=>todos.push(m));
  });
  return todos;
}


// ===== COPA NACIONAL DOS OUTROS PAÍSES =====
// S.copasMundo[pais] = { temp, vivos:[nome], fase, campeao, hist:[[fase,[[a,b,ga,gb]...]]] }  (compacto)
// Mata-mata de jogo único com TODOS os clubes das divisões (divisão ATUAL). Fases preliminares nivelam até potência de 2.
function copaMundoNomeFase(n){return n===2?"Final":n===4?"Semifinal":n===8?"Quartas de final":n===16?"Oitavas de final":n===32?"16 avos de final":"Fase preliminar"}
function copaMundoInicia(pais){
  if(!S.copasMundo)S.copasMundo={};
  const nomes=[];
  LIGAS[pais].forEach((_,dv)=>clubesNaDivisao(pais,dv).forEach(c=>nomes.push(c[0])));
  let alvo0=1;while(alvo0*2<=nomes.length)alvo0*=2;
  S.copasMundo[pais]={temp:S.temp,vivos:nomes,fase:0,total:(nomes.length>alvo0?1:0)+Math.round(Math.log2(alvo0)),campeao:null,hist:[]};
  return S.copasMundo[pais];
}
function copaMundoGaranteTemporada(){
  Object.keys(LIGAS).forEach(pais=>{
    if(pais===S.pais)return;                                   // a minha tem a copa completa
    const c=S.copasMundo&&S.copasMundo[pais];
    if(!c||c.temp!==S.temp)copaMundoInicia(pais);
  });
}
// joga UMA fase da copa do país; quem tem divisão menor joga primeiro nas preliminares
function copaMundoJogaFase(pais,rg){
  const c=S.copasMundo[pais];if(!c||c.campeao)return;
  let v=c.vivos.slice();const n=v.length;
  if(n<=1){c.campeao=v[0]||null;return}
  let alvo=1;while(alvo*2<=n)alvo*=2;
  let jogam,folga=[];
  if(n===alvo){jogam=v}
  else{                                                         // preliminar: só o excedente joga, os de divisão menor primeiro
    const ord=v.map(nm=>({nm,d:divDoClube(pais,nm)||0,r:rg()})).sort((a,b)=>b.d-a.d||a.r-b.r).map(o=>o.nm);
    const jogos=n-alvo;                                         // nº de jogos preliminares
    jogam=ord.slice(0,jogos*2);folga=ord.slice(jogos*2);
  }
  const emb=jogam.map(nm=>({nm,r:rg()})).sort((a,b)=>a.r-b.r).map(o=>o.nm);
  const vencedores=[],reg=[];
  for(let i=0;i+1<emb.length;i+=2){
    const a=emb[i],b=emb[i+1];
    const fa=forcaParaLiga(pais,0,a)+3,fb=forcaParaLiga(pais,0,b);
    const gm=m=>{const lim=Math.exp(-m);let q=0,pr=1;do{q++;pr*=rg()}while(pr>lim);return q-1};
    let ga=gm(Math.max(.25,(fa-fb)/22+1.35)),gb=gm(Math.max(.25,(fb-fa)/22+1.0));
    if(ga===gb){const pa=1/(1+Math.exp(-(fa-fb)/12));if(rg()<pa)ga++;else gb++}   // pênaltis: leve vantagem do mais forte
    vencedores.push(ga>gb?a:b);reg.push([a,b,ga,gb]);
  }
  c.hist.push([n===alvo?copaMundoNomeFase(n):"Fase preliminar",reg]);
  c.vivos=[...folga,...vencedores];c.fase++;
  if(c.vivos.length===1)c.campeao=c.vivos[0];
}
// Avança as copas do mundo proporcionalmente ao progresso da temporada (prog 0..1): janela 6%-66%
function copaMundoAvanca(prog){
  copaMundoGaranteTemporada();
  const rg=rngClube("copaMundo|"+S.temp+"|"+Math.round(prog*1000));
  Object.keys(S.copasMundo).forEach(pais=>{
    const c=S.copasMundo[pais];if(!c||c.temp!==S.temp||c.campeao||pais===S.pais)return;
    const total=c.total||6;                                      // nº de fases fixado no início da copa
    const quer=prog>=.66?total:Math.min(total,Math.floor(total*Math.max(0,(prog-.06))/(.66-.06)));
    let guard=0;while(!c.campeao&&c.fase<quer&&guard++<8)copaMundoJogaFase(pais,rg);
  });
}
function campeaoCopaMundo(pais){
  const c=S.copasMundo&&S.copasMundo[pais];
  if(!c||c.temp!==S.temp-1&&c.temp!==S.temp)return null;
  return c.campeao;
}


function fechaCopasMundo(){
  copaMundoAvanca(1);                                              // termina o que faltar
  if(!S.campeoesCopa)S.campeoesCopa={};
  if(!S.histCopaMundo)S.histCopaMundo=[];
  Object.keys(S.copasMundo||{}).forEach(pais=>{
    const c=S.copasMundo[pais];if(!c||c.temp!==S.temp||pais===S.pais)return;
    if(!c.campeao){let g=0;const rg=rngClube("copaFim|"+pais+"|"+S.temp);while(!c.campeao&&g++<10)copaMundoJogaFase(pais,rg)}
    if(c.campeao){S.campeoesCopa[pais]={temp:S.temp,nome:c.campeao};S.histCopaMundo.push({temp:S.temp,pais,nome:c.campeao})}
  });
  if(S.histCopaMundo.length>400)S.histCopaMundo=S.histCopaMundo.slice(-400);
}


// ===== ENERGIA POR DIAS DE DESCANSO + NOTAS E GANHO DE FORÇA (v32) =====
// Data real (em dias) da data atual da agenda; usada para medir o descanso entre jogos.
function diaAbsolutoAgenda(i){
  const d=S.agenda&&S.agenda[i];if(!d)return null;
  return Math.floor(Date.UTC(d.ano,d.mes,d.dia)/86400000);
}
// Quantos dias de descanso o clube teve antes do jogo na data S.dia (compara com a data anterior da agenda)
function diasDescansoAntes(){
  const a=diaAbsolutoAgenda(S.dia),b=S.dia>0?diaAbsolutoAgenda(S.dia-1):null;
  if(a==null||b==null)return 7;
  return Math.max(0,a-b);
}
// Desgaste do jogo (feito logo ao fim da partida) — vale para liga e copas
function desgasteJogo(j,copa){
  const base=copa?rnd(14,24):Math.round(rnd(18,28)*poupaEnergia(j)*((j.hab||[]).includes("Resistência")?.8:1));
  return base;
}
// Aplica, ao FIM de um jogo do meu clube, o desgaste de quem jogou e a recuperação de quem não jogou.
// A recuperação para o PRÓXIMO jogo é aplicada na hora em que a próxima data começa (ver recuperaParaProximoJogo).
function energiaPosJogo(clube,copa){
  // v58: antes de mexer em 'tit', registra quem ATUOU neste jogo (para entrosamento/moral) e o resultado do meu time
  let res=0,classico=false;
  try{
    const P=S.pos;
    if(P){const meuA=P.a===S.meu,mg=meuA?P.ga:P.gb,ag=meuA?P.gb:P.ga;res=mg>ag?1:mg<ag?-1:0;
      const adv=S.clubes[meuA?P.b:P.a];classico=!!(adv&&ehRival(adv.nome))}
  }catch(e){}
  clube.elenco.forEach(j=>{j.jogou_ultimo=!!j.tit});
  try{atualizaEntrosMoral(clube,res,classico);registraClassico(res,classico)}catch(e){}
  try{if(!S._clbak||true){verificaPedidosSaida()}}catch(e){}
  try{if(S.pos&&S.pos.a===S.meu){desgasteGramado();if(S.pos.clima==='chuva'||S.pos.clima==='tempestade')S.gramado=Math.max(20,S.gramado-1.5)}}catch(e){}
  clube.elenco.forEach(j=>{
    const e0=j.en==null?100:j.en;
    if(j.tit){j.en=Math.max(20,e0-desgasteJogo(j,copa));j.ultimoJogoDia=diaAbsolutoAgenda(S.dia)}
    j.jogou=j.jogou||!!j.tit;
    if(j.lesao>0&&!j.lesAoVivo)j.lesao--;
    j.lesAoVivo=false;j.lesionadoJogo=false;
  });
}
// Chamada ao avançar a data do calendário: quem descansou 4+ dias volta a 100%; menos que isso recupera 8 por dia (dias seguidos: 100 → 85 → 70)
function recuperaParaProximoJogo(clube){
  const hoje=diaAbsolutoAgenda(S.dia);if(hoje==null)return;
  clube.elenco.forEach(j=>{
    const e0=j.en==null?100:j.en;
    if(e0>=100)return;
    const ref=(j.ultimoJogoDia!=null)?j.ultimoJogoDia:hoje-7;
    const dias=Math.max(0,hoje-ref);
    j.en=dias>=4?100:Math.min(100,e0+8*dias);
  });
}
// ---------- notas por jogador e ganho de força a cada 10 jogos ----------
// j.nts = últimas notas do bloco atual (máx 10). Ao completar 10 jogos, avalia o bloco e zera.
function registraNotasJogo(clube,listaNotas){
  // listaNotas: [{id,nota}] de quem atuou
  listaNotas.forEach(o=>{
    const j=clube.elenco.find(x=>x.id===o.id);if(!j)return;
    if(!j.nts)j.nts=[];
    j.nts.push(o.nota);
    j.mediaNota=Math.round(j.nts.reduce((q,x)=>q+x,0)/j.nts.length*10)/10;
    if(j.nts.length>=10)avaliaBlocoNotas(clube,j);
  });
}
function registraNotasDoPos(clube,meuEhA){
  try{
    if(!S.pos)return;
    const lado=meuEhA?S.pos.A:S.pos.B;
    S.avisosForca=[];
    if(lado&&lado.lista)registraNotasJogo(clube,lado.lista.map(o=>({id:o.id,nota:o.nota})));
    // v57: evolução jogo a jogo — todo mundo que atuou ganha de acordo com nota e minutos; avisa quem subiu um ponto inteiro
    try{
      const fama=nivelFama(clube.nome),subs=(lado&&lado.sub)||[],subsMin=subs.map(x=>({m:x.m,entra:x.entra,sai:x.sai}));
      const subiu=[];
      if(lado&&lado.lista)lado.lista.forEach(o=>{
        const j=clube.elenco.find(x=>x.id===o.id);if(!j)return;
        const min=o.ent?minutosDoJogo(o,subsMin,o.id):minutosDoJogo(o,subsMin,o.id);
        const g=ganhoPorJogo(j,o.nota,min,fama);
        if(j.ultimoBloco)j.ultimoBloco.acum=(j.ultimoBloco.acum||0)+g;else j.ultimoBloco={altas:0,media:0,ganho:0,acum:g};
        const d=aplicaGanhoJogo(clube,j,g);
        if(d>0)subiu.push(`⬆️ ${j.nome} (${j.pos}): ${j.f-d} → ${j.f} de força`);
      });
      S.avisosForca=subiu;
    }catch(e){}
    S.pos.ganhos=(S.avisosForca||[]).slice();S.avisosForca=[];
    // histórico completo por partida (para a ficha do jogador)
    const advC=S.clubes[meuEhA?S.pos.b:S.pos.a];
    const meuG=meuEhA?S.pos.ga:S.pos.gb,advG=meuEhA?S.pos.gb:S.pos.ga;
    const comp=(S.pos.tituloCompleto||S.pos.rodadaTxt||"Liga").replace(/^.*?·\s*/,"");
    const dia=S.agenda&&S.agenda[S.dia]?S.agenda[S.dia].dia+"/"+((S.agenda[S.dia].mes+1)+"").padStart(2,"0"):"";
    if(lado&&lado.lista)lado.lista.forEach(o=>{
      const j=clube.elenco.find(x=>x.id===o.id);if(!j)return;
      if(!j.hn)j.hn=[];
      j.hn.push([o.nota,advC?(advC.sig||advC.nome.slice(0,3).toUpperCase()):"?",meuG+"x"+advG,comp.slice(0,22),o.gols||0,o.vm?2:(o.cart?1:0),o.ent?1:0,dia,S.temp]);
      if(j.hn.length>40)j.hn=j.hn.slice(-40);
    });
  }catch(e){}
}
function avaliaBlocoNotas(clube,j){
  // v57: a força agora evolui A CADA JOGO (aplicaGanhoJogo). O bloco de 10 só fecha a estatística do jogador.
  const ns=j.nts.slice(0,10);j.nts=[];
  const altas=ns.filter(n=>n>=7).length;
  const media=ns.reduce((q,x)=>q+x,0)/ns.length;
  j.ultimoBloco={altas,media:Math.round(media*10)/10,ganho:j.ultimoBloco&&j.ultimoBloco.acum?Math.round(j.ultimoBloco.acum*10)/10:0};
  if(j.ultimoBloco)j.ultimoBloco.acum=0;
}


// ===== TELA: COPAS NACIONAIS DO MUNDO =====
function abaCopasMundo(){
  try{copaMundoGaranteTemporada()}catch(e){}
  const paises=Object.keys(LIGAS).filter(p=>p!==S.pais);
  const pa=S.cmPais&&paises.includes(S.cmPais)?S.cmPais:paises[0];
  const c=S.copasMundo&&S.copasMundo[pa];
  let h=topoAba("🗺️","Copas nacionais do mundo","Acompanhe a copa de cada país",[]);
  h+=`<div class="card">
    <select style="width:100%;padding:10px;font-size:14px;border-radius:10px;background:var(--card2);color:var(--tx);border:1px solid var(--bd)" onchange="S.cmPais=this.value;render()">${paises.map(p=>`<option ${p===pa?'selected':''}>${p}</option>`).join("")}</select></div>`;
  if(!c){return h+`<div class="card mu">A copa deste país começa na próxima data do calendário.</div>`}
  const total=c.total||6;
  const prog=Math.min(100,Math.round(c.fase/total*100));
  h+=`<div class="card"><div class="cmTopo"><div><div class="cmT">Copa ${pa==='Brasil'?'do Brasil':'de '+pa} · Temp. ${c.temp}</div><div class="cmS">${c.campeao?'Campeão definido':'Fase '+(c.fase+1)+' de '+total+' · '+c.vivos.length+' clubes vivos'}</div></div>${c.campeao?'<div class="cmTrof">🏆</div>':''}</div>
    <div class="cmBar"><i style="width:${prog}%"></i></div>`;
  if(c.campeao){const inf=infoCor(pa,c.campeao);h+=`<div class="cmCamp">${escudo(inf,34)}<div><small>CAMPEÃO</small><b>${c.campeao}</b></div></div>`}
  h+=`</div>`;
  // chaveamento: fases jogadas (resultados guardados) – mais recente primeiro
  const hist=(c.hist||[]).slice().reverse();
  if(hist.length){
    hist.forEach(([nome,jogos])=>{
      h+=`<div class="card"><div class="tag" style="margin-bottom:6px">${nome} · ${jogos.length} jogo${jogos.length>1?'s':''}</div>`;
      jogos.slice(0,16).forEach(([a,b,ga,gb])=>{
        const ia=infoCor(pa,a),ib=infoCor(pa,b);
        h+=`<div class="cmJ"><div class="cmC ${ga>gb?'v':''}">${escudo(ia,15)}<span>${a}</span></div><div class="cmP">${ga}</div><div class="cmP">${gb}</div><div class="cmC d ${gb>ga?'v':''}"><span>${b}</span>${escudo(ib,15)}</div></div>`;
      });
      if(jogos.length>16)h+=`<div class="mu" style="font-size:11px;text-align:center;padding:4px">+ ${jogos.length-16} jogos</div>`;
      h+=`</div>`;
    });
  }else h+=`<div class="card mu" style="text-align:center">As fases aparecem aqui conforme a temporada avança.</div>`;
  // histórico de campeões
  const hc=(S.histCopaMundo||[]).filter(x=>x.pais===pa).slice().reverse();
  h+=`<div class="card"><div class="tag" style="margin-bottom:6px">🏆 Campeões anteriores</div>${hc.length?hc.map(x=>`<div class="ln2 row" style="display:flex;justify-content:space-between"><span class="mu">Temp. ${x.temp}</span><b>${x.nome}</b></div>`).join(""):'<div class="mu" style="font-size:12px">Nenhuma temporada concluída ainda.</div>'}</div>`;
  return h;
}


// ===== FAMA DOS CLUBES: regional, continental, mundial (v34) =====
// Base histórica (clubes conhecidos) + títulos conquistados no jogo. Nível 0 regional, 1 continental, 2 mundial.
const FAMA_MUNDIAL=["Real Madrid","Barcelona","Manchester United","Liverpool","Manchester City","Bayern de Munique","Paris Saint-Germain","Juventus","Milan","Inter","Chelsea","Arsenal","Atlético de Madrid","Borussia Dortmund","Flamengo","Boca Juniors","River Plate"];
const FAMA_CONTINENTAL=["Tottenham","Napoli","Roma","Lazio","Atalanta","Benfica","Porto","Sporting CP","Ajax","PSV Eindhoven","Feyenoord","Bayer Leverkusen","RB Leipzig","Olympique de Marseille","Olympique Lyonnais","Monaco","Sevilla","Valencia","Athletic Bilbao","Villarreal","Real Sociedad","Newcastle United","Aston Villa","West Ham","Everton","Leeds United","Celtic","Rangers","Galatasaray","Fenerbahçe","Beşiktaş","Club Brugge","Anderlecht","Zenit","Palmeiras","Corinthians","São Paulo","Santos","Grêmio","Internacional","Atlético Mineiro","Cruzeiro","Fluminense","Botafogo","Vasco da Gama","Racing Club","Independiente","San Lorenzo","Estudiantes","Vélez Sarsfield","América","Guadalajara","Cruz Azul","Tigres UANL","Monterrey","Pumas UNAM","Peñarol","Nacional","Colo-Colo","Atlético Nacional","Millonarios","Al-Hilal","Al-Nassr","Inter Miami","LA Galaxy"];
// pontos de fama: base (continental 40, mundial 75, regional 10) + títulos do jogo
function famaBase(nome){return FAMA_MUNDIAL.includes(nome)?75:FAMA_CONTINENTAL.includes(nome)?40:10}
function titulosClube(nome){
  const t=S.titulos&&S.titulos[nome];return t||{liga:0,copa:0,cont:0,mundial:0};
}
function pontosFama(nome){
  const t=titulosClube(nome);
  return famaBase(nome)+t.liga*4+t.copa*3+t.cont*14+t.mundial*30;
}
function nivelFama(nome){const p=pontosFama(nome);return p>=85?2:p>=45?1:0}
function nomeFama(nome){return["Regional","Continental","Mundial"][nivelFama(nome)]}
function iconeFama(nome){return["📍","🌎","🌍"][nivelFama(nome)]}
function registraTitulo(nome,tipo){ // tipo: liga | copa | cont | mundial
  if(!S.titulos)S.titulos={};
  if(!S.titulos[nome])S.titulos[nome]={liga:0,copa:0,cont:0,mundial:0};
  S.titulos[nome][tipo]++;
}
// bônus de evolução dos jogadores conforme a fama do clube (clube grande atrai e desenvolve melhor)
function bonusFamaEvolucao(nome){return[0,.15,.35][nivelFama(nome)]}
// multiplicador de público/renda: depende da fama do clube e do momento (posição, torcida)
function fatorFamaPublico(nome){return[1,1.12,1.28][nivelFama(nome)]}


// Registra, no fim da temporada, os títulos de TODOS os campeonatos (liga, copa nacional, continentais) para alimentar a fama
function registraTitulosTemporada(campeaoMinhaLiga){
  const nomeDe=(e)=>{try{return(e&&e.campeao!=null&&e.parts&&e.parts[e.campeao])?e.parts[e.campeao].nome:null}catch(x){return null}};
  const premia=[];
  const add=(nome,tipo,pais,comp)=>{if(!nome)return;registraTitulo(nome,tipo);premia.push({nome,tipo,pais});try{regTituloTec(nome,comp||tipo,pais||S.pais)}catch(e){}};
  add(campeaoMinhaLiga,"liga",S.pais,"liga");
  add(nomeDe(S.cn),"copa",S.pais,"copa");
  add(nomeDe(S.cl),"cont",null,"cl");add(nomeDe(S.el),"cont",null,"el");add(nomeDe(S.lb),"cont",null,"lb");add(nomeDe(S.sa),"cont",null,"sa");
  if(!S.campContinental)S.campContinental=[];
  [[S.cl,"eur"],[S.lb,"sul"]].forEach(([e,conf])=>{const n=nomeDe(e);if(n)S.campContinental.push({temp:S.temp,nome:n,conf})});
  if(S.campContinental.length>12)S.campContinental=S.campContinental.slice(-12);
  // ligas e copas dos outros países
  Object.keys(S.ligas||{}).forEach(k=>{
    const [pais,dv]=k.split("|");if(+dv!==0||pais===S.pais)return;
    const t=tabelaDe(pais,0);if(t.length)add(t[0].nome,"liga",pais,"liga");
  });
  Object.keys(S.copasMundo||{}).forEach(pais=>{const c=S.copasMundo[pais];if(c&&c.temp===S.temp&&c.campeao&&pais!==S.pais)add(c.campeao,"copa",pais,"copa")});
  return premia;
}


// ===== PREMIAÇÃO (v34) =====
// Valores em reais. Champions/Libertadores seguem a ordem de grandeza dos valores reais (UEFA ≈ €2,1 mi por vitória, €25 mi ao campeão;
// CONMEBOL ≈ US$ 330 mil por vitória, US$ 24 mi ao campeão). Ligas nacionais: escala própria por país e divisão (não são valores oficiais).
const EUR=6,USD=5.5,K_EU=0.10,K_SA=0.085;     // K reduz os valores reais para a escala econômica do jogo (v37)
const PREMIO_COMP={
  cl:{part:18.6e6*EUR*K_EU,vit:2.1e6*EUR*K_EU,emp:.7e6*EUR*K_EU,fase:{repescagem:1e6*EUR*K_EU,oitavas:11e6*EUR*K_EU,quartas:12.5e6*EUR*K_EU,semi:15e6*EUR*K_EU,final:18.5e6*EUR*K_EU},campeao:25e6*EUR*K_EU},
  el:{part:4.3e6*EUR*K_EU,vit:.45e6*EUR*K_EU,emp:.15e6*EUR*K_EU,fase:{oitavas:.8e6*EUR*K_EU,quartas:1.5e6*EUR*K_EU,semi:2.4e6*EUR*K_EU,final:4e6*EUR*K_EU},campeao:6e6*EUR*K_EU},
  lb:{part:3e6*USD*K_SA,vit:.33e6*USD*K_SA,emp:0,fase:{oitavas:1.25e6*USD*K_SA,quartas:1.5e6*USD*K_SA,semi:3e6*USD*K_SA,final:7e6*USD*K_SA},campeao:24e6*USD*K_SA},
  sa:{part:1.2e6*USD*K_SA,vit:.1e6*USD*K_SA,emp:0,fase:{oitavas:.5e6*USD*K_SA,quartas:.8e6*USD*K_SA,semi:1.5e6*USD*K_SA,final:3e6*USD*K_SA},campeao:6e6*USD*K_SA},
  cn:{part:50e3,vit:30e3,emp:0,fase:{},campeao:1.2e6},
  mund:{part:12e6*USD*K_EU,vit:2e6*USD*K_EU,emp:1e6*USD*K_EU,fase:{},campeao:40e6*USD*K_EU}
};
// escala das ligas nacionais: potência econômica do país (1 = Brasil) e queda por divisão
const ECON_PAIS={Inglaterra:5,Espanha:3.2,Itália:2.8,Alemanha:3,França:2.4,Portugal:1.4,Holanda:1.4,Brasil:1,Argentina:.5,México:1.1,"Estados Unidos":1.6,Japão:1.2,Turquia:.9,Bélgica:.9,Escócia:.7,Rússia:.8,Colômbia:.4,Uruguai:.3,Chile:.35,"Arábia Saudita":1.8};
function premioLiga(pais,div,posFinal,nClubes){
  const econ=ECON_PAIS[pais]||.6,esc=[1,.22,.06][div]||.04;
  const topo=6e6*econ*esc;                                          // prêmio do campeão
  const frac=Math.max(0,1-(posFinal-1)/Math.max(1,nClubes-1));      // 1º = 100%, último = 0
  return Math.round(topo*(0.12+0.88*Math.pow(frac,1.6)));
}
function premioPartidaLiga(pais,div,resultado){ // 1 vitória, 0 empate, -1 derrota: bônus por jogo
  const econ=ECON_PAIS[pais]||.6,esc=[1,.22,.06][div]||.04;
  const v=40e3*econ*esc;return resultado>0?Math.round(v):resultado===0?Math.round(v*.35):0;
}
// guarda extrato da temporada
function lancaPremio(valor,descricao){
  if(!valor)return;
  const eu=(S._clbak?S._clbak.clubes[S._clbak.meu]:S.clubes[S.meu]);if(!eu)return;
  eu.caixa+=valor;finRec('Prêmios e premiações',valor);
  if(!S.extrato)S.extrato={temp:S.temp,itens:[],total:0};
  if(S.extrato.temp!==S.temp)S.extrato={temp:S.temp,itens:[],total:0};
  S.extrato.itens.push([descricao,Math.round(valor)]);S.extrato.total+=Math.round(valor);
  if(S.extrato.itens.length>120)S.extrato.itens=S.extrato.itens.slice(-120);
}
// premia o jogo da competição `comp` (cl/el/lb/sa/cn) ou "liga"; res: 1,0,-1; faseTxt: ex. "oitavas"
function premiaJogo(comp,res,faseTxt,primeiraVez){
  if(comp==="liga"){const v=premioPartidaLiga(S.pais,S.div,res);if(v)lancaPremio(v,(res>0?"Vitória":"Empate")+" · "+LIGANOME[S.pais][S.div]);return}
  const P=PREMIO_COMP[comp];if(!P)return;
  const nome={cl:"Champions",el:"Liga Europa",lb:"Libertadores",sa:"Sul-Americana",cn:"Copa nacional",mund:"Mundial"}[comp];
  if(res>0&&P.vit)lancaPremio(P.vit,"Vitória · "+nome);else if(res===0&&P.emp)lancaPremio(P.emp,"Empate · "+nome);
}
// bônus ao ENTRAR numa nova fase (cota de participação na 1ª vez; bônus de fase depois)
function premiaFase(comp,fase){
  const P=PREMIO_COMP[comp];if(!P)return;
  const nome={cl:"Champions",el:"Liga Europa",lb:"Libertadores",sa:"Sul-Americana",cn:"Copa nacional"}[comp];
  if(!S.premiadas)S.premiadas={};
  const k=S.temp+"|"+comp+"|"+fase;if(S.premiadas[k])return;S.premiadas[k]=1;
  if(fase==="liga"||fase==="grupos"){if(P.part)lancaPremio(P.part,"Cota de participação · "+nome)}
  else if(P.fase[fase])lancaPremio(P.fase[fase],"Classificação "+fase+" · "+nome);
}
function premiaCampeao(comp){
  const P=PREMIO_COMP[comp];if(!P||!P.campeao)return;
  const nome={cl:"Champions",el:"Liga Europa",lb:"Libertadores",sa:"Sul-Americana",cn:"Copa nacional"}[comp];
  lancaPremio(P.campeao,"🏆 Título · "+nome);
}


function premiosFimTemporada(posFinal,nClubes,meuNome){
  lancaPremio(premioLiga(S.pais,S.div,posFinal,nClubes),`Premiação da liga · ${posFinal}º lugar · ${LIGANOME[S.pais][S.div]}`);
  const nomeDe=(e)=>{try{return(e&&e.campeao!=null&&e.parts&&e.parts[e.campeao])?e.parts[e.campeao].nome:null}catch(x){return null}};
  [["cl",S.cl],["el",S.el],["lb",S.lb],["sa",S.sa],["cn",S.cn]].forEach(([k,e])=>{if(nomeDe(e)===meuNome)premiaCampeao(k)});
}


// ===== MUNDIAL DE CLUBES (formato de 32 clubes: 8 grupos de 4 + mata-mata) =====
// Vagas por confederação: Europa 12, América do Sul 6, África 4, Ásia 4, N/C América 4, Oceania 1, anfitrião 1.
// Preenchimento: campeões continentais mais recentes primeiro; depois melhores por força. África/Oceania usam clubes genéricos.
const MUNDIAL_VAGAS={eur:12,sul:6,afr:4,asi:4,nca:4,oce:1,anf:1};
const CONF_PAIS={eur:["Inglaterra","Espanha","Itália","Alemanha","França","Portugal","Holanda","Bélgica","Turquia","Escócia","Rússia"],sul:["Brasil","Argentina","Colômbia","Uruguai","Chile"],asi:["Japão","Arábia Saudita"],nca:["México","Estados Unidos"]};
/*v50*/

// ===== MUNDIAL — CLUBES DE FORA DAS 20 LIGAS (v50) =====
// [nome, sigla, país, cor1, cor2, força]. Forças na escala do jogo (Europa ≈ 52–61 de pico; Brasil ≈ 47).
const POOL_AFR=[
 ["Al Ahly","AHL","Egito","#c8102e","#ffffff",57],["Zamalek","ZAM","Egito","#ffffff","#c8102e",54],["Pyramids","PYR","Egito","#1b4fa0","#ffffff",53],
 ["Wydad Casablanca","WAC","Marrocos","#c8102e","#ffffff",55],["Raja Casablanca","RCA","Marrocos","#0a7d3b","#ffffff",54],["FAR Rabat","FAR","Marrocos","#0a7d3b","#c8102e",50],
 ["Mamelodi Sundowns","SUN","África do Sul","#ffd100","#1b4fa0",56],["Orlando Pirates","ORL","África do Sul","#111111","#ffffff",52],["Kaizer Chiefs","KAI","África do Sul","#ffd100","#111111",50],
 ["Espérance de Tunis","EST","Tunísia","#ffd100","#c8102e",54],["Club Africain","CAF","Tunísia","#c8102e","#ffffff",48],
 ["TP Mazembe","MAZ","RD Congo","#111111","#ffffff",51],["Petro de Luanda","PET","Angola","#ffd100","#111111",47],["Simba SC","SIM","Tanzânia","#c8102e","#ffffff",46],
 ["Al Hilal Omdurman","HOM","Sudão","#1b4fa0","#ffffff",45],["Enyimba","ENY","Nigéria","#1b4fa0","#ffffff",46],["CR Belouizdad","BEL","Argélia","#c8102e","#ffffff",49],["JS Kabylie","JSK","Argélia","#0a7d3b","#ffd100",47]
];
const POOL_ASI=[
 ["Al Ain","AIN","Emirados Árabes","#6b2c91","#ffffff",52],["Al Sadd","SAD","Catar","#7a1f3d","#ffffff",50],["Al Duhail","DUH","Catar","#c8102e","#ffffff",48],
 ["Persepolis","PRS","Irã","#c8102e","#ffffff",50],["Esteghlal","EST","Irã","#1b4fa0","#ffffff",49],["Sepahan","SEP","Irã","#ffd100","#111111",47],
 ["Jeonbuk Motors","JEO","Coreia do Sul","#0a7d3b","#ffffff",50],["Ulsan HD","ULS","Coreia do Sul","#1b4fa0","#ffd100",50],["Pohang Steelers","POH","Coreia do Sul","#c8102e","#111111",47],
 ["Shanghai Port","SHP","China","#c8102e","#ffffff",46],["Shandong Taishan","SHT","China","#ffd100","#c8102e",45],["Buriram United","BUR","Tailândia","#1b4fa0","#c8102e",43],
 ["Western Sydney","WSW","Austrália","#c8102e","#111111",44],["Melbourne City","MEL","Austrália","#6bb5e8","#ffffff",43],["Johor Darul Ta'zim","JDT","Malásia","#c8102e","#ffffff",42]
];
const POOL_NCA=[
 ["Saprissa","SAP","Costa Rica","#6b2c91","#ffffff",43],["Alajuelense","ALA","Costa Rica","#c8102e","#111111",42],["Olimpia","OLI","Honduras","#ffffff","#1b4fa0",40],
 ["Comunicaciones","COM","Guatemala","#ffffff","#0a7d3b",39],["Herediano","HER","Costa Rica","#ffd100","#c8102e",41],["Tauro FC","TAU","Panamá","#ffffff","#111111",38],
 ["CF Montréal","MTL","Canadá","#1b4fa0","#111111",43],["Toronto FC","TOR","Canadá","#c8102e","#ffffff",42],["Vancouver Whitecaps","VAN","Canadá","#1b4fa0","#ffffff",42],["Cavalry FC","CAV","Canadá","#ffffff","#c8102e",36]
];
const POOL_OCE=[
 ["Auckland City","AUC","Nova Zelândia","#1b4fa0","#ffffff",45],["Wellington Phoenix","WEL","Nova Zelândia","#ffd100","#111111",44],["Hekari United","HEK","Papua Nova Guiné","#c8102e","#ffd100",34],["Lautoka","LAU","Fiji","#ffffff","#1b4fa0",33]
];
const GEN_AFR=["Al Ahly","Wydad Casablanca","Mamelodi Sundowns","Espérance de Tunis","Zamalek","TP Mazembe","Raja Casablanca","Pyramids"];
const GEN_OCE=["Auckland City"];
function mundialMonta(){
  const lista=[];const usados=new Set();
  const add=(nome,pais,conf,forca,sig,cor,cor2)=>{if(usados.has(nome))return;usados.add(nome);lista.push({nome,pais,conf,forca:Math.round(forca),sig,cor,cor2,fama:pontosFama(nome)})};
  // por confederação: top da 1ª divisão (pela tabela final real, quando houver; senão pela força), campeões continentais primeiro
  const campCont=(S.campContinental||[]).filter(x=>x.temp!==S.temp).slice(-4);
  const corr=(e,conf)=>{try{if(e&&e.campeao!=null&&e.parts[e.campeao])campCont.push({temp:S.temp,nome:e.parts[e.campeao].nome,conf})}catch(x){}};
  corr(S.cl,"eur");corr(S.lb,"sul");
  const porConf=(conf,n)=>{
    const cand=[];
    campCont.filter(x=>x.conf===conf).reverse().forEach(x=>cand.push(x.nome));
    CONF_PAIS[conf].forEach(pa=>{
      const c=classificacaoMundo(pa,0).slice(0,conf==="eur"?4:3);
      c.forEach(x=>cand.push(pa+"|"+x.nome));
    });
    const rg=rngClube("mundial|"+conf+"|"+S.temp);
    const info=[];
    cand.forEach(k=>{
      const [pa,nm]=k.includes("|")?k.split("|"):[null,k];
      const pais=pa||Object.keys(CONF_PAIS).map(c=>CONF_PAIS[c]).flat().find(p=>chaveFixa(p,nm));
      if(!pais)return;const ch=chaveFixa(pais,nm);if(!ch)return;
      const inf=LIGAS[pais][ch.div][ch.idx];
      info.push({nome:nm,pais,forca:forcaParaLiga(pais,ch.div,nm),sig:inf[1],cor:inf[2],cor2:inf[3],camp:campCont.some(x=>x.nome===nm)});
    });
    // campeões continentais garantidos; resto pelas maiores forças+fama
    const camp=info.filter(x=>x.camp),resto=info.filter(x=>!x.camp).sort((a,b)=>(b.forca+pontosFama(b.nome)*.08)-(a.forca+pontosFama(a.nome)*.08));
    [...camp,...resto].slice(0,n).forEach(x=>add(x.nome,x.pais,conf,x.forca,x.sig,x.cor,x.cor2));
  };
  porConf("eur",MUNDIAL_VAGAS.eur);porConf("sul",MUNDIAL_VAGAS.sul);porConf("asi",MUNDIAL_VAGAS.asi-1);porConf("nca",MUNDIAL_VAGAS.nca-1);
  // v50: África, Ásia e Concacaf completam as vagas com clubes REAIS do pool (países sem liga jogável); Oceania sorteia do pool
  const rgg=rngClube("mundialGen|"+S.temp);
  const sorteia=(pool,n,conf,rotulo)=>{
    const cand=pool.filter(x=>!usados.has(x[0])).map(x=>({x,r:rgg()-(x[5]/60)*.9})).sort((a,b)=>a.r-b.r).slice(0,n);     // força pesa, mas todos têm chance
    cand.forEach(o=>{const c=o.x;add(c[0],c[2],conf,c[5]+rgg()*3-1.5,c[1],c[3],c[4])});
  };
  sorteia(POOL_AFR,MUNDIAL_VAGAS.afr,"afr");
  sorteia(POOL_OCE,MUNDIAL_VAGAS.oce,"oce");
  // se Ásia ou Concacaf ficaram com menos vagas do que o previsto (poucos clubes qualificados), completa com o pool
  const contaConf=c=>lista.filter(t=>t.conf===c).length;
  if(contaConf("asi")<MUNDIAL_VAGAS.asi)sorteia(POOL_ASI,MUNDIAL_VAGAS.asi-contaConf("asi"),"asi");
  if(contaConf("nca")<MUNDIAL_VAGAS.nca)sorteia(POOL_NCA,MUNDIAL_VAGAS.nca-contaConf("nca"),"nca");
  // anfitrião: um clube do meu país (o mais forte ainda fora)
  const fora=classificacaoMundo(S.pais,0).find(x=>!usados.has(x.nome));
  if(fora){const ch=chaveFixa(S.pais,fora.nome);if(ch)add(fora.nome,S.pais,"anf",forcaParaLiga(S.pais,ch.div,fora.nome),fora.sig,fora.cor,fora.cor2)}
  if(lista.length<32){[...POOL_ASI,...POOL_NCA,...POOL_AFR].filter(x=>!usados.has(x[0])).slice(0,32-lista.length).forEach(c=>add(c[0],c[2],c[2]==="Canadá"?"nca":"asi",c[5],c[1],c[3],c[4]))}
  return lista.slice(0,32);
}
function mundialInicia(){
  const parts=mundialMonta();
  // sorteio dos grupos: potes por fama/força
  const rg=rngClube("mundialSorteio|"+S.temp);
  const ord=[...parts].sort((a,b)=>(b.forca+b.fama*.1)-(a.forca+a.fama*.1));
  const grupos=[[],[],[],[],[],[],[],[]];
  for(let pote=0;pote<4;pote++){
    const fatia=ord.slice(pote*8,pote*8+8).map(x=>({x,r:rg()})).sort((a,b)=>a.r-b.r).map(o=>o.x);
    fatia.forEach((t,i)=>grupos[i].push(t));
  }
  S.mundial={temp:S.temp,fase:"grupos",etapa:0,jogosEtapa:[],vencEtapa:[],grupos:grupos.map(g=>g.map(t=>({...t,pts:0,j:0,v:0,e:0,d:0,gp:0,gc:0}))),mata:null,campeao:null,hist:[],premiado:false};
  return S.mundial;
}
function mundialPartida(a,b,rg,mata){
  const fa=a.forca+3,fb=b.forca;
  const gm=m=>{const lim=Math.exp(-m);let q=0,pr=1;do{q++;pr*=rg()}while(pr>lim);return q-1};
  let ga=gm(Math.max(.25,(fa-fb)/22+1.35)),gb=gm(Math.max(.25,(fb-fa)/22+1.0));
  let pen=false;
  if(mata&&ga===gb){pen=true;const pa=1/(1+Math.exp(-(fa-fb)/12));if(rg()<pa)ga++;else gb++}
  return[ga,gb,pen];
}
// ===== ETAPAS DO MUNDIAL =====
// Etapas: 0,1,2 = rodadas de grupo; 3 = oitavas; 4 = quartas; 5 = semi; 6 = final. Cada etapa tem uma lista de jogos [A,B].
function mundialEtapaTotal(){return 7}
function mundialNomeEtapa(e){return["Grupos · 1ª rodada","Grupos · 2ª rodada","Grupos · 3ª rodada","Oitavas de final","Quartas de final","Semifinal","Final"][e]||"Mundial"}
function mundialJogosDaEtapa(){ // [[A,B],...] da etapa atual
  const M=S.mundial;if(!M||M.campeao)return[];
  if(M.etapa<3){
    const pares=[[[0,3],[1,2]],[[0,2],[3,1]],[[0,1],[2,3]]][M.etapa];
    const out=[];M.grupos.forEach(g=>pares.forEach(([i,k])=>out.push([g[i],g[k]])));return out;
  }
  return M.mata?M.mata.pares:[];
}
function mundialMeuJogo(){ // o jogo do meu clube na etapa atual, ou null
  const eu=nomeMeuClube();
  return mundialJogosDaEtapa().find(([A,B])=>A.nome===eu||B.nome===eu)||null;
}
function mundialEstouVivo(){
  const M=S.mundial;if(!M||M.campeao)return false;
  const eu=nomeMeuClube();
  if(M.etapa<3){return M.grupos.some(g=>g.some(t=>t.nome===eu))}
  return !!(M.mata&&M.mata.pares.some(([A,B])=>A.nome===eu||B.nome===eu));
}
// aplica o resultado de UM jogo da etapa
function mundialAplicaJogo(A,B,ga,gb,pen){
  const M=S.mundial,mata=M.etapa>=3;
  if(!mata){
    A.j++;B.j++;A.gp+=ga;A.gc+=gb;B.gp+=gb;B.gc+=ga;
    if(ga>gb){A.pts+=3;A.v++;B.d++}else if(ga<gb){B.pts+=3;B.v++;A.d++}else{A.pts++;B.pts++;A.e++;B.e++}
  }
  M.jogosEtapa.push([A.nome,B.nome,ga,gb,!!pen]);
  if(mata)M.vencEtapa.push(ga>gb?A:B);
}
// fecha a etapa atual: classifica, monta o mata-mata, define campeão
function mundialFechaEtapa(){
  const M=S.mundial;
  M.hist.push([mundialNomeEtapa(M.etapa),M.jogosEtapa.slice()]);
  if(M.etapa===2){
    const cls=M.grupos.map(g=>[...g].sort((a,b)=>b.pts-a.pts||(b.gp-b.gc)-(a.gp-a.gc)||b.gp-a.gp));
    const par=[];for(let i=0;i<8;i+=2){par.push([cls[i][0],cls[i+1][1]]);par.push([cls[i+1][0],cls[i][1]])}
    M.mata={fase:"oitavas",pares:par};M.fase="mata";
  }else if(M.etapa>=3){
    const v=M.vencEtapa;
    if(M.etapa===6){M.campeao=v[0].nome;M.fase="fim";M.etapa++;M.jogosEtapa=[];M.vencEtapa=[];mundialFim();return}
    const par=[];for(let i=0;i<v.length;i+=2)par.push([v[i],v[i+1]]);
    M.mata={fase:["quartas","semi","final"][M.etapa-3],pares:par};
  }
  M.etapa++;M.jogosEtapa=[];M.vencEtapa=[];
}
// simula a etapa inteira (exceto, se informado, o meu jogo, que já foi jogado ao vivo e aplicado antes)
function mundialSimulaEtapa(pularMeu){
  const M=S.mundial;if(!M||M.campeao)return;
  const rg=rngClube("mundialJogo|"+S.temp+"|"+M.etapa);
  const eu=nomeMeuClube();
  mundialJogosDaEtapa().forEach(([A,B])=>{
    if(pularMeu&&(A.nome===eu||B.nome===eu))return;
    const [ga,gb,pen]=mundialPartida(A,B,rg,M.etapa>=3);
    mundialAplicaJogo(A,B,ga,gb,pen);
  });
  mundialFechaEtapa();
}
function mundialSimulaTudo(){
  if(!S.mundial||S.mundial.temp!==S.temp)mundialInicia();
  let g=0;while(!S.mundial.campeao&&g++<10)mundialSimulaEtapa(false);
}
function mundialFim(){
  const M=S.mundial;if(!M||M.premiado)return;M.premiado=true;
  registraTitulo(M.campeao,"mundial");try{const gt=M.grupos.flat().find(t=>t.nome===M.campeao);regTituloTec(M.campeao,"mund",gt&&gt.pais?gt.pais:S.pais)}catch(e){}
  const eu=S.clubes[S.meu];
  if(M.campeao===eu.nome)lancaPremio(PREMIO_COMP.mund.campeao,"🏆 Campeão do Mundial de Clubes");
  else if(M.grupos.flat().some(t=>t.nome===eu.nome))lancaPremio(PREMIO_COMP.mund.part,"Participação no Mundial de Clubes");
  if(!S.histMundial)S.histMundial=[];S.histMundial.push({temp:S.temp,nome:M.campeao});
}
function mundialJogaTudo(){mundialSimulaTudo()}


// ===== TELA: MUNDIAL DE CLUBES =====
function abaMundial(){
  const M=S.mundial&&S.mundial.temp===S.temp?S.mundial:null,hist=(S.histMundial||[]).slice().reverse();
  const eu=nomeMeuClube();
  const estou=M?mundialSouParticipante():false;
  const etapaTxt=!M?"Será disputado no fim da temporada":M.campeao?"Encerrado":mundialNomeEtapa(Math.min(M.etapa,6));
  let h=topoAba("🌍","Mundial de Clubes",etapaTxt,[[32,"Clubes"],[estou?"Sim":"Não","Você"],[hist.length,"Edições"]]);
  h+=`<div class="card"><div class="mu" style="font-size:12px">32 clubes: 12 da Europa, 6 da América do Sul, 4 da África, 4 da Ásia, 4 da América do Norte/Central, 1 da Oceania e 1 do país-sede. 8 grupos de 4; os 2 melhores avançam ao mata-mata. Os jogos acontecem nas últimas datas da temporada, só se o seu clube estiver entre os classificados.</div></div>`;
  if(!M){
    h+=`<div class="card"><div class="tag" style="margin-bottom:6px">Participantes previstos</div>`;
    try{h+=mundialMonta().map(t=>`<div class="cmJ" style="grid-template-columns:1fr 70px"><div class="cmC ${t.nome===eu?'v':''}">${escudo({nome:t.nome,cor:t.cor,cor2:t.cor2},15)}<span>${t.nome}</span></div><div class="cmP" style="font-size:11px">${iconeFama(t.nome)} ${nomeFama(t.nome)}</div></div>`).join("")}catch(e){h+='<div class="mu">Disponível depois da primeira temporada.</div>'}
    h+=`</div>`;
  }else{
    if(estou&&!M.campeao){const g=mundialMeuJogo();h+=`<div class="card"><div class="tag">Seu próximo jogo</div>${g?`<div class="cmJ" style="margin-top:6px"><div class="cmC v">${escudo({nome:g[0].nome,cor:g[0].cor,cor2:g[0].cor2},15)}<span>${g[0].nome}</span></div><div class="cmP">x</div><div class="cmP">x</div><div class="cmC d v"><span>${g[1].nome}</span>${escudo({cor:g[1].cor,cor2:g[1].cor2},15)}</div></div>`:'<div class="mu" style="font-size:12px;margin-top:4px">Seu clube foi eliminado.</div>'}</div>`}
    if(M.campeao){const t=M.grupos.flat().find(x=>x.nome===M.campeao)||{};h+=`<div class="card"><div class="cmCamp">${escudo({nome:t.nome||M.campeao,cor:t.cor||'#444',cor2:t.cor2||'#fff'},34)}<div><small>CAMPEÃO DO MUNDO</small><b>${M.campeao}</b></div></div></div>`}
    M.grupos.forEach((g,gi)=>{
      const o=[...g].sort((a,b)=>b.pts-a.pts||(b.gp-b.gc)-(a.gp-a.gc)||b.gp-a.gp);
      h+=`<div class="card"><div class="tag" style="margin-bottom:5px">Grupo ${"ABCDEFGH"[gi]}</div><table><tr><th>#</th><th>Clube</th><th>P</th><th>J</th><th>SG</th></tr>${o.map((t,i)=>`<tr style="${t.nome===eu?'background:#245a3f':i<2?'background:#1d4a33':''}"><td>${i+1}</td><td>${escudo({cor:t.cor,cor2:t.cor2},14)} ${t.nome}</td><td><b>${t.pts}</b></td><td>${t.j}</td><td>${t.gp-t.gc}</td></tr>`).join("")}</table></div>`;
    });
    (M.hist||[]).filter(x=>!x[0].startsWith("Grupos")).slice().reverse().forEach(([nome,jogos])=>{
      h+=`<div class="card"><div class="tag" style="margin-bottom:6px">${nome}</div>${jogos.map(([a,b,ga,gb,pen])=>`<div class="cmJ"><div class="cmC ${ga>gb?'v':''}"><span>${a}</span></div><div class="cmP">${ga}</div><div class="cmP">${gb}</div><div class="cmC d ${gb>ga?'v':''}"><span>${b}</span></div></div>${pen?'<div class="mu" style="font-size:10px;text-align:center">decidido nos pênaltis</div>':''}`).join("")}</div>`;
    });
  }
  h+=`<div class="card"><div class="tag" style="margin-bottom:6px">🏆 Campeões do mundo</div>${hist.length?hist.map(x=>`<div class="inL"><span>Temp. ${x.temp}</span><b>${x.nome}</b></div>`).join(""):'<div class="mu" style="font-size:12px">Nenhum Mundial disputado ainda.</div>'}</div>`;
  return h;
}
// ===== TELA: PREMIAÇÃO E FAMA =====
function abaPremios(){
  const eu=S.clubes[S.meu],E=S.extrato&&S.extrato.temp===S.temp?S.extrato:{itens:[],total:0};
  const t=titulosClube(eu.nome),pf=pontosFama(eu.nome),nf=nivelFama(eu.nome);
  const prox=[45,85,999][nf],ant=[0,45,85][nf];
  const pct=nf===2?100:Math.round((pf-ant)/(prox-ant)*100);
  let h=topoAba("💰","Prêmios e fama","Dinheiro das competições e prestígio do clube",[[R$(E.total),"Recebido"],[nomeFama(eu.nome),"Fama"],[pf,"Pontos"]]);
  h+=`<div class="card"><div class="cmTopo"><div><div class="cmT">${iconeFama(eu.nome)} Fama: ${nomeFama(eu.nome)}</div><div class="cmS">${pf} pontos · ${nf<2?'próximo nível em '+prox+' pts':'nível máximo'}</div></div></div><div class="cmBar"><i style="width:${pct}%"></i></div>
    <div class="fcGrid"><div><small>Ligas</small><b>${t.liga}</b></div><div><small>Copas</small><b>${t.copa}</b></div><div><small>Continentais</small><b>${t.cont}</b></div><div><small>Mundiais</small><b>${t.mundial}</b></div><div><small>Público</small><b>×${fatorFamaPublico(eu.nome).toFixed(2)}</b></div><div><small>Evolução</small><b>+${bonusFamaEvolucao(eu.nome).toFixed(2)}</b></div></div>
    <div class="mu" style="font-size:11px;margin-top:6px">Clubes mais famosos enchem mais o estádio e desenvolvem melhor os jogadores. A fama sobe com títulos: liga +4, copa +3, continental +14, Mundial +30.</div></div>`;
  h+=`<div class="card"><div class="tag" style="margin-bottom:6px">💰 Premiações da temporada ${S.temp}</div><div class="ln2 row" style="display:flex;justify-content:space-between"><span>Total recebido</span><b class="g">${R$(E.total)}</b></div>${E.itens.length?E.itens.slice().reverse().slice(0,40).map(([d,v])=>`<div class="ln2 row" style="display:flex;justify-content:space-between;font-size:12px"><span>${d}</span><b class="g">${R$(v)}</b></div>`).join(""):'<div class="mu" style="font-size:12px;padding:6px 0">Nenhum prêmio ainda. Vitórias, fases e títulos rendem dinheiro.</div>'}</div>`;
  h+=`<div class="card"><div class="tag" style="margin-bottom:6px">Tabela de prêmios</div>
    <div style="font-size:12px;line-height:1.6">
    <b>Campeonato (${S.pais}, ${LIGANOME[S.pais][S.div]})</b><br>Campeão: ${R$(premioLiga(S.pais,S.div,1,20))} · 10º: ${R$(premioLiga(S.pais,S.div,10,20))} · último: ${R$(premioLiga(S.pais,S.div,20,20))}<br>Por jogo: vitória ${R$(premioPartidaLiga(S.pais,S.div,1))} · empate ${R$(premioPartidaLiga(S.pais,S.div,0))}<br><br>
    <b>Champions</b>: cota ${R$(PREMIO_COMP.cl.part)} · vitória ${R$(PREMIO_COMP.cl.vit)} · campeão ${R$(PREMIO_COMP.cl.campeao)}<br>
    <b>Libertadores</b>: cota ${R$(PREMIO_COMP.lb.part)} · vitória ${R$(PREMIO_COMP.lb.vit)} · campeão ${R$(PREMIO_COMP.lb.campeao)}<br>
    <b>Liga Europa</b>: campeão ${R$(PREMIO_COMP.el.campeao)} · <b>Sul-Americana</b>: campeão ${R$(PREMIO_COMP.sa.campeao)}<br>
    <b>Copa nacional</b>: campeão ${R$(PREMIO_COMP.cn.campeao)} · <b>Mundial</b>: campeão ${R$(PREMIO_COMP.mund.campeao)}</div></div>`;
  h+=premiosIndividuaisHTML();
  return h;
}


// ===== MUNDIAL AO VIVO (integração com a agenda) =====
function mundialTitulo(){return "Mundial de Clubes · "+(S.mundial?mundialNomeEtapa(Math.min(S.mundial.etapa,6)):"")}
function mundialSouParticipante(){
  const M=S.mundial;if(!M||M.temp!==S.temp)return false;
  const eu=nomeMeuClube();return M.grupos.some(g=>g.some(t=>t.nome===eu));
}
// prepara o Mundial para a temporada: monta os 32 classificados e, se meu clube estiver, reserva 7 datas no fim da agenda
function mundialPreparaAgenda(){
  if(!S.mundial||S.mundial.temp!==S.temp)mundialInicia();
  if(!mundialSouParticipante())return false;
  if(S.agenda.some(d=>d.comp==="mund"))return true;
  const ult=S.agenda[S.agenda.length-1];
  const base=new Date(ult.ano,ult.mes,ult.dia);
  const passos=[0,4,8,35,39,43,50];                 // 3 rodadas de grupos, depois oitavas, quartas, semi, final
  passos.forEach((d,i)=>{
    const dt=new Date(base.getFullYear(),base.getMonth(),base.getDate()+3+d);
    S.agenda.push({comp:"mund",idx:i,mes:dt.getMonth(),dia:dt.getDate(),ano:dt.getFullYear(),dow:dt.getDay(),res:null,adv:null,casa:null});
  });
  return true;
}
function mundialComecaMeuJogo(){
  const M=S.mundial,g=mundialMeuJogo();if(!g)return false;
  const eu=nomeMeuClube(),A=g[0],B=g[1];
  const pt=t=>({nome:t.nome,pais:t.conf==="afr"||t.conf==="oce"?t.pais:t.pais,sig:t.sig,cor:t.cor,cor2:t.cor2});
  const CA=clubeParaJogo(pt(A)),CB=clubeParaJogo(pt(B));
  S._clbak={clubes:S.clubes,meu:S.meu,fixt:S.fixt,rodada:S.rodada,ids:S.clubes.map(c=>c.id)};
  const meuEhA=A.nome===eu;
  S.clubes=[CA,CB];CA.id=0;CB.id=1;S.meu=meuEhA?0:1;S.fixt=[[[0,1]]];S.rodada=0;
  S.clAoVivo={meuEhA,mund:true,A:A.nome,B:B.nome};
  est(CA);est(CB);if(criaLive()===false)return;
  S.live.outras=[];S.live.emCL=true;S.live.tela="lista";
  S.aba="live";render();somApito();playLive();
  return true;
}
function fimLiveMD(){
  const L=S.live,j=L.jogos[0],ai=S.clAoVivo,M=S.mundial;
  S.pos=posJogo(j);S.pos.tituloCompleto=mundialTitulo();
  const g=mundialMeuJogo();
  // placar do meu jogo (pênaltis se empate no mata-mata)
  let ga=j.ga,gb=j.gb,pen=false;
  if(M.etapa>=3&&ga===gb){pen=true;const rg=rngClube("mundialPen|"+S.temp+"|"+M.etapa);const fa=ga+gb;if(rg()<.5)ga++;else gb++}
  // resultados dos outros jogos da etapa (simulados) para a lista lateral
  const outros=[];
  const rgS=rngClube("mundialJogo|"+S.temp+"|"+M.etapa);
  const eu=ai.meuEhA?ai.A:ai.B;
  if(g){
    const [A,B]=g;
    mundialAplicaJogo(A,B,ai.meuEhA?ga:gb,ai.meuEhA?gb:ga,pen);
  }
  mundialJogosDaEtapa().forEach(([A,B])=>{
    if(A.nome===ai.A&&B.nome===ai.B)return;
    const [x,y,pn]=mundialPartida(A,B,rgS,M.etapa>=3);
    mundialAplicaJogo(A,B,x,y,pn);
    outros.push({a:A.nome,b:B.nome,ca:A.cor,cb:B.cor,ga:x,gb:y});
  });
  const meuJ={a:ai.A,b:ai.B,ca:(M.grupos.flat().find(t=>t.nome===ai.A)||{}).cor,cb:(M.grupos.flat().find(t=>t.nome===ai.B)||{}).cor,ga:j.ga,gb:j.gb,meu:true};
  const dados={};Object.keys(LIGAS).forEach(pa=>{dados[pa]=resultadosPais(pa)});
  dados["Mundial de Clubes"]=[{div:0,nome:mundialTitulo(),jogos:[meuJ,...outros]}];
  S.resultados={rodada:S.rodada+1,pais:"Mundial de Clubes",dados};S.filtroPais="Mundial de Clubes";
  const bak=S._clbak;
  S.clubes=bak.clubes;S.meu=bak.meu;S.fixt=bak.fixt;S.rodada=bak.rodada;S._clbak=null;if(bak.ids)S.clubes.forEach((c,i)=>{c.id=bak.ids[i]});S.clAoVivo=null;
  const rest=S.clubes[S.meu];
  registraNotasDoPos(rest,ai.meuEhA);energiaPosJogo(rest,true);
  rest.elenco.forEach(x=>{if(x.lesao>0)x.tit=false});try{garante11(rest,true)}catch(e){}
  if(ai.meuEhA&&S.pos)recebeBilheteria('el',1.2);
  const g1=ai.meuEhA?j.ga:j.gb,g2=ai.meuEhA?j.gb:j.ga;
  try{if(M.etapa<3)premiaJogo('mund',g1>g2?1:g1===g2?0:-1)}catch(e){}
  mundialFechaEtapa();
  limpaPartidaEstado();S.live=null;S.aba=S.pos?"pos":"home";S.subs=0;
  agendaRegistra(g1+" x "+g2,ai.meuEhA?ai.B:ai.A,ai.meuEhA);agendaAvanca();
  registraForma(g1>g2?'V':g1===g2?'E':'D');save();render();
}
// data do Mundial em que meu clube NÃO joga (eliminado/folga): simula a etapa e avança
function mundialSimulaDataSemMim(){
  mundialSimulaEtapa(false);
}

// ===== PARTIDA AO VIVO =====
function criaLive(){
  try{preparaAudios()}catch(e){}
  const jogos=S.fixt[S.rodada];
  S.pos=null;S.subs=0;S.live={min:0,vel:(S.velPref||1),pausado:false,jogos:jogos.map(([i,k])=>({a:i,b:k,ga:0,gb:0,ev:[],st:{pa:50,pm:0,fa:0,fb:0,ga_:0,gb_:0,da:0,db:0,pea:0,peb:0},cart:[]})),ver:null};
  S.clubes.forEach(c=>{if(c.id!==S.meu&&!c.hum)auto(c)});
  const meuC=S.clubes[S.meu];if(meuC.elenco.some(x=>x.tit&&x.suspenso>0)){meuC.elenco.forEach(x=>{if(x.suspenso>0&&x.tit)x.tit=false});auto(meuC,true);}
  try{garante11(meuC,true)}catch(e){}humPreparaOutros();
  if(titularesAptos(meuC).length<11){                                          // v56: trava definitiva — qualquer partida (liga, copas, Mundial) passa por aqui
    S.live=null;S.pos=null;if(S._clbak){const b=S._clbak;S.clubes=b.clubes;S.meu=b.meu;S.fixt=b.fixt;S.rodada=b.rodada;S._clbak=null;S.clAoVivo=null}
    S.aba='tat';
    setTimeout(()=>{try{garante11(S.clubes[S.meu],false)}catch(e){render()}},30);
    return false;
  }
    S.live.jogos.forEach((j,n)=>{const H=S.clubes[j.a];j.est=est(H).nome;j.cap=capEst(H);try{preparaClimaJogo(j,H)}catch(e){}j.pub=pubJogo(H,S.clubes[j.b]);j.classico=!!((j.a===S.meu||j.b===S.meu)&&ehRival(S.clubes[j.a===S.meu?j.b:j.a].nome));if(j.classico)j.pub=Math.min(j.cap,Math.round(j.pub*1.12));j.renda=Math.round(j.pub*est(H).preco*(1+est(H).conforto*.05)*(j.classico?1.25:1));j.subs=[];j.inicio={a:S.clubes[j.a].elenco.filter(x=>x.tit).map(x=>x.id),b:S.clubes[j.b].elenco.filter(x=>x.tit).map(x=>x.id)};});
  S.live.ver=S.live.jogos.findIndex(j=>j.a===S.meu||j.b===S.meu);
  S.live.tela="lista";criaOutras();
  S.aba="live";
  return true;
}

// ===== PÊNALTI AO VIVO + COBRADORES (v46) =====
// Pênalti: o tempo para, abre a mesma tela de escalação do seu jogo e você escolhe quem cobra. O adversário (IA) escolhe o melhor cobrador.
function melhorCobrador(c){ // IA: maior força + bônus de Finalização, entre quem está em campo (sem goleiro)
  const em=c.elenco.filter(x=>x.tit&&!x.expulso&&x.pos!=="GOL");
  em.sort((a,b)=>(b.f+((b.hab||[]).includes("Finalização")?4:0))-(a.f+((a.hab||[]).includes("Finalização")?4:0)));
  return em[0]||null;
}
function goleiroEmCampo(c){return c.elenco.find(x=>x.tit&&!x.expulso&&x.pos==="GOL")||null}
function chancePenalti(cob,gol){
  const fc=cob?cob.f+bonusEstrela(cob):40,fg=gol?gol.f+bonusEstrela(gol):40;
  let c=.76+(fc-fg)/250;
  if(cob&&(cob.hab||[]).includes("Finalização"))c+=.04;
  if(gol&&(gol.hab||[]).includes("Pênaltis"))c-=.06;
  if(cob){const en=(cob.en==null?100:cob.en)/100;c-=(1-en)*.08}       // cansado erra mais
  return Math.max(.45,Math.min(.92,c));
}
// resolve a cobrança: cobradorId = jogador escolhido (ou null → melhor cobrador). Registra gol ou defesa/trave/fora.
function resolvePenalti(j,sA,cobradorId){
  const L=S.live;const F=sA?S.clubes[j.a]:S.clubes[j.b],D=sA?S.clubes[j.b]:S.clubes[j.a];
  let cob=cobradorId?F.elenco.find(x=>x.id===cobradorId&&x.tit&&!x.expulso):null;
  if(!cob)cob=melhorCobrador(F);
  const gk=goleiroEmCampo(D);
  const pg=chancePenalti(cob,gk);
  const r=R();
  const nome=cob?cob.nome:"Cobrador";
  const lado=sA?"a":"b";
  const meuTime=(sA&&j.a===S.meu)||(!sA&&j.b===S.meu),jogoMeu=(j.a===S.meu||j.b===S.meu);
  if(r<pg){                                                                  // GOL
    if(cob){cob.gols++;if(!(S.live&&S.live.emCL))cob.golsLiga=(cob.golsLiga||0)+1}
    sA?j.ga++:j.gb++;sA?j.st.fa++:j.st.fb++;sA?j.st.ga_++:j.st.gb_++;
    j.ev.push({m:L.min,t:"g",lado,n:nome,jid:cob?cob.id:null,pen:true});
    if(jogoMeu&&!L.pulando){if(meuTime){somGol();golFx("GOOOL! (pênalti)")}else somGolContra();
      narraGol({meu:meuTime,contra:!meuTime,autor:nome.split(" ").slice(-1)[0],time:F.nome,golsA:sA?j.ga:j.gb,golsB:sA?j.gb:j.ga,min:L.min})}
    return{gol:true,nome};
  }
  const tipo=r<pg+(1-pg)*.55?"defesa":r<pg+(1-pg)*.8?"trave":"fora";           // defesa do goleiro, trave ou para fora
  sA?j.st.fa++:j.st.fb++;if(tipo==="defesa")sA?j.st.ga_++:j.st.gb_++;
  j.ev.push({m:L.min,t:"p",lado,n:nome,jid:cob?cob.id:null,res:tipo});
  if(jogoMeu&&!L.pulando){if(meuTime){somLamento();toast("❌ Pênalti perdido!")}else{somGol();toast("🧤 Seu goleiro pegou!")}}
  return{gol:false,tipo,nome};
}
// abre a tela com o campo/banco do seu time + a lista de cobradores. O jogo fica parado até você tocar em "Cobrar".
function abreJanelaPenalti(){
  const L=S.live;if(!L||!L.penReq)return;
  L.janela="penalti";L.pausaTec=true;S.selId=null;
  const jg=L.jogos[L.penReq.jogoIdx];if(jg)L.ver=L.penReq.jogoIdx;
  if(!L.pulando)somPenalti();                                                   // o árbitro marca o pênalti (seu áudio)
  renderJanela();
}
function cobradoresMeus(){
  const eu=S.clubes[S.meu];
  return eu.elenco.filter(x=>x.tit&&!x.expulso&&x.pos!=="GOL").sort((a,b)=>(b.f+((b.hab||[]).includes("Finalização")?4:0))-(a.f+((a.hab||[]).includes("Finalização")?4:0)));
}
function painelPenaltiHTML(){
  const L=S.live;if(!L||L.janela!=="penalti")return"";
  const jg=L.jogos[L.penReq.jogoIdx],eu=S.clubes[S.meu],op=jg.a===S.meu?S.clubes[jg.b]:S.clubes[jg.a];
  const gk=goleiroEmCampo(op);
  if(!S.cobPen||!eu.elenco.find(x=>x.id===S.cobPen&&x.tit&&!x.expulso))S.cobPen=(cobradoresMeus()[0]||{}).id;
  const lista=cobradoresMeus();
  return`<div class="card penCard"><div class="penTit">⚽ PÊNALTI A FAVOR! Escolha o cobrador</div>
    <div class="mu" style="font-size:11.5px;margin-bottom:6px">Goleiro adversário: <b>${gk?gk.nome:'—'}</b> ${gk?`· F${gk.f}${(gk.hab||[]).includes('Pênaltis')?' · pega-pênaltis 🧤':''}`:''}</div>
    ${lista.map(x=>{const pc=Math.round(chancePenalti(x,gk)*100);const sel=x.id===S.cobPen;
      return`<div class="penL ${sel?'on':''}" onclick="S.cobPen='${x.id}';renderJanela()"><span class="elP" style="background:${({ZAG:'#4aa3ff',LD:'#4aa3ff',LE:'#4aa3ff',VOL:'#3ddc84',MEI:'#3ddc84',PE:'#ff7a59',ATA:'#ff5d5d'})[x.pos]||'#888'}">${x.pos}</span>
      <span class="penN"><b>${x.nome}</b><small>F${x.f} · energia ${Math.round(x.en==null?100:x.en)}% · ${(x.hab||[]).map(sig).join(' · ')}</small></span><span class="penP"><b>${pc}%</b><small>chance</small></span></div>`}).join("")}
    <button class="big" style="margin-top:8px" onclick="cobraPenaltiMeu()">⚽ Cobrar</button></div>`;
}
function cobraPenaltiMeu(){
  const L=S.live;if(!L||!L.penReq)return;
  const jg=L.jogos[L.penReq.jogoIdx];const sA=L.penReq.sA;
  const el=document.getElementById("janelaEscala");if(el)el.remove();
  L.janela=null;L.pausaTec=false;
  const cobId=S.cobPen;L.penReq=null;
  const r=resolvePenalti(jg,sA,cobId);
  if(!r.gol)toast(r.tipo==="defesa"?"🧤 Defendeu!":r.tipo==="trave"?"💥 Na trave!":"🚫 Para fora!");
  S.selId=null;DR=null;renderLive();
}


// ===== FALTAS DIRETAS (v47) =====
// Falta perigosa perto da área (~1,1 por jogo, somando os dois times). O cobrador do SEU time vem do campo "Cobrança de faltas" da Tática
// (sem janela de escolha); se ele não está em campo, o jogo usa o melhor batedor disponível. A IA usa sempre o melhor batedor.
function cobradorFaltaDe(c,meu){
  const em=c.elenco.filter(x=>x.tit&&!x.expulso&&x.pos!=="GOL");
  if(meu&&S.cob){const x=em.find(z=>z.id===S.cob);if(x)return x}
  const pt=x=>x.f+((x.hab||[]).includes("Chute longo")?6:0)+((x.hab||[]).includes("Finalização")?4:0);
  return em.sort((a,b)=>pt(b)-pt(a))[0]||null;
}
function chanceFalta(cob,gol){
  let p=.06;
  if(cob){
    p*=1+(cob.f+bonusEstrela(cob)-50)/200;                                     // cobrador melhor chuta melhor
    if((cob.hab||[]).includes("Chute longo"))p*=1.35;
    if((cob.hab||[]).includes("Finalização"))p*=1.25;
    p*=.9+.1*((cob.en==null?100:cob.en)/100);                                   // cansado chuta pior
  }
  if(gol)p*=1-(gol.f+bonusEstrela(gol)-50)/350;                                  // goleiro bom defende mais
  return Math.max(.015,Math.min(.22,p));
}
function resolveFalta(j,sA,meuAtacando){
  const L=S.live;const F=sA?S.clubes[j.a]:S.clubes[j.b],D=sA?S.clubes[j.b]:S.clubes[j.a];
  const cob=cobradorFaltaDe(F,meuAtacando),gk=goleiroEmCampo(D);
  const nome=cob?cob.nome:"Cobrador",lado=sA?"a":"b";
  const meuTime=(sA&&j.a===S.meu)||(!sA&&j.b===S.meu),jogoMeu=(j.a===S.meu||j.b===S.meu);
  sA?j.st.fa++:j.st.fb++;
  if(R()<chanceFalta(cob,gk)){                                         // GOL de falta
    if(cob){cob.gols++;if(!(S.live&&S.live.emCL))cob.golsLiga=(cob.golsLiga||0)+1}
    sA?j.ga++:j.gb++;sA?j.st.ga_++:j.st.gb_++;
    j.ev.push({m:L.min,t:"g",lado,n:nome,jid:cob?cob.id:null,falta:true});
    if(jogoMeu&&!L.pulando){if(meuTime){somGol();golFx("GOOOL! (falta)")}else somGolContra();
      narraGol({meu:meuTime,contra:!meuTime,autor:nome.split(" ").slice(-1)[0],time:F.nome,golsA:sA?j.ga:j.gb,golsB:sA?j.gb:j.ga,min:L.min})}
    return;
  }
  const r=R(),tipo=r<.4?"defesa":r<.62?"trave":r<.82?"fora":"barreira";   // defesa do goleiro, trave, para fora ou na barreira
  if(tipo==="defesa")sA?j.st.ga_++:j.st.gb_++;
  j.ev.push({m:L.min,t:"p",lado,n:nome,jid:cob?cob.id:null,res:tipo,falta:true});
}

// ===== ESCANTEIOS (v46) =====
// 5 por jogo, em média. O cobrador (Tática) e o cabeceador da área mudam a chance de gol. Resolvido dentro do motor, sem pausar o jogo.
function cobradorEscanteioDe(c,meu){
  const em=c.elenco.filter(x=>x.tit&&!x.expulso&&x.pos!=="GOL");
  if(meu&&S.esc){const x=em.find(z=>z.id===S.esc);if(x)return x}
  return em.sort((a,b)=>((b.hab||[]).includes("Cruzamento")?6:0)+b.f-(((a.hab||[]).includes("Cruzamento")?6:0)+a.f))[0]||null;
}
function resolveEscanteio(j,sA,meuAtacando){
  const L=S.live;const F=sA?S.clubes[j.a]:S.clubes[j.b],D=sA?S.clubes[j.b]:S.clubes[j.a];
  const cob=cobradorEscanteioDe(F,meuAtacando);
  const cab=F.elenco.filter(x=>x.tit&&!x.expulso&&x.pos!=="GOL"&&x.id!==(cob&&cob.id)).sort((a,b)=>((b.hab||[]).includes("Cabeceio")?8:0)+(b.pos==="ZAG"?3:0)+b.f-(((a.hab||[]).includes("Cabeceio")?8:0)+(a.pos==="ZAG"?3:0)+a.f))[0]||null;
  sA?j.st.ec_a=(j.st.ec_a||0)+1:j.st.ec_b=(j.st.ec_b||0)+1;
  let p=.04;
  if(cob&&(cob.hab||[]).includes("Cruzamento"))p*=1.5;
  if(cab&&(cab.hab||[]).includes("Cabeceio"))p*=1.3;
  if(cob)p*=1+(cob.f-50)/250;                                             // cobrador melhor, bola melhor
  const gk=goleiroEmCampo(D);if(gk)p*=1-(gk.f-50)/400;                      // goleiro seguro sai bem
  if(R()<Math.max(.01,Math.min(.14,p))){
    const autor=cab||cob;if(autor){autor.gols++;if(!(S.live&&S.live.emCL))autor.golsLiga=(autor.golsLiga||0)+1}
    sA?j.ga++:j.gb++;sA?j.st.fa++:j.st.fb++;sA?j.st.ga_++:j.st.gb_++;
    j.ev.push({m:L.min,t:"g",lado:sA?"a":"b",n:autor?autor.nome:"?",jid:autor?autor.id:null,esc:true});
    try{if(cob&&autor&&cob.id!==autor.id)registraAssistencia(j,j.ev[j.ev.length-1],cob,!!(S.live&&S.live.emCL))}catch(e){}
    const meuTime=(sA&&j.a===S.meu)||(!sA&&j.b===S.meu);
    if((j.a===S.meu||j.b===S.meu)&&!L.pulando){if(meuTime){somGol();golFx("GOOOL! (escanteio)")}else somGolContra();
      narraGol({meu:meuTime,contra:!meuTime,autor:(autor?autor.nome:"").split(" ").slice(-1)[0],time:F.nome,golsA:sA?j.ga:j.gb,golsB:sA?j.gb:j.ga,min:L.min})}
  }
}



// ===== LESÕES AO VIVO (v48) =====
// Risco por jogador em campo e por minuto: 0,0004 × (2 − energia/100) × fator da marcação × fator da idade.
// ≈ 0,43 lesões por time por jogo (≈ 16 por temporada). O lesionado sai NA HORA; no SEU time o jogo para e abre a mesma tela do vermelho.
const LES_MARC={Leve:.85,Normal:1,Forte:1.25};
function gravidadeLesao(){          // v54: lesões mais curtas (média ≈ 2,3 jogos); as graves continuam raras
  const r=R();
  return r<.50?1:r<.75?2:r<.90?rnd(3,4):r<.98?rnd(5,8):rnd(9,14);
}
const NOMES_LESAO=["torção no tornozelo","lesão muscular","pancada no joelho","distensão","contusão","entorse","dor na coxa","lesão no ligamento"];
function sorteiaLesaoAoVivo(j,clube,souMeu){
  const L=S.live;if(!L)return null;
  const fLes=(CLIMAS[j.clima||'sol']||CLIMAS.sol).les*fatorGramadoLesao(j.gramado==null?70:j.gramado);
  if(!j._les)j._les={};const ladoK=clube===S.clubes[j.a]?"a":"b";if(j._les[ladoK])return null;       // v54: no máximo 1 lesão por time por jogo
  const marc=souMeu?(LES_MARC[TTc(clube).marc]||1):1;
  const em=clube.elenco.filter(x=>x.tit&&!x.expulso&&!(x.lesao>0));
  for(const x of em){
    const en=(x.en==null?100:x.en)/100;
    const fi=x.idade<=22?.85:x.idade<=30?1:1.3;
    if(R()<.0001*(2-en)*marc*fi*fLes){                                        // v54: ≈ 0,11 lesões por time por jogo (≈ 6 por temporada) — antes 0,45
      x.lesao=gravidadeLesao();x.lesAoVivo=true;x.lesNome=NOMES_LESAO[Math.floor(R()*NOMES_LESAO.length)];
      x.tit=false;x.em_campo=false;x.lesionadoJogo=true;j._les[ladoK]=true;           // sai de campo agora
      if(clube===meuReal()||clube===S.clubes[S.meu])abreVagaLesao(x);                  // v62: a vaga fica na partida, não na marca do jogador
      j.ev.push({m:L.min,t:"l",lado:clube===S.clubes[j.a]?"a":"b",n:x.nome,jid:x.id,jogos:x.lesao,tipo:x.lesNome});
      return x;
    }
  }
  return null;
}


// Entra o melhor reserva da MESMA posição no lugar de quem saiu machucado (IA, ou o seu time se você tocar em "Fim").
// A troca por lesão NÃO gasta uma das 5 substituições.
function iaCompletaTime(c){
  const vagas=c.elenco.filter(x=>x.lesionadoJogo&&!x.tit);
  vagas.forEach(sai=>{
    sai.lesionadoJogo=false;try{fechaVagaLesao(sai.id)}catch(e){}
    const fe0=x=>x.f*(0.7+0.3*(x.en==null?100:x.en)/100);
    const pool=c.elenco.filter(x=>!x.tit&&!(x.lesao>0)&&!x.expulso&&!(x.suspenso>0)&&x.id!==sai.id);
    let melhor=pool.filter(x=>x.pos===sai.pos).sort((a,b)=>fe0(b)-fe0(a))[0];
    if(!melhor)melhor=pool.filter(x=>sai.pos==="GOL"?x.pos==="GOL":x.pos!=="GOL").sort((a,b)=>fe0(b)-fe0(a))[0];
    if(!melhor)return;
    melhor.px=sai.px;melhor.py=sai.py;melhor._g=grupoPos(melhor);melhor._slot=sai._slot;melhor._role=sai._role;melhor.tit=true;
    if(S.cap===sai.id)S.cap=melhor.id;
    const L=S.live;if(L){const jg=L.jogos.find(g=>S.clubes[g.a]===c||S.clubes[g.b]===c);if(jg){
      const lado=S.clubes[jg.a]===c?"a":"b";
      jg.ev.push({m:L.min,t:"s",lado,n:melhor.nome+" ↔ "+sai.nome,les:true});
      jg.subs.push({m:L.min,lado,entra:melhor.id,sai:sai.id,en:melhor.nome,sn:sai.nome,ep:melhor.pos,les:true});
    }}
  });
}


function lesaoAvisoHTML(){
  const eu=S.clubes[S.meu],ids=(S._lesLista||[]).slice();
  const lst=vagasLesaoAbertas().length?vagasLesaoAbertas():eu.elenco.filter(x=>x.id===S._lesPend);
  if(!lst.length)return"";
  return`<div class="hint" style="margin:6px 0 0;background:linear-gradient(90deg,#7a3b00,#b45309)">${lst.map(x=>`🤕 <b>${x.nome}</b> (${x.pos}) saiu machucado: ${x.lesNome||'lesão'} · fora por <b>${x.lesao} jogo(s)</b>.`).join("<br>")}<br>Toque em um reserva para ele entrar. A troca por lesão <b>não conta</b> nas 5 substituições.</div>`;
}

// ===== ELENCO: LIMITE DE 32 (v49) =====
const MAX_ELENCO=32,MIN_ELENCO=16;
function elencoCheio(c){return (c||S.clubes[S.meu]).elenco.length>=MAX_ELENCO}
function avisoCheio(){aviso("Elenco cheio (máx. "+MAX_ELENCO+").\nPara contratar, venda, empreste ou dispense alguém antes.")}


// ===== CATEGORIA DE BASE (v49) =====
// Todo fim de temporada o seu clube recebe 2–4 garotos (15–18 anos) com potencial. Ficam em eu.base (NÃO contam nos 32).
// Qualidade: pico do clube, nível do estádio (investimento) e fama. Você promove (vai ao elenco) ou dispensa. Quem não for decidido em 2 temporadas sai.
function geraBaseClube(c){
  if(!c.base)c.base=[];
  const nivelEst=(c.estadio&&c.estadio.nivel)||(S.estadio&&S.estadio.nivel)||1;
  const inv=nivelEst>=4?2:nivelEst>=2?1:0;
  const pico=Math.max(30,Math.round(c.forca||50));
  const n=2+(R()<.5?1:0)+(inv>=1&&R()<.4?1:0);
  const nasc=[];
  for(let i=0;i<n;i++){
    const pos=pick(["GOL","ZAG","ZAG","LD","LE","VOL","MEI","MEI","ATA","ATA","PE"]);
    const idade=rnd(15,18),rg=R;
    const f=Math.max(22,pico-rnd(12,20)+(inv>=2?2:0));
    const j=criaJogadorFixo(pos,f,rg,idade);
    j.pot=Math.min(95,Math.max(j.pot,f+rnd(8,22)+(inv>=2?3:0)));        // base tem potencial alto (calibrado em 40 anos de simulação: não infla o mundo)
    j.val=valorDe(j.f,j.idade,j.pot,j.mk);j.sal=Math.max(1,Math.round(salarioDe(j.f,j.mk)*.5));j.ct=3;j.anoBase=S.temp;j.nBase=true;
    j.nome=j.nome;nasc.push(j);
  }
  c.base=c.base.filter(j=>S.temp-(j.anoBase||S.temp)<2).concat(nasc);   // garotos não decididos há 2 temporadas saem
  return nasc;
}
function promoveBase(id){
  const eu=S.clubes[S.meu];if(!eu.base)return;
  const j=eu.base.find(x=>x.id===id);if(!j)return;
  if(elencoCheio(eu))return avisoCheio();
  eu.base=eu.base.filter(x=>x.id!==id);delete j.nBase;j.tit=false;j.ct=3;j.en=100;j.gols=0;
  try{if(j.num==null||eu.elenco.some(x=>x.num===j.num))j.num=null}catch(e){}
  jogadorNovoNoClube(j);j.entr=45;eu.elenco.push(j);try{atribuiNumeros(eu)}catch(e){}
  save();render();toast(j.nome+" foi promovido ao elenco!");
}
function dispensaBase(id){
  const eu=S.clubes[S.meu];if(!eu.base)return;
  const j=eu.base.find(x=>x.id===id);if(!j)return;
  confirma("Dispensar "+j.nome+" da base?",()=>{eu.base=eu.base.filter(x=>x.id!==id);save();render()});
}
function abaBase(){
  const eu=S.clubes[S.meu];if(!eu.base)eu.base=[];
  let h=topoAba("🌱","Categoria de base","Novos talentos todo ano. Promova os melhores.",[[eu.base.length,"Na base"],[eu.elenco.length+"/"+MAX_ELENCO,"Elenco"]]);
  if(!eu.base.length)h+=`<div class="card"><small class="mu">Nenhum garoto na base agora. Novos talentos chegam no fim de cada temporada (2 a 4). Estádio melhor = base melhor.</small></div>`;
  else{
    h+=`<div class="card"><small class="mu">Eles não contam nos ${MAX_ELENCO} do elenco. Quem não for decidido em 2 temporadas é liberado.</small><div class="tbL">`;
    [...eu.base].sort((a,b)=>b.pot-a.pot).forEach(j=>{
      h+=`<div class="tbR"><span class="tbN"><span><b>${j.nome}</b><small>${j.pos} · ${j.idade} anos · Força ${j.f} · Potencial ${j.pot}${(j.hab||[]).length?' · '+j.hab.join(", "):''}</small></span></span><span style="display:flex;gap:6px"><button class="sm s" onclick="promoveBase('${j.id}')">⬆️ Promover</button><button class="sm" onclick="dispensaBase('${j.id}')">Dispensar</button></span></div>`;
    });
    h+=`</div></div>`;
  }
  return h;
}


// ===== NUMERAÇÃO DE CAMISAS (v49) =====
function numeroLivre(c,n,exceto){return !c.elenco.some(x=>x.id!==exceto&&x.num===n)}
function mudaNumero(id,val){
  const eu=S.clubes[S.meu],j=eu.elenco.find(x=>x.id===id);if(!j)return;
  const n=parseInt(val,10);
  if(!(n>=1&&n<=99)){aviso("Escolha um número de 1 a 99.");render();return}
  const outro=eu.elenco.find(x=>x.id!==id&&x.num===n);
  if(outro){                                         // número ocupado: pergunta se quer trocar os dois
    const meu=j.num;
    confirma("O "+n+" é de "+outro.nome+". Trocar os números? (ele fica com o "+(meu!=null?meu:"—")+")",()=>{outro.num=meu;j.num=n;save();render()});
    return;
  }
  j.num=n;save();render();
}
function numerosAuto(){
  const eu=S.clubes[S.meu];
  eu.elenco.forEach(j=>{j.num=null});
  try{atribuiNumeros(eu)}catch(e){}
  save();render();toast("Números gerados automaticamente");
}
function numerosHTML(eu){
  const lista=[...eu.elenco].sort((a,b)=>(a.num||999)-(b.num||999));
  return `<div class="card" style="margin-top:10px"><div style="display:flex;justify-content:space-between;align-items:center;gap:8px"><div class="tag">👕 Numeração das camisas (1–99)</div><button class="sm s" onclick="numerosAuto()">⚙️ Gerar automático</button></div>
  <small class="mu">Toque no número para mudar. Se já existir, o jogo oferece trocar os dois.</small>
  <div class="sc2" style="max-height:260px;overflow:auto;margin-top:6px"><table class="tl">${lista.map(j=>`<tr class="${j.tit?'t':''}"><td style="width:60px"><input type="number" min="1" max="99" value="${j.num!=null?j.num:''}" style="width:54px;padding:6px;border-radius:8px;background:var(--card2);color:var(--tx);border:1px solid var(--bd);text-align:center;font-weight:700" onchange="mudaNumero('${j.id}',this.value)"></td><td>${j.pos}</td><td>${j.nome}</td><td class="y">${j.f}</td></tr>`).join("")}</table></div></div>`;
}

function limitaElenco32(){
  const out=[];
  S.clubes.forEach(c=>{
    while(c.elenco.length>MAX_ELENCO){
      const cand=c.elenco.filter(j=>!j.emprestado).sort((a,b)=>(a.f+(a.pot-a.f)*.3-Math.max(0,a.idade-31))-(b.f+(b.pot-b.f)*.3-Math.max(0,b.idade-31)))[0];
      if(!cand)break;c.elenco=c.elenco.filter(x=>x.id!==cand.id);if(c.id===S.meu)out.push(cand.nome);
    }
  });
  if(out.length)setTimeout(()=>aviso("Elenco acima de "+MAX_ELENCO+": foram liberados "+out.join(", ")+"."),600);
}


// ===== TRANSFERÊNCIA DE TÉCNICOS (v49) =====
// Duas janelas por temporada: MEIO (ao fechar o 1º turno) e FIM. Técnicos de baixa confiança são demitidos; os livres vão para clubes
// sem técnico; técnicos muito bons de clubes pequenos podem ser contratados por clubes maiores. O USUÁRIO demitido recebe ofertas.
function confiancaDe(c,t,N){                                            // 0–100, mesma fórmula do usuário, para qualquer clube da liga
  const pos=t.findIndex(x=>x.id===c.id)+1;
  const esperado=[...S.clubes].sort((a,b)=>b.forca-a.forca).findIndex(x=>x.id===c.id)+1;
  if(c._conf==null)c._conf=70;
  const base=100-(pos-1)*3.5,sobra=(esperado-pos)*2.2,zona=pos>N-4?-14*(esperado<=N-6?1:.35):0;
  const alvo=Math.max(5,Math.min(100,base+sobra+zona+(c.caixa<0?-10:0)));
  c._conf=Math.round(c._conf*.8+alvo*.2);return c._conf;
}
function pDemissao(m){return m>=40?0:Math.min(.95,(40-m)/25)}
function ofertasParaMim(motivo){
  const eu=S.clubes[S.meu],rep=reputacao();
  const lista=S.clubes.filter(c=>c.id!==S.meu).map(c=>({c,at:c.forca-rep}))
    .filter(o=>o.at<=12)                                                  // clubes não muito acima da sua reputação
    .sort(()=>R()-.5).slice(0,4).map(o=>o.c);
  if(lista.length<2){const todos=[...S.clubes].filter(c=>c.id!==S.meu).sort((a,b)=>a.forca-b.forca);lista.push(...todos.slice(0,2).filter(c=>!lista.includes(c)))}
  return lista.slice(0,4);
}
function aceitaOferta(id){
  const novo=S.clubes[id],eu=S.clubes[S.meu];
  const hab=eu.tec.hab,tit=eu.tec.tit;
  const antigoTecNovo=geraTec(eu.forca),tecAntigoDoNovo=novo.tec?novo.tec.nome:"—";
  eu.tec=antigoTecNovo;                                                   // o clube antigo ganha técnico novo
  try{regTec("fim",S.treinador,antigoTecNovo.nome,eu.nome,S.pais,"Você saiu (demitido)");regTec("fim",tecAntigoDoNovo,S.treinador,novo.nome,S.pais,"Você assumiu o clube")}catch(e){}
  S.meu=id;S.dir=70;S.tor=70;S.cap=null;S.selId=null;S.emp=[];S.homeAba="jogar";S.cob=null;S.cobPen=null;S.esc=null;
  novo.tec={id:"eu",nome:S.treinador,hab:hab,tit:tit,sal:0,idade:40,meu:true};
  S.clubes.forEach(c=>{c._conf=70});
  try{garanteTec();auto(novo,true)}catch(e){}
  S.ofertas=null;save();fechaDlg();aviso("Você agora é o técnico do "+novo.nome+"!",render);
}
function recusaOfertas(){S.ofertas=null;fechaDlg();aviso("Você recusou as ofertas.\nA diretoria do clube atual concede uma última chance: a confiança volta a 40 e você segue no cargo até a próxima janela.",()=>{S.dir=40;S.tor=40;save();render()})}
function janelaTecnicos(tipo,silencioso){                                          // tipo: "meio" | "fim"
  const t=tabela(),N=t.length,rod=S.rodada||0,meuId=S.meu;
  const eventos=[];
  if(!S.tecLivres)S.tecLivres=[];
  let nMundo=0;try{nMundo=janelaTecnicosMundo(tipo)}catch(e){}
  if(nMundo)eventos.push('🌍 +'+nMundo+' trocas de técnicos pelo mundo (veja o Histórico)');
  // 1) quem é demitido
  const demitidos=[];
  S.clubes.forEach(c=>{
    const ehMeu=c.id===meuId,conf=ehMeu?Math.min(S.dir==null?70:S.dir,S.tor==null?70:S.tor):confiancaDe(c,t,N);
    const pos=t.findIndex(x=>x.id===c.id)+1;
    if(pos<=3)return;                                                     // top 3 nunca demite
    if(tipo==="meio"&&rod<8)return;                                       // proteção nas 8 primeiras rodadas
    if(R()<pDemissao(conf)){
      if(ehMeu){demitidos.push({c,eu:true,conf});return}
      if(!c.tec||c.tec.meu)return;
      demitidos.push({c,eu:false,conf,tec:c.tec});
    }
  });
  // 2) IA: demitidos vão para livres; cada clube sem técnico contrata o melhor livre "parecido"
  const semTec=[];
  demitidos.forEach(d=>{
    if(d.eu)return;
    const velho=d.c.tec;velho.sal=velho.sal||Math.round(velho.hab*velho.hab/40*1000);S.tecLivres.push(velho);semTec.push(d.c);
    eventos.push("❌ "+d.c.nome+" demitiu "+velho.nome+" (confiança "+d.conf+")");
    d.c._velhoNome=velho.nome;
  });
  // 3) cobiça: técnico muito bom (hab≥80) de clube bem abaixo pode ir para um clube bem acima que está procurando
  semTec.forEach(c=>{
    S.tecLivres.sort((a,b)=>Math.abs(a.hab-(c.forca+5))-Math.abs(b.hab-(c.forca+5)));
    const novo=S.tecLivres.find(x=>x.id!==undefined)||null;
    if(novo){S.tecLivres=S.tecLivres.filter(x=>x!==novo);c.tec=novo;c._conf=70;eventos.push("✅ "+c.nome+" contratou "+novo.nome+" (H "+novo.hab+")")}
    else{c.tec=geraTec(c.forca);c._conf=70;eventos.push("✅ "+c.nome+" contratou "+c.tec.nome)}
    try{regTec(tipo,c._velhoNome,c.tec.nome,c.nome,S.pais,"Demissão por resultados",c._conf)}catch(e){}
  });
  while(S.tecLivres.length<8)S.tecLivres.push(geraTec(rnd(50,85)));
  S.tecLivres=S.tecLivres.slice(0,16);
  // 4) clube grande rouba técnico bom de clube pequeno (1 por janela, 25% de chance)
  if(R()<.25){
    const grandes=[...S.clubes].filter(c=>c.id!==meuId).sort((a,b)=>b.forca-a.forca).slice(0,4);
    const peq=[...S.clubes].filter(c=>c.id!==meuId&&c.tec&&!c.tec.meu).sort((a,b)=>a.forca-b.forca).slice(0,10).filter(c=>c.tec.hab>=70);
    if(grandes.length&&peq.length){
      const g=grandes[Math.floor(R()*grandes.length)],q=peq[Math.floor(R()*peq.length)];
      if(g.tec&&!g.tec.meu&&g.tec.hab<q.tec.hab-6){
        const a=g.tec,b=q.tec;g.tec=b;q.tec=a;g._conf=q._conf=70;
        eventos.push("🔁 "+g.nome+" contratou "+b.nome+" do "+q.nome+" (e "+q.nome+" ficou com "+a.nome+")");
        try{regTec(tipo,a.nome,b.nome,g.nome,S.pais,"Contratado do "+q.nome);regTec(tipo,b.nome,a.nome,q.nome,S.pais,"Trocou com o "+g.nome)}catch(e){}
      }
    }
  }
  S.eventosTec=eventos.slice(0,10);
  // 5) o usuário
  const eu=demitidos.find(d=>d.eu);
  const quando=tipo==="meio"?"no meio da temporada":"no fim da temporada";
  if(eu){try{regTec(tipo,S.treinador,"—",eu.c.nome,S.pais,"Você foi demitido",eu.conf)}catch(e){}}
  if(silencioso){S._tecPend={eu:!!eu,tipo,eventos:eventos.slice(0,8),ofertas:eu?ofertasParaMim(tipo).map(c=>c.id):[],clubeAnt:S.clubes[S.meu].nome};return eventos}
  if(eu){
    const of=ofertasParaMim(tipo);S.ofertas=of.map(c=>c.id);
    const clubeAnt=S.clubes[S.meu].nome;
    const cartoes=of.map(c=>`<div class="tbR"><span class="tbN">${escudo(c,16)}<span><b>${c.nome}</b><small>${iconeFama(c.nome)} ${nomeFama(c.nome)} · Força ${Math.round(c.forca)}</small></span></span><button class="sm s" onclick="aceitaOferta(${c.id})">Aceitar</button></div>`).join("");
    modal(`<div style="margin-bottom:8px"><b>👔 Você foi demitido!</b><br><small class="mu">A diretoria do ${clubeAnt} perdeu a confiança ${quando}. Clubes interessados:</small></div><div class="tbL">${cartoes}</div><div class="row" style="margin-top:10px"><button class="s" onclick="recusaOfertas()">Recusar tudo</button></div>`);
  }else if(eventos.length){
    setTimeout(()=>aviso("👔 Janela de técnicos ("+(tipo==="meio"?"meio da temporada":"fim da temporada")+")\n\n"+eventos.slice(0,8).join("\n")),500);
  }
  return eventos;
}

// no fim da temporada o aviso de encerramento já é mostrado; esta janela roda em silêncio e entrega o resumo (e as ofertas, se o usuário foi demitido)
function janelaTecnicosFim(){
  const ev=janelaTecnicos("fim",true);S._tecFimEv=ev;return ev;
}

// mostra a janela de técnicos do fim da temporada (resumo da IA e, se você foi demitido, as ofertas) depois do aviso "Temporada encerrada"
function mostraTecPendente(){
  if(S._objFim){const m=S._objFim;S._objFim=null;setTimeout(()=>aviso(m),60)}
  if(S._premiosInd&&S._premiosInd.meus){const P=S._premiosInd;S._premiosInd=null;
    const mp=P.meus.meusPremiados||[];
    const txt=(mp.length?mp.map(x=>`${x.tipos.map(t=>PREMIO_NOME[t]).join(" + ")}: ${x.nome} (${x.pos})${x.ganho>0?` ⬆️ ${x.de}→${x.para}`:""}`).join("\n"):"Nenhum jogador seu foi premiado.")+`\n\nJogadores premiados no mundo: ${P.totalPremiados}.\nVeja os premiados de cada liga em 💰 Prêmios e fama → Prêmios individuais.`;
    setTimeout(()=>aviso("🏅 Prêmios individuais da temporada\n\n"+txt),90)}
  if(S._renovAuto&&(S._renovAuto.renov.length||S._renovAuto.ficou.length)){const R=S._renovAuto;S._renovAuto=null;setTimeout(()=>aviso('🔁 Renovação automática\n'+(R.renov.length?'Renovaram: '+R.renov.join(', ')+'.\n':'')+(R.ficou.length?'Não renovados: '+R.ficou.join(', ')+'.':'')),120)}
  if(S._avisoPatro){const m=S._avisoPatro;S._avisoPatro=null;setTimeout(()=>aviso('🤝 Patrocínio\n'+m),250)}
  const P=S._tecPend;S._tecPend=null;if(!P)return;
  if(P.eu){
    const of=(P.ofertas||[]).map(id=>S.clubes[id]).filter(Boolean);
    if(!of.length)return;
    S.ofertas=of.map(c=>c.id);
    const cartoes=of.map(c=>`<div class="tbR"><span class="tbN">${escudo(c,16)}<span><b>${c.nome}</b><small>${iconeFama(c.nome)} ${nomeFama(c.nome)} · Força ${Math.round(c.forca)}</small></span></span><button class="sm s" onclick="aceitaOferta(${c.id})">Aceitar</button></div>`).join("");
    modal(`<div style="margin-bottom:8px"><b>👔 Você foi demitido!</b><br><small class="mu">A diretoria do ${P.clubeAnt} perdeu a confiança no fim da temporada. Clubes interessados:</small></div><div class="tbL">${cartoes}</div><div class="row" style="margin-top:10px"><button class="s" onclick="recusaOfertas()">Recusar tudo</button></div>`);
  }else if(P.eventos&&P.eventos.length){
    aviso("👔 Janela de técnicos (fim da temporada)\n\n"+P.eventos.join("\n"));
  }
}


// ===== TÉCNICOS DO MUNDO + HISTÓRICO (v50) =====
// Cada clube de OUTRO país tem um técnico em S.tecMundo[nome]. Nasce da semente (não pesa no save até mudar). As trocas usam a tabela real
// de cada liga (tabelaDe). Tudo (minha liga + mundo) entra em S.histTec: [{temp,tipo,saiu,entrou,clube,pais,motivo,conf}].
function tecDoMundo(pais,div,idx,nome){
  if(!S.tecMundo)S.tecMundo={};
  if(S.tecMundo[nome])return S.tecMundo[nome];
  const rg=rngClube("tecM|"+nome);
  const pico=picoClube(pais,div,idx);
  const hab=Math.max(30,Math.min(95,Math.round(pico+rg()*27-12)));
  const t={id:"m"+Math.floor(rg()*1e9).toString(36),nome:NOMES_T[Math.floor(rg()*NOMES_T.length)]+" "+SOB_T[Math.floor(rg()*SOB_T.length)],hab,tit:Math.floor(rg()*12),idade:35+Math.floor(rg()*33)};
  S.tecMundo[nome]=t;return t;
}
function regTec(tipo,saiu,entrou,clube,pais,motivo,conf,div){
  if(!S.histTec)S.histTec=[];
  S.histTec.push({temp:S.temp,tipo,saiu:saiu||"—",entrou:entrou||"—",clube,pais:pais||S.pais,motivo:motivo||"",conf:conf==null?null:Math.round(conf),div:div==null?0:div});
  S.histTec=S.histTec.filter(x=>S.temp-x.temp<4);                                // guarda só as últimas 4 temporadas
  if(S.histTec.length>700)S.histTec=S.histTec.slice(-700);
}
function janelaTecnicosMundo(tipo){
  if(!S.tecMundo)S.tecMundo={};
  let total=0;
  Object.keys(LIGAS).forEach(pais=>{
    if(pais===S.pais)return;
    const nd=LIGAS[pais].length;
    for(let dv=0;dv<nd;dv++){
      let t;try{t=tabelaDe(pais,dv)}catch(e){continue}
      if(!t||t.length<8)continue;
      const N=t.length,lista=LIGAS[pais][dv];
      // força esperada: ordem pelo pico
      const idxDe={};lista.forEach((c,i)=>{idxDe[c[0]]=i});
      const esp=[...t].map(x=>({n:x.nome,p:picoClube(pais,dv,idxDe[x.nome]!=null?idxDe[x.nome]:0)})).sort((a,b)=>b.p-a.p).map(x=>x.n);
      t.forEach((x,pos0)=>{
        const pos=pos0+1;if(pos<=3)return;
        const i=idxDe[x.nome];if(i==null)return;
        const jogos=x.j||0;if(tipo==="meio"&&jogos<8)return;
        // confiança "do momento" (sem estado guardado): a mesma fórmula, aplicada à tabela atual
        const esperado=esp.indexOf(x.nome)+1;
        const base=100-(pos-1)*3.5,sobra=(esperado-pos)*2.2,zona=pos>N-4?-14*(esperado<=N-6?1:.35):0;
        const conf=Math.max(5,Math.min(100,base+sobra+zona));
        if(R()>=pDemissao(conf)*0.9)return;
        const velho=tecDoMundo(pais,dv,i,x.nome);
        const livres=S.tecLivres||[];
        let novo=null;
        if(livres.length&&R()<.5){livres.sort((a,b)=>Math.abs(a.hab-(velho.hab))-Math.abs(b.hab-(velho.hab)));novo=livres.shift();S.tecLivres=livres;}
        if(!novo){const rg=R;novo={id:"m"+Math.floor(rg()*1e9).toString(36),nome:pick(NOMES_T)+" "+pick(SOB_T),hab:Math.max(30,Math.min(95,Math.round(picoClube(pais,dv,i)+rnd(-12,14)))),tit:rnd(0,8),idade:rnd(35,66)}}
        S.tecMundo[x.nome]=novo;
        regTec(tipo,velho.nome,novo.nome,x.nome,pais,"Demissão por resultados",conf,dv);
        // o demitido pode ser contratado por outro clube ou ir para a lista de livres
        if(S.tecLivres.length<16)S.tecLivres.push(velho);
        total++;
      });
    }
  });
  // roubo de técnico bom por clube grande de outro país (máx. 3 por janela)
  try{
    const paises=Object.keys(LIGAS).filter(p=>p!==S.pais);let rouba=0;
    for(let k=0;k<12&&rouba<3;k++){
      const pa=pick(paises),pb=pick(paises);if(pa===pb)continue;
      const la=LIGAS[pa][0],lb=LIGAS[pb][0];
      const ia=Math.floor(R()*Math.min(6,la.length)),ib=Math.floor(R()*lb.length);
      const grande=la[ia][0],peq=lb[ib][0];
      const tg=tecDoMundo(pa,0,ia,grande),tp=tecDoMundo(pb,0,ib,peq);
      if(tp.hab>=tg.hab+8&&picoClube(pa,0,ia)>picoClube(pb,0,ib)){
        S.tecMundo[grande]=tp;S.tecMundo[peq]=tg;rouba++;
        regTec(tipo,tg.nome,tp.nome,grande,pa,"Contratado do "+peq+" ("+pb+")",null);
        regTec(tipo,tp.nome,tg.nome,peq,pb,"Trocou com o "+grande,null);
      }
    }
  }catch(e){}
  return total;
}
function abaTecHist(){
  const H=S.histTec||[];
  const temps=[...new Set(H.map(x=>x.temp))].sort((a,b)=>b-a);
  if(!temps.includes(S.temp))temps.unshift(S.temp);
  const sel=S.thTemp!=null&&temps.includes(S.thTemp)?S.thTemp:temps[0];
  const tipoSel=S.thTipo||"todos";
  const so=H.filter(x=>x.temp===sel&&(tipoSel==="todos"||x.tipo===tipoSel));
  let h=topoAba("📜","Histórico de técnicos","Demissões e contratações do mundo inteiro",[[so.length,"Trocas"],[H.filter(x=>x.temp===sel&&x.pais===S.pais).length,"No meu país"],[temps.length,"Temporadas"]]);
  const sty="padding:9px;border-radius:10px;background:var(--card2);color:var(--tx);border:1px solid var(--bd);font-size:13px";
  h+=`<div class="card"><div style="display:flex;gap:8px;flex-wrap:wrap">
    <select style="${sty}" onchange="S.thTemp=+this.value;S.thPg=1;render()">${temps.map(t=>`<option value="${t}" ${t===sel?'selected':''}>Temporada ${t}</option>`).join("")}</select>
    <select style="${sty}" onchange="S.thTipo=this.value;S.thPg=1;render()">${[["todos","Todas as janelas"],["meio","Meio da temporada"],["fim","Fim da temporada"]].map(([v,n])=>`<option value="${v}" ${v===tipoSel?'selected':''}>${n}</option>`).join("")}</select>
    <select style="${sty}" onchange="S.thPais=this.value;S.thPg=1;render()"><option value="">Mundo inteiro</option>${Object.keys(LIGAS).map(p=>`<option ${S.thPais===p?'selected':''}>${p}</option>`).join("")}</select>
  </div></div>`;
  const lista=(S.thPais?so.filter(x=>x.pais===S.thPais):so).slice().sort((a,b)=>(a.div||0)-(b.div||0)||(a.conf==null?999:a.conf)-(b.conf==null?999:b.conf));
  if(!lista.length)h+=`<div class="card"><small class="mu">Nenhuma troca registrada nesta seleção. As janelas acontecem no meio e no fim de cada temporada.</small></div>`;
  else{
    const dem=lista.filter(x=>/Demiss/.test(x.motivo)),outros=lista.filter(x=>!/Demiss/.test(x.motivo));
    const linha=x=>`<div class="tbR"><span class="tbN"><span><b>${x.clube}</b> <small class="mu">· ${x.pais} · ${x.tipo==="meio"?"meio":"fim"}</small><small>❌ ${x.saiu} → ✅ ${x.entrou}</small>${x.motivo?`<small class="mu">${x.motivo}${x.conf!=null?" · confiança "+x.conf:""}</small>`:""}</span></span></div>`;
    const PG=25,pgMax=Math.max(1,Math.ceil(dem.length/PG)),pg=Math.min(Math.max(1,S.thPg||1),pgMax);
    h+=`<div class="card"><div class="tag" style="margin-bottom:6px">❌ Demitidos e ✅ contratados (${dem.length})</div><div class="tbL">${dem.slice((pg-1)*PG,pg*PG).map(linha).join("")||'<small class="mu">—</small>'}</div>${pgMax>1?`<div class="row" style="margin-top:8px"><button class="sm s" ${pg<=1?'disabled':''} onclick="S.thPg=${pg-1};render()">◀</button><small class="mu" style="align-self:center">Página ${pg} de ${pgMax}</small><button class="sm s" ${pg>=pgMax?'disabled':''} onclick="S.thPg=${pg+1};render()">▶</button></div>`:''}</div>`;
    if(outros.length)h+=`<div class="card"><div class="tag" style="margin-bottom:6px">🔁 Troca entre clubes (${outros.length})</div><div class="tbL">${outros.map(linha).join("")}</div></div>`;
  }
  return h;
}


// ===== LESÕES VISÍVEIS (v51) =====
// Selo padrão: 🤕 + jogos que faltam (ex.: "🤕 3j"). Jogador sem tipo guardado (lesão antiga) mostra "lesão".
function lesaoSelo(j){
  if(!(j.lesao>0))return "";
  const grave=j.lesao>=6;
  return `<i class="mk" title="${(j.lesNome||'Lesão')} · fora por ${j.lesao} jogo(s)" style="background:${grave?'#7f1d1d':'#7a3b00'};color:#fff;border-radius:6px;padding:0 4px;font-style:normal;font-size:10px;font-weight:800">🤕 ${j.lesao}j</i>`;
}
function lesaoTexto(j){
  if(!(j.lesao>0))return "";
  const n=j.lesao;
  const nivel=n<=2?"leve":n<=5?"moderada":n<=10?"grave":"muito grave";
  return `${j.lesNome?j.lesNome.charAt(0).toUpperCase()+j.lesNome.slice(1):"Lesão"} · ${nivel} · volta em ${n} jogo${n>1?"s":""}`;
}
function desfalquesHTML(c){
  const l=c.elenco.filter(j=>j.lesao>0).sort((a,b)=>b.lesao-a.lesao);
  const s2=c.elenco.filter(j=>j.suspenso>0&&!(j.lesao>0));
  if(!l.length&&!s2.length)return "";
  return `<div class="card" style="margin:8px 0;border-left:3px solid #b45309"><div class="tag" style="margin-bottom:6px">🏥 Departamento médico (${l.length})${s2.length?` · ⛔ Suspensos (${s2.length})`:''}</div>
    ${l.map(j=>`<div class="tbR" style="cursor:pointer" onclick="abreFichaJogador('${j.id}')"><span class="tbN"><span><b>${numDe(j)?numDe(j)+' · ':''}${j.nome}</b> <small class="mu">${j.pos}${j.tit?' · titular':''}</small><small style="color:#ffb86b">${lesaoTexto(j)}</small></span></span><b style="color:${j.lesao>=6?'#ff8a8a':'#ffb86b'}">${j.lesao}j</b></div>`).join("")}
    ${s2.map(j=>`<div class="tbR" style="cursor:pointer" onclick="abreFichaJogador('${j.id}')"><span class="tbN"><span><b>${j.nome}</b> <small class="mu">${j.pos}</small><small style="color:#ff8a8a">Suspenso · ${j.suspenso} jogo(s)</small></span></span><b style="color:#ff8a8a">⛔</b></div>`).join("")}
  </div>`;
}


// ===== FINANÇAS DE VERDADE (v52) =====
// Como no Brasfoot: a FOLHA INTEIRA de salários sai do caixa TODO MÊS do calendário (não por jogo), com extrato de receitas e despesas.
// Bilheteria vale ×FATOR_RENDA e o estádio custa manutenção por lugar. Rescisão na venda: 12–30%. Calibrado em simulação:
// clube forte ≈ +5 mi/temporada, médio ≈ +1 mi, fraco ≈ 0 (sem vender jogadores).
const FATOR_RENDA=.55,MANUT_LUGAR=15;                                 // R$ por lugar do estádio por mês
function extratoFin(){
  if(!S.fin||S.fin.temp!==S.temp)S.fin={temp:S.temp,rec:{},desp:{},mes:{}};
  return S.fin;
}
function finRec(cat,v){if(!v)return;const F=extratoFin();F.rec[cat]=(F.rec[cat]||0)+Math.round(v)}
function finDesp(cat,v){if(!v)return;const F=extratoFin();F.desp[cat]=(F.desp[cat]||0)+Math.round(v)}
function meuReal(){return S._clbak?S._clbak.clubes[S._clbak.meu]:S.clubes[S.meu]}
function folhaMensal(c){return (c||meuReal()).elenco.reduce((q,j)=>q+(j.emprestado&&j.donoNome?j.sal*1000:j.sal*1000),0)}
// bilheteria: só quando joga em casa; multiplica pelo fator e pelo peso da competição
function recebeBilheteria(comp,mult){
  const eu=meuReal();if(!eu||!S.pos)return 0;
  const v=Math.round(S.pos.renda*(mult||1)*FATOR_RENDA);
  eu.caixa+=v;finRec("Bilheteria",v);S.pos.rendaLiq=v;return v;
}
// virada de mês no calendário: cobra folha + manutenção do estádio + auxiliar. Chamada por agendaAvanca().
function cobraMes(){
  const eu=meuReal();if(!eu)return;
  const folha=Math.round(folhaMensal(eu));
  const manut=Math.round(capEst(eu)*MANUT_LUGAR);
  const aux=S.aux?Math.round(S.aux.sal):0;
  const tot=folha+manut+aux;
  eu.caixa-=tot;finDesp("Salários",folha);finDesp("Manutenção do estádio",manut);if(aux)finDesp("Auxiliar técnico",aux);
  let patro=0;try{patro=patrocinioMes()}catch(e){}
  S.ultMes={folha,manut,aux,tot,patro,caixa:Math.round(eu.caixa)};
  const F=extratoFin();
  if(eu.caixa<0){S.dir=Math.max(5,(S.dir==null?70:S.dir)-6);S.tor=Math.max(5,(S.tor==null?70:S.tor)-2)}
  S._avisoMes="💸 Fim do mês: salários "+R$(folha)+" + estádio "+R$(manut)+(aux?" + auxiliar "+R$(aux):"")+(patro?"\\n🤝 Patrocínio: +"+R$(patro):"")+"\\nCaixa: "+R$(Math.round(eu.caixa))+(eu.caixa<0?"\\n⚠️ Caixa NEGATIVO: a diretoria perde a confiança. Venda jogadores ou peça empréstimo.":"");
}
// rescisão na venda (12% / 25% / 30%, conforme o contrato restante)
function rescisaoDe(j,v){const ct=j.ct||1;const pct=ct>=3?.30:ct===2?.25:.12;return Math.round(v*pct)}


function abaFin(){
  const eu=S.clubes[S.meu],F=extratoFin();
  const recT=Object.values(F.rec).reduce((q,x)=>q+x,0),despT=Object.values(F.desp).reduce((q,x)=>q+x,0);
  const folha=Math.round(folhaMensal(eu)),manut=Math.round(capEst(eu)*MANUT_LUGAR),aux=S.aux?Math.round(S.aux.sal):0;
  const mensal=folha+manut+aux;
  const linhas=(o,cor)=>Object.entries(o).sort((a,b)=>b[1]-a[1]).map(([k,v])=>`<div class="upL"><div><b>${k}</b></div><b style="color:${cor}">${R$(v)}</b></div>`).join("")||'<small class="mu">—</small>';
  const prox=S.agenda&&S.agenda[S.dia]?["jan","fev","mar","abr","mai","jun","jul","ago","set","out","nov","dez"][S.agenda[S.dia].mes]:"—";
  let h=topoAba("📊","Finanças","Receitas, despesas e folha do clube",[[R$(eu.caixa),"Caixa"],[R$(mensal),"Custo/mês"],[R$(recT-despT),"Saldo temp."]]);
  h+=`<div class="card"><div class="tag" style="margin-bottom:6px">💸 Todo mês sai do caixa</div>
    ${linhaInfo("Salários ("+eu.elenco.length+" jogadores)",R$(folha))}${linhaInfo("Manutenção do estádio",R$(manut))}${aux?linhaInfo("Auxiliar técnico",R$(aux)):''}
    ${linhaInfo("Total por mês",R$(mensal))}
    <small class="mu" style="display:block;margin-top:6px">A cobrança acontece quando o mês vira no calendário (mês atual: ${prox}), como no Brasfoot. Contratar jogador aumenta a folha a partir do mês seguinte. Caixa negativo derruba a confiança da diretoria e da torcida.</small>
    ${S.ultMes?`<small class="mu" style="display:block;margin-top:6px">Último mês pago: ${R$(S.ultMes.tot)}</small>`:''}</div>`;
  h+=`<div class="card"><div class="tag" style="margin-bottom:6px">⬆️ Receitas da temporada · ${R$(recT)}</div>${linhas(F.rec,'#7dff9a')}</div>`;
  h+=`<div class="card"><div class="tag" style="margin-bottom:6px">⬇️ Despesas da temporada · ${R$(despT)}</div>${linhas(F.desp,'#ff8a8a')}</div>`;
  h+=`<div class="card"><small class="mu">Bilheteria vale ${Math.round(FATOR_RENDA*100)}% do bruto do jogo (custos de operação). Vender jogador custa rescisão: 30% (contrato de 3+ anos), 25% (2 anos) ou 12% (1 ano).</small></div>`;
  return h;
}


// ===== TÍTULOS POR TÉCNICO + TAÇAS (v52) =====
// S.titTec = lista de {tec, clube, comp, temp, pais}. comp: liga | copa | cl | el | lb | sa | mund.
// Funciona para QUALQUER técnico do mundo (o clube campeão tem um técnico: S.tecMundo[nome] ou clube.tec na minha liga; você = S.treinador).
const COMP_TITULO={
  liga:{n:"Campeonato nacional",c1:"#f5c542",c2:"#a8801c",forma:"liga"},
  copa:{n:"Copa nacional",c1:"#c0c8d0",c2:"#7d8791",forma:"copa"},
  cl:{n:"Champions League",c1:"#d9dfe6",c2:"#7f8b99",forma:"orelhas"},
  el:{n:"Liga Europa",c1:"#e8a33d",c2:"#9c6416",forma:"copa"},
  lb:{n:"Libertadores",c1:"#f5c542",c2:"#222222",forma:"liberta"},
  sa:{n:"Sul-Americana",c1:"#34c47a",c2:"#17653f",forma:"copa"},
  mund:{n:"Mundial de Clubes",c1:"#f5c542",c2:"#1f3f8f",forma:"globo"}
};
// taças desenhadas em SVG (próprias, nas cores de cada competição): leves e sem depender de download
function tacaSVG(comp,tam){
  const I=COMP_TITULO[comp]||COMP_TITULO.copa,w=tam||34,h=Math.round(w*1.25),c1=I.c1,c2=I.c2,f=I.forma;
  let g="";
  if(f==="orelhas"){      // Champions: copa grande com duas alças largas
    g=`<path d="M12 6 Q3 8 5 18 Q7 26 14 26" fill="none" stroke="${c1}" stroke-width="3"/><path d="M28 6 Q37 8 35 18 Q33 26 26 26" fill="none" stroke="${c1}" stroke-width="3"/>
       <path d="M11 4 H29 L27 24 Q20 30 13 24 Z" fill="${c1}" stroke="${c2}" stroke-width="1"/><rect x="18" y="26" width="4" height="9" fill="${c2}"/><rect x="12" y="35" width="16" height="5" rx="1.5" fill="${c2}"/>`;
  }else if(f==="liberta"){ // Libertadores: copa alta dourada, base preta
    g=`<path d="M13 3 H27 L25 22 Q20 27 15 22 Z" fill="${c1}" stroke="#a8801c" stroke-width="1"/><path d="M13 7 Q5 8 7 16 Q9 21 14 21" fill="none" stroke="${c1}" stroke-width="2.5"/><path d="M27 7 Q35 8 33 16 Q31 21 26 21" fill="none" stroke="${c1}" stroke-width="2.5"/>
       <rect x="18" y="24" width="4" height="8" fill="${c1}"/><rect x="11" y="32" width="18" height="8" rx="1.5" fill="${c2}"/><rect x="11" y="32" width="18" height="2" fill="${c1}"/>`;
  }else if(f==="globo"){   // Mundial: globo sobre pedestal
    g=`<circle cx="20" cy="15" r="10" fill="${c1}" stroke="#a8801c" stroke-width="1"/><path d="M10 15 H30 M20 5 Q14 15 20 25 M20 5 Q26 15 20 25" fill="none" stroke="#a8801c" stroke-width="1"/>
       <rect x="18" y="25" width="4" height="8" fill="${c1}"/><rect x="11" y="33" width="18" height="7" rx="1.5" fill="${c2}"/>`;
  }else if(f==="liga"){    // campeonato: taça com tampa
    g=`<path d="M12 7 Q4 8 6 17 Q8 23 14 23" fill="none" stroke="${c1}" stroke-width="2.5"/><path d="M28 7 Q36 8 34 17 Q32 23 26 23" fill="none" stroke="${c1}" stroke-width="2.5"/>
       <path d="M11 6 H29 L27 22 Q20 28 13 22 Z" fill="${c1}" stroke="${c2}" stroke-width="1"/><path d="M15 6 Q20 1 25 6 Z" fill="${c1}" stroke="${c2}" stroke-width="1"/>
       <rect x="18" y="26" width="4" height="7" fill="${c2}"/><rect x="12" y="33" width="16" height="6" rx="1.5" fill="${c2}"/>`;
  }else{                   // copa simples (copa nacional, Liga Europa, Sul-Americana)
    g=`<path d="M12 6 Q5 7 7 15 Q9 20 14 20" fill="none" stroke="${c1}" stroke-width="2.5"/><path d="M28 6 Q35 7 33 15 Q31 20 26 20" fill="none" stroke="${c1}" stroke-width="2.5"/>
       <path d="M12 5 H28 L26 20 Q20 25 14 20 Z" fill="${c1}" stroke="${c2}" stroke-width="1"/><rect x="18" y="23" width="4" height="9" fill="${c2}"/><rect x="12" y="32" width="16" height="7" rx="1.5" fill="${c2}"/>`;
  }
  return `<svg width="${w}" height="${h}" viewBox="0 0 40 42" xmlns="http://www.w3.org/2000/svg" style="flex:none">${g}</svg>`;
}
function tecDoClube(nome,pais){            // nome do técnico que treina o clube agora
  const c=S.clubes.find(x=>x.nome===nome);
  if(c&&c.tec)return c.tec.meu?S.treinador:c.tec.nome;
  const ch=chaveFixa(pais||S.pais,nome);
  if(ch&&S.tecMundo&&S.tecMundo[nome])return S.tecMundo[nome].nome;
  if(ch){try{return tecDoMundo(pais,ch.div,ch.idx,nome).nome}catch(e){}}
  return null;
}
function regTituloTec(clube,comp,pais){
  if(!clube)return;
  const t=tecDoClube(clube,pais);if(!t)return;
  if(!S.titTec)S.titTec=[];
  S.titTec.push({tec:t,clube,comp,temp:S.temp,pais:pais||S.pais});
  if(S.titTec.length>2500)S.titTec=S.titTec.slice(-2500);
}
function titulosDoTec(nome){
  const L=(S.titTec||[]).filter(x=>x.tec===nome),por={};
  L.forEach(x=>{(por[x.comp]=por[x.comp]||[]).push(x)});
  return{lista:L,por,total:L.length};
}
function abreFichaTecnico(nome,clubeNome){
  const T=titulosDoTec(nome);
  const ordem=["cl","lb","mund","el","sa","liga","copa"].filter(k=>T.por[k]);
  const corpo=T.total?ordem.map(k=>{
    const L=T.por[k],I=COMP_TITULO[k];
    return `<div style="display:flex;gap:10px;align-items:center;padding:8px 0;border-bottom:1px solid #ffffff14">${tacaSVG(k,38)}<div style="flex:1"><b>${I.n}</b><div class="mu" style="font-size:11px">${L.map(x=>x.clube+" ("+x.temp+"ª temp.)").join(" · ")}</div></div><b style="font-size:20px;color:var(--y,#f5c542)">${L.length}×</b></div>`;
  }).join(""):`<div class="mu" style="padding:10px 0">Nenhum título conquistado desde que o jogo começou.</div>`;
  modal(`<div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px"><div><b style="font-size:16px">👔 ${nome}</b><div class="mu" style="font-size:12px">${clubeNome||""}</div></div><button class="sm" onclick="fechaDlg()">Fechar</button></div>
    <div style="margin:8px 0;font-size:13px">🏆 <b>${T.total}</b> título${T.total===1?"":"s"} no total</div>${corpo}`);
}


// ===== 11 EM CAMPO OBRIGATÓRIO (v55) =====
// Antes de QUALQUER partida do seu time (liga, copas, Mundial) o jogo exige 11 titulares aptos. Faltou gente (expulso, lesão, suspensão)?
// Ele completa sozinho com o melhor reserva da mesma posição; se não houver ninguém, bloqueia e leva você à Tática.
function aptoParaJogar(j){return !(j.lesao>0)&&!(j.suspenso>0)&&!j.expulso&&!j.emprestadoFora}
function titularesAptos(c){return c.elenco.filter(j=>j.tit&&aptoParaJogar(j))}
function motivoInapto(j){return j.lesao>0?"lesionado ("+j.lesao+"j)":j.suspenso>0?"suspenso":j.expulso?"expulso":"indisponível"}
function garante11(c,silencioso){
  c=c||meuReal();if(!c)return{ok:true,trocas:[]};
  const fe0=x=>x.f*(0.7+0.3*(x.en==null?100:x.en)/100);
  // 1) cada titular que não pode jogar vira UMA vaga (a do goleiro tem prioridade)
  const vagas=[];
  c.elenco.forEach(j=>{if(j.tit&&!aptoParaJogar(j)){j.tit=false;vagas.push({sai:j,entra:null,improv:false})}});
  vagas.sort((a,b)=>(a.sai.pos==="GOL"?0:1)-(b.sai.pos==="GOL"?0:1));
  // 2) cada vaga: melhor reserva da MESMA posição; senão outro de linha; sem goleiro apto, um jogador de linha improvisa no gol
  vagas.forEach(v=>{
    const pool=c.elenco.filter(x=>!x.tit&&aptoParaJogar(x));if(!pool.length)return;
    const pos=v.sai.pos;let m=pool.filter(x=>x.pos===pos).sort((a,b)=>fe0(b)-fe0(a))[0]||null;
    if(!m&&pos==="GOL"){m=pool.sort((a,b)=>fe0(b)-fe0(a))[0];v.improv=true}
    else if(!m){m=pool.filter(x=>x.pos!=="GOL").sort((a,b)=>fe0(b)-fe0(a))[0]||null}
    if(!m)return;
    m.px=v.sai.px;m.py=v.sai.py;m._g=grupoPos(m);m._slot=v.sai._slot;m._role=v.sai._role;m.tit=true;v.entra=m;
    if(S.cap===v.sai.id)S.cap=m.id;
  });
  // 3) ainda faltam titulares (escalação incompleta)? completa do banco
  let g=0;
  while(titularesAptos(c).length<11&&g++<20){
    const pool=c.elenco.filter(x=>!x.tit&&aptoParaJogar(x));if(!pool.length)break;
    const temGol=titularesAptos(c).some(x=>x.pos==="GOL");
    const gol=!temGol?pool.filter(x=>x.pos==="GOL")[0]:null;
    const linha=pool.filter(x=>x.pos!=="GOL").sort((a,b)=>fe0(b)-fe0(a))[0];
    (gol||linha||pool[0]).tit=true;
  }
  const ok=titularesAptos(c).length>=11;
  if(vagas.some(v=>v.entra)||!ok){try{auto(c,true)}catch(e){}}                  // reorganiza as posições sem perder quem já está escalado
  if(!ok&&!silencioso){
    const faltam=11-titularesAptos(c).length;
    const lista=c.elenco.filter(j=>!aptoParaJogar(j)).map(j=>"• "+j.nome+" ("+j.pos+") — "+motivoInapto(j)).slice(0,6).join("\\n");
    S.aba="tat";
    aviso("⛔ Você precisa de 11 jogadores em campo.\\nFaltam "+faltam+" apto(s) no elenco.\\n\\n"+(lista?"Indisponíveis:\\n"+lista+"\\n\\n":"")+"Contrate ou promova alguém da base e escale o time na Tática.",render);
    return{ok:false,trocas:vagas};
  }
  if(!silencioso&&vagas.some(v=>v.entra)){
    const txt=vagas.filter(v=>v.entra).map(v=>"• "+v.entra.nome+(v.improv?" (improvisado no gol)":"")+" entra no lugar de "+v.sai.nome+" ("+motivoInapto(v.sai)+")").join("\\n");
    setTimeout(()=>toast("🔁 Time completado:\\n"+txt),100);
  }
  return{ok,trocas:vagas};
}

function seloOnze(c){
  c=c||meuReal();const n=titularesAptos(c).length,ok=n>=11;
  return `<span class="tag" style="background:${ok?'#14532d':'#7f1d1d'};color:#fff;font-weight:800">${ok?'✅':'⛔'} ${n}/11 em campo</span>`;
}


// ===== PAINEL DE ALERTAS (v55) =====
// Resumo rápido na Início: o que precisa de atenção antes do próximo jogo.
function alertasClube(){
  const eu=meuReal();if(!eu)return[];
  const A=[];
  const n=eu.elenco.length;
  if(n<MIN_ELENCO+2)A.push({n:3,t:"⚠️ Elenco curto: "+n+" jogadores (mínimo "+MIN_ELENCO+"). Contrate ou promova alguém da base."});
  const apt=titularesAptos(eu).length;if(apt<11)A.push({n:5,t:"⛔ Só "+apt+" titulares aptos escalados."});
  const convS=eu.elenco.filter(j=>j.conv);if(convS.length)A.push({n:2,t:"✈️ "+convS.length+" convocado(s) pelas seleções: "+convS.slice(0,3).map(j=>fl(j.conv.p)+" "+j.nome.split(" ").slice(-1)[0]).join(", ")+(convS.length>3?"…":"")});const lesion=eu.elenco.filter(j=>j.lesao>0&&!j.conv);if(lesion.length)A.push({n:2,t:"🤕 "+lesion.length+" lesionado(s): "+lesion.slice(0,3).map(j=>j.nome.split(" ").slice(-1)[0]+" "+j.lesao+"j").join(", ")+(lesion.length>3?"…":"")});
  const amar=eu.elenco.filter(j=>(j.ac||0)===2&&!(j.suspenso>0));if(amar.length)A.push({n:2,t:"🟨🟨 Pendurado (mais um amarelo = suspensão): "+amar.slice(0,3).map(j=>j.nome.split(" ").slice(-1)[0]).join(", ")+(amar.length>3?"…":"")});
  if((S.pedidosSaida||[]).length)A.push({n:4,t:"🚪 "+S.pedidosSaida.length+" jogador(es) pediram para sair: veja na Início ou no Mercado."});
  const susp=eu.elenco.filter(j=>j.suspenso>0);if(susp.length)A.push({n:2,t:"⛔ Suspenso(s) no próximo jogo: "+susp.slice(0,3).map(j=>j.nome.split(" ").slice(-1)[0]).join(", ")});
  const ct=eu.elenco.filter(j=>!j.emprestado&&(j.ct||1)<=1&&j.tit);if(ct.length)A.push({n:1,t:"📄 Contrato no último ano de titulares: "+ct.slice(0,3).map(j=>j.nome.split(" ").slice(-1)[0]).join(", ")+(ct.length>3?"…":"")});
  const mensal=Math.round(folhaMensal(eu)+capEst(eu)*MANUT_LUGAR+(S.aux?S.aux.sal:0));
  if(eu.caixa<0)A.push({n:5,t:"💸 Caixa NEGATIVO ("+R$(Math.round(eu.caixa))+"). A diretoria está perdendo a confiança: venda jogadores ou peça empréstimo."});
  else if(mensal>0&&eu.caixa<mensal*1.5)A.push({n:4,t:"💸 Caixa baixo: "+R$(Math.round(eu.caixa))+" cobre só "+(eu.caixa/mensal).toFixed(1)+" mês de custos ("+R$(mensal)+"/mês)."});
  if((S.dir!=null&&S.dir<35)||(S.tor!=null&&S.tor<35))A.push({n:4,t:"😠 Confiança baixa (diretoria "+(S.dir||0)+"% · torcida "+(S.tor||0)+"%): risco de demissão na próxima janela."});
  return A.sort((a,b)=>b.n-a.n);
}
function alertasHTML(){
  let A=[];try{A=alertasClube()}catch(e){}
  if(!A.length)return "";
  return `<div class="card" style="margin:8px 0;border-left:3px solid #f5c542"><div class="tag" style="margin-bottom:4px">📣 Atenção</div>${A.slice(0,5).map(a=>`<div style="font-size:12px;padding:3px 0;color:${a.n>=4?'#ffb3b3':'inherit'}">${a.t}</div>`).join("")}</div>`;
}


// ===== EVOLUÇÃO DURANTE OS CAMPEONATOS (v57) =====
// Quem JOGA ganha força a cada partida (na liga, nas copas e no Mundial): ganho = falta até o potencial × taxa da idade × nota do jogo × minutos jogados.
// 75% do crescimento anual chega assim, aos poucos; o fim de ano paga só o restante (maturação) e o treino dos reservas. Aos 29 anos ninguém evolui mais.
const EVO_PARTE_JOGOS=.75,EVO_JOGOS_ANO=60;
function fracAnualIdade(i){return i<=20?.22:i<=22?.20:i<=24?.16:i<=27?.11:.06}
function ganhoPorJogo(j,nota,minutos,fama){
  if(j.idade>28)return 0;
  const fr=(j.fReal!=null?j.fReal:j.f),falta=Math.max(0,(j.pot||fr)-fr);if(falta<=0)return 0;
  const fn=Math.max(.5,Math.min(1.8,1+(nota-6)*.4));                      // nota 6 = 1,0× · 8+ = 1,8× · 5 ou menos = 0,5×
  const fm=Math.max(0,Math.min(1,minutos/90));                            // quem entrou aos 80' ganha pouco
  const bf=1+[0,.15,.35][fama||0];
  return Math.min(falta,falta*fracAnualIdade(j.idade)*EVO_PARTE_JOGOS/EVO_JOGOS_ANO*fn*fm*bf);
}
function aplicaGanhoJogo(clube,j,g){
  if(!(g>0))return 0;
  const fr=(j.fReal!=null?j.fReal:j.f),novo=Math.min(100,Math.min(j.pot||100,fr+g));
  if(j.f0Temp==null||j.f0TempAno!==S.temp){j.f0Temp=(j.fReal!=null?j.fReal:j.f);j.f0TempAno=S.temp}
  const antes=j.f;j.fReal=novo;j.f=Math.max(15,Math.min(100,Math.round(novo)));
  if(j.f!==antes){                                                         // virou um ponto inteiro: atualiza valor, salário e força do time
    j.val=valorDe(j.f,j.idade,j.pot,j.mk);j.sal=salarioDe(j.f,j.mk);
    try{clube.forca=forcaMedia(clube)}catch(e){}
    return j.f-antes;
  }
  return 0;
}
// minutos de cada jogador numa partida: titular o jogo todo; quem entrou, a partir do minuto da substituição; quem saiu, até ela
function minutosDoJogo(o,subs,idJ){
  let ini=0,fim=90;
  (subs||[]).forEach(x=>{if(x.entra===idJ)ini=x.m;if(x.sai===idJ)fim=x.m});
  return Math.max(0,fim-ini);
}


// ===== EVOLUÇÃO DOS CLUBES DA IA DURANTE A TEMPORADA (v57) =====
// Minha liga: a cada rodada os titulares da IA ganham como um jogador de nota ≈ 6,3. Mundo compacto: em passos a cada rodada simulada.
// O fim de ano da IA continua pagando o restante (maturação). Assim os rivais crescem junto com o seu time.
function evoluiIARodada(){
  try{
    const rodadas=Math.max(1,(S.fixt||[]).length),pesoRod=EVO_JOGOS_ANO/rodadas;     // 38 rodadas ≈ 60 jogos de ritmo
    S.clubes.forEach((c,ci)=>{
      if(ci===S.meu)return;
      const fama=nivelFama(c.nome);let mudou=false;
      c.elenco.forEach(j=>{
        if(j.idade>28)return;
        const jogou=j.tit||R()<.2;if(!jogou)return;
        const nota=6.3+(R()-.5)*.8,g=ganhoPorJogo(j,nota,j.tit?90:30,fama)*pesoRod;
        const d=aplicaGanhoJogo(c,j,g);if(d>0)mudou=true;
      });
      if(mudou)try{c.forca=forcaMedia(c)}catch(e){}
    });
  }catch(e){}
}
// mundo compacto: ganho por fatia de rodada (em décimos de força), só para quem tem potencial e idade ≤ 28
function evoluiMundoFatia(frac){
  // frac = fatia da temporada que acabou de passar (ex.: 1/38). O estado compacto guarda a força em DÉCIMOS; cada fatia rende bem menos que 0,1,
  // então o ganho em décimos é sorteado (parte inteira + 1 com chance = parte fracionária): a média fica exata e nada é perdido no arredondamento.
  try{
    if(!S.mundo)return;
    const rg=R;
    Object.keys(S.mundo).forEach(k=>{
      const est=S.mundo[k];if(!est||!est.c)return;
      let mudou=false;
      est.c=est.c.map(t=>{
        const idade=t[0];if(idade>28)return t;
        const f=t[1]/10,pot=t[2],falta=Math.max(0,pot-f);if(falta<=0)return t;
        const dec=falta*fracAnualIdade(idade)*EVO_PARTE_JOGOS*frac*10*(0.6+rg()*.8);   // ganho da fatia, em décimos
        const b=Math.floor(dec),inc=b+(rg()<dec-b?1:0);if(inc<=0)return t;
        const novo=Math.min(pot*10,t[1]+inc);if(novo===t[1])return t;
        const r=t.slice();r[1]=novo;mudou=true;return r;
      });
    });
    S._mem={};                                                                         // clubes montados na sessão serão remontados já evoluídos
  }catch(e){}
}

function evolucaoFichaHTML(j){
  const fr=(j.fReal!=null?j.fReal:j.f),pot=j.pot||fr;
  const ganhoTemp=(j.f0TempAno===S.temp&&j.f0Temp!=null)?fr-j.f0Temp:0;
  if(j.idade>28)return `<div><small>Evolução</small><b style="color:#ffb86b">Declínio</b><small>${j.idade} anos: só perde força</small></div>`;
  if(fr>=pot-0.05)return `<div><small>Evolução</small><b style="color:#7dff9a">No teto</b><small>potencial ${pot}</small></div>`;
  const prog=Math.max(0,Math.min(100,Math.round((fr-Math.floor(fr))*100)));
  return `<div><small>Próximo ponto</small><b>${prog}%</b><small>${ganhoTemp>=0?'+':''}${ganhoTemp.toFixed(1).replace('.',',')} na temporada</small></div>`;
}


// ===== ENTROSAMENTO E MORAL (v58) =====
// ENTROSAMENTO (0–100, por jogador): sobe +1,2 a cada jogo que atua; jogador novo começa em 20; cai −1,5 por jogo no banco. O time joga com
// força × (0,97 + 0,06 × entrosamento médio do XI / 100): de −3% (grupo todo novo) a +3% (grupo afinado, ≈ 1 ponto de força).
// MORAL (0–100, por jogador): vitória +2,5 · empate 0 · derrota −3 · titular +0,4 · reserva −0,6 · clássico ganho +2 / perdido −3 · título +10.
// Efeito: força × (0,97 + 0,06 × moral/100). Moral muito baixa (<25) faz o jogador recusar renovação e pedir para sair.
function entrosJ(j){return j.entr==null?60:j.entr}
function moralJ(j){return j.mor==null?60:j.mor}
function entrosMedio(c){const t=c.elenco.filter(x=>x.tit);return t.length?t.reduce((q,x)=>q+entrosJ(x),0)/t.length:60}
function fatorEntrosMoral(c){
  const t=c.elenco.filter(x=>x.tit);if(!t.length)return 1;
  const e=t.reduce((q,x)=>q+entrosJ(x),0)/t.length,m=t.reduce((q,x)=>q+moralJ(x),0)/t.length;
  return (0.97+0.06*e/100)*(0.985+0.03*m/100);             // entrosamento ±3% · moral ±1,5% (juntos: de −4,5% a +4,5%)
}
function jogadorNovoNoClube(j){j.entr=20;j.mor=Math.max(50,moralJ(j))}                      // chama quando alguém chega
function atualizaEntrosMoral(c,res,classico){               // res: 1 vitória · 0 empate · −1 derrota. Chamado no fim de cada jogo do SEU time.
  c.elenco.forEach(j=>{
    const jogou=!!j.jogou_ultimo;
    j.entr=Math.max(0,Math.min(100,entrosJ(j)+(jogou?1.2:-1.5)));
    let m=moralJ(j)+(res>0?2.5:res<0?-3:0)+(jogou?.4:-.6)+(classico?(res>0?2:res<0?-3:0):0);
    j.mor=Math.max(jogou?20:15,Math.min(100,m));
  });
}
function rotuloEntros(v){return v>=80?"Afinado":v>=55?"Bom":v>=35?"Em formação":"Desentrosado"}
function rotuloMoral(v){return v>=80?"Motivado":v>=55?"Bem":v>=35?"Irritado":"Descontente"}
function corNivel(v){return v>=65?"#3ddc84":v>=40?"#f5c542":"#ff5d5d"}


// ===== CLUBE RIVAL E CLÁSSICOS (v58) =====
// Você escolhe UM rival entre os clubes do seu país (ou deixa o jogo sugerir os mais próximos em prestígio e vizinhos de divisão).
// Clássico: público +12%, bilheteria × 1,25, moral do grupo +2 se vencer / −3 se perder. O histórico de confrontos fica em S.classicos.
function ehRival(nome){return !!S.rival&&S.rival===nome}
function sugestoesRival(){
  const eu=meuReal();if(!eu)return[];
  const todos=[];
  (LIGAS[S.pais]||[]).forEach((lst,dv)=>lst.forEach(c=>{if(c[0]!==eu.nome)todos.push({nome:c[0],sig:c[1],cor:c[2],cor2:c[3],dv})}));
  return todos.map(x=>{let f=0;try{f=pontosFama(x.nome)}catch(e){}
    const mf=pontosFama(eu.nome);return{...x,fama:f,d:Math.abs(f-mf)+Math.abs(x.dv-S.div)*25}})
    .sort((a,b)=>a.d-b.d).slice(0,12);
}
function escolheRival(nome){S.rival=nome;S.classicos=S.classicos||{v:0,e:0,d:0,gp:0,gc:0,jogos:[]};save();fechaDlg();render();toast("🔥 "+nome+" é o seu rival!")}
function tiraRival(){S.rival=null;save();fechaDlg();render()}
function abreEscolhaRival(){
  const lista=sugestoesRival();
  modal(`<div style="display:flex;justify-content:space-between;align-items:center"><b>🔥 Escolha o seu rival</b><button class="sm" onclick="fechaDlg()">Fechar</button></div>
    <small class="mu" style="display:block;margin:6px 0">Jogos contra o rival são clássicos: mais público, mais bilheteria e mais emoção no vestiário. Sugestões do seu nível:</small>
    <div class="tbL" style="max-height:340px;overflow:auto">${lista.map(c=>`<div class="tbR" onclick="escolheRival('${c.nome.replace(/'/g,"\\'")}')" style="cursor:pointer"><span class="tbN">${escudo(c,16)}<span><b>${c.nome}</b><small>${LIGANOME[S.pais][c.dv]} · ${iconeFama(c.nome)} ${nomeFama(c.nome)}</small></span></span><span class="tag">${S.rival===c.nome?'✔ atual':'Escolher'}</span></div>`).join("")}</div>
    ${S.rival?`<button class="s" style="margin-top:8px;width:100%" onclick="tiraRival()">Remover rival</button>`:''}`);
}
function registraClassico(res,classico){
  if(!classico)return;
  const C=S.classicos=S.classicos||{v:0,e:0,d:0,gp:0,gc:0,jogos:[]};
  if(res>0)C.v++;else if(res<0)C.d++;else C.e++;
  try{const P=S.pos,meuA=P.a===S.meu;C.gp+=meuA?P.ga:P.gb;C.gc+=meuA?P.gb:P.ga;
    C.jogos.push({t:S.temp,adv:S.rival,res:(meuA?P.ga:P.gb)+"x"+(meuA?P.gb:P.ga)});if(C.jogos.length>12)C.jogos=C.jogos.slice(-12)}catch(e){}
}
function cartaoRivalHTML(){
  const C=S.classicos||{v:0,e:0,d:0,gp:0,gc:0,jogos:[]};
  if(!S.rival)return `<div class="card" style="margin:8px 0"><div class="tag" style="margin-bottom:6px">🔥 Clássico</div><small class="mu">Você ainda não tem um rival. Escolha um clube para ter clássicos com mais público e bilheteria.</small><button class="sm s" style="margin-top:6px" onclick="abreEscolhaRival()">Escolher rival</button></div>`;
  return `<div class="card" style="margin:8px 0;border-left:3px solid #ff7a59"><div style="display:flex;justify-content:space-between;align-items:center"><div class="tag">🔥 Clássico contra ${S.rival}</div><button class="sm s" onclick="abreEscolhaRival()">Trocar</button></div>
    <div class="fcGrid" style="margin-top:6px"><div><small>Vitórias</small><b style="color:#3ddc84">${C.v}</b></div><div><small>Empates</small><b>${C.e}</b></div><div><small>Derrotas</small><b style="color:#ff8a8a">${C.d}</b></div><div><small>Gols</small><b>${C.gp}x${C.gc}</b></div></div>
    ${(C.jogos||[]).length?`<small class="mu" style="display:block;margin-top:6px">Últimos: ${C.jogos.slice(-5).reverse().map(j=>j.res+" ("+j.t+"ª)").join(" · ")}</small>`:''}</div>`;
}


// ===== JOGADORES LIVRES, PERMUTA E PATROCÍNIO (v58) =====
// LIVRES: no fim da temporada ficam ~30 jogadores sem clube (os seus com contrato vencido + veteranos e jovens sem espaço no mundo). Contratação SEM passe:
// você paga só as luvas (3 meses de salário) e o salário pedido (+10–25%). A lista é renovada todo ano; quem sobra volta ao mercado como veterano.
function geraLivres(saidosMeus){
  const lista=[];
  (saidosMeus||[]).forEach(j=>{const c={...j};["px","py","_slot","_role","tit","num"].forEach(k=>delete c[k]);c.origem="Seu ex-jogador";lista.push(c)});
  const eu=meuReal(),n=Math.max(0,30-lista.length);
  for(let i=0;i<n;i++){
    const idade=R()<.55?rnd(30,34):rnd(19,24);
    const alvo=Math.max(22,(eu?eu.forca:45)-rnd(14,0)-(idade>=30?0:6));
    const j=novoJog(pick(POS),alvo);j.idade=idade;
    if(idade>=29)j.pot=j.f;
    j.val=valorDe(j.f,j.idade,j.pot,j.mk);j.sal=salarioDe(j.f,j.mk);j.ct=0;j.origem=idade>=30?"Veterano sem clube":"Jovem dispensado";
    lista.push(j);
  }
  S.livres=lista.slice(0,32);
}
function salarioPedidoLivre(j){return Math.round(j.sal*1000*(1.10+((j.hum||40)%15)/100))}   // +10% a +24%
function contrataLivre(id){
  const eu=meuReal(),k=(S.livres||[]).findIndex(x=>x.id===id);if(k<0)return;
  const j=S.livres[k];
  if(elencoCheio(eu))return avisoCheio();
  const sal=salarioPedidoLivre(j),luvas=sal*3;
  if(eu.caixa<luvas)return aviso("Caixa insuficiente para as luvas ("+R$(luvas)+").");
  pergunta(`${j.nome} (${j.pos}, ${j.idade} anos, F${j.f}) está livre.\nSalário pedido: ${R$(sal)}/mês · Luvas: ${R$(luvas)} (3 meses).\nContrato (1 a 4 anos):`,2,a=>{
    const an=Math.max(1,Math.min(4,parseInt(a)||2));
    confirma(`Contratar ${j.nome} por ${an} ano(s)?\nLuvas: ${R$(luvas)}\nSalário: ${R$(sal)}/mês`,()=>{
      eu.caixa-=luvas;finDesp("Luvas (jogadores livres)",luvas);
      const novo={...j,ct:an,en:100,tit:false,gols:0,sal:sal/1000,raro:false};delete novo.origem;
      jogadorNovoNoClube(novo);eu.elenco.push(novo);S.livres.splice(k,1);auto(eu,true);save();render();toast(novo.nome+" assinou com você!");
    });
  });
}
function livresHTML(){
  const L=S.livres||[];
  if(!L.length)return `<div class="card"><small class="mu">Sem jogadores livres agora. A lista é renovada no fim de cada temporada, quando os contratos vencem.</small></div>`;
  const eu=meuReal();
  return `<div class="card"><h3>🆓 Jogadores livres (${L.length})</h3><small class="mu">Sem passe: você paga só as luvas (3 meses de salário). O salário é o que pesa todo mês.</small>
    <div class="tbL" style="max-height:380px;overflow:auto;margin-top:6px">${[...L].sort((a,b)=>b.f-a.f).map(j=>{const sal=salarioPedidoLivre(j);
      return `<div class="tbR"><span class="tbN"><span><b>${j.nome}</b> <small class="mu">${j.pos} · ${j.idade} anos · F${j.f}${j.pot>j.f?" → "+j.pot:""}</small><small>${j.origem||""} · ${R$(sal)}/mês · luvas ${R$(sal*3)}</small></span></span><button class="sm s" ${eu.caixa<sal*3?'disabled':''} onclick="contrataLivre('${j.id}')">Contratar</button></div>`}).join("")}</div></div>`;
}

// PERMUTA: oferece UM jogador seu (+ dinheiro opcional) por um jogador de outro clube da sua liga. O clube compara o valor total com o preço pedido.
function abrePermuta(clubeId,jid){
  const eu=meuReal(),cl=S.clubes[clubeId];if(!cl)return;
  const alvo=cl.elenco.find(x=>x.id===jid);if(!alvo)return;
  const pedido=precoPedido(cl,alvo);
  const meus=eu.elenco.filter(x=>!x.emprestado).sort((a,b)=>b.val-a.val);
  modal(`<div style="display:flex;justify-content:space-between;align-items:center"><b>🔄 Permuta por ${alvo.nome}</b><button class="sm" onclick="fechaDlg()">Fechar</button></div>
    <small class="mu" style="display:block;margin:4px 0">${cl.nome} pede ${R$(pedido)} (${alvo.pos}, F${alvo.f}). Escolha quem você oferece; o valor dele conta como pagamento.</small>
    <div class="tbL" style="max-height:300px;overflow:auto">${meus.map(m=>`<div class="tbR" onclick="propoePermuta(${clubeId},'${jid}','${m.id}')" style="cursor:pointer"><span class="tbN"><span><b>${m.nome}</b> <small class="mu">${m.pos} · ${m.idade} anos · F${m.f}</small><small>Valor ${R$(Math.round(m.val))}</small></span></span><span class="tag">Oferecer</span></div>`).join("")}</div>`);
}
function propoePermuta(clubeId,jid,meuId){
  fechaDlg();
  const eu=meuReal(),cl=S.clubes[clubeId],alvo=cl.elenco.find(x=>x.id===jid),meu=eu.elenco.find(x=>x.id===meuId);
  if(!alvo||!meu)return;
  const pedido=precoPedido(cl,alvo);
  pergunta(`Você oferece ${meu.nome} (${R$(Math.round(meu.val))}) por ${alvo.nome} (pedido ${R$(pedido)}).\nQuanto em dinheiro você soma? (em mil R$, 0 para só a troca)`,0,x=>{
    const extra=Math.max(0,(parseFloat(x)||0)*1000);if(extra>eu.caixa)return aviso("Caixa insuficiente.");
    const total=meu.val+extra,r=total/pedido;
    const ch=r>=1.15?1:r>=1?.8:r>=.9?.45:r>=.8?.15:.02;
    const adj=ch*(1-importancia(cl,alvo)*.2)*(meu.idade<=28?1:.85);
    if(R()>adj)return aviso(`${cl.nome} recusou a permuta.`+(r<1?`\nA oferta (${R$(Math.round(total))}) ficou abaixo do pedido.`:''));
    confirma(`${cl.nome} aceita!\n${meu.nome} ⇄ ${alvo.nome}${extra?`\nVocê paga mais ${R$(extra)}`:''}`,()=>{
      eu.caixa-=extra;if(extra)finDesp("Compra de jogadores",extra);
      cl.elenco=cl.elenco.filter(x=>x.id!==alvo.id);eu.elenco=eu.elenco.filter(x=>x.id!==meu.id);
      const cp={...meu};["px","py","_slot","_role","tit"].forEach(k=>delete cp[k]);cp.tit=false;cl.elenco.push(cp);
      const nv={...alvo,tit:false,en:100,ct:Math.max(2,alvo.ct||2)};["px","py","_slot","_role"].forEach(k=>delete nv[k]);
      jogadorNovoNoClube(nv);eu.elenco.push(nv);try{auto(eu,true)}catch(e){}save();render();toast("🔄 Permuta fechada: "+nv.nome+" chegou!");
    });
  });
}

// PATROCÍNIO: até 3 propostas por temporada (renovadas no fim do ano). Valor por ano depende da divisão, do país e da fama; cada contrato tem uma META
// com bônus. O dinheiro entra em parcelas mensais junto da cobrança do mês. Contratos de 1 a 3 anos; só um ativo por vez.
function geraPropostasPatrocinio(){
  const eu=meuReal();if(!eu)return;
  const econ=(typeof ECON_PAIS!=="undefined"&&ECON_PAIS[S.pais])||.6;
  const fama=nivelFama(eu.nome),div=S.div;
  const base=[1.0,.30,.10][div]*econ*1.4e6*(1+[0,.5,1.2][fama])*(0.8+eu.forca/100);
  const marcas=["Banco Aurora","Rede Atlântica","Cervejaria do Vale","Telecom Nova","Construtora Prime","Airways Sul","Supermercados Boa Compra","Energia Viva","Seguradora Global","Cartão Ouro"].sort(()=>R()-.5).slice(0,3);
  const nclubes=S.clubes.length;
  S.patroPropostas=marcas.map((m,i)=>{
    const anos=[1,2,3][i],fixo=Math.round(base*(.85+i*.1)/1e4)*1e4;
    const meta=i===0?{tipo:"semi",txt:"Sem meta (valor menor)",pos:0,bonus:0}:i===1?{tipo:"top",txt:"Terminar entre os "+Math.max(3,Math.round(nclubes*.35))+" primeiros",pos:Math.max(3,Math.round(nclubes*.35)),bonus:Math.round(fixo*.35/1e4)*1e4}:{tipo:"top",txt:"Terminar entre os "+Math.max(2,Math.round(nclubes*.2))+" primeiros",pos:Math.max(2,Math.round(nclubes*.2)),bonus:Math.round(fixo*.7/1e4)*1e4};
    return{marca:m,anos,fixo:i===0?Math.round(fixo*.85/1e4)*1e4:fixo,meta};
  });
}
function assinaPatrocinio(i){
  const P=(S.patroPropostas||[])[i];if(!P)return;
  if(S.patro&&S.patro.anosRest>0)return aviso("Você já tem patrocinador ("+S.patro.marca+") por mais "+S.patro.anosRest+" ano(s).");
  confirma(`Assinar com ${P.marca} por ${P.anos} ano(s)?\nValor: ${R$(P.fixo)}/ano (${R$(Math.round(P.fixo/10))} por mês).\nMeta: ${P.meta.txt}${P.meta.bonus?` → bônus ${R$(P.meta.bonus)}`:''}`,()=>{
    S.patro={...P,anosRest:P.anos,anoInicio:S.temp};S.patroPropostas=null;
    const eu=meuReal(),luvas=Math.round(P.fixo*.15);eu.caixa+=luvas;finRec("Patrocínio (assinatura)",luvas);   // 15% na assinatura
    save();render();toast("🤝 Patrocínio com "+P.marca+" assinado!");
  });
}
function patrocinioMes(){          // chamado em cobraMes(): 10 parcelas por ano, 85% do valor fixo
  const P=S.patro;if(!P||!(P.anosRest>0))return 0;
  const v=Math.round(P.fixo*.85/10);
  const eu=meuReal();eu.caixa+=v;finRec("Patrocínio (mensalidade)",v);return v;
}
function patrocinioFimTemporada(posFinal){
  const P=S.patro;
  if(P&&P.anosRest>0){
    if(P.meta&&P.meta.pos&&posFinal<=P.meta.pos){const eu=meuReal();eu.caixa+=P.meta.bonus;finRec("Patrocínio (bônus da meta)",P.meta.bonus);S._avisoPatro="🏅 Meta batida! "+P.marca+" pagou bônus de "+R$(P.meta.bonus)+"."}
    else if(P.meta&&P.meta.pos)S._avisoPatro="Meta do patrocinador não batida ("+P.meta.txt+"). Sem bônus.";
    P.anosRest--;if(P.anosRest<=0){S._avisoPatro=(S._avisoPatro||"")+"\nO contrato com "+P.marca+" terminou."}
  }
  geraPropostasPatrocinio();
}
function abaPatro(){
  const eu=meuReal();if(!S.patroPropostas&&(!S.patro||S.patro.anosRest<=0))geraPropostasPatrocinio();
  let h=topoAba("🤝","Patrocínio","Dinheiro extra com metas",[[S.patro&&S.patro.anosRest>0?S.patro.marca:"—","Atual"],[S.patro&&S.patro.anosRest>0?R$(S.patro.fixo)+"/ano":"—","Valor"],[S.patro&&S.patro.anosRest>0?S.patro.anosRest+" ano(s)":"—","Restam"]]);
  if(S.patro&&S.patro.anosRest>0){
    h+=`<div class="card"><div class="tag" style="margin-bottom:6px">Contrato em vigor</div><b>${S.patro.marca}</b><br><small class="mu">${R$(S.patro.fixo)}/ano · recebido em 10 parcelas mensais · meta: ${S.patro.meta.txt}${S.patro.meta.bonus?` (bônus ${R$(S.patro.meta.bonus)})`:''}</small></div>`;
  }else{
    h+=`<div class="card"><small class="mu">Propostas desta temporada. Quanto maior a meta, maior o bônus. 15% é pago na assinatura e o resto vem mês a mês.</small></div>`;
    (S.patroPropostas||[]).forEach((p,i)=>{h+=`<div class="card"><div style="display:flex;justify-content:space-between;align-items:center"><b>${p.marca}</b><span class="tag">${p.anos} ano(s)</span></div><div style="margin:6px 0"><b style="font-size:18px;color:#7dff9a">${R$(p.fixo)}</b><small class="mu"> por ano</small></div><small class="mu">Meta: ${p.meta.txt}${p.meta.bonus?` · bônus ${R$(p.meta.bonus)}`:''}</small><div style="margin-top:8px"><button class="sm s" onclick="assinaPatrocinio(${i})">Assinar</button></div></div>`});
  }
  return h;
}

function eu0Saidos(){                         // jogadores seus que vão ficar livres (contrato acaba nesta virada)
  const eu=meuReal();return eu.elenco.filter(j=>(j.ct||1)<=1&&!j.emprestado).map(j=>({...j}));
}

function resumoGrupoHTML(c){
  const mor=c.elenco.reduce((q,x)=>q+moralJ(x),0)/Math.max(1,c.elenco.length),ent=entrosMedio(c),f=fatorEntrosMoral(c);
  const ef=((f-1)*100);
  return `<div class="card" style="margin:8px 0"><div class="fcGrid"><div><small>Moral do grupo</small><b style="color:${corNivel(mor)}">${Math.round(mor)} · ${rotuloMoral(mor)}</b></div><div><small>Entrosamento do XI</small><b style="color:${corNivel(ent)}">${Math.round(ent)} · ${rotuloEntros(ent)}</b></div><div><small>Efeito no jogo</small><b style="color:${ef>=0?'#3ddc84':'#ff8a8a'}">${ef>=0?'+':''}${ef.toFixed(1).replace('.',',')}%</b></div></div>
  <small class="mu" style="display:block;margin-top:6px">Entrosamento sobe com jogos juntos e cai quando chega gente nova. Moral sobe com vitórias e minutos, e cai com derrotas e banco.</small></div>`;
}


// ===== RENOVAÇÃO AUTOMÁTICA DE CONTRATOS (v59) =====
// Caixa na tela de Elenco: "Renovar contratos automaticamente". Ao virar a temporada, quem está no último ano renova por 2 anos, com aumento
// de 4% a 12% no salário (menos para quem tem moral alta). Só renova quem VALE: força acima da média do elenco OU jovem (até 24 anos) com potencial.
// Quem está descontente (moral < 25), tem 34+ anos ou é reserva fraco sai de graça, como antes. O que foi renovado aparece no aviso do fim da temporada.
function opcRenovaAuto(){return !!(S.cfg&&S.cfg.renovaAuto)}
function setRenovaAuto(v){S.cfg=S.cfg||{};S.cfg.renovaAuto=!!v;save();render()}
function renovaAutomatico(){
  const eu=meuReal(),out={renov:[],ficou:[]};
  if(!opcRenovaAuto())return out;
  const medF=eu.elenco.reduce((q,j)=>q+j.f,0)/Math.max(1,eu.elenco.length);
  eu.elenco.forEach(j=>{
    if(j.emprestado||(j.ct||1)>1)return;                        // só quem vence nesta virada (ct ainda será decrementado)
    const vale=j.f>=medF-1||(j.idade<=24&&(j.pot||j.f)>=j.f+4);
    const ok=vale&&j.idade<34&&moralJ(j)>=25;
    if(!ok){out.ficou.push(j.nome);return}
    const aum=1+.04+Math.max(0,(60-moralJ(j)))/60*.08;           // 4% a 12%
    j.sal=Math.round(j.sal*aum*10)/10;j.ct=3;                    // 3 porque vencerContratos tira 1 → fica 2 anos
    j.renovAuto=S.temp;out.renov.push(j.nome);
  });
  return out;
}

function renovaAutoHTML(eu){
  const vencendo=eu.elenco.filter(j=>!j.emprestado&&(j.ct||1)<=1);
  return `<div class="card" style="margin:8px 0"><label class="ck" style="display:flex;gap:10px;align-items:center;font-size:14px"><input type="checkbox" ${opcRenovaAuto()?'checked':''} onchange="setRenovaAuto(this.checked)" style="width:20px;height:20px"> <span><b>🔁 Renovar contratos automaticamente</b><br><small class="mu">No fim da temporada, quem vence e vale a pena (bom nível ou jovem promissor, moral ok, menos de 34 anos) renova por 2 anos com aumento de 4% a 12%.</small></span></label>
    ${vencendo.length?`<small class="mu" style="display:block;margin-top:6px">Vencem este ano (${vencendo.length}): ${vencendo.slice(0,5).map(j=>j.nome.split(" ").slice(-1)[0]).join(", ")}${vencendo.length>5?"…":""}</small>`:''}</div>`;
}


// ===== PRÊMIOS INDIVIDUAIS · TODAS AS LIGAS (v59) =====
// Em CADA liga (as 60 do mundo, incluindo a sua) o jogo escolhe no fim da temporada: 🏆 Melhor jogador · 🧤 Melhor goleiro · 🌟 Revelação (até 21 anos)
// · ⚽ Artilheiro (já existente) · 📋 Time do Ano (11 jogadores). Cada premiado recebe um impulso de FORÇA em % (limitado pelo potencial, só até 28 anos):
// Melhor +1,5% · Goleiro +1,0% · Revelação +2,0% · Artilheiro +1,0% · Time do Ano +0,7% (teto de +4% por temporada). A partir dos 29 vira só prestígio.
const PREMIO_PCT={melhor:.015,goleiro:.010,revelacao:.020,art:.010,time:.007};
const PREMIO_NOME={melhor:"🏆 Melhor jogador",goleiro:"🧤 Melhor goleiro",revelacao:"🌟 Revelação",art:"⚽ Artilheiro",time:"📋 Time do Ano"};
const TIME_DO_ANO=[["GOL",1],["ZAG",2],["LD",1],["LE",1],["VOL",1],["MEI",2],["PE",1],["ATA",2]];                 // 11
function aplicaPremioForca(j,tipos){                                                                                // j é um jogador montado (objeto) — devolve os pontos ganhos
  if(!j||j.idade>28)return 0;
  const pct=Math.min(.04,tipos.reduce((q,t)=>q+(PREMIO_PCT[t]||0),0));
  const fr=(j.fReal!=null?j.fReal:j.f),ganho=Math.min(Math.max(0,(j.pot||fr)-fr),fr*pct);
  if(ganho<=0)return 0;
  j.fReal=fr+ganho;j.f=Math.max(15,Math.min(100,Math.round(j.fReal)));
  return ganho;
}
// índice de temporada de um jogador do MUNDO (slot): força + gols + campanha do clube + sorte determinística
function indiceMundo(t,pos,golsLiga,posClube,nClubes,rg){
  const f=t[1]/10,idade=t[0];
  const ofensivo=(pos==="ATA"||pos==="PE"||pos==="MEI")?1:(pos==="GOL"?0:.4);
  const camp=(nClubes-posClube)/Math.max(1,nClubes-1);                                  // 0 (último) .. 1 (campeão)
  return f*.5+golsLiga*2.2*ofensivo+camp*18+rg()*6;
}
function premiosMundoLiga(pais,div,rg){
  const L=S.ligas&&S.ligas[chaveLiga(pais,div)];if(!L)return null;
  const tab=tabelaDe(pais,div);if(!tab||tab.length<4)return null;
  const posDe={};tab.forEach((x,i)=>posDe[x.nome]=i+1);
  const cands=[];
  tab.forEach(x=>{
    const ch=chaveFixa(pais,x.nome);if(!ch)return;
    const kc=chaveClube(pais,ch.div,ch.idx);
    if(!S.mundo)S.mundo={};
    if(!S.mundo[kc])S.mundo[kc]=criaEstadoMundo(kc,picoClube(pais,ch.div,ch.idx));
    const est=S.mundo[kc];
    est.c.forEach((t,slot)=>{
      const pos=POS22[slot],g=(L.gols&&L.gols[x.nome+"#"+slot])||0,as=(L.ass&&L.ass[x.nome+"#"+slot])||0;
      cands.push({kc,slot,pos,idade:t[0],f:t[1]/10,pot:t[2],g,clube:x.nome,idx:indiceMundo(t,pos,g+as*.6,posDe[x.nome],tab.length,rg)});
    });
  });
  if(!cands.length)return null;
  const topo=(arr,n)=>[...arr].sort((a,b)=>b.idx-a.idx).slice(0,n);
  const out={melhor:topo(cands.filter(c=>c.pos!=="GOL"||true),1)[0],
    goleiro:topo(cands.filter(c=>c.pos==="GOL"),1)[0],
    revelacao:topo(cands.filter(c=>c.idade<=21),1)[0],
    time:[]};
  const usados=new Set();
  TIME_DO_ANO.forEach(([pos,n])=>{topo(cands.filter(c=>c.pos===pos&&!usados.has(c.kc+"|"+c.slot)),n).forEach(c=>{usados.add(c.kc+"|"+c.slot);out.time.push(c)})});
  return out;
}
// aplica o impulso no estado compacto do mundo e devolve os nomes (para o histórico)
function aplicaPremiosMundo(pais,div,P){
  if(!P)return[];
  const porSlot={};                                                                      // "kc|slot" → [tipos]
  const add=(c,tipo)=>{if(!c)return;const k=c.kc+"|"+c.slot;(porSlot[k]=porSlot[k]||{c,t:[]}).t.push(tipo)};
  add(P.melhor,"melhor");add(P.goleiro,"goleiro");add(P.revelacao,"revelacao");P.time.forEach(c=>add(c,"time"));
  const hist=[];
  Object.values(porSlot).forEach(({c,t})=>{
    const est=S.mundo[c.kc],tt=est.c[c.slot];if(!tt)return;
    const fake={f:Math.round(tt[1]/10),fReal:tt[1]/10,pot:tt[2],idade:tt[0]};
    const g=aplicaPremioForca(fake,t);
    if(g>0){const r=tt.slice();r[1]=Math.round(fake.fReal*10);est.c[c.slot]=r}
    let nome="?";try{const ch=chaveFixa(pais,c.clube);nome=nomeDoSlot(c.kc,pais,ch.div,ch.idx,c.slot)}catch(e){}
    hist.push({nome,clube:c.clube,pos:c.pos,tipos:t,ganho:Math.round(g*10)/10,idade:c.idade});
  });
  S._mem={};                                                                             // clubes montados serão remontados já com o impulso
  return hist;
}
function fechaPremiosIndividuais(){
  // MUNDO (todas as ligas, menos a sua): decide e aplica
  const resumo={};let totalPremiados=0;
  Object.keys(LIGAS).forEach(pais=>{
    if(pais===S.pais)return;
    const rg=rngClube("premios|"+pais+"|"+S.temp);
    LIGAS[pais].forEach((_,div)=>{
      try{const P=premiosMundoLiga(pais,div,rg);if(!P)return;
        const h=aplicaPremiosMundo(pais,div,P);totalPremiados+=h.length;
        resumo[pais+"|"+div]={melhor:h.find(x=>x.tipos.includes("melhor")),goleiro:h.find(x=>x.tipos.includes("goleiro")),revelacao:h.find(x=>x.tipos.includes("revelacao")),time:h.filter(x=>x.tipos.includes("time")).length};
      }catch(e){}
    });
  });
  // SUA LIGA: usa elencos reais (notas, gols, minutos)
  const meus=premiosSuaLiga();
  if(meus)resumo[S.pais+"|"+S.div]=meus.resumo;
  if(!S.premiosHist)S.premiosHist=[];
  S.premiosHist.push({temp:S.temp,ligas:resumo});
  if(S.premiosHist.length>6)S.premiosHist=S.premiosHist.slice(-6);
  return{resumo,meus,totalPremiados};
}
function premiosSuaLiga(){
  const todos=S.clubes.flatMap(c=>c.elenco.map(j=>({j,c})));
  const posDe={};tabela().forEach((x,i)=>posDe[x.id]=i+1);
  const n=S.clubes.length;
  const ind=o=>{const j=o.j,nm=j.mediaNota!=null?j.mediaNota:6;
    const ofensivo=(j.pos==="ATA"||j.pos==="PE"||j.pos==="MEI")?1:(j.pos==="GOL"?0:.4);
    return j.f*.45+nm*4+(j.golsLiga||0)*1.8*ofensivo+((n-posDe[o.c.id])/Math.max(1,n-1))*14+(j.selRodada||0)*1.2};
  const top=(arr,k)=>[...arr].sort((a,b)=>ind(b)-ind(a)).slice(0,k);
  const melhor=top(todos,1)[0],goleiro=top(todos.filter(o=>o.j.pos==="GOL"),1)[0],revel=top(todos.filter(o=>o.j.idade<=21),1)[0];
  const time=[];const usado=new Set();
  TIME_DO_ANO.forEach(([pos,k])=>top(todos.filter(o=>o.j.pos===pos&&!usado.has(o.j.id)),k).forEach(o=>{usado.add(o.j.id);time.push(o)}));
  const art=[...todos].filter(o=>(o.j.golsLiga||0)>0).sort((a,b)=>(b.j.golsLiga||0)-(a.j.golsLiga||0))[0];
  const por={};const add=(o,t)=>{if(!o)return;(por[o.j.id]=por[o.j.id]||{o,t:[]}).t.push(t)};
  add(melhor,"melhor");add(goleiro,"goleiro");add(revel,"revelacao");add(art,"art");time.forEach(o=>add(o,"time"));
  const meusPremiados=[];
  Object.values(por).forEach(({o,t})=>{
    const antes=o.j.f,g=aplicaPremioForca(o.j,t);
    if(g>0){o.j.val=valorDe(o.j.f,o.j.idade,o.j.pot,o.j.mk);o.j.sal=salarioDe(o.j.f,o.j.mk);try{o.c.forca=forcaMedia(o.c)}catch(e){}}
    o.j.premios=(o.j.premios||[]);t.forEach(x=>o.j.premios.push({t:S.temp,p:x}));
    if(o.c.id===S.meu)meusPremiados.push({nome:o.j.nome,pos:o.j.pos,tipos:t,ganho:Math.round(g*10)/10,de:antes,para:o.j.f});
    if(t.includes("melhor")||t.includes("goleiro")||t.includes("revelacao")){try{o.j.hum=Math.min(99,(o.j.hum||50)+8);if(o.c.id===S.meu)o.j.mor=Math.min(100,moralJ(o.j)+10)}catch(e){}}
  });
  const f=(o,t)=>o?{nome:o.j.nome,clube:o.c.nome,pos:o.j.pos,tipos:[t]}:null;
  return{meusPremiados,resumo:{melhor:f(melhor,"melhor"),goleiro:f(goleiro,"goleiro"),revelacao:f(revel,"revelacao"),art:f(art,"art"),time:time.length},timeDoAno:time.map(o=>({nome:o.j.nome,pos:o.j.pos,clube:o.c.nome,meu:o.c.id===S.meu}))};
}

function premiosIndividuaisHTML(){
  const H=S.premiosHist||[];
  if(!H.length)return `<div class="card"><div class="tag" style="margin-bottom:6px">🏅 Prêmios individuais</div><small class="mu">Os prêmios individuais saem no fim de cada temporada, em todas as ligas do mundo: melhor jogador, melhor goleiro, revelação, artilheiro e Time do Ano. Premiados com até 28 anos ganham um impulso de força.</small></div>`;
  const ultimo=H[H.length-1],temps=H.map(x=>x.temp).reverse();
  const sel=S.premTemp!=null&&H.find(x=>x.temp===S.premTemp)?H.find(x=>x.temp===S.premTemp):ultimo;
  const chaves=Object.keys(sel.ligas);
  const paisSel=S.premPais&&chaves.some(k=>k.startsWith(S.premPais+"|"))?S.premPais:S.pais;
  const paises=[...new Set(chaves.map(k=>k.split("|")[0]))];
  const linhas=chaves.filter(k=>k.startsWith(paisSel+"|")).sort().map(k=>{
    const [pa,dv]=k.split("|"),L=sel.ligas[k],f=x=>x?`<b>${x.nome}</b> <small class="mu">(${x.clube||''}${x.pos?' · '+x.pos:''})</small>`:'<small class="mu">—</small>';
    return `<div style="padding:8px 0;border-top:1px solid var(--bd)"><b>${LIGANOME[pa][+dv]}</b>
      <div style="font-size:12px;margin-top:4px">🏆 ${f(L.melhor)}<br>🧤 ${f(L.goleiro)}<br>🌟 ${f(L.revelacao)}${L.art?`<br>⚽ ${f(L.art)}`:''}${L.time?`<br>📋 Time do Ano: ${typeof L.time==="number"?L.time+" jogadores":""}`:''}</div></div>`}).join("");
  return `<div class="card"><div class="tag" style="margin-bottom:6px">🏅 Prêmios individuais · ${sel.temp}ª temporada</div>
    <div style="display:flex;gap:8px;margin-bottom:6px"><select style="padding:8px;border-radius:8px;background:var(--card2);color:var(--tx);border:1px solid var(--bd)" onchange="S.premPais=this.value;render()">${paises.map(p=>`<option ${p===paisSel?'selected':''}>${p}</option>`).join("")}</select>
    <select style="padding:8px;border-radius:8px;background:var(--card2);color:var(--tx);border:1px solid var(--bd)" onchange="S.premTemp=+this.value;render()">${temps.map(t=>`<option value="${t}" ${t===sel.temp?'selected':''}>${t}ª</option>`).join("")}</select></div>
    ${linhas||'<small class="mu">Sem dados para este país.</small>'}
    <small class="mu" style="display:block;margin-top:6px">Impulso de força (até 28 anos, limitado pelo potencial): melhor +1,5% · revelação +2% · goleiro +1% · artilheiro +1% · Time do Ano +0,7%.</small></div>`;
}


// ===== MENU ☰ NO TOPO E OBJETIVOS DA DIRETORIA (v59) =====
const MENU_GRUPOS=[
 ["🏠 Clube",[["home","🏠","Início"],["elenco","👥","Elenco"],["tat","📋","Tática"],["base","🌱","Base"],["est","🏛","Estádio"]]],
 ["💱 Jogadores",[["mer","💱","Mercado"],["tecn","👔","Técnicos"],["tech","📜","Histórico de técnicos"]]],
 ["💰 Finanças",[["fin","📊","Finanças"],["banco","🏦","Banco"],["patro","🤝","Patrocínio"],["prem","💰","Prêmios e fama"]]],
 ["🏆 Competições",[["tab","🏆","Tabela"],["arti","🥇","Artilheiros"],["cal","📅","Calendário"],["cn","🏆","Copa nacional"],["cl","⭐","Champions"],["el","🟧","L. Europa"],["lb","🌎","Libertadores"],["sa","🟩","Sul-Americana"],["cmundo","🗺️","Copas do mundo"],["mund","🌍","Mundial"]]],
 ["📈 Histórico",[["rank","🏅","Ranking"],["ed","✏️","Editor"]]]
];
function abreMenu(){
  const eu=S.clubes[S.meu];
  modal(`<div style="display:flex;justify-content:space-between;align-items:center"><b>☰ Menu</b><button class="sm" onclick="fechaDlg()">Fechar</button></div>
   ${MENU_GRUPOS.map(([g,itens])=>`<div class="tag" style="margin:10px 0 6px">${g}</div><div class="menuG">${itens.map(([k,i,n])=>`<button onclick="fechaDlg();ir('${k}')"><span>${i}</span>${n}</button>`).join("")}</div>`).join("")}
   <div class="tag" style="margin:10px 0 6px">⚙️ Sistema</div><div class="menuG"><button onclick="fechaDlg();ir('db')"><span>📦</span>Base de dados</button><button onclick="fechaDlg();ir('clubes')"><span>🛡</span>Clubes</button><button onclick="fechaDlg();salvarAgora()"><span>💾</span>Salvar</button><button onclick="fechaDlg();ir('hum')"><span>👥</span>Técnicos</button><button onclick="fechaDlg();ir('onl')"><span>🌐</span>Online</button><button onclick="fechaDlg();ir('sel')"><span>🏳️</span>Seleções</button><button onclick="fechaDlg();irTitulo()"><span>🏠</span>Tela inicial</button><button onclick="abreEscolhaRival()"><span>🔥</span>Rival</button></div>`);
}
// OBJETIVOS DA DIRETORIA: no começo da temporada a diretoria define 1 meta principal conforme o prestígio e a força do clube na liga.
// Bateu a meta no fim do ano: confiança da diretoria +15, torcida +8 e um bônus em dinheiro; ficou muito abaixo: confiança −15.
function geraObjetivo(){
  const eu=meuReal();if(!eu)return;
  const n=S.clubes.length,esperado=[...S.clubes].sort((a,b)=>b.forca-a.forca).findIndex(c=>c.id===eu.id)+1;
  let alvo=Math.max(1,Math.round(esperado-1)),txt;
  if(esperado<=2){alvo=1;txt="Ser campeão da liga"}
  else if(esperado<=Math.round(n*.3)){alvo=Math.max(3,Math.round(n*.2));txt="Terminar entre os "+alvo+" primeiros (vaga continental)"}
  else if(esperado<=Math.round(n*.6)){alvo=Math.round(n*.5);txt="Terminar na metade de cima da tabela (até "+alvo+"º)"}
  else {alvo=n-4;txt="Evitar o rebaixamento (ficar acima do "+(n-3)+"º)"}
  S.objetivo={temp:S.temp,alvo,txt,bonus:Math.round(((6e6*(ECON_PAIS[S.pais]||.6))*[1,.22,.06][S.div||0])*.18/1e4)*1e4,resultado:null};
}
function fechaObjetivo(posFinal){
  const O=S.objetivo;if(!O||O.temp!==S.temp||O.resultado)return null;
  const eu=meuReal();
  if(posFinal<=O.alvo){
    O.resultado="ok";S.dir=Math.min(100,(S.dir==null?70:S.dir)+15);S.tor=Math.min(100,(S.tor==null?70:S.tor)+8);
    if(O.bonus){eu.caixa+=O.bonus;finRec("Bônus de objetivo da diretoria",O.bonus)}
    return "🎯 Objetivo cumprido: "+O.txt+".\\nDiretoria +15 de confiança, torcida +8"+(O.bonus?" e bônus de "+R$(O.bonus):"")+".";
  }
  const longe=posFinal-O.alvo;
  O.resultado=longe>=4?"mal":"quase";
  if(longe>=4){S.dir=Math.max(5,(S.dir==null?70:S.dir)-15);S.tor=Math.max(5,(S.tor==null?70:S.tor)-8)}
  return "🎯 Objetivo "+(longe>=4?"não cumprido":"quase cumprido")+": "+O.txt+" (você ficou em "+posFinal+"º)."+(longe>=4?"\\nDiretoria −15 de confiança, torcida −8.":"");
}
function objetivoHTML(){
  const O=S.objetivo;if(!O||O.temp!==S.temp)return "";
  const t=tabela(),pos=t.findIndex(c=>c.id===S.meu)+1,ok=pos<=O.alvo;
  return `<div class="card" style="margin:8px 0;border-left:3px solid ${ok?'#3ddc84':'#f5c542'}"><div class="tag" style="margin-bottom:4px">🎯 Objetivo da diretoria</div><div style="font-size:13px"><b>${O.txt}</b></div><small class="mu">Hoje: ${pos}º · meta: até ${O.alvo}º${O.bonus?` · bônus ${R$(O.bonus)}`:''}</small></div>`;
}


// ===== TIME DA RODADA (v59) =====
// A cada rodada da SUA liga os 11 melhores (pelo índice nota + gols) entram no Time da Rodada. Quem mais aparece ganha "seleções da rodada"
// e isso conta no Time do Ano. Guardado só a última rodada, para o save não crescer.
function registraTimeDaRodada(){
  try{
    const L=S.live;if(!L||!L.jogos)return;
    const todos=[];
    S.clubes.forEach(c=>c.elenco.forEach(j=>{
      const noJogo=L.jogos.some(g=>S.clubes[g.a]===c||S.clubes[g.b]===c);if(!noJogo)return;
      const jogou=j.tit||j.jogou_ultimo;if(!jogou)return;
      const gols=L.jogos.reduce((q,g)=>q+g.ev.filter(e=>e.t==="g"&&e.jid===j.id).length,0);
      // nota do meu time vem do S.pos; dos outros usa força relativa + gols + sorteio
      let nota=6+(j.f-(c.forca||50))/18+(R()-.5)*1.2+gols*1.1;
      if(S.pos&&c.id===S.meu){const lado=S.pos.a===S.meu?S.pos.A:S.pos.B;const o=lado&&lado.lista&&lado.lista.find(x=>x.id===j.id);if(o)nota=o.nota}
      todos.push({j,c,idx:nota+gols*.4});
    }));
    const time=[];const usados=new Set();
    TIME_DO_ANO.forEach(([pos,n])=>{todos.filter(o=>o.j.pos===pos&&!usados.has(o.j.id)).sort((a,b)=>b.idx-a.idx).slice(0,n).forEach(o=>{usados.add(o.j.id);time.push(o)})});
    time.forEach(o=>{o.j.selRodada=(o.j.selRodada||0)+1});
    S.timeRodada={rodada:S.rodada+1,temp:S.temp,jogadores:time.map(o=>({id:o.j.id,nome:o.j.nome,pos:o.j.pos,clube:o.c.nome,nota:Math.round(o.idx*10)/10,meu:o.c.id===S.meu}))};
  }catch(e){}
}
function timeRodadaHTML(){
  const T=S.timeRodada;if(!T||!T.jogadores||!T.jogadores.length)return "";
  const meus=T.jogadores.filter(x=>x.meu).length;
  return `<div class="card" style="margin:8px 0"><div class="tag" style="margin-bottom:6px">⭐ Time da ${T.rodada}ª rodada${meus?` · ${meus} seu${meus>1?'s':''}`:''}</div>
    <div style="display:flex;flex-wrap:wrap;gap:4px">${T.jogadores.map(x=>`<span class="tag" style="${x.meu?'background:#14532d;color:#fff':''}">${x.pos} ${x.nome.split(" ").slice(-1)[0]} <small>${x.nota.toFixed(1)}</small></span>`).join("")}</div></div>`;
}


// ===== ASSISTÊNCIAS (v60) =====
// ~68% dos gols de jogada têm assistente (nunca o próprio autor). Peso por posição: meia e ponta criam mais; zagueiro e goleiro quase nunca.
// Habilidades de criação aumentam a chance. Pênalti e falta direta NÃO têm assistente; no escanteio o cobrador é o assistente.
const PESO_ASSIST={GOL:.05,ZAG:.35,LD:1.4,LE:1.4,VOL:1.1,MEI:3.2,PE:3.0,ATA:1.8};
function sorteiaAssistente(tit,autor){
  if(R()>=.68)return null;
  const cand=tit.filter(x=>x.id!==autor.id&&!x.expulso);if(!cand.length)return null;
  const w=cand.map(x=>{
    const h=x.hab||[];let p=(PESO_ASSIST[x.pos]||1)*(0.6+x.f/70);
    if(h.includes("Passe"))p*=1.45;if(h.includes("Criação"))p*=1.5;if(h.includes("Cruzamento"))p*=1.35;if(h.includes("Drible"))p*=1.15;if(h.includes("Visão"))p*=1.4;
    return p});
  let tot=w.reduce((q,x)=>q+x,0),r=R()*tot,k=0;while(k<w.length-1&&r>w[k]){r-=w[k];k++}
  return cand[k];
}
function registraAssistencia(jogo,evento,ass,emCopa){
  if(!ass)return;
  ass.assist=(ass.assist||0)+1;if(!emCopa)ass.assistLiga=(ass.assistLiga||0)+1;
  evento.ass=ass.nome;evento.assId=ass.id;
}


// ===== ELENCO EM TABELA DENSA (v60) =====
// Alterna entre "Cartões" (o modo de sempre) e "Tabela" (estilo Brasfoot): uma linha por jogador, colunas fixas, rolagem lateral no celular.
// Colunas: Nº · Pos · Nome · Id · Força · Pot · Ener · Contr. · Salário/mês · Valor · J · G · A · Nota · Moral · Entr. · situação.
// Toque no cabeçalho para ordenar por aquela coluna; toque na linha para abrir a ficha.
const COLUNAS_DENSA=[
 ["num","Nº",34,j=>numDe(j)||"—",j=>j.num||99],
 ["pos","Pos",42,j=>j.pos,j=>POS_ORD(j.pos)],
 ["nome","Nome",150,j=>j.nome,j=>j.nome],
 ["idade","Id",34,j=>j.idade,j=>j.idade],
 ["f","F",34,j=>j.f,j=>-j.f],
 ["pot","Pot",38,j=>j.pot||j.f,j=>-(j.pot||j.f)],
 ["en","En%",42,j=>Math.round(j.en==null?100:j.en),j=>(j.en==null?100:j.en)],
 ["ct","Ct",32,j=>j.emprestado?"emp.":(j.ct||1)+"a",j=>j.ct||1],
 ["sal","Sal/mês",70,j=>R$(Math.round(j.sal*1000)),j=>-j.sal],
 ["val","Valor",70,j=>R$(Math.round(j.val)),j=>-j.val],
 ["jg","J",30,j=>(j.hn||[]).filter(x=>x[8]===S.temp).length,j=>-((j.hn||[]).filter(x=>x[8]===S.temp).length)],
 ["gl","G",30,j=>j.golsLiga||0,j=>-(j.golsLiga||0)],
 ["as","A",30,j=>j.assistLiga||0,j=>-(j.assistLiga||0)],
 ["nota","Nota",42,j=>j.mediaNota!=null?j.mediaNota.toFixed(1).replace(".",","):"—",j=>-(j.mediaNota||0)],
 ["mor","😊",36,j=>Math.round(moralJ(j)),j=>-moralJ(j)],
 ["ent","🤝",36,j=>Math.round(entrosJ(j)),j=>-entrosJ(j)]
];
function setElModo(m){S.elModo=m;save();render()}
function ordenaDensa(k){S.elDensaOrd=(S.elDensaOrd===k?"-"+k:k);render()}
function elencoDensaHTML(eu){
  const ord=S.elDensaOrd||"pos",inv=ord[0]==="-",chave=inv?ord.slice(1):ord;
  const col=COLUNAS_DENSA.find(c=>c[0]===chave)||COLUNAS_DENSA[1];
  const lista=[...eu.elenco].sort((a,b)=>{const x=col[4](a),y=col[4](b);const r=(typeof x==="string")?x.localeCompare(y):x-y;return (inv?-r:r)||b.f-a.f});
  const larg=COLUNAS_DENSA.reduce((q,c)=>q+c[2],0)+COLUNAS_DENSA.length*4+30;
  const posCor={GOL:'#f5c542',ZAG:'#4aa3ff',LD:'#4aa3ff',LE:'#4aa3ff',VOL:'#3ddc84',MEI:'#3ddc84',PE:'#ff7a59',ATA:'#ff5d5d'};
  const gt=COLUNAS_DENSA.map(c=>c[2]+"px").join(" ")+" 28px";
  const cab=`<div class="dnH" style="grid-template-columns:${gt};min-width:${larg}px">${COLUNAS_DENSA.map(c=>`<span onclick="ordenaDensa('${c[0]}')" style="cursor:pointer;${c[0]==='nome'?'text-align:left':''}${chave===c[0]?';color:var(--ac);font-weight:800':''}">${c[1]}${chave===c[0]?(inv?' ▼':' ▲'):''}</span>`).join("")}<span></span></div>`;
  const linhas=lista.map(j=>{
    const apto=aptoParaJogar(j),sit=j.conv?fl(j.conv.p):j.lesao>0?`🤕${j.lesao}`:j.suspenso>0?'⛔':'';
    const cel=COLUNAS_DENSA.map(c=>{
      let v=c[3](j),st="";
      if(c[0]==="pos")return `<span><i style="display:inline-block;padding:1px 4px;border-radius:5px;background:${posCor[j.pos]||'#888'};color:#111;font-weight:800;font-size:10px">${v}</i></span>`;
      if(c[0]==="nome")return `<span style="text-align:left;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${j.tit?'<b style="color:var(--ac)">●</b> ':''}${v}${j.emprestado?' 🔁':''}</span>`;
      if(c[0]==="en")st=`color:${corEn(v)}`;if(c[0]==="mor")st=`color:${corNivel(v)}`;if(c[0]==="ent")st=`color:${corNivel(v)}`;
      if(c[0]==="ct"&&!j.emprestado&&(j.ct||1)<=1)st="color:#ff8a8a;font-weight:800";
      if(c[0]==="f")st="font-weight:800;color:#ffd45e";
      if(c[0]==="nota"&&j.mediaNota!=null)st=`color:${j.mediaNota>=7.5?'#34d98b':j.mediaNota>=6?'#ffd45e':'#ff8a8a'}`;
      return `<span style="${st}">${v}</span>`;
    }).join("");
    return `<div class="dnL ${j.tit?'tit':''} ${apto?'':'ina'}" style="grid-template-columns:${gt};min-width:${larg}px" onclick="abreFichaJogador('${j.id}')">${cel}<span>${sit}</span></div>`;
  }).join("");
  const tot=eu.elenco.length,folha=eu.elenco.reduce((q,j)=>q+j.sal*1000,0),vl=eu.elenco.reduce((q,j)=>q+j.val,0);
  return `<div class="dnWrap"><div style="overflow-x:auto;-webkit-overflow-scrolling:touch">${cab}${linhas}</div></div>
   <div class="dnRod"><span>${tot} jogadores</span><span>Folha ${R$(Math.round(folha))}/mês</span><span>Valor do elenco ${R$(Math.round(vl))}</span></div>
   <div class="tag" style="margin:6px 2px;opacity:.8">Deslize para os lados para ver todas as colunas · toque no título para ordenar · ● = titular</div>`;
}


// ===== ARTILHARIA E ASSISTÊNCIAS DE TODAS AS LIGAS — FORMATO COMPACTO (v61) =====
// Em memória: L.gols["Clube#slot"] = n e L.ass["Clube#slot"] = n (como sempre, o resto do código não muda).
// No SAVE: cada liga grava dois textos de 1 caractere por jogador (22 por clube, na ordem de L.nomes), em base 36 (0–35).
// 59 ligas × (440+440) caracteres ≈ 51 KB — menos que os 273 KB do formato antigo, e agora com as assistências de TODOS os jogadores.
const B36="0123456789abcdefghijklmnopqrstuvwxyz";
function mapaParaTexto(mapa,nomes){
  let t="";
  nomes.forEach(n=>{for(let s=0;s<22;s++){const v=(mapa&&mapa[n+"#"+s])||0;t+=B36[Math.min(35,v)]}});
  return t;
}
function textoParaMapa(txt,nomes){
  const m={};if(!txt)return m;
  nomes.forEach((n,i)=>{for(let s=0;s<22;s++){const c=txt.charCodeAt(i*22+s);if(isNaN(c))continue;
    const v=c>=97?c-87:c-48;if(v>0)m[n+"#"+s]=v}});
  return m;
}
function ligasParaSave(ligas){
  const nl={};
  Object.keys(ligas||{}).forEach(k=>{
    const L=ligas[k];
    nl[k]={k:L.k,R:L.R,nomes:L.nomes,tab:L.tab,gt:mapaParaTexto(L.gols,L.nomes),at:mapaParaTexto(L.ass,L.nomes),ultimos:L.ultimos,temp:L.temp};
  });
  return nl;
}
function ligasDoSave(ligas){                    // aceita o formato novo (gt/at) e o antigo (gols como mapa)
  Object.keys(ligas||{}).forEach(k=>{
    const L=ligas[k];if(!L)return;
    if(typeof L.gt==="string"){L.gols=textoParaMapa(L.gt,L.nomes);L.ass=textoParaMapa(L.at,L.nomes);delete L.gt;delete L.at}
    if(!L.gols)L.gols={};if(!L.ass)L.ass={};
  });
}

function pesosDeAssist(pais,div,nome){
  const ch=chaveFixa(pais,nome);if(!ch)return POS22.map(p=>PESO_ASSIST[p]);
  const k=chaveClube(pais,ch.div,ch.idx),est=S.mundo&&S.mundo[k];
  return POS22.map((pos,i)=>{const f=est?est.c[i][1]/10:50;return(PESO_ASSIST[pos]||1)*(0.6+f/70)});
}


function abaArtilheiros(){
  const A=(S.artHistMundo||[]).slice(),AS=(S.astHist||[]).slice();
  // inclui a SUA liga (artHist) para a consulta ficar completa
  (S.artHist||[]).forEach(x=>A.push({temp:x.temp,pais:x.pais||S.pais,div:x.div!=null?x.div:S.div,nome:x.nome,clube:x.clube,gols:x.gols,meu:true}));
  const temps=[...new Set([...A.map(x=>x.temp),...AS.map(x=>x.temp)])].sort((a,b)=>b-a);
  let h=topoAba("🥇","Artilheiros e assistências","Líderes de todas as ligas do mundo",[[temps.length,"Temporadas"],[A.length,"Artilheiros"],[AS.length,"Garçons"]]);
  if(!temps.length)return h+`<div class="card"><small class="mu">Os líderes de cada liga são registrados no fim da temporada. Jogue a primeira temporada para ver a lista.</small></div>`;
  const sel=S.artTemp!=null&&temps.includes(S.artTemp)?S.artTemp:temps[0];
  const paises=[...new Set([...A,...AS].filter(x=>x.temp===sel).map(x=>x.pais))].sort();
  const paisSel=S.artPais&&paises.includes(S.artPais)?S.artPais:(paises.includes(S.pais)?S.pais:paises[0]);
  const sty="padding:9px;border-radius:10px;background:var(--card2);color:var(--tx);border:1px solid var(--bd);font-size:13px";
  h+=`<div class="card"><div style="display:flex;gap:8px;flex-wrap:wrap"><select style="${sty}" onchange="S.artTemp=+this.value;render()">${temps.map(t=>`<option value="${t}" ${t===sel?'selected':''}>Temporada ${t}</option>`).join("")}</select>
    <select style="${sty}" onchange="S.artPais=this.value;render()">${paises.map(p=>`<option ${p===paisSel?'selected':''}>${p}</option>`).join("")}</select></div></div>`;
  const divs=[0,1,2].filter(d=>A.concat(AS).some(x=>x.temp===sel&&x.pais===paisSel&&(x.div||0)===d));
  divs.forEach(d=>{
    const ar=A.find(x=>x.temp===sel&&x.pais===paisSel&&(x.div||0)===d),as=AS.find(x=>x.temp===sel&&x.pais===paisSel&&(x.div||0)===d);
    h+=`<div class="card"><div class="tag" style="margin-bottom:6px">${LIGANOME[paisSel]?LIGANOME[paisSel][d]:'Liga'}</div>
      <div class="upL"><div><b>⚽ ${ar?ar.nome:'—'}</b><small>${ar?ar.clube:''}</small></div><b>${ar?ar.gols+' gols':''}</b></div>
      <div class="upL"><div><b>🅰️ ${as?as.nome:'—'}</b><small>${as?as.clube:''}</small></div><b>${as?as.a+' assist.':''}</b></div></div>`;
  });
  // artilheiros de todos os tempos (soma por nome+clube) nas ligas guardadas
  const tot={};A.forEach(x=>{const k=x.nome+"|"+x.clube;tot[k]=tot[k]||{nome:x.nome,clube:x.clube,pais:x.pais,t:0,g:0};tot[k].t++;tot[k].g+=x.gols});
  const rank=Object.values(tot).sort((a,b)=>b.t-a.t||b.g-a.g).slice(0,6);
  if(rank.length&&rank[0].t>1)h+=`<div class="card"><div class="tag" style="margin-bottom:6px">👑 Mais artilharias (todas as ligas)</div>${rank.filter(x=>x.t>1).map(x=>`<div class="upL"><div><b>${x.nome}</b><small>${x.clube} · ${x.pais}</small></div><b>${x.t}× · ${x.g} gols</b></div>`).join("")}</div>`;
  return h;
}


// ===== LESÃO AO VIVO — VAGAS DA PARTIDA (v62) =====
function vagasLesaoAbertas(){
  const L=S.live;if(!L||!L.vagasLesao)return[];
  const eu=meuReal();
  return L.vagasLesao.map(id=>eu.elenco.find(x=>x.id===id)).filter(x=>x&&!x.tit&&x.lesao>0);
}
function abreVagaLesao(jogador){
  const L=S.live;if(!L)return;
  if(!L.vagasLesao)L.vagasLesao=[];
  if(!L.vagasLesao.includes(jogador.id))L.vagasLesao.push(jogador.id);
}
function fechaVagaLesao(id){const L=S.live;if(L&&L.vagasLesao)L.vagasLesao=L.vagasLesao.filter(x=>x!==id)}
function fantasmaVagaHTML(){                       // marcador no campo: onde o lesionado jogava
  const vs=vagasLesaoAbertas();if(!vs.length)return"";
  return vs.map(v=>`<div class="pl" style="left:${v.px==null?50:v.px}%;top:${v.py==null?50:v.py}%;opacity:.95;pointer-events:none"><div style="width:44px;height:44px;border-radius:50%;border:2px dashed #ffb86b;display:flex;align-items:center;justify-content:center;background:#7a3b0066;font-size:22px">🤕</div><span style="color:#ffb86b;font-weight:800">${nomeCurto(v)}</span><small style="color:#ffd9a8">VAGA ${v.pos}</small></div>`).join("");
}


// ===== JOGADOR PEDE PARA SAIR (v63) =====
// A cada rodada o jogo mede a "pressão" de cada jogador do SEU time: moral baixa, reserva sem jogar (a partir do 3º jogo), salário abaixo do justo
// para o nível dele, clube na parte de baixo da tabela. Titular reclama menos (×0,6) e os mais jovens têm paciência.
// Com pressão ≥ 55 por 2 rodadas seguidas ele PEDE PARA SAIR. Você escolhe: ✅ Liberar (clube vende pelo valor, sem rescisão) ·
// 🤝 Convencer (promete minutos e/ou aumento: chance de ficar) · 🚫 Ignorar (moral −8 e ele volta a reclamar em 6 rodadas).
function pressaoSaida(j,eu,posRel){
  const moral=moralJ(j),sem=j.semJogar||0,salJusto=Math.max(1,salarioDe(j.f,j.mk)),sal=j.sal/salJusto;
  let p=0;
  if(moral<55)p+=(55-moral)*1.2;
  p+=Math.min(45,Math.max(0,sem-2)*6);
  if(sal<.85)p+=(0.85-sal)*70;
  if(posRel>.7)p+=12;
  if(j.idade<=22)p-=12;else if(j.idade<=25)p-=5;
  if(j.tit)p*=.6;
  return Math.max(0,p);
}
function verificaPedidosSaida(){
  try{
    const eu=meuReal();if(!eu)return;
    const t=tabela(),posRel=(t.findIndex(c=>c.id===S.meu))/Math.max(1,t.length-1);
    if(!S.pedidosSaida)S.pedidosSaida=[];
    S.pedidosSaida=S.pedidosSaida.filter(x=>eu.elenco.find(j=>j.id===x.jid));
    eu.elenco.forEach(j=>{
      if(j.emprestado)return;
      j.semJogar=j.jogou_ultimo?0:(j.semJogar||0)+1;
      if(j.promessaMin&&(j.semJogar||0)>=3){j.mor=Math.max(15,moralJ(j)-10);j.promessaMin=null;j.pedidoEspera=0}   // promessa quebrada
      if(j.pedidoEspera>0){j.pedidoEspera--;return}
      const p=pressaoSaida(j,eu,posRel);
      j.pressSaida=p>=55?(j.pressSaida||0)+1:0;
      if(j.pressSaida>=2&&!S.pedidosSaida.find(x=>x.jid===j.id)&&S.pedidosSaida.length<3){
        const motivo=moralJ(j)<40?"Está descontente com o ambiente do grupo":(j.semJogar||0)>=5?"Quer jogar mais: está há "+(j.semJogar||0)+" jogos sem atuar":(j.sal/Math.max(1,salarioDe(j.f,j.mk))<.85)?"Acha que ganha abaixo do que merece":"Quer mudar de ares";
        S.pedidosSaida.push({jid:j.id,nome:j.nome,motivo,temp:S.temp});
        j.pressSaida=0;
      }
    });
    if(S.pedidosSaida.length)S._avisoSaida=true;
  }catch(e){}
}
function pedidosSaidaHTML(){
  const P=(S.pedidosSaida||[]);if(!P.length)return "";
  const eu=meuReal();
  return `<div class="card" style="margin:8px 0;border-left:3px solid #ff7a59"><div class="tag" style="margin-bottom:6px">🚪 Pedidos para sair (${P.length})</div>${P.map((p,i)=>{
    const j=eu.elenco.find(x=>x.id===p.jid);if(!j)return"";
    return `<div style="padding:8px 0;border-top:1px solid var(--bd)"><b>${j.nome}</b> <small class="mu">${j.pos} · ${j.idade} anos · F${j.f} · moral ${Math.round(moralJ(j))}</small><div style="font-size:12px;margin:3px 0;color:#ffb86b">${p.motivo}</div>
      <div class="row" style="gap:6px"><button class="sm" onclick="liberaSaida(${i})">✅ Liberar</button><button class="sm s" onclick="convenceSaida(${i})">🤝 Convencer</button><button class="sm s" onclick="ignoraSaida(${i})">🚫 Ignorar</button></div></div>`}).join("")}</div>`;
}
function liberaSaida(i){
  const eu=meuReal(),p=(S.pedidosSaida||[])[i];if(!p)return;const j=eu.elenco.find(x=>x.id===p.jid);if(!j)return;
  if(eu.elenco.length<=MIN_ELENCO)return aviso("Elenco mínimo: "+MIN_ELENCO+" jogadores. Contrate alguém antes de liberar.");
  const v=Math.round(j.val*rnd(80,100)/100);
  confirma(`Liberar ${j.nome}?\nUm clube paga ${R$(v)} (sem rescisão: ele quer sair).`,()=>{
    eu.caixa+=v;finRec("Venda de jogadores",v);eu.elenco=eu.elenco.filter(x=>x.id!==j.id);
    S.pedidosSaida.splice(i,1);
    eu.elenco.forEach(x=>{x.mor=Math.max(15,moralJ(x)-(x.f>=j.f?1:0))});               // o grupo sente a saída de um titular
    try{auto(eu,true)}catch(e){}save();render();toast("🚪 "+j.nome+" saiu por "+R$(v));
  });
}
function convenceSaida(i){
  const eu=meuReal(),p=(S.pedidosSaida||[])[i];if(!p)return;const j=eu.elenco.find(x=>x.id===p.jid);if(!j)return;
  const aum=Math.round(j.sal*1000*.15);
  modal(`<b>🤝 Convencer ${j.nome}</b><div class="mu" style="font-size:12px;margin:6px 0">${p.motivo}. O que você oferece?</div>
    <button class="big" style="margin:4px 0" onclick="fechaDlg();tentaConvencer(${i},'minutos')">⚽ Prometer mais minutos</button>
    <button class="big" style="margin:4px 0" onclick="fechaDlg();tentaConvencer(${i},'aumento')">💰 Aumento de 15% (+${R$(aum)}/mês)</button>
    <button class="big" style="margin:4px 0" onclick="fechaDlg();tentaConvencer(${i},'ambos')">⚽💰 Minutos e aumento</button>
    <button class="s" style="width:100%;margin-top:6px" onclick="fechaDlg()">Cancelar</button>`);
}
function tentaConvencer(i,oferta){
  const eu=meuReal(),p=(S.pedidosSaida||[])[i];if(!p)return;const j=eu.elenco.find(x=>x.id===p.jid);if(!j)return;
  let ch=.25;
  if(oferta==="minutos"||oferta==="ambos")ch+=(j.semJogar||0)>=3?.35:.12;
  if(oferta==="aumento"||oferta==="ambos")ch+=(j.sal/Math.max(1,salarioDe(j.f,j.mk))<.85)?.35:.15;
  ch+=Math.max(0,(moralJ(j)-30)/200);ch=Math.min(.9,ch);
  if(R()<ch){
    if(oferta==="aumento"||oferta==="ambos"){j.sal=Math.round(j.sal*1.15*10)/10}
    j.mor=Math.min(100,moralJ(j)+15);j.semJogar=0;j.pedidoEspera=12;j.promessaMin=(oferta==="minutos"||oferta==="ambos")?S.temp:null;
    S.pedidosSaida.splice(i,1);save();render();aviso(`${j.nome} aceitou ficar!`+(oferta!=="aumento"?"\nVocê prometeu mais minutos: escale-o nos próximos jogos ou ele volta a reclamar.":""));
  }else{
    j.mor=Math.max(15,moralJ(j)-4);save();render();aviso(`${j.nome} não se convenceu.\nVocê ainda pode liberá-lo ou ignorar o pedido.`);
  }
}
function ignoraSaida(i){
  const eu=meuReal(),p=(S.pedidosSaida||[])[i];if(!p)return;const j=eu.elenco.find(x=>x.id===p.jid);if(!j)return;
  j.mor=Math.max(15,moralJ(j)-8);j.pedidoEspera=6;S.pedidosSaida.splice(i,1);save();render();
}


// ===== CLIMA E GRAMADO (v63) =====
// CLIMA (por jogo, sorteado conforme o MÊS da data e o hemisfério do país do mandante): ☀️ sol · ☁️ nublado · 🌧 chuva · ⛈ tempestade · 🔥 calor · ❄️ frio.
//   🌧 chuva −8% nos chutes certos e +10% de cartões · ⛈ tempestade −14% e +15% de cartões · 🔥 calor: o time cansa 18% mais rápido · ❄️ frio: lesões +12%.
// GRAMADO (0–100, por estádio; o do SEU estádio vem de S.gramado e melhora com obras): ≥85 ótimo · 60–84 bom · 35–59 ruim · <35 péssimo.
//   Chuva derruba o gramado do jogo em 15 pontos. Gramado ruim: lesões +20%; péssimo: +40% e −5% nos chutes certos. Time do gramado ótimo joga melhor em casa.
const CLIMAS={
  sol:{ic:"☀️",n:"Sol",noGol:1,cart:1,cansa:1,les:1,grama:0},
  nublado:{ic:"☁️",n:"Nublado",noGol:1,cart:1,cansa:1,les:1,grama:0},
  chuva:{ic:"🌧",n:"Chuva",noGol:.92,cart:1.10,cansa:1,les:1.05,grama:-15},
  tempestade:{ic:"⛈",n:"Tempestade",noGol:.86,cart:1.15,cansa:1.05,les:1.10,grama:-25},
  calor:{ic:"🔥",n:"Calor forte",noGol:.98,cart:1,cansa:1.18,les:1,grama:-3},
  frio:{ic:"❄️",n:"Frio",noGol:1,cart:1,cansa:.97,les:1.12,grama:0}
};
const PAISES_SUL=["Brasil","Argentina","Chile","Uruguai"],PAISES_UMIDOS=["Inglaterra","Escócia","Holanda","Bélgica","Alemanha"];
function sorteiaClima(pais,mes){
  if(pais==="Colômbia"){const r=R();return r<.45?"sol":r<.75?"nublado":r<.95?"chuva":"tempestade"}
  const sul=PAISES_SUL.includes(pais);
  const inverno=sul?(mes>=5&&mes<=8):(mes===11||mes<=2),verao=sul?(mes===11||mes<=2):(mes>=5&&mes<=8);
  const chuva=PAISES_UMIDOS.includes(pais)?.28:.18;
  const p={sol:.35+(verao?.12:0)-(inverno?.08:0),nublado:.25,chuva,tempestade:.05,calor:verao?.18:0,frio:inverno?.20:0};
  let tot=0;Object.keys(p).forEach(k=>{p[k]=Math.max(0,p[k]);tot+=p[k]});
  let r=R()*tot;for(const k of Object.keys(p)){r-=p[k];if(r<=0)return k}
  return "sol";
}
function gramadoDe(clube){                          // 0–100: clubes da IA derivam do nível do estádio e da fama (determinístico)
  if(clube.id===S.meu||clube===meuReal()){if(S.gramado==null)S.gramado=62;return S.gramado}
  let h=0;const n=clube.nome;for(let i=0;i<n.length;i++)h=(h*31+n.charCodeAt(i))>>>0;
  const base=45+(h%30)+(clube.forca>55?8:clube.forca>45?3:-3);
  return Math.max(25,Math.min(95,base));
}
function rotuloGramado(g){return g>=85?"Ótimo":g>=60?"Bom":g>=35?"Ruim":"Péssimo"}
function fatorGramadoNoGol(g){return g<35?.95:g<60?.98:1}
function fatorGramadoLesao(g){return g<35?1.4:g<60?1.2:1}
function preparaClimaJogo(jogo,mandante){            // chamado no criaLive: guarda o clima e o gramado efetivo no jogo
  let mes=0;try{mes=(S.agenda&&S.agenda[S.dia]&&S.agenda[S.dia].mes!=null)?S.agenda[S.dia].mes:new Date().getMonth()}catch(e){}
  let pais=S.pais;try{if(mandante.pais)pais=mandante.pais}catch(e){}
  const clima=sorteiaClima(pais,mes),C=CLIMAS[clima];
  const gBase=gramadoDe(mandante),gEf=Math.max(5,Math.min(100,gBase+C.grama));
  jogo.clima=clima;jogo.gramado=Math.round(gEf);jogo.gramBase=Math.round(gBase);
}
function previsaoClima(){                                // previsão para o próximo jogo em casa: a mais provável do mês (só informativo; o real é sorteado no jogo)
  try{const mes=(S.agenda&&S.agenda[S.dia]&&S.agenda[S.dia].mes!=null)?S.agenda[S.dia].mes:0;
    const cont={};for(let i=0;i<60;i++){const c=sorteiaClima(S.pais,mes);cont[c]=(cont[c]||0)+1}
    const top=Object.entries(cont).sort((a,b)=>b[1]-a[1]).slice(0,2);
    return top.map(([k,v])=>`${CLIMAS[k].ic} ${CLIMAS[k].n} (${Math.round(v*100/60)}%)`).join(" · ");
  }catch(e){return ""}
}
function climaJogoHTML(j){
  if(!j||!j.clima)return "";
  const C=CLIMAS[j.clima];
  return `<span class="tag" title="Clima e gramado">${C.ic} ${C.n} · 🌱 ${rotuloGramado(j.gramado)} (${j.gramado})</span>`;
}
function gramadoMelhora(){                           // obra de gramado: +12 pontos, custo cresce com o nível do gramado
  const eu=meuReal();if(S.gramado==null)S.gramado=62;
  if(S.gramado>=95)return aviso("O gramado já está no máximo.");
  const custo=Math.round(900000*(1+(S.gramado-40)/40));
  if(eu.caixa<custo)return aviso("Caixa insuficiente ("+R$(custo)+").");
  confirma(`Reformar o gramado?\n+12 pontos (de ${Math.round(S.gramado)} para ${Math.min(95,Math.round(S.gramado)+12)}).\nCusto: ${R$(custo)}`,()=>{eu.caixa-=custo;finDesp("Estádio (gramado)",custo);S.gramado=Math.min(95,S.gramado+12);save();render()});
}
function desgasteGramado(){                          // o gramado do SEU estádio estraga com o uso e com a chuva; recupera um pouco com o tempo
  if(S.gramado==null)S.gramado=62;
  S.gramado=Math.max(20,S.gramado-1.2);
}
function gramadoRecupera(){if(S.gramado==null)S.gramado=62;S.gramado=Math.min(S.gramadoMax||95,S.gramado+.5)}

function icoEstadio(sz){sz=sz||13;
  return `<svg width="${sz}" height="${sz}" viewBox="0 0 24 24" style="vertical-align:-2px;flex:none"><ellipse cx="12" cy="9" rx="10" ry="4.2" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M2 9v6c0 2.4 4.5 4.4 10 4.4s10-2 10-4.4V9" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M7 11.2v6.2M12 12v7M17 11.2v6.2" stroke="currentColor" stroke-width="1.2" opacity=".8"/></svg>`;
}

// ===== MARCAÇÃO (v48) =====
// Leve:  poucos cartões (×0,6), dá espaço ao adversário (+22% de chances dele), não cansa.
// Normal: equilíbrio.
// Forte: muitos cartões (×1,8), fecha o adversário (−20% de chances dele) e rouba a posse (+10%), mas cansa mais o time.
const MARCACAO={Leve:{cartao:.6,espaco:1.22,pressao:.93,cansa:.85},Normal:{cartao:1,espaco:1,pressao:1,cansa:1},Forte:{cartao:1.8,espaco:.8,pressao:1.10,cansa:1.3}};
const marcDe=(meu,T)=>MARCACAO[(meu?(T||TTc(S.clubes[S.meu])).marc:"Normal")]||MARCACAO.Normal;

function tick(){
  S._soTick=true;
  const L=S.live;if(!L||L.pausado||L.pausaTec||L.janela||L.janelaVer||document.getElementById("modalsub")||document.getElementById("dlg"))return;
  // fim do 1º tempo: apito, tempo para e a escalação abre (só para quem tem treinador humano)
  if(L.min===45&&!L.intervaloFeito){L.intervaloFeito=true;L.segundoTempo=true;if(!L.pulando)somIntervalo();S._soTick=false;
    const jm=L.jogos.find(g=>souTecReal(g.a)||souTecReal(g.b));
    if(jm&&!L.pulando){abreJanelaEscala('intervalo');return}
  }
  L.min++;tickOutras();
  if(L.min%10===0)S.clubes.forEach((cc,ci)=>{const jm=L.jogos.find(g=>g.a===S.meu||g.b===S.meu),fcl=(jm&&jm.clima&&(ci===jm.a||ci===jm.b))?(CLIMAS[jm.clima].cansa):1;const fc=(ehHc(cc)?marcDe(true,TTc(cc)).cansa:1)*fcl;cc.elenco.forEach(j=>{if(j.tit){const res=(j.hab||[]).includes("Resistência")?.8:1;j.en=Math.max(10,(j.en==null?100:j.en)-2*poupaEnergia(j)*res*fc)}})});
  L.jogos.forEach(j=>{
    const A=S.clubes[j.a],B=S.clubes[j.b];
    const mA=ehHc(A),mB=ehHc(B),TA=TTc(A),TB=TTc(B);
    const fa=forcaTime(A,mA?TA.tatica:"Equilibrada")+3,fb=forcaTime(B,mB?TB.tatica:"Equilibrada");
    const k=t=>({"Ofensiva":1.2,"Defensiva":.8,"Contra-ataque":.9,"Equilibrada":1})[t]||1;
    // ENERGIA média dos titulares em campo (cansaço reduz o domínio) e jogadores a menos (expulsões)
    const enM=c=>{const t=c.elenco.filter(x=>x.tit&&!x.expulso);return t.length?t.reduce((q,x)=>q+(x.en==null?100:x.en),0)/t.length/100:1};
    const nA=A.elenco.filter(x=>x.tit&&!x.expulso).length||11,nB=B.elenco.filter(x=>x.tit&&!x.expulso).length||11;
    const fAe=fa*(.6+.4*enM(A))*Math.pow(Math.min(11,nA)/11,1.6),fBe=fb*(.6+.4*enM(B))*Math.pow(Math.min(11,nB)/11,1.6);
    const mom=1-.04*(j.ga-j.gb);                      // quem perde pressiona um pouco mais
    const pa=Math.max(.18,Math.min(.82,.5+(fAe*mom-fBe/mom)/90*.7));          // v54: diferença de força pesa 70% (a posse agora rende mais chutes, então o favorito não pode passar do ponto)
    const ef=(m,T)=>m?{att:k(T.tatica)*(T.conc==="Pelas pontas"?1.03:1),def:({"Leve":1,"Normal":1.06,"Forte":1.12})[T.marc],card:({"Leve":1,"Normal":1.4,"Forte":2})[T.marc]}:{att:1,def:1,card:1};
    const eA=ef(mA,TA),eB=ef(mB,TB);
    const mcA=marcDe(mA,TA),mcB=marcDe(mB,TB);
    const tA=pa*eA.att*mcA.pressao,tB=(1-pa)*eB.att*mcB.pressao;
    const dono=R()<tA/(tA+tB)?"a":"b";
    // POSSE REAL = minutos com a bola / minutos jogados (a bola muda de dono a cada minuto conforme o domínio)
    if(j.st.pm==null)j.st.pm=Math.round((j.st.pa||50)/100*Math.max(0,L.min-1));
    if(dono==="a")j.st.pm++;
    j.st.pa=Math.round(j.st.pm/Math.max(1,L.min)*100);
    // quem domina a bola cria mais chances; quem não tem a bola quase não finaliza (contra-ataque ocasional)
    const posA=j.st.pm/Math.max(1,L.min),posD=dono==="a"?posA:1-posA;
    const chance=Math.max(.06,Math.min(.40,(.23+.15*(posD-.5)*2)*(dono==="a"?mcB.espaco:mcA.espaco)));     // v54: quem tem a bola finaliza MUITO mais (70% de posse ≈ 14–15 chutes contra 5–6)   // 0,188: já desconta pênalti/escanteio/falta; × espaço dado pela marcação de quem defende
    const rf=R();
    let lanceEspecial=false;
    // PÊNALTI: ~0,27 por jogo; acontece no lugar de uma finalização e favorece quem tem mais a bola
    if(rf<.003*(1+.4*(posD-.5)*2)&&!L.penReq&&!S.expulsaoPendente){
      const sAp=dono==="a",meuJogo=(j.a===S.meu||j.b===S.meu),souCobrador=meuJogo&&((sAp&&j.a===S.meu)||(!sAp&&j.b===S.meu));
      if(souCobrador&&!L.pulando){L.penReq={jogoIdx:L.jogos.indexOf(j),sA:sAp}}      // escolher o cobrador: a janela abre no fim do tick
      else{
        if(meuJogo&&!L.pulando)somPenalti();                                          // pênalti CONTRA você: o árbitro marca (seu áudio)
        resolvePenalti(j,sAp,null);                                                   // time da IA, jogo contra o meu ou jogo pulado: resolve na hora
      }
      lanceEspecial=true;                                                             // o pênalti ocupa o lugar da finalização deste minuto
    }
    if(!lanceEspecial&&rf>=.003*(1+.4*(posD-.5)*2)&&rf<.003*(1+.4*(posD-.5)*2)+.055*(1+.5*(posD-.5)*2)){   // ESCANTEIO (~5 por jogo): ocupa o lugar de uma finalização
      const sAe=dono==="a";resolveEscanteio(j,sAe,(sAe&&j.a===S.meu)||(!sAe&&j.b===S.meu));lanceEspecial=true;
    }
    const fIni=.003*(1+.4*(posD-.5)*2)+.055*(1+.5*(posD-.5)*2);
    if(!lanceEspecial&&rf>=fIni&&rf<fIni+.012*(1+.5*(posD-.5)*2)){   // FALTA DIRETA (~1,1 por jogo): ocupa o lugar de uma finalização
      const sAf=dono==="a";resolveFalta(j,sAf,(sAf&&j.a===S.meu)||(!sAf&&j.b===S.meu));lanceEspecial=true;
    }
    const finalizaDono=!lanceEspecial&&rf<chance,contraAtaque=!lanceEspecial&&!finalizaDono&&rf<chance+.03;   // 3% extra: o time sem a bola escapa em contra-ataque
    if(finalizaDono||contraAtaque){ // finalização
      const sA=contraAtaque?dono!=="a":dono==="a";
      const F=sA?A:B,D=sA?B:A;
      const ataque=forcaTime(F,"Equilibrada")+bonusHabTime(F,["criar","gol"]),defesa=forcaTime(D,"Equilibrada")+bonusHabTime(D,["defesa","goleiro"]);
      sA?j.st.fa++:j.st.fb++;
      const posF=sA?posA:1-posA;                                                  // posse acumulada de QUEM finaliza
      const cEf=CLIMAS[j.clima||'sol'],fNG=cEf.noGol*fatorGramadoNoGol(j.gramado==null?70:j.gramado);
      const noGol=R()<(.47+.24*(posF-.5))*fNG;                          // v54: posse → chutes certos · v63: clima e gramado
      if(noGol)sA?j.st.ga_++:j.st.gb_++;
      const bonus=((sA?mA:mB)&&(sA?TA:TB).tatica==="Contra-ataque"&&(sA?pa<.5:pa>.5))?.07:0;
      if(noGol&&R()<.27+bonus+(ataque-defesa)/200*.7+.12*(posF-.5)){                // v54: e mais chance de virar gol
        const at=F.elenco.filter(x=>x.tit&&x.pos!=="GOL");
        const w=at.map(x=>{let p=x.pos==="ATA"?5:x.pos==="MEI"||x.pos==="PE"?2.5:x.pos==="VOL"?1:.4;const h=x.hab||[];const ef=eficHab(x);if(h.includes("Finalização"))p*=1+0.55*ef;if(h.includes("Cabeceio"))p*=1+0.25*ef;if(h.includes("Chute longo")&&x.pos!=="ATA")p*=1+0.2*ef;p*=1+bonusEstrela(x)*0.04;return p});
        let s_=w.reduce((x,y)=>x+y,0),r=R()*s_,q=0;while(q<w.length-1&&r>w[q]){r-=w[q];q++}
        const art=at[q];art.gols++;if(!(S.live&&S.live.emCL))art.golsLiga=(art.golsLiga||0)+1;
        sA?j.ga++:j.gb++;
        if(j.a===S.meu||j.b===S.meu){const meuGol=(sA&&j.a===S.meu)||(!sA&&j.b===S.meu);if(meuGol){somGol();golFx('GOOOL!')}else somGolContra();
          narraGol({meu:meuGol,contra:!meuGol,autor:art.nome.split(' ').slice(-1)[0],time:F.nome,golsA:sA?j.ga:j.gb,golsB:sA?j.gb:j.ga,min:L.min})}
        j.ev.push({m:L.min,t:"g",lado:sA?"a":"b",n:art.nome.split(" ").slice(-1)[0]+" "+art.nome.split(" ")[0][0]+"."});
        j.ev[j.ev.length-1].n=art.nome;j.ev[j.ev.length-1].jid=art.id;
        try{registraAssistencia(j,j.ev[j.ev.length-1],sorteiaAssistente(F.elenco.filter(x=>x.tit&&!x.expulso),art),!!(S.live&&S.live.emCL))}catch(e){}
      }
    }
    if(R()<.12)(dono==="a"?j.st.db++:j.st.da++);
    if(R()<.2)(dono==="a"?j.st.pea++:j.st.peb++);
    // CARTÕES: cada time tem a sua taxa (0,0113 por minuto × a marcação dele) — a marcação Leve realmente protege, a Forte custa cartões
    const fCt=(CLIMAS[j.clima||'sol']||CLIMAS.sol).cart;
    const pcA=.0113*mcA.cartao*fCt,pcB=.0113*mcB.cartao*fCt,rc=R();
    if(rc<pcA+pcB){
      const sA=rc<pcA,F=sA?A:B;const emCampo=F.elenco.filter(x=>x.tit&&!x.expulso);if(emCampo.length<=7)return;
      const c=pick(emCampo);
      c.amarelos=c.amarelos||0;
      const direto=R()<.03;
      const segundo=!direto&&c.amarelos>=1;
      const verm=direto||segundo;
      if(!verm){c.amarelos++;c.ac=(c.ac||0)+1;c._acNovo=true}
      if(verm){c.vm=(c.vm||0)+1;c._vmNovo=true}
      j.ev.push({m:L.min,t:"c",lado:sA?"a":"b",n:c.nome,jid:c.id,verm:verm,segAm:segundo});
      if(verm){
        c.expulso=true;c.tit=false;c.em_campo=false;           // sai de campo: o time joga com um a menos
        const idxClube=sA?j.a:j.b;
        if(souTecReal(idxClube)){S.expulsaoPendente=true;if(!L.pulando)somExpulsao()}   // só o SEU time: abre a janela e apita
        /* times da IA seguem com 10: o expulso já saiu (sem apito) */
      }
    }
    // LESÃO AO VIVO: cada time pode perder um jogador por minuto; só o SEU time para o jogo e abre a janela de ajuste
    [[A,j.a],[B,j.b]].forEach(([cl,idx])=>{
      if(cl.elenco.filter(x=>x.tit&&!x.expulso).length<=8)return;
      const les=sorteiaLesaoAoVivo(j,cl,ehHc(cl));
      if(les&&souTecReal(idx)){S.lesaoPendente=les.id;if(!L.pulando){try{tocaAudio('verm',.5)||0}catch(e){}}}
      else if(les&&!souTecReal(idx)){ /* IA: o reserva entra sozinho */ try{iaCompletaTime(cl)}catch(e){} }
    });
  });
  if(L.min>=90){
    if(L.penReq){try{const jg=L.jogos[L.penReq.jogoIdx];if(jg)resolvePenalti(jg,L.penReq.sA,S.cobPen)}catch(e){}L.penReq=null}   // pênalti no último minuto: cobra com o cobrador da Tática
    S._soTick=false;fimLive();return}
  if(L.penReq&&!L.janela&&!L.pulando){S._soTick=false;abreJanelaPenalti();return}
  if(S.expulsaoPendente||S.lesaoPendente){const eraLes=!S.expulsaoPendente&&!!S.lesaoPendente;const idLes=S.lesaoPendente;S.expulsaoPendente=false;S.lesaoPendente=null;S._soTick=false;if(!L.pulando){if(eraLes)S._lesPend=idLes;abreJanelaEscala(eraLes?'lesao':'vermelho');return}try{iaCompletaTime(S.clubes[S.meu])}catch(e){}}
  renderLive();
  S._soTick=false;
}
let timer=null;
function playLive(){clearInterval(timer);timer=setInterval(tick,S.live.vel===1?500:S.live.vel===2?200:60)}
function fimLive(){
  clearInterval(timer);try{speechSynthesis.cancel()}catch(e){}somApitoFinal();
  if(S.live&&S.live.emCL){const ai=S.clAoVivo||{};return ai.mund?fimLiveMD():ai.copa?fimLiveCN():ai.lib?fimLiveLB():ai.eu?fimLiveEL():ai.sa?fimLiveSA():fimLiveCL()}
  const L=S.live,eu=S.clubes[S.meu];let meu=null;
  try{avancaMundo(S.rodada+1,S.fixt.length)}catch(e){}
  guardaResultados();
  L.jogos.forEach(j=>{
    const a=S.clubes[j.a],b=S.clubes[j.b];
    aplica(a,b,{ga:j.ga,gb:j.gb});
    if(j.a===S.meu||j.b===S.meu){S.pos=posJogo(j);S.pos.rodadaTxt=(S.rodada+1)+'ª rodada'}
    if(j.a===S.meu||j.b===S.meu)meu={a,b,r:{ga:j.ga,gb:j.gb,ea:j.ev.filter(e=>e.t==="g"&&e.lado==="a").map(e=>e.n),eb:j.ev.filter(e=>e.t==="g"&&e.lado==="b").map(e=>e.n)},casa:j.a===S.meu};
  });
  if(meu){meu.fin=meu.casa&&S.pos?recebeBilheteria('liga',1):0}
  S.clubes.forEach((c,ci)=>{
    if(ci===S.meu){registraNotasDoPos(c,S.pos&&S.pos.a===S.meu);energiaPosJogo(c,false);try{const mg=S.pos.a===S.meu?S.pos.ga:S.pos.gb,ag=S.pos.a===S.meu?S.pos.gb:S.pos.ga;premiaJogo('liga',mg>ag?1:mg===ag?0:-1)}catch(e){}return}
    c.elenco.forEach(j=>{j.en=j.tit?Math.max(60,(j.en==null?100:j.en)-Math.round(rnd(10,18))):100;j.jogou=j.jogou||!!j.tit;if(j.lesao>0&&!j.lesAoVivo)j.lesao--;j.lesAoVivo=false;j.lesionadoJogo=false});
  });
  eu.elenco.forEach(j=>{if(j.lesao>0)j.tit=false});
  try{garante11(eu,true)}catch(e){}                                           // v56: completa o time já no fim do jogo
  try{evoluiIARodada()}catch(e){}                                              // v57: os rivais também evoluem a cada rodada
  if(meu)meu.fin-=cobraParcelas();else cobraParcelas();if(meu&&eu.tec){const vit=meu.casa?meu.r.ga>meu.r.gb:meu.r.gb>meu.r.ga;eu.tec.hab=Math.min(95,eu.tec.hab+(vit?.4:meu.r.ga===meu.r.gb?.1:-.1))}if(meu){const vv=meu.casa?meu.r.ga-meu.r.gb:meu.r.gb-meu.r.ga;registraForma(vv>0?'V':vv===0?'E':'D')}if(meu){const q=meu.casa?[meu.r.ga,meu.r.gb]:[meu.r.gb,meu.r.ga];agendaRegistra(q[0]+' x '+q[1],(meu.casa?meu.b:meu.a).nome,meu.casa)}S.rodada++;agendaAvanca();S.extras=0;confianca();try{if(S.fixt&&S.rodada>=Math.floor(S.fixt.length/2)&&S._tecMeioTemp!==S.temp){S._tecMeioTemp=S.temp;S._janelaMeio=true}}catch(e){}S.ultimo=meu;try{registraTimeDaRodada()}catch(e){}limpaPartidaEstado();S.live=null;S.aba=S.pos?"pos":"home";
  if(R()<.4)geraMercado();
  geraPropostas();
  save();render();
  if(S._avisoMes){const m=S._avisoMes;S._avisoMes=null;setTimeout(()=>aviso(m),350)}
  else if(S._avisoSaida){S._avisoSaida=false;setTimeout(()=>aviso('🚪 Um jogador pediu para sair.\nResolva na Início ou no Mercado: liberar, convencer ou ignorar.'),400)}
  if(S._janelaMeio){S._janelaMeio=false;setTimeout(()=>{try{janelaTecnicos("meio");save();render()}catch(e){}},700)}      // v49: janela de técnicos do meio da temporada
}
const ESTADIOS=["Parque Aurora","Arena do Vale","Estádio Litoral","Mineirão Novo","Arena Serrana","Estádio Central","Campo do Porto","Arena Planalto","Estádio da Ponte","Arena Cerrado"];
function abaLive(){
  const L=S.live;if(!L)return"";
  const j=L.jogos[L.ver],A=S.clubes[j.a],B=S.clubes[j.b],st=j.st,pa=Math.round(st.pa);
  const nj=id=>{for(const c of [A,B]){const x=c.elenco.find(z=>z.id===id);if(x)return x.nome}return""};
  const cor2=x=>x.cor2&&x.cor2!=='#ffffff'?x.cor2:x.cor;
  const ult=j.ev.slice(-1)[0];
  const icL=e=>e.t==="g"?(e.pen?'⚽🎯':e.esc?'⚽🚩':e.falta?'⚽🧱':'⚽'):e.t==="s"?'🔁':e.t==="l"?'🤕':e.t==="p"?(e.res==="defesa"?'🧤':e.res==="trave"?'💥':e.res==="barreira"?'🧱':'🚫'):e.verm?'🟥':'🟨';
  // lance de cada gol/cartão do jogo em destaque (como o "Hereda 10' - 1º" da referência)
  const destaque=j.ev.filter(e=>e.t==='g'||e.t==='c').slice(-3).reverse();
  let h=`<div class="barraTempo">${L.pausado?'<span class="tag" style="align-self:center;background:#7a5a00;color:#ffe08a">⏸ Tempo parado</span>':''}<button class="s sm" onclick="S.live.pausado=!S.live.pausado;renderLive()">${L.pausado?'▶ Continuar':'⏸ Pausar'}</button>
  <button class="s sm" onclick="mudaVel()">⏩ ${L.vel}x</button>
  <button class="sm" onclick="pulaFim()">⏭ Fim</button></div>
  <div class="bfHd">
   <div class="bfTop"><b>${tituloAoVivo()}</b><span class="bfTmp">${L.min}' · ${L.min<=45?'1º':'2º'} tempo</span><span class="bfBar"><i style="width:${L.min/90*100}%"></i></span></div>
   <div class="bfCorpo">
    <div class="bfEst"><span>${icoEstadio(13)}</span><b>${j.est}</b><small>${j.pub.toLocaleString("pt-BR")} pagantes</small>${climaJogoHTML(j)?`<small>${climaJogoHTML(j)}</small>`:''}</div>
    <div class="bfPlacar">
     <div class="bfTimes"><div class="bfN" style="--c1:${A.cor};--c2:${cor2(A)}">${escudo(A,22)}<span>${A.nome}</span></div><div class="bfG">${j.ga} <i>x</i> ${j.gb}</div><div class="bfN d" style="--c1:${B.cor};--c2:${cor2(B)}"><span>${B.nome}</span>${escudo(B,22)}</div></div>
     <div class="bfLances">${destaque.length?destaque.map(e=>`<span>${icL(e)} ${(nj(e.jid)||e.n||'').split(" ").slice(-1)[0]} ${e.m}' - ${e.m<=45?'1º':'2º'}</span>`).join(""):'<span class="mu">Bola rolando…</span>'}</div>
    </div>
    <div class="bfStat">
     <div><b>${pa}%</b><i>posse de bola</i><b>${100-pa}%</b></div>
     <div><b>${st.fa}</b><i>finalizações</i><b>${st.fb}</b></div>
     <div><b>${st.ga_}/${st.fa-st.ga_}</b><i>no gol/fora</i><b>${st.gb_}/${st.fb-st.gb_}</b></div>
     <div><b>${st.da}</b><i>desarmes</i><b>${st.db}</b></div>
     <div><b>${st.pea}</b><i>erros passes</i><b>${st.peb}</b></div>
    </div>
   </div>
  </div>`;
  // DIVISÃO: uma linha por jogo. Nome do estádio | público ...... mandante | gols | gols | visitante ...... último lance
  const linhaJogo=(g,n,meuJ,aoClicar,AA,BB)=>{
    const e=g.ev.filter(x=>x.t==='g'||x.t==='c').slice(-1)[0];
    const lance=e?`${e.t==='g'?'⚽':(e.verm?'🟥':'🟨')} ${((typeof nj2==='function'?nj2(g,e):'')||e.n||'').split(" ").slice(-1)[0]} ${e.m}' - ${e.m<=45?'1º':'2º'}`:'';
    return `<div class="bfJ ${meuJ?'meu':''}" onclick="${aoClicar}">
      <span class="bfE">${g.est} | ${Math.round(g.pub/1000)}k</span>
      <div class="bfC" style="--c1:${AA.cor};--c2:${cor2(AA)}">${escudo(AA,15)}<span>${AA.nome}</span></div>
      <div class="bfS ${g.ga>g.gb?'w':''}">${g.ga}</div><div class="bfS ${g.gb>g.ga?'w':''}">${g.gb}</div>
      <div class="bfC d" style="--c1:${BB.cor};--c2:${cor2(BB)}"><span>${BB.nome}</span>${escudo(BB,15)}</div>
      <span class="bfL">${lance}</span></div>`;
  };
  h+=`<div class="bfLista"><div class="bfDv">${tituloAoVivo()}</div>`;
  L.jogos.forEach((g,n)=>{
    const a=S.clubes[g.a],b=S.clubes[g.b],meuJ=g.a===S.meu||g.b===S.meu;
    h+=linhaJogo(g,n,meuJ,meuJ?"abreJanelaEscala('manual')":"abreVerJogoLiga("+n+")",a,b);
  });
  h+=`</div><div class="tag" style="margin:4px 4px 2px">👆 Toque no seu jogo (destacado) para abrir a escalação</div>`;
  h+=htmlOutras();
  // linha do tempo completa do jogo que você acompanha
  h+=`<div class="card" style="margin-top:10px"><div class="lv">${j.ev.length?j.ev.slice().reverse().map(e=>`<div>${icL(e)} ${e.m}' ${nj(e.jid)||e.n}${e.pen?' (pên.)':e.esc?' (esc.)':e.falta?' (falta)':''} <span class="mu">(${e.lado==="a"?A.sig:B.sig})</span>${e.t==="g"&&e.ass?` <small class="mu">ass. ${(nj(e.assId)||e.ass).split(" ").slice(-1)[0]}</small>`:''}</div>`).join(""):'<span class="mu">Bola rolando…</span>'}</div></div>`;
  return h;
}
// ---- Tela de escalação do meu jogo (ao vivo) ----
function nj2(g,e){for(const id of [g.a,g.b]){const x=S.clubes[id].elenco.find(z=>z.id===e.jid);if(x)return x.nome}return""}
function renderLive(){
  if(DR)return;
  if(S.live&&S.live.janela){renderJanela();return}
  if(S.live&&S.live.tela==='escala'&&S._soTick){ // durante o tick, só atualiza o cabeçalho (não mexe no campo)
    const t=document.querySelector('.hd .top');const L=S.live,g=L.jogos.find(x=>x.a===S.meu||x.b===S.meu);
    if(t){t.lastElementChild.textContent=L.min+"' · "+g.ga+" x "+g.gb}
    return;
  }
  const sc=window.scrollY;render();
  window.scrollTo(0,sc);
}
// Cada competição: como saber se há data, se o meu clube joga nela e como simular / jogar.
function compExtras(){
  return[
    {k:"cn",nome:"Copa nacional",prox:()=>cnProximaData(),est:()=>S.cn,jog:()=>S.cn&&cnSouParticipante()&&cnMeuJogo(),sim:()=>cnSimulaData(),vivo:()=>cnComecaMeuJogo()},
    {k:"sa",nome:"Sul-Americana",prox:()=>saProximaData(),est:()=>S.sa,jog:()=>S.sa&&saSouParticipante()&&S.sa.fase!=="fim"&&saMeuJogo(),sim:()=>saSimulaData(),vivo:()=>saComecaMeuJogo()},
    {k:"lb",nome:"Libertadores",prox:()=>lbProximaData(),est:()=>S.lb,jog:()=>S.lb&&lbSouParticipante()&&S.lb.fase!=="fim"&&lbMeuJogo(),sim:()=>lbSimulaData(),vivo:()=>lbComecaMeuJogo()},
    {k:"el",nome:"Liga Europa",prox:()=>elProximaData(),est:()=>S.el,jog:()=>S.el&&elSouParticipante()&&S.el.fase!=="fim"&&elMeuJogo(),sim:()=>elSimulaData(),vivo:()=>elComecaMeuJogo()},
    {k:"cl",nome:"Champions League",prox:()=>clProximaData(),est:()=>S.cl,jog:()=>S.cl&&clSouParticipante()&&S.cl.fase!=="fim"&&clMeusJogos(),sim:()=>clSimulaData(),vivo:()=>clComecaMeuJogo()}
  ];
}
function jogoDoMeuTimeNestaData(){                              // true se o meu clube entra em campo na data atual
  try{
    const d=agendaAtual();if(!d)return false;const c=d.comp;
    if(c==="liga")return !!(S.fixt&&S.fixt[S.rodada]&&S.fixt[S.rodada].some(([a,b])=>a===S.meu||b===S.meu));
    if(c==="cn")return !!(S.cn&&cnSouParticipante()&&cnMeuJogo());
    if(c==="cl")return !!(S.cl&&clSouParticipante()&&S.cl.fase!=="fim"&&clMeusJogos());
    if(c==="el")return !!(S.el&&elSouParticipante()&&S.el.fase!=="fim"&&elMeuJogo());
    if(c==="lb")return !!(S.lb&&lbSouParticipante()&&S.lb.fase!=="fim"&&lbMeuJogo());
    if(c==="sa")return !!(S.sa&&saSouParticipante()&&S.sa.fase!=="fim"&&saMeuJogo());
    if(c==="mund")return !!(mundialEstouVivo()&&mundialMeuJogo());
  }catch(e){}
  return false;
}
function comecaRodada(){
  if(S.live){S.aba='live';render();return}
  if(!S.agenda||S.dia==null)agendaMonta();
  // v55: o time precisa ter 11 aptos em campo para entrar (completa sozinho; se não der, bloqueia e leva à Tática)
  try{if(S.agenda&&S.dia<S.agenda.length&&jogoDoMeuTimeNestaData()&&!S._clbak){const r=garante11(S.clubes[S.meu]);if(!r.ok)return}}catch(e){}
  if(S.dia>=S.agenda.length){
    // fim das datas regulares: se o Mundial ainda não foi preparado e meu clube está nele, abre as 7 datas finais
    if(!S._mundOk){S._mundOk=true;let temDatas=false;try{temDatas=mundialPreparaAgenda()}catch(e){}if(temDatas&&S.dia<S.agenda.length)return comecaRodada()}
    return fimTemporada();
  }
  const d=agendaAtual(),comp=d.comp;
  if(comp==="mund"){
    try{if(S.clubes[S.meu]&&!S._clbak)recuperaParaProximoJogo(S.clubes[S.meu])}catch(e){}
    if(mundialEstouVivo()&&mundialMeuJogo()&&mundialComecaMeuJogo())return;
    mundialSimulaEtapa(false);agendaAvanca();toast("Mundial: etapa simulada (seu clube não joga)");save();render();return;
  }
  try{if(S.clubes[S.meu]&&!S._clbak)recuperaParaProximoJogo(S.clubes[S.meu])}catch(e){}
  agendaSimulaOutras();
  if(comp==="liga"){if(criaLive()===false)return;render();somApito();playLive();return}
  // competição de copa: só o MEU jogo é ao vivo; se já fui eliminado, a data é simulada e o dia passa
  const mapa={
    cn:{e:S.cn,jog:()=>cnSouParticipante()&&cnMeuJogo(),vivo:()=>cnComecaMeuJogo(),sim:()=>cnSimulaData(),nome:"Copa nacional"},
    cl:{e:S.cl,jog:()=>S.cl&&clSouParticipante()&&S.cl.fase!=="fim"&&clMeusJogos(),vivo:()=>clComecaMeuJogo(),sim:()=>clSimulaData(),nome:"Champions League"},
    el:{e:S.el,jog:()=>S.el&&elSouParticipante()&&S.el.fase!=="fim"&&elMeuJogo(),vivo:()=>elComecaMeuJogo(),sim:()=>elSimulaData(),nome:"Liga Europa"},
    lb:{e:S.lb,jog:()=>S.lb&&lbSouParticipante()&&S.lb.fase!=="fim"&&lbMeuJogo(),vivo:()=>lbComecaMeuJogo(),sim:()=>lbSimulaData(),nome:"Libertadores"},
    sa:{e:S.sa,jog:()=>S.sa&&saSouParticipante()&&S.sa.fase!=="fim"&&saMeuJogo(),vivo:()=>saComecaMeuJogo(),sim:()=>saSimulaData(),nome:"Sul-Americana"}
  }[comp];
  if(!mapa||!mapa.e){agendaAvanca();save();render();return}
  if(mapa.jog())return mapa.vivo();                 // ao terminar, o fim do jogo avança a agenda
  mapa.sim();agendaAvanca();toast(mapa.nome+": data simulada (seu clube não joga)");save();render();
}

// ===== UI =====
function ir(k){
  if(k==='cal'){S.calMes=null;S.calAno=null} // navegação segura: durante a partida, só volta para a partida
  if(S&&S.live){S.aba='live';render();return}
  S.aba=k;render();
}
function render(){
  const app=document.getElementById("app");
  if(!S){app.innerHTML=telaInicio();return}
  if(S.live&&S.aba!=='live')S.aba='live';
  const eu=S.clubes[S.meu];
  let h=`<header><div class="row"><div><h2>${escudo(eu,24)} ${eu.nome}</h2><small>Treinador ${S.treinador} · Temp. ${S.temp} · ${agendaTexto()}</small></div><div style="text-align:right"><b class="${eu.caixa<0?'r':'g'}" style="cursor:pointer" onclick="ir('fin')">${R$(eu.caixa)}</b><br><div style="display:flex;gap:6px;justify-content:flex-end;margin-top:4px"><button class="disq" title="Menu" onclick="abreMenu()">☰</button><button class="disq" title="Salvar jogo" onclick="salvarAgora()">💾</button><button class="disq" title="Online" onclick="ir(\'onl\')">🌐</button><button class="disq" title="Menu inicial" onclick="irTitulo()">🏠</button><button class="disq" title="Som" onclick="somOn=!somOn;if(somOn){audio()}else{try{speechSynthesis.cancel()}catch(e){}}render()">${somOn?'🔊':'🔇'}</button></div></div></div></header><div class="wrap">`;
  const trocouTela=(window._abaAnt!==S.aba);window._abaAnt=S.aba;
  h+=`<div class="${trocouTela?'fade':''}">`;h+=({sel:()=>abaSel(),hum:()=>abaHum(),onl:()=>abaOnl(),home:abaHome,cal:abaCal,cl:()=>abaCL(),lb:()=>abaLB(),el:abaEL,sa:abaSA,cn:abaCN,est:abaEst,banco:abaBanco,tecn:abaTec,fin:abaFin,arti:abaArtilheiros,patro:abaPatro,tech:abaTecHist,base:abaBase,rank:abaRank,pos:abaPos,live:abaLive,elenco:abaElenco,clubes:abaClubes,db:abaDB,cmundo:abaCopasMundo,mund:abaMundial,prem:abaPremios,tat:abaTat,tab:abaTab,mer:abaMer,ed:abaEd})[S.aba]();h+=`</div>`;
  h+=`</div><nav style="overflow-x:auto">${(S.live?[["live","🔴","Ao vivo"]]:[["home","🏠","Início"],["elenco","👥","Elenco"],["tat","📋","Tática"],["cal","📅","Calendário"],["tab","🏆","Tabela"]]).map(([k,i,n])=>`<button style="min-width:72px" class="${S.aba===k?'on':''}" onclick="ir('${k}')"><span class="ic">${i}</span>${n}</button>`).join("")}</nav>`;
  app.innerHTML=h;
  posRender();
}

let telaTitulo=true;                        // tela inicial (Novo jogo / Carregar)
let NOVO={passo:0,nome:"",pais:null,div:null};
function irTitulo(){ // volta ao menu inicial (jogo atual já está salvo se houver slot)
  if(S&&S.live)return aviso("Termine a partida antes de voltar ao menu.");
  if(S&&SLOT_ATUAL!=null)gravaSlot(SLOT_ATUAL,true);
  S=null;SLOT_ATUAL=null;telaTitulo=true;NOVO={passo:0,nome:localStorage.getItem("tn")||"",pais:null,div:null};render();
}
function telaInicio(){
  if(telaTitulo&&NOVO.passo===0&&!NOVO.carregando){
    const algum=[0,1,2].some(i=>lerSlot(i));
    return`<div class="titulo fade"><div class="logo"><div class="bola">⚽</div><h1>Manager</h1><small>Gerenciador de futebol · ligas do mundo</small></div>
      <button class="grande" onclick="NOVO={passo:1,nome:localStorage.getItem('tn')||'',pais:null,div:null};render()">🆕 Novo jogo</button>
      <button class="grande s" ${algum?'':'disabled'} onclick="NOVO={passo:0,carregando:true};render()">📂 Carregar jogo salvo</button><button class="grande s" onclick="onlEntrarDlg()">🌐 Entrar em sala online</button>
      ${algum?'':'<div class="mu" style="text-align:center;font-size:12px">Nenhum jogo salvo ainda.</div>'}
    </div>`;
  }
  if(NOVO.carregando){
    let h=`<header><h2>📂 Carregar jogo</h2><small>Escolha um slot</small></header><div class="wrap fade">
      <button class="s sm" onclick="NOVO={passo:0};render()">← Voltar</button><div style="height:10px"></div>`;
    for(let i=0;i<3;i++){
      const inf=infoSlot(i);
      h+=inf?`<div class="slotc"><div onclick="carregaSlot(${i})" style="flex:1;cursor:pointer"><b>Slot ${i+1} · ${inf.clube}</b><br><small class="mu">${inf.tecnico} · ${inf.pais} · Temp. ${inf.temp} · jogo ${inf.dia}/${inf.total}<br>salvo em ${inf.quando}</small></div><button class="sm s" onclick="apagaSlot(${i})">🗑</button></div>`
               :`<div class="slotc vazio"><div><b>Slot ${i+1}</b><br><small class="mu">vazio</small></div></div>`;
    }
    return h+`</div>`;
  }
  // ----- Novo jogo, em passos -----
  const passos=[1,2,3,4].map(n=>`<i class="${NOVO.passo>=n?'on':''}"></i>`).join("");
  let h=`<header><h2>🆕 Novo jogo</h2><small>Passo ${NOVO.passo} de 4</small></header><div class="wrap fade"><div class="passo">${passos}</div>`;
  if(NOVO.passo===1){
    h+=`<div class="card"><h3>Qual é o seu nome de treinador?</h3><input id="tn" placeholder="Ex.: Danilo" value="${NOVO.nome||''}" oninput="NOVO.nome=this.value" style="margin-top:8px"></div>
        <div class="row"><button class="s" onclick="telaTitulo=true;NOVO={passo:0};render()">← Menu</button><button onclick="if(!NOVO.nome.trim())return aviso('Digite o seu nome para continuar.');localStorage.setItem('tn',NOVO.nome.trim());NOVO.passo=2;render()">Continuar →</button></div>`;
  }else if(NOVO.passo===2){
    h+=`<button class="s sm" onclick="NOVO.passo=1;render()">← Voltar</button><h3 style="margin:10px 0 8px">Escolha o país da liga</h3>`+Object.keys(LIGAS).map(pa=>`<div class="clube" onclick="NOVO.pais='${pa}';NOVO.passo=3;render()"><span>🌍 ${pa}</span><span class="tag">${LIGANOME[pa][0]}</span></div>`).join("");
  }else if(NOVO.passo===3){
    h+=`<button class="s sm" onclick="NOVO.passo=2;render()">← Voltar</button><h3 style="margin:10px 0 8px">Divisão · ${NOVO.pais}</h3>`+LIGAS[NOVO.pais].map((d,i)=>`<div class="clube" onclick="NOVO.div=${i};NOVO.passo=4;render()"><span>${LIGANOME[NOVO.pais][i]}</span><span class="tag">${d.length} clubes</span></div>`).join("");
  }else{
    h+=`<button class="s sm" onclick="NOVO.passo=3;render()">← Voltar</button><h3 style="margin:10px 0 8px">Escolha o seu clube · ${LIGANOME[NOVO.pais][NOVO.div]}</h3>`+LIGAS[NOVO.pais][NOVO.div].map((c,i)=>`<div class="clube" onclick="inicia(${i})"><span>${escudo({nome:c[0],cor:c[2],cor2:c[3]},20)} ${c[0]}</span><span class="tag">${c[1]}</span></div>`).join("");
  }
  return h+`</div>`;
}
function inicia(i){
  const n=(NOVO.nome||"").trim()||"Mister";
  novoJogo(NOVO.pais,NOVO.div,i,n);setTimeout(()=>{try{congelaMundoEmLotes()}catch(e){}},1500);
  SLOT_ATUAL=null;telaTitulo=false;NOVO={passo:0};
  render();
  // pede o slot logo no início para o autosave funcionar
  setTimeout(()=>escolheSlotParaSalvar(),250);
}
function confianca(){ // diretoria e torcida: posição REAL comparada ao que se esperava do clube (v49)
  const t=tabela(),N=t.length,pos=t.findIndex(c=>c.id===S.meu)+1,eu=S.clubes[S.meu];
  if(S.dir==null){S.dir=70;S.tor=70}
  const esperado=[...S.clubes].sort((a,b)=>b.forca-a.forca).findIndex(c=>c.id===S.meu)+1;
  const base=100-(pos-1)*3.5;
  const sobra=(esperado-pos)*2.2;                                       // superar (ou decepcionar) a expectativa
  const zona=pos>N-4?-14*(esperado<=N-6?1:.35):0;                       // rebaixamento pesa mais para quem não era esperado lá
  const alvoD=Math.max(5,Math.min(100,base+sobra+zona+(eu.caixa<0?-15:0)));
  const alvoT=Math.max(5,Math.min(100,base+sobra+zona+5));
  S.dir=Math.round(S.dir*.8+alvoD*.2);S.tor=Math.round(S.tor*.8+alvoT*.2);
}
function verFicha(id){abreFichaJogador(id)}
const FUNC={GOL:"Normal",ZAG:"Defensivo",LD:"Defensivo",LE:"Defensivo",VOL:"Volante",MEI:"Pelo meio",PE:"Pelas pontas",ATA:"Atacante"};
function abaHome(){
  if(!S.objetivo||S.objetivo.temp!==S.temp){try{geraObjetivo()}catch(e){}}
  const t=tabela(),pos=t.findIndex(c=>c.id===S.meu)+1,eu=S.clubes[S.meu];
  if(S.dir==null){S.dir=70;S.tor=70}
  if(!S.homeAba)S.homeAba="jogar";
  const pj=proximoJogoInfo();
  const prox=!!pj;
  const adv=pj&&pj.adv,casa=pj?pj.casa:"";
  const tc=eu.cor==='#ffffff'?'#111':'#fff';
  const bg=eu.cor==='#ffffff'?`linear-gradient(135deg,#e9eef0,${eu.cor2||'#999'})`:`linear-gradient(135deg,${eu.cor},${eu.cor2&&eu.cor2!=='#ffffff'?eu.cor2:'#00000066'})`;
  const barra=(v,cor)=>`<div class="vb"><i style="width:${v}%;background:${cor}"></i><b>${v}%</b></div>`;
  const cc=v=>v>=65?'#3ddc84':v>=35?'#f5c542':'#ff5d5d';
  const sj=eu.elenco.find(j=>j.id===S.selId)||null;
  const A=S.homeAba;
  let corpo="";
  if(A==="jogar"){
    corpo=`${pedidosSaidaHTML()}${alertasHTML()}${objetivoHTML()}${cartaoRivalHTML()}<div class="pj3"><div class="tag" style="background:#0005;color:#fff">${prox?`${S.agenda&&S.agenda[S.dia]?S.agenda[S.dia].dia+' '+MESES[S.agenda[S.dia].mes].slice(0,3)+' · ':''}${pj.titulo}`:'Fim da temporada'}</div>
    ${adv?`<div style="display:flex;align-items:center;gap:8px;margin-top:8px">${escudo(adv,36)}<div><b>${adv.nome}</b>${ehRival(adv.nome)?' <span class="tag" style="background:#7a1f00;color:#fff">🔥 CLÁSSICO</span>':''}<br><small>${casa} · ${iconeFama(adv.nome)} ${nomeFama(adv.nome)}</small><br><small class="mu">Tempo provável: ${previsaoClima()} · 🌱 Gramado ${rotuloGramado(S.gramado==null?62:S.gramado)}</small></div></div>`:(prox?'<div style="margin-top:8px">Seu clube não joga nesta data (a competição segue sem você).</div>':'<div style="margin-top:8px">Fim da temporada</div>')}
    ${adv&&titularesAptos(eu).length<11?`<div class="hint" style="margin-top:8px;background:linear-gradient(90deg,#7f1d1d,#b91c1c)">⛔ Só ${titularesAptos(eu).length} jogador(es) apto(s) escalado(s). Ao jogar, o time é completado com reservas; se não houver, vá à Tática.</div>`:''}
    <button class="big" onclick="comecaRodada()" ${adv&&titularesAptos(eu).length<11?'style="opacity:.6"':''}>${prox?(adv?(titularesAptos(eu).length<11?'▶ Jogar (completar time)':'▶ Jogar'):'⏭ Avançar data'):'Encerrar temporada'}</button></div>
`;
  }else if(A==="hist"){
    corpo=`<div class="pj3">${S.hist.length?S.hist.map(x=>`<div class="ln2"><span>Temp. ${x.temp}</span><span>Campeão: ${x.campeao} · você ${x.meu}º</span></div>`).join(""):'Sem temporadas concluídas.'}</div>`;
  }else if(A==="tec"){
    corpo=`<div class="pj3"><div class="ln2"><span>Técnico</span><b>${S.treinador}</b></div><div class="ln2"><span>Liga</span><b>${LIGANOME[S.pais][S.div]}</b></div><div class="ln2"><span>País</span><b>${S.pais}</b></div><div class="ln2"><span>Temporada</span><b>${S.temp}</b></div><div class="ln2"><span>Folha salarial</span><b>${R$(eu.elenco.reduce((q,j)=>q+j.sal*1000,0))}/mês</b></div></div>`;
  }else{
    const posCor={GOL:'#f5c542',ZAG:'#4aa3ff',LD:'#4aa3ff',LE:'#4aa3ff',VOL:'#3ddc84',MEI:'#3ddc84',PE:'#ff7a59',ATA:'#ff5d5d'};
    const lst=[...eu.elenco].sort((x,y)=>(y.tit?1:0)-(x.tit?1:0)||POS_ORD(x.pos)-POS_ORD(y.pos)||y.f-x.f);
    corpo=`<div class="hmEl"><div class="hmH"><span>P</span><span>Nome</span><span>F</span><span>Nota</span><span>Energia</span></div>${lst.map(j=>{
      const e=Math.round(j.en==null?100:j.en);
      const m=j.mediaNota!=null?j.mediaNota.toFixed(1).replace('.',','):'—';
      const cm=j.mediaNota>=7.5?'#34d98b':j.mediaNota>=6?'#ffd45e':j.mediaNota!=null?'#ff8a8a':'#6f8a7c';
      return`<div class="hmL ${j.tit?'tit':''}" onclick="abreFichaJogador('${j.id}')"><span class="hmP" style="background:${posCor[j.pos]||'#888'}">${j.pos}</span><span class="hmN"><i class="nm">${numDe(j)}</i> ${j.nome}${cartaoHTML(j)}${lesaoSelo(j)}${estrelaHTML(j)}</span><span class="hmF">${j.f}</span><span style="color:${cm};font-weight:800">${m}</span><span class="hmE"><i style="width:${e}%;background:${corEn(e)}"></i><b>${e}</b></span></div>`}).join("")}</div><div class="mu" style="font-size:11px;text-align:center;padding:6px">Toque num jogador para ver o histórico de notas</div>`;
  }
  const esq=`<div class="cb" style="background:${bg};color:${tc}">
    <div class="tt">${escudo(eu,46)}<div><h2>${eu.nome}</h2><small>${LIGANOME[S.pais][S.div]} · ${pos}º lugar · ${eu.pts} pts</small><br><small>Técnico: ${S.treinador}</small></div></div>
    <div class="conf"><div><div class="lb">Confiança da diretoria</div>${barra(S.dir,cc(S.dir))}</div><div><div class="lb">Confiança da torcida</div>${barra(S.tor,cc(S.tor))}</div></div>
    <div class="kpis"><div class="kpi"><b>${pos}º</b><small>Posição</small></div><div class="kpi"><b>${eu.pts}</b><small>Pontos</small></div><div class="kpi"><b>${iconeFama(eu.nome)} ${nomeFama(eu.nome)}</b><small>Prestígio</small></div></div><div class="forma">${(S.forma||[]).map(x=>`<i class="${x}">${x}</i>`).join("")||'<small style="opacity:.7">Sem jogos ainda</small>'}</div>
    <div class="abas">${[["jogar","Jogar"],["jog","Elenco"],["hist","Histórico"],["tec","Técnico"]].map(([k,n])=>`<button class="${A===k?'on':''}" onclick="S.homeAba='${k}';render()">${n}</button>`).join("")}</div>
    ${corpo}
    <div class="bt"><div>📰 <b>Notícias</b><br>${S.ultimo?`${S.ultimo.a.nome} ${S.ultimo.r.ga} x ${S.ultimo.r.gb} ${S.ultimo.b.nome}`:'Sem novidades'}</div><div>💰 <b>Seu dinheiro</b><br>${R$(eu.caixa)}</div></div></div>`;
  return `<div class="home2"><div>${esq}</div><div>${painelDir()}</div></div>`;
}
const corEn=(e)=>e>=75?'#3ddc84':e>=45?'#f5c542':'#ff5d5d';
const enBar=j=>{const e=Math.round(j.en==null?100:j.en);return `<div style="min-width:46px"><b style="color:${corEn(e)}">${e}%</b><div class="bar"><i style="width:${e}%;background:${corEn(e)}"></i></div></div>`};

function notaCelula(j){
  const n=(j.nts||[]).length;
  if(!n&&!j.ultimoBloco)return'<small class="mu">—</small>';
  const m=j.mediaNota!=null?String(j.mediaNota.toFixed(1)).replace('.',','):'—';
  const cor=j.mediaNota>=7.5?'#34d98b':j.mediaNota>=6?'#ffd45e':'#ff8a8a';
  const altas=(j.nts||[]).filter(x=>x>=7).length;
  return`<b style="color:${cor}">${m}</b><br><small class="mu">${altas}/${n} acima de 7 · ${n}/10</small>`;
}


function topoAba(ic,titulo,sub,kpis){ // faixa padrão das abas: ícone + título + indicadores
  const eu=S.clubes[S.meu];
  const bg=eu.cor==='#ffffff'?`linear-gradient(135deg,#e9eef0,${eu.cor2||'#999'})`:`linear-gradient(135deg,${eu.cor},${eu.cor2&&eu.cor2!=='#ffffff'?eu.cor2:'#00000066'})`;
  const tc=eu.cor==='#ffffff'?'#111':'#fff';
  return`<div class="elTopo" style="background:${bg};color:${tc}"><div class="elT1"><div style="font-size:30px">${ic}</div><div><div class="elNome">${titulo}</div><div class="elSub">${sub||''}</div></div></div>${kpis&&kpis.length?`<div class="elKp" style="grid-template-columns:repeat(${kpis.length},1fr)">${kpis.map(([v,l])=>`<div><b>${v}</b><small>${l}</small></div>`).join("")}</div>`:''}</div>`;
}
function linhaInfo(r,v,cls){return`<div class="inL"><span>${r}</span><b class="${cls||''}">${v}</b></div>`}

function abaElenco(){
  const eu=S.clubes[S.meu];
  const ord=S.elOrd||"pos";
  const lista=[...eu.elenco];
  if(ord==="pos")lista.sort((a,b)=>POS_ORD(a.pos)-POS_ORD(b.pos)||b.f-a.f);
  else if(ord==="f")lista.sort((a,b)=>b.f-a.f);
  else if(ord==="nota")lista.sort((a,b)=>(b.mediaNota||0)-(a.mediaNota||0));
  else if(ord==="en")lista.sort((a,b)=>(a.en==null?100:a.en)-(b.en==null?100:b.en));
  else if(ord==="idade")lista.sort((a,b)=>a.idade-b.idade);
  else if(ord==="les")lista.sort((a,b)=>(b.lesao>0)-(a.lesao>0)||(b.lesao||0)-(a.lesao||0)||(b.suspenso>0)-(a.suspenso>0)||POS_ORD(a.pos)-POS_ORD(b.pos));
  const tit=lista.filter(j=>j.tit).length;
  const folha=eu.elenco.reduce((q,j)=>q+j.sal*1000,0);
  const bg=eu.cor==='#ffffff'?`linear-gradient(135deg,#e9eef0,${eu.cor2||'#999'})`:`linear-gradient(135deg,${eu.cor},${eu.cor2&&eu.cor2!=='#ffffff'?eu.cor2:'#00000066'})`;
  const tc=eu.cor==='#ffffff'?'#111':'#fff';
  const posCor={GOL:'#f5c542',ZAG:'#4aa3ff',LD:'#4aa3ff',LE:'#4aa3ff',VOL:'#3ddc84',MEI:'#3ddc84',PE:'#ff7a59',ATA:'#ff5d5d'};
  let h=`<div class="elTopo" style="background:${bg};color:${tc}">
    <div class="elT1">${escudo(eu,40)}<div><div class="elNome">${eu.nome}</div><div class="elSub">${LIGANOME[S.pais][S.div]} · Elenco de ${eu.elenco.length} jogadores</div></div></div>
    <div class="elKp"><div><b>${iconeFama(eu.nome)} ${nomeFama(eu.nome)}</b><small>Prestígio</small></div><div><b>${tit}/11</b><small>Titulares</small></div><div><b>${R$(Math.round(folha))}</b><small>Folha/mês</small></div></div></div>`;
  const modo=S.elModo||"cartoes";
  h+=`<div class="elModo"><button class="${modo==='cartoes'?'on':''}" onclick="setElModo('cartoes')">🃏 Cartões</button><button class="${modo==='tabela'?'on':''}" onclick="setElModo('tabela')">📊 Tabela</button></div>`;
  if(modo==="tabela"){
    h+=desfalquesHTML(eu);
    h+=elencoDensaHTML(eu);
    h+=resumoGrupoHTML(eu);
    h+=renovaAutoHTML(eu);
    return h;
  }
  h+=`<div class="elOrd">${[["pos","Posição"],["f","Força"],["nota","Nota"],["en","Energia"],["idade","Idade"],["les","🤕 Lesões"]].map(([k,n])=>`<button class="${ord===k?'on':''}" onclick="S.elOrd='${k}';render()">${n}</button>`).join("")}</div>`;
  h+=desfalquesHTML(eu);
  h+=resumoGrupoHTML(eu);
  h+=renovaAutoHTML(eu);
  h+=`<div class="elTab"><div class="elH"><span>Pos</span><span>Jogador</span><span>F</span><span>Nota</span><span>Energia</span><span>Ct</span></div>`;
  lista.forEach(j=>{
    const e=Math.round(j.en==null?100:j.en);
    const m=j.mediaNota!=null?j.mediaNota.toFixed(1).replace('.',','):'—';
    const cm=j.mediaNota>=7.5?'#34d98b':j.mediaNota>=6?'#ffd45e':j.mediaNota!=null?'#ff8a8a':'#6f8a7c';
    const marcas=(j.tit?'<i class="mk t" title="Titular">●</i>':'')+cartaoHTML(j)+lesaoSelo(j)+(j.emprestado?'<i class="mk">🔁</i>':'')+estrelaHTML(j);
    h+=`<div class="elL ${j.tit?'tit':''}" onclick="abreFichaJogador('${j.id}')">
      <span class="elP" style="background:${posCor[j.pos]||'#888'}">${j.pos}</span>
      <span class="elN"><b><i class="nm">${numDe(j)}</i> ${j.nome}</b>${marcas}<small>${papelDe(j)} · ${(j.hab||[]).join(' · ')}</small><small style="opacity:.95"><span style="color:${corNivel(moralJ(j))}">😊 ${Math.round(moralJ(j))}</span> · <span style="color:${corNivel(entrosJ(j))}">🤝 ${Math.round(entrosJ(j))}</span>${(j.golsLiga||j.assistLiga)?` · ⚽${j.golsLiga||0} 🅰️${j.assistLiga||0}`:''}</small></span>
      <span class="elF">${j.f}</span>
      <span class="elNt" style="color:${cm}">${m}</span>
      <span class="elE"><i style="width:${e}%;background:${corEn(e)}"></i><b>${e}</b></span>
      <span class="elC ${(j.ct||1)<=1&&!j.emprestado?'r':''}">${j.emprestado?'1a':(j.ct||1)+'a'}</span></div>`;
  });
  h+=`</div><div class="tag" style="margin:8px 2px">Toque num jogador para ver o histórico de notas e as ações</div>`;
  return h;
}
// ===== FICHA DO JOGADOR (janela) com histórico de notas =====
function abreFichaJogador(id){
  const eu=S.clubes[S.meu],j=eu.elenco.find(x=>x.id===id);if(!j)return;
  const hn=(j.hn||[]).slice().reverse();
  const cn=n=>n>=7.5?'#34d98b':n>=6?'#ffd45e':'#ff8a8a';
  const e=Math.round(j.en==null?100:j.en);
  const bonus=bonusEstrela(j);
  const media=hn.length?(hn.reduce((q,x)=>q+x[0],0)/hn.length):null;
  const nts=(j.nts||[]).length;
  const linhas=hn.length?hn.map(x=>`<div class="hnL"><span class="hnD">${x[7]||''}</span><span class="hnA">${x[1]}</span><span class="hnR">${x[2]}</span><span class="hnC">${x[3]}</span><span class="hnG">${x[4]?'⚽'.repeat(Math.min(3,x[4])):''}${x[5]===2?'🟥':x[5]===1?'🟨':''}${x[6]?'🔼':''}</span><b class="hnN" style="color:${cn(x[0])}">${x[0].toFixed(1).replace('.',',')}</b></div>`).join(""):'<div class="mu" style="padding:10px;text-align:center">Ainda sem partidas. As notas aparecem aqui depois de cada jogo.</div>';
  const barras=hn.slice(0,12).reverse().map(x=>`<i style="height:${Math.max(8,(x[0]-2)/8*100)}%;background:${cn(x[0])}" title="${x[0]}"></i>`).join("");
  modal(`<div class="fcHead"><div><div class="fcNome">${j.nome} ${estrelaHTML(j)}</div><div class="fcSub">${j.num!=null?'#'+j.num+' · ':''}${j.pos} · ${papelDe(j)} · ${PE_NOME[peDe(j)]} · ${j.idade} anos</div></div><div class="fcF">${j.f}<small>${bonus?'+'+bonus+' ★':'força'}</small></div></div>
    <div class="fcGrid">
      <div><small>Potencial</small><b>${j.pot||j.f}</b></div><div><small>Energia</small><b style="color:${corEn(e)}">${e}%</b></div>
      <div><small>Contrato</small><b>${j.emprestado?'empréstimo':(j.ct||1)+' ano(s)'}</b></div><div><small>Salário/mês</small><b>${Math.round(j.sal*1000).toLocaleString('pt-BR')}</b></div>
      <div><small>Valor</small><b>${R$(Math.round(j.val))}</b></div><div><small>Gols (temp.)</small><b>${j.golsLiga||0}</b></div><div><small>Assistências (temp.)</small><b>${j.assistLiga||0}</b></div><div><small>Artilharias</small><b>${j.art||0}</b></div><div><small>Amarelos (temp.)</small><b>${j.ac||0}/3</b></div><div><small>Vermelhos</small><b>${j.vm||0}</b></div><div><small>Situação</small><b style="color:${j.suspenso>0?'#ff8a8a':j.lesao>0?'#ffb86b':'#7dff9a'}">${j.suspenso>0?'Suspenso':j.lesao>0?'Lesionado':'Apto'}</b></div></div>
    <div class="fcGrid" style="margin:6px 0"><div><small>Moral</small><b style="color:${corNivel(moralJ(j))}">${Math.round(moralJ(j))} · ${rotuloMoral(moralJ(j))}</b></div><div><small>Entrosamento</small><b style="color:${corNivel(entrosJ(j))}">${Math.round(entrosJ(j))} · ${rotuloEntros(entrosJ(j))}</b></div></div>
    ${typeof selFichaHTML==='function'?selFichaHTML(j):''}
    ${j.lesao>0&&!j.conv?`<div class="hint" style="margin:6px 0;background:linear-gradient(90deg,#7a3b00,#b45309)">🤕 <b>${lesaoTexto(j)}</b><br><small>Fica de fora dos próximos ${j.lesao} jogo${j.lesao>1?'s':''} (cada jogo do time conta, de qualquer competição).</small></div>`:''}
    <div style="margin:6px 0">${habChips(j,false)}</div>
    <div class="fcNotaBox"><div><small>Média (${hn.length} jogos)</small><b style="color:${media!=null?cn(media):'#999'}">${media!=null?media.toFixed(2).replace('.',','):'—'}</b></div>
      ${evolucaoFichaHTML(j)}
      <div class="fcGraf">${barras||'<small class="mu">sem dados</small>'}</div></div>
    <div class="hnH"><span>Data</span><span>Adv.</span><span>Placar</span><span>Torneio</span><span></span><span>Nota</span></div>
    <div class="hnLista">${linhas}</div>
    <div class="fcAcoes"><button onclick="fechaDlg();toggle('${j.id}')">${j.tit?'Tirar do time':'Escalar'}</button>${j.emprestado?'':`<button onclick="fechaDlg();renova('${j.id}')">Renovar</button><button class="v" onclick="fechaDlg();vender('${j.id}')">Vender</button>`}<button class="x" onclick="fechaDlg()">Fechar</button></div>`);
}

const POS_ORD=p=>["GOL","ZAG","LD","LE","VOL","MEI","PE","ATA"].indexOf(p);
function vender(id){
  const eu=S.clubes[S.meu],j=eu.elenco.find(x=>x.id===id);
  if(j&&j.emprestado)return aviso(j.nome+" está emprestado e pertence ao "+(j.donoNome||"outro clube")+".");
  if(eu.elenco.length<=16)return aviso("Elenco mínimo: 16 jogadores.");
  const v=Math.round(j.val*rnd(85,110)/100),resc=rescisaoDe(j,v),liq=v-resc;
  confirma(`Vender ${j.nome} por ${R$(v)}?\nRescisão contratual (${Math.round(resc/v*100)}%): -${R$(resc)}\nVocê recebe: ${R$(liq)}`,()=>{eu.caixa+=liq;finRec("Venda de jogadores",v);finDesp("Rescisões",resc);eu.elenco=eu.elenco.filter(x=>x.id!==id);auto(eu,true);save();render()});
}

// ===== TÁTICA (campo + banco) =====
function grupoPos(j){return j.pos==="GOL"?"GOL":["ZAG","LD","LE"].includes(j.pos)?"DEF":["ATA"].includes(j.pos)?"ATA":"MEI"}
function abaTat(){
  const eu=S.clubes[S.meu];
  if(!S.cap||!eu.elenco.find(j=>j.id===S.cap))S.cap=(eu.elenco.filter(j=>j.tit).sort((a,b)=>b.f-a.f)[0]||eu.elenco[0]).id;
  if(S.cob&&!eu.elenco.find(j=>j.id===S.cob))S.cob=null;   // v47: sem batedor guardado = Automático (antes o capitão era imposto)
  const tit=eu.elenco.filter(j=>j.tit);
  const opts=(arr,sel)=>arr.map(j=>`<option value="${j.id}" ${j.id===sel?'selected':''}>${j.nome}</option>`).join("");
  const adv=(()=>{const pr=S.fixt[S.rodada]?.find(([a,b])=>a===S.meu||b===S.meu);if(!pr)return null;return S.clubes[pr[0]===S.meu?pr[1]:pr[0]]})();
  return `<div class="escola"><div>${campoHTML(eu,'tat')}
    <div class="hint" id="dicaToque" style="margin-top:6px">Toque num titular e num reserva para substituir. Arraste para mover de posição.</div></div>
  <div class="painelD">
   <div class="advbar"><span>Adversário: <b>${adv?escudo(adv,16)+' '+adv.nome:'—'}</b></span><span style="display:flex;gap:6px;align-items:center">${seloOnze(eu)}<span class="tag">${S.form}</span></span></div>
   <div class="tag">Banco de reservas</div>${bancoHTML(eu)}
   <div class="ctl">
     <div><label>Formação</label><select onchange="S.form=this.value;S.selId=null;eu_auto();">${Object.keys(FORM).map(f=>`<option ${f===S.form?'selected':''}>${f}</option>`).join("")}</select></div>
     <div><label>Estilo de jogo</label><select onchange="S.tatica=this.value;save()">${["Defensiva","Equilibrada","Ofensiva","Contra-ataque"].map(f=>`<option ${f===S.tatica?'selected':''}>${f}</option>`).join("")}</select></div>
     <div><label>Marcação</label><select onchange="S.marc=this.value;save()">${["Leve","Normal","Forte"].map(f=>`<option ${f===S.marc?'selected':''}>${f}</option>`).join("")}</select></div>
     <div><label>Concentrar ataques</label><select onchange="S.conc=this.value;save()">${["Pelo meio","Pelas pontas"].map(f=>`<option ${f===S.conc?'selected':''}>${f}</option>`).join("")}</select></div>
     <div><label>Capitão</label><select onchange="S.cap=this.value;save();render()">${opts(tit,S.cap)}</select></div>
     <div><label>Cobrança de faltas</label><select onchange="S.cob=this.value||null;save()"><option value="" ${!S.cob||!tit.find(j=>j.id===S.cob)?'selected':''}>⚙️ Automático (melhor batedor)</option>${opts(tit.filter(j=>j.pos!=="GOL"),S.cob)}</select></div>
     <div><label>Cobrança de pênaltis</label><select onchange="S.cobPen=this.value||null;save()"><option value="" ${!S.cobPen||!tit.find(j=>j.id===S.cobPen)?'selected':''}>⚙️ Automático (melhor cobrador)</option>${opts(tit.filter(j=>j.pos!=="GOL"),S.cobPen)}</select></div>
     <div><label>Cobrança de escanteios</label><select onchange="S.esc=this.value||null;save()"><option value="" ${!S.esc||!tit.find(j=>j.id===S.esc)?'selected':''}>⚙️ Automático (melhor cruzador)</option>${opts(tit.filter(j=>j.pos!=="GOL"),S.esc)}</select></div>
   </div>
   <div class="row" style="margin-top:10px"><button class="s" onclick="autoBotao(false)">🔄 Seleção automática</button><button class="s" onclick="resetPos(S.clubes[S.meu]);save();render()">↺ Posições</button></div>
   <div class="row" style="margin-top:8px"><button onclick="S.aba='home';render()">Voltar ao time</button><button onclick="comecaRodada()" ${titularesAptos(eu).length<11?'disabled style="opacity:.45;filter:grayscale(1)"':''}>${titularesAptos(eu).length<11?'⛔ Faltam '+(11-titularesAptos(eu).length)+' em campo':'⚽ Jogar &gt;&gt;'}</button></div>
   <label class="ck"><input type="checkbox" ${S.padrao?'checked':''} onchange="S.padrao=this.checked;save()"> Salvar formação</label>
  </div></div>
  ${numerosHTML(eu)}
  <div class="card" style="margin-top:10px"><div class="sc2" style="max-height:240px;overflow:auto"><table class="tl"><tr><th>P</th><th>Nome</th><th>F</th><th>Energia</th><th>Ct</th><th>G</th><th>I</th></tr>
  ${[...eu.elenco].sort((a,b)=>POS_ORD(a.pos)-POS_ORD(b.pos)||b.f-a.f).map(j=>`<tr class="${j.tit?'t':''}"><td>${j.tit?'★':''}${j.pos[0]}</td><td>${j.nome}${j.conv?' '+fl(j.conv.p)+' Convocado':(j.lesao>0?' 🤕 '+j.lesao+'j':'')}</td><td class="y">${j.f}</td><td style="min-width:60px">${enBar(j)}</td><td>${j.ct||1}a</td><td>${j.gols}</td><td>${j.idade}</td></tr>`).join("")}</table></div></div>`;
}
function eu_auto(){S.selId=null;const eu=S.clubes[S.meu];eu.form=S.form;auto(eu,false);save();render()}
function toggle(id){const eu=S.clubes[S.meu],j=eu.elenco.find(x=>x.id===id);
  if(j.lesao>0)return aviso("Jogador lesionado.");
  if(!j.tit&&eu.elenco.filter(x=>x.tit).length>=11)return aviso("Já há 11 titulares. Tire alguém antes.");
  j.tit=!j.tit;save();render()}
function abaTab(){
  const pa=S.tabPais||S.pais,dv=(S.tabDiv!=null&&S.tabPais)?S.tabDiv:S.div;
  const meuView=(pa===S.pais&&dv===S.div);
  const trHTML=meuView?timeRodadaHTML():'';
  const t=tabelaDe(pa,dv);
  let h=`<div class="card"><div class="row" style="gap:8px">
    <select onchange="S.tabPais=this.value;S.tabDiv=0;render()">${Object.keys(LIGAS).map(p=>`<option ${p===pa?'selected':''}>${p}</option>`).join("")}</select>
    <select onchange="S.tabDiv=+this.value;S.tabPais='${pa}';render()">${LIGAS[pa].map((_,i)=>`<option value="${i}" ${i===dv?'selected':''}>${LIGANOME[pa][i]}</option>`).join("")}</select></div>
    ${meuView?'':`<button class="s sm" style="margin-top:8px" onclick="S.tabPais=null;S.tabDiv=null;render()">↩ Voltar à minha liga</button>`}</div>`;
  const L=S.ligas&&S.ligas[chaveLiga(pa,dv)];
  const rod=meuView?Math.min(S.rodada,S.fixt.length):(L?L.k:0),tot=meuView?S.fixt.length:(L?L.R:0);
  h+=`<div class="card"><div class="tag">${LIGANOME[pa][dv]} · rodada ${rod}/${tot}</div><table style="margin-top:6px"><tr><th>#</th><th>Clube</th><th>P</th><th>J</th><th>V</th><th>SG</th></tr>`;
  const nDiv=LIGAS[pa].length,kk=Math.min(4,Math.floor(t.length/4));
  t.forEach((c,i)=>{
    const meu=(meuView&&c.nome===S.clubes[S.meu].nome);
    const sobe=dv>0&&i<kk,cai=dv<nDiv-1&&i>=t.length-kk;
    const bd=sobe?'#34d98b':cai?'#ff5d6c':'transparent';
    h+=`<tr style="${meu?'background:#245a3f':''}"><td style="border-left:3px solid ${bd};padding-left:4px">${i+1}</td><td>${escudo(infoCor(pa,c.nome),16)} ${c.nome}</td><td><b>${c.pts}</b></td><td>${c.j}</td><td>${c.v}</td><td>${c.gp-c.gc}</td></tr>`;
  });
  h+=`</table><small class="mu">${dv>0?'Verde: zona de acesso · ':''}${dv<nDiv-1?'Vermelho: zona de rebaixamento':''}</small></div>`;
  // artilharia
  let art=[];
  if(meuView){
    art=S.clubes.flatMap(c=>c.elenco.map(j=>({nome:j.nome,clube:c.sig,g:j.golsLiga||0,art:j.art||0,j})) ).filter(x=>x.g>0).sort((a,b)=>b.g-a.g).slice(0,8);
  }else if(L){
    art=Object.keys(L.gols).map(kk=>{const ix=kk.lastIndexOf("#");const clube=kk.slice(0,ix),sl=+kk.slice(ix+1);return{clube,sl,g:L.gols[kk]}})
      .sort((a,b)=>b.g-a.g).slice(0,8).map(x=>{
        const ch=chaveFixa(pa,x.clube);let nome="Jogador",artN=0;
        if(ch){const kc=chaveClube(pa,ch.div,ch.idx);try{nome=nomeDoSlot(kc,pa,ch.div,ch.idx,x.sl);artN=(S.mundo&&S.mundo[kc]&&S.mundo[kc].c[x.sl])?S.mundo[kc].c[x.sl][3]:0}catch(e){}}
        const inf=infoPorNome2(pa,x.clube);
        return{nome,clube:inf.sig||x.clube.slice(0,3).toUpperCase(),g:x.g,art:artN,j:{art:artN}};
      });
  }
  h+=`<div class="card"><h3>Artilharia</h3><table>${art.length?art.map(x=>`<tr><td>${x.nome} ${estrelaHTML(x.j)}<br><small class="mu">${x.art} artilharia(s)</small></td><td>${x.clube}</td><td><b>${x.g}</b></td></tr>`).join(""):'<tr><td class="mu">Nenhum gol ainda.</td></tr>'}</table></div>`;
  let ast=[];
  if(meuView){
    ast=S.clubes.flatMap(c=>c.elenco.map(j=>({nome:j.nome,clube:c.sig,a:j.assistLiga||0,g:j.golsLiga||0,j}))).filter(x=>x.a>0).sort((a,b)=>b.a-a.a||b.g-a.g).slice(0,8);
  }else if(L&&L.ass){
    ast=Object.keys(L.ass).map(kk=>{const ix=kk.lastIndexOf("#");return{clube:kk.slice(0,ix),sl:+kk.slice(ix+1),a:L.ass[kk],g:(L.gols&&L.gols[kk])||0}})
      .sort((x,y)=>y.a-x.a||y.g-x.g).slice(0,8).map(x=>{
        const ch=chaveFixa(pa,x.clube);let nome="Jogador";
        if(ch){const kc=chaveClube(pa,ch.div,ch.idx);try{nome=nomeDoSlot(kc,pa,ch.div,ch.idx,x.sl)}catch(e){}}
        const inf=infoPorNome2(pa,x.clube);
        return{nome,clube:inf.sig||x.clube.slice(0,3).toUpperCase(),a:x.a,g:x.g,j:{}};
      });
  }
  h+=`<div class="card"><h3>Assistências</h3><table>${ast.length?ast.map(x=>`<tr><td>${x.nome}<br><small class="mu">${x.g?x.g+' gol(s)':''}</small></td><td>${x.clube}</td><td><b>${x.a}</b></td></tr>`).join(""):'<tr><td class="mu">Nenhuma assistência ainda.</td></tr>'}</table></div>`;

  if(trHTML)h+=trHTML;
  if(meuView&&S.hist.length)h+=`<div class="card"><h3>Histórico</h3>${S.hist.map(x=>`<div>Temp. ${x.temp}: campeão ${x.campeao} · você ${x.meu}º</div>`).join("")}</div>`;
  return h;
}
function infoCor(pais,nome){const ch=chaveFixa(pais,nome);if(!ch)return{cor:"#445566",cor2:"#fff"};const c=LIGAS[pais][ch.div][ch.idx];return{nome:nome,cor:c[2],cor2:c[3]}}
function infoPorNome2(pais,nome){const ch=chaveFixa(pais,nome);if(!ch)return{sig:""};const c=LIGAS[pais][ch.div][ch.idx];return{sig:c[1]}}



// ===== TELA: BASE DE DADOS (2.0.0-alpha) =====
function setEscClube(i){const v=document.getElementById("esc"+i).value.trim();S.clubes[i].esc=v||null;save();render()}
function setKitClube(i,v){S.clubes[i].kit=+v||1;save();render()}
function reaplicaElencos(){let n=0;S.clubes.forEach(function(c){try{if(realizaElenco(c)){c.forca=forcaMedia(c);n++}}catch(e){}});try{S.clubes.forEach(c=>auto(c))}catch(e){}save();render();aviso(n+" elenco(s) reais aplicados.")}
function dbExportar(){
  const out={ver:DB_VER,gerado:new Date().toISOString(),clubes:S.clubes.map(function(c,i){return {i:i,nome:c.nome,pais:c.pais,div:c.div,liga:c.liga,est:c.est?{nome:c.est.nome,base:c.est.base,nivel:c.est.nivel}:null,esc:c.esc||null,kit:c.kit||1,uniformes:[1,2,3].map(function(n){const k=kitDe(c,n);return [k.c1,k.c2,k.pat]})}})};
  try{const ta=document.getElementById("dbjson");ta.value=JSON.stringify(out,null,1);ta.focus();ta.select();document.execCommand&&document.execCommand("copy");toast("JSON gerado e copiado")}catch(e){aviso("Não foi possível copiar. Selecione o texto e copie manualmente.")}
}
function dbImportar(){
  const ta=document.getElementById("dbjson");let d;
  try{d=JSON.parse(ta.value)}catch(e){return aviso("JSON inválido: "+e.message)}
  if(!d||!d.clubes)return aviso("JSON sem a chave 'clubes'.");
  let n=0;
  d.clubes.forEach(function(o){
    const c=(o.i!=null&&S.clubes[o.i]&&(!o.nome||S.clubes[o.i].nome===o.nome))?S.clubes[o.i]:S.clubes.find(function(x){return x.nome===o.nome});
    if(!c)return;
    if(o.esc!==undefined)c.esc=o.esc||null;
    if(o.kit)c.kit=+o.kit;
    if(o.est){c.est=c.est||{};if(o.est.nome)c.est.nome=o.est.nome;if(o.est.base)c.est.base=+o.est.base;if(o.est.nivel!=null)c.est.nivel=+o.est.nivel}
    if(Array.isArray(o.uniformes)&&o.uniformes.length)KITS_REAL[c.nome]=o.uniformes.map(function(u){return [u[0],u[1],u[2]||"listras"]});
    n++;
  });
  save();render();aviso(n+" clube(s) atualizados pela base.");
}
function abaDB(){
  const st=dbStats();
  const eu=S.clubes[S.meu];
  let h=topoAba("📦","Base de dados · v"+DB_VER,"Dados reais, editáveis e versionados",[[st.reais+"/"+st.tot,"Clubes com elenco real"],[st.est+"/"+st.tot,"Estádios reais"],[st.kit+"/"+st.tot,"Uniformes 1·2·3"]]);
  h+=`<div class="card"><div class="tag" style="margin-bottom:6px">Fontes da base</div>
  ${linhaInfo("Clubes (nome, país, liga, cores)","1200 clubes · 20 países","g")}
  ${linhaInfo("Estádios (nome e capacidade)",st.est+" cadastrados","g")}
  ${linhaInfo("Uniformes (1º, 2º e 3º)",st.kit+" clubes com 3 kits","y")}
  ${linhaInfo("Jogadores reais",st.jog+" clubes · resto gerado","y")}
  <small class="mu" style="display:block;margin-top:6px">Tudo aqui é gravado no save e pode ser sobrescrito por JSON, sem tocar no código do jogo.</small>
  <button class="sm big" onclick="reaplicaElencos()">♻️ Reaplicar elencos reais</button></div>`;
  h+=`<div class="card"><div class="tag" style="margin-bottom:8px">Clubes da minha divisão</div>`;
  S.clubes.forEach(function(c,i){
    const k1=kitDe(c,1),k2=kitDe(c,2),k3=kitDe(c,3);
    const sw=function(k){return `<i style="display:inline-block;width:15px;height:15px;border-radius:3px;border:1px solid #0007;background:linear-gradient(90deg,${k.c1} 50%,${k.c2} 50%)"></i>`};
    h+=`<div style="padding:7px 0;border-top:1px solid var(--bd)">
      <div class="row"><div style="min-width:0"><b style="font-size:13px">${escudo(c,18)} ${c.nome}</b><br>
      <small class="mu">${c.liga||""} · ${c.est?c.est.nome:"—"} · ${c.elenco.length} jogadores · ${JOG_REAL[c.nome]?JOG_REAL[c.nome].length+" reais":"gerado"}</small></div>
      <div style="display:flex;gap:3px;align-items:center">${sw(k1)}${sw(k2)}${sw(k3)}<select style="width:auto;padding:4px;font-size:12px" onchange="setKitClube(${i},this.value)">${[1,2,3].map(n=>`<option value="${n}" ${(c.kit||1)===n?'selected':''}>${n}º</option>`).join("")}</select></div></div>
      <input id="esc${i}" placeholder="URL do escudo (opcional)" value="${c.esc?String(c.esc).replace(/"/g,'&quot;'):''}" onchange="setEscClube(${i})" style="margin-top:6px;font-size:12px">
    </div>`;
  });
  h+=`</div>`;
  h+=`<div class="card"><div class="tag" style="margin-bottom:6px">Atualizar a base (JSON)</div>
  <small class="mu" style="display:block;margin-bottom:6px">Exporte, edite fora do jogo e cole de volta: clubes, estádios, escudos e uniformes. As chaves são o nome do clube.</small>
  <textarea id="dbjson" rows="6" placeholder='{"ver":"2.0.0-alpha","clubes":[{"nome":"Flamengo","est":{"nome":"Maracanã","base":78838},"uniformes":[["#c8102e","#111111","listras"],["#ffffff","#111111","solida"],["#0b0b0b","#c8102e","listras"]]}]}' style="width:100%;font-family:monospace;font-size:12px"></textarea>
  <div class="row" style="margin-top:8px"><button class="sm s" onclick="dbExportar()">⬇️ Exportar</button><button class="sm" onclick="dbImportar()">⬆️ Importar</button></div></div>`;
  return h;
}


// ===== TELA: CLUBES (schema completo · auditoria · exportação) =====
function abaClubes(){
  const st=dbAuditoria();
  const paises=[...new Set(S.clubes.map(c=>c.pais||S.pais))];
  const f=S.dbPais||"__todos";
  if(S.dbBusca==null)S.dbBusca="";
  const q=(S.dbBusca||"").toLowerCase();
  const lista=S.clubes.filter(function(c){
    if(f!=="__todos"&&(c.pais||S.pais)!==f)return false;
    if(!q)return true;
    return (c.nome+" "+(c.nomeOficial||"")+" "+(c.nomeInternacional||"")+" "+(c.liga||"")).toLowerCase().indexOf(q)>=0;
  });
  let h=topoAba("🛡","Clubes · "+CLUBE_DB_VER,"Nomes oficiais, escudos, uniformes, estádios e orçamento",[
    [String(S.clubes.length),"Clubes na liga"],[String(st.comLogo),"Com escudo real"],[String(st.idsDup.length+st.nomesDup.length),"Inconsistências"]]);
  h+=`<div class="card"><div class="tag" style="margin-bottom:6px">Auditoria da base (Etapa 7)</div>
  ${linhaInfo("IDs duplicados",st.idsDup.length?st.idsDup.join(", "):"nenhum",st.idsDup.length?"r":"g")}
  ${linhaInfo("Nomes repetidos",st.nomesDup.length?st.nomesDup.join(", "):"nenhum",st.nomesDup.length?"y":"g")}
  ${linhaInfo("Escudos faltando",st.semLogo+" de "+S.clubes.length,st.semLogo?"y":"g")}
  ${linhaInfo("Uniformes sem dados",st.kitVazio,st.kitVazio?"r":"g")}
  ${linhaInfo("Jogadores órfãos",st.orfaos,st.orfaos?"r":"g")}
  <small class="mu" style="display:block;margin-top:6px">Clubes sem escudo real usam o escudo procedural do jogo (nunca deforma: a imagem é sempre 'contain' dentro de uma caixa fixa).</small></div>`;
  h+=`<div class="card"><div class="row" style="gap:6px"><select style="width:auto;padding:6px" onchange="S.dbPais=this.value;render()"><option value="__todos">Todos os países</option>${paises.map(p=>`<option ${f===p?'selected':''}>${p}</option>`).join("")}</select><input placeholder="Buscar clube..." value="${(S.dbBusca||'').replace(/"/g,'&quot;')}" oninput="S.dbBusca=this.value;render()" style="flex:1"></div></div>`;
  h+=`<div class="card"><div class="tag" style="margin-bottom:6px">${lista.length} clube(s)</div>`;
  lista.forEach(function(c){
    const k1=kitDe(c,1),k2=kitDe(c,2),k3=kitDe(c,3);
    const sw=k=>`<i title="${k.n}" style="display:inline-block;width:14px;height:14px;border-radius:3px;border:1px solid #0008;background:${k.pat==='listras'?`repeating-linear-gradient(90deg,${k.c1} 0 3px,${k.c2} 3px 6px)`:k.pat==='metade'?`linear-gradient(90deg,${k.c1} 50%,${k.c2} 50%)`:k.pat==='faixa'?`linear-gradient(180deg,${k.c1} 0 35%,${k.c2} 35% 65%,${k.c1} 65%)`:k.c1}"></i>`;
    h+=`<div style="padding:8px 0;border-top:1px solid var(--bd)">
      <div class="row"><div style="min-width:0"><b style="font-size:13px">${escudo(c,22)} ${c.nome}</b>
      <br><small class="mu">${c.nomeOficial||c.nome}</small>
      <br><small class="mu">${c.liga||""} · ${c.estadio?c.estadio.nome:(c.est?c.est.nome:"—")}${c.estadio?" · "+Number(c.estadio.capacidade).toLocaleString("pt-BR")+" lugares":""}</small></div>
      <div style="text-align:right"><div style="display:flex;gap:3px;justify-content:flex-end">${sw(k1)}${sw(k2)}${sw(k3)}</div>
      <small class="mu">${"★".repeat(c.reputacao||1)} · ${R$(c.orcamento||0)}</small></div></div>
      <div style="display:flex;gap:4px;margin-top:6px;justify-content:flex-end">
        <span style="height:34px">${camisaSVG(c,false,false,null,1)}</span><span style="height:34px">${camisaSVG(c,false,false,null,2)}</span><span style="height:34px">${camisaSVG(c,false,false,null,3)}</span></div>
      <div class="tag" style="margin-top:5px">id ${c.id} · ${c.nomeInternacional||c.nome} · ${c.elenco.length} jogadores${(CLUBE_DB[c.nome]?" · base verificada": "")}</div></div>`;
  });
  h+=`</div>`;
  h+=`<div class="card"><div class="tag" style="margin-bottom:6px">Exportar base (JSON)</div><textarea id="dbjson" rows="5" style="width:100%;font-family:monospace;font-size:11px"></textarea><button class="sm big" onclick="dbExportar2()">⬇️ Gerar e copiar JSON</button></div>`;
  return h;
}
function dbExportar2(){
  const out={versao:CLUBE_DB_VER,gerado:new Date().toISOString(),clubes:S.clubes.map(function(c){
    return {id:c.id,nome:c.nome,nomeCurto:c.nomeCurto,nomeOficial:c.nomeOficial,nomeInternacional:c.nomeInternacional,
      pais:c.pais,liga:c.liga,logo:c.logo||"",uniformeCasa:c.uniformeCasa,uniformeFora:c.uniformeFora,uniformeTerceiro:c.uniformeTerceiro,
      estadio:c.estadio||{nome:c.est?c.est.nome:"",capacidade:c.est?c.est.base:0},reputacao:c.reputacao,orcamento:c.orcamento};
  })};
  const ta=document.getElementById("dbjson");ta.value=JSON.stringify(out,null,1);
  try{ta.select();document.execCommand&&document.execCommand("copy");toast("JSON gerado e copiado")}catch(e){aviso("Selecione o texto e copie.")}
}
function dbAuditoria(){
  const ids={},nomes={},idsDup=[],nomesDup=[];let comLogo=0,semLogo=0,kitVazio=0,orfaos=0;
  const N=S.clubes.length;
  S.clubes.forEach(function(c,i){
    if(ids[c.id]!=null)idsDup.push(c.nome);else ids[c.id]=i;
    const k=(c.nome||"").trim().toLowerCase();
    if(nomes[k])nomesDup.push(c.nome);else nomes[k]=i;
    if(c.logo||c.esc||c.escudo)comLogo++;else semLogo++;
    if(!c.uniformeCasa||!c.uniformeFora||c.uniformeCasa.indexOf("|")<0)kitVazio++;
    (c.elenco||[]).forEach(function(j){if(j.id==null)orfaos++});
  });
  try{(S.props||[]).forEach(function(p){if(p.clube==null||p.clube<0||p.clube>=N)orfaos++})}catch(e){}
  return {idsDup:idsDup,nomesDup:nomesDup,comLogo:comLogo,semLogo:semLogo,kitVazio:kitVazio,orfaos:orfaos};
}

function abaEd(){
  let h=`<div class="card"><h3>Editor de clubes e jogadores</h3><small class="mu">Renomeie clubes e jogadores como quiser. Salvo automaticamente.</small><button class="sm big" onclick="ir('db')">📦 Base de dados realista (uniformes, estádios, escudos)</button></div>`;
  S.clubes.forEach((c,i)=>{h+=`<div class="card"><div class="row"><div class="tag">Clube ${i+1}</div><div>${escudo(c,28)}</div></div><input value="${c.nome}" onchange="S.clubes[${i}].nome=this.value;save()">
  <label class="tag" style="display:block;margin-top:8px">🖼 Escolher escudo da galeria<input type="file" accept="image/*" style="display:none" onchange="setEscudo(${i},this)"></label><button class="sm s" style="margin-top:6px" onclick="S.clubes[${i}].escudo=null;save();render()">Remover escudo</button><details style="margin-top:8px"><summary>Jogadores (${c.elenco.length})</summary>${c.elenco.map((j,k)=>`<input style="margin-top:4px" value="${j.nome}" onchange="S.clubes[${i}].elenco[${k}].nome=this.value;save()">`).join("")}</details></div>`});
  return h;
}

document.addEventListener('click',()=>audio(),{once:true});
S=null;telaTitulo=true;render();

/* ================================================================
   MÓDULO v11 — escudos reais (pasta/galeria), vários técnicos humanos
   (estilo Brasfoot) e sala online (Firebase). Carrega DEPOIS do jogo.
   ================================================================ */

/* ---------- 1) ESCUDOS ---------------------------------------------------
   Ordem de busca de cada escudo:
   1. escudo escolhido à mão no Editor (c.escudo)
   2. escudo importado da galeria (guardado no aparelho)
   3. arquivo na pasta  escudos/<nome-do-clube>.png  (junto do index.html)
   4. escudo desenhado padrão (cores do clube)                             */
const ESC={base:(function(){try{return localStorage.getItem('escBase')||'assets/escudos/'}catch(e){return'assets/escudos/'}})(),exts:['png','svg','webp','jpg'],falha:{},local:{}};
function escSlug(n){return String(n||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'')}
const _escudoOrig=escudo;
escudo=function(c,sz){
  sz=sz||18;
  if(!c||c.escudo)return _escudoOrig(c,sz);
  const slug=escSlug(c.nome);
  if(!slug)return _escudoOrig(c,sz);
  if(ESC.local[slug])return`<img src="${ESC.local[slug]}" style="width:${sz}px;height:${sz}px;object-fit:contain;vertical-align:middle">`;
  const k=ESC.falha[slug];
  if(k===undefined||k<ESC.exts.length){
    const i=k===undefined?0:k;
    return`<img src="${ESC.base}${slug}.${ESC.exts[i]}" data-s="${slug}" data-i="${i}" data-a="${c.cor||'#444'}" data-b="${c.cor2||'#fff'}" data-z="${sz}" onerror="escErro(this)" style="width:${sz}px;height:${sz}px;object-fit:contain;vertical-align:middle">`;
  }
  return _escudoOrig(c,sz);
};
function escErro(img){
  const s=img.dataset.s,i=(+img.dataset.i)+1;ESC.falha[s]=i;
  if(i<ESC.exts.length){img.dataset.i=i;img.src=ESC.base+s+'.'+ESC.exts[i];return}
  img.onerror=null;img.outerHTML=_escudoOrig({cor:img.dataset.a,cor2:img.dataset.b},+img.dataset.z);
}
/* guarda os escudos importados da galeria no IndexedDB (sobrevive a fechar o app) */
function escDB(fn){try{const rq=indexedDB.open('manager_escudos',1);rq.onupgradeneeded=()=>rq.result.createObjectStore('e');rq.onsuccess=()=>{try{fn(rq.result)}catch(e){}};rq.onerror=()=>{}}catch(e){}}
function escCarregaLocais(){escDB(db=>{const r=db.transaction('e').objectStore('e').openCursor();r.onsuccess=()=>{const c=r.result;if(c){ESC.local[c.key]=c.value;c.continue()}else{try{render()}catch(e){}}}})}
function escTodosClubes(){const o=[];try{Object.keys(LIGAS).forEach(p=>LIGAS[p].forEach((d,di)=>d.forEach(c=>o.push({nome:c[0],pais:p,div:di}))))}catch(e){}return o}
function escImportar(inp){
  const fs=[...inp.files];if(!fs.length)return;let ok=0,sem=[];const nomes={};escTodosClubes().forEach(c=>nomes[escSlug(c.nome)]=c.nome);
  let falta=fs.length;
  const fim=()=>{if(--falta>0)return;try{render()}catch(e){}aviso(`✅ ${ok} escudo(s) importado(s).`+(sem.length?`\n\n⚠️ ${sem.length} arquivo(s) não bateram com nenhum clube (o nome do arquivo precisa ser o nome do clube):\n`+sem.slice(0,12).join(', ')+(sem.length>12?'…':''):''))};
  fs.forEach(f=>{
    const slug=escSlug(f.name.replace(/\.[^.]+$/,''));
    if(!nomes[slug]){sem.push(f.name);return fim()}
    const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{
      const cv=document.createElement('canvas');cv.width=cv.height=96;const x=cv.getContext('2d');const k=Math.min(96/im.width,96/im.height);
      x.drawImage(im,(96-im.width*k)/2,(96-im.height*k)/2,im.width*k,im.height*k);
      const url=cv.toDataURL('image/png');ESC.local[slug]=url;ok++;escDB(db=>db.transaction('e','readwrite').objectStore('e').put(url,slug));fim()};
      im.onerror=()=>{sem.push(f.name);fim()};im.src=r.result};
    r.onerror=()=>{sem.push(f.name);fim()};r.readAsDataURL(f);
  });
}
function escLimpaLocais(){confirma('Apagar todos os escudos importados da galeria deste aparelho?',()=>{ESC.local={};escDB(db=>db.transaction('e','readwrite').objectStore('e').clear());render()})}
function escBaixaLista(){
  const txt=escTodosClubes().map(c=>escSlug(c.nome)+'.png\t'+c.nome+'\t'+c.pais).join('\n');
  const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([txt],{type:'text/plain'}));a.download='escudos_lista.txt';a.click();
}
function escSalvaBase(v){v=(v||'').trim();if(v&&!/\/$/.test(v))v+='/';ESC.base=v||'assets/escudos/';try{localStorage.setItem('escBase',ESC.base)}catch(e){}ESC.falha={};render()}
function escCard(){
  const todos=escTodosClubes(),loc=Object.keys(ESC.local).length;
  return`<div class="card"><h3>🛡️ Escudos dos clubes</h3>
  <small class="mu">O jogo procura cada escudo em <b>${ESC.base}nome-do-clube.png</b> (ex.: <code>${ESC.base}atletico-mineiro.png</code>) e, se não achar, usa o escudo desenhado.<br>Importados da galeria neste aparelho: <b>${loc}</b> de ${todos.length} clubes.</small>
  <label class="tag" style="display:block;margin-top:8px;padding:10px;text-align:center">📥 Importar vários escudos da galeria<input type="file" accept="image/*" multiple style="display:none" onchange="escImportar(this)"></label>
  <small class="mu">Dica: salve cada imagem com o nome do clube (ex.: <i>Flamengo.png</i>, <i>Atlético Mineiro.png</i>) — o jogo liga o arquivo ao clube sozinho.</small>
  <div class="row" style="margin-top:8px"><button class="s sm" onclick="escBaixaLista()">📄 Baixar lista de nomes de arquivo</button><button class="s sm" onclick="escLimpaLocais()">🗑 Limpar importados</button></div>
  <label class="tag" style="display:block;margin-top:8px">Pasta/URL dos escudos (online)</label><input value="${ESC.base}" onchange="escSalvaBase(this.value)"></div>`;
}
const _abaEd=abaEd;abaEd=function(){return escCard()+_abaEd()};
try{escCarregaLocais()}catch(e){}

/* ---------- 2) VÁRIOS TÉCNICOS HUMANOS ----------------------------------
   Cada clube controlado por humano tem  c.hum = {nome, uid?, tt:{...}}
   O técnico "ativo" (quem está com a tela) é sempre S.meu; trocar de técnico
   guarda a tática do atual dentro do clube dele e carrega a do outro.      */
const TT_PAD={form:null,tatica:'Equilibrada',marc:'Normal',conc:'Pelo meio',cap:null,cob:null,cobPen:null,esc:null,padrao:false,subs:0};
function ttAtivo(){return{tatica:S.tatica||'Equilibrada',marc:S.marc||'Normal',conc:S.conc||'Pelo meio'}}
function ehHc(c){return!!c&&(c===S.clubes[S.meu]||!!c.hum)}
function TTc(c){
  if(!c)return{tatica:'Equilibrada',marc:'Normal',conc:'Pelo meio'};
  if(c===S.clubes[S.meu])return ttAtivo();
  if(c.hum){const t=c.hum.tt||(c.hum.tt=Object.assign({},TT_PAD));return{tatica:t.tatica||'Equilibrada',marc:t.marc||'Normal',conc:t.conc||'Pelo meio'}}
  return{tatica:'Equilibrada',marc:'Normal',conc:'Pelo meio'};
}
function humInit(){const c=S.clubes[S.meu];if(c&&!c.hum)c.hum={nome:S.treinador||'Técnico',tt:{}}}
function guardaTT(){const c=S.clubes[S.meu];if(!c)return;if(!c.hum)c.hum={nome:S.treinador||'Técnico'};c.hum.tt={form:S.form,tatica:S.tatica,marc:S.marc,conc:S.conc,cap:S.cap,cob:S.cob,cobPen:S.cobPen,esc:S.esc,padrao:S.padrao,subs:S.subs||0}}
function carregaTT(c){
  const t=Object.assign({},TT_PAD,c.hum&&c.hum.tt||{});
  S.form=t.form||c.form||S.form;c.form=S.form;S.tatica=t.tatica;S.marc=t.marc;S.conc=t.conc;S.cap=t.cap;S.cob=t.cob;S.cobPen=t.cobPen;S.esc=t.esc;S.padrao=t.padrao;
  S.subs=S.live?(t.subs||0):0;if(c.hum&&c.hum.nome)S.treinador=c.hum.nome;
}
function humLista(){if(!S._clbak)humInit();const base=S._clbak?S._clbak.clubes:S.clubes;return base.filter(c=>c.hum)}
function humCount(){if(!S||!S.clubes||!S.clubes[S.meu])return 0;return humLista().length}
function humPreparaOutros(){ /* chamado no início de cada jogo: completa o time dos outros humanos (suspensos/lesionados) */
  S.clubes.forEach(c=>{
    if(!c.hum||c.id===S.meu)return;
    try{
      if(c.hum.tt)c.hum.tt.subs=0;
      if(c.elenco.some(x=>x.tit&&(x.suspenso>0||x.lesao>0))){c.elenco.forEach(x=>{if((x.suspenso>0||x.lesao>0)&&x.tit)x.tit=false});auto(c,true)}
      garante11(c,true);
    }catch(e){}
  });
}
function trocaTecnico(ci,irTatica){
  if(!S||ci===S.meu)return false;
  const alvo=S.clubes[ci];if(!alvo||!alvo.hum)return false;
  if(S._clbak)return aviso('Termine esta partida de copa antes de trocar de técnico.'),false;
  if(S.live&&S.live.janela)return aviso('Feche a janela de escalação antes de trocar de técnico.'),false;
  humInit();guardaTT();S.meu=ci;carregaTT(alvo);S.selId=null;
  if(S.live){const i=S.live.jogos.findIndex(j=>j.a===ci||j.b===ci);if(i>=0)S.live.ver=i}
  if(!S.live)S.aba=irTatica?'tat':S.aba;
  save();render();toast('👤 Agora controlando: '+alvo.hum.nome+' ('+alvo.nome+')');return true;
}
function humAddDlg(){
  if(S.live)return aviso('Espere a partida terminar para adicionar técnicos.');
  humInit();const livres=S.clubes.filter(c=>!c.hum).sort((a,b)=>a.nome.localeCompare(b.nome));
  if(!livres.length)return aviso('Todos os clubes desta divisão já têm técnico humano.');
  modal(`<b>➕ Adicionar técnico humano</b><div class="mu" style="font-size:12px;margin:6px 0 10px">Ele passa a controlar o clube escolhido, com escalação e tática próprias. Os técnicos se revezam no mesmo aparelho (use o botão 👤 para trocar).</div>
   <label class="tag">Nome do técnico</label><input id="humNome" placeholder="Ex.: Maria" maxlength="24">
   <label class="tag" style="display:block;margin-top:8px">Clube</label><select id="humClube">${livres.map(c=>`<option value="${c.id}">${c.nome}</option>`).join('')}</select>
   <div class="row" style="margin-top:12px"><button class="s" onclick="fechaDlg()">Cancelar</button><button onclick="humAdd()">Adicionar</button></div>`);
}
function humAdd(){
  const nome=(document.getElementById('humNome').value||'').trim()||('Técnico '+(humCount()+1));
  const ci=+document.getElementById('humClube').value,c=S.clubes[ci];if(!c||c.hum)return;
  c.hum={nome,tt:Object.assign({},TT_PAD,{form:c.form})};fechaDlg();save();render();toast('✅ '+nome+' assumiu o '+c.nome);
}
function humRemove(ci){
  const c=S.clubes[ci];if(!c||!c.hum||ci===S.meu)return;
  confirma('Tirar '+c.hum.nome+' do '+c.nome+'? O clube volta a ser controlado pelo computador.',()=>{delete c.hum;save();render()});
}
function humStatus(c){const n=titularesAptos(c).length;return n>=11?'<span class="g">✅ 11 aptos</span>':'<span class="y">⚠️ '+n+' aptos (completa sozinho)</span>'}
function abaHum(){
  humInit();const L=humLista();
  let h=`<div class="card"><h3>👥 Técnicos humanos</h3><small class="mu">Estilo Brasfoot: vários técnicos no mesmo jogo, cada um com o seu clube. Quem está com a tela é o <b>técnico ativo</b>; toque em <b>Controlar</b> para passar a vez.</small></div>`;
  L.forEach(c=>{
    const ativo=c.id===S.meu,on=c.hum.uid?`<span class="tag">🌐 online</span>`:'';
    h+=`<div class="card"><div class="row"><div>${escudo(c,26)} <b>${c.nome}</b><br><small class="mu">Técnico: ${c.hum.nome} ${on}</small></div><div style="text-align:right">${ativo?'<span class="tag" style="background:#14532d;color:#fff">ativo</span>':''}<br><small>${humStatus(c)}</small></div></div>
    <div class="row" style="margin-top:8px">${ativo?'<button class="s sm" onclick="ir(\'tat\')">📋 Tática</button>':`<button class="sm" onclick="trocaTecnico(${c.id},true)">🎮 Controlar</button>`}${(!ativo&&!c.hum.uid)?`<button class="s sm" onclick="humRemove(${c.id})">Remover</button>`:''}</div></div>`;
  });
  h+=`<button class="big" onclick="humAddDlg()">➕ Adicionar técnico</button>
  <div class="card" style="margin-top:12px"><small class="mu">ℹ️ Nesta versão os técnicos precisam ser da <b>mesma divisão</b>. Dinheiro, bilheteria e mercado detalhados rodam para o técnico que estiver ativo na hora; os demais jogam com a escalação e a tática que deixaram salvas.</small></div>`;
  return h;
}
function humMenu(){
  const L=humLista();
  modal(`<div class="row"><b>👤 Técnicos</b><button class="sm" onclick="fechaDlg()">Fechar</button></div>`+
   L.map(c=>`<div class="clube" onclick="fechaDlg();trocaTecnico(${c.id},false)" style="${c.id===S.meu?'outline:1px solid var(--ac)':''}"><span>${escudo(c,20)} <b>${c.hum.nome}</b><br><small class="mu">${c.nome}</small></span><span class="tag">${c.id===S.meu?'ativo':'controlar'}</span></div>`).join('')+
   `<button class="s big" onclick="fechaDlg();ir('hum')">Gerenciar técnicos</button>`);
}
function humChip(){
  let b=document.getElementById('humChip');
  const mostrar=S&&!telaTitulo&&(humCount()>1||(ONL&&ONL.on));
  if(!mostrar){if(b)b.remove();return}
  const c=S.clubes[S.meu];if(!c)return;
  if(!b){b=document.createElement('button');b.id='humChip';b.className='sm';document.body.appendChild(b)}
  b.onclick=()=>ONL.on&&ONL.papel==='guest'?ir('onl'):humMenu();
  b.innerHTML=(ONL.on?'🌐 ':'👤 ')+(c.hum?c.hum.nome:S.treinador)+' ▾';
}
const _render=render;render=function(){_render.apply(this,arguments);try{humChip()}catch(e){}};

/* abertura de rodada: lista os técnicos e deixa cada um ajustar o time antes de apitar */
function humDlgRodada(){
  const L=humLista();
  modal(`<b>🏁 Antes de começar a rodada</b><div class="mu" style="font-size:12px;margin:4px 0 8px">Cada técnico confere a escalação do seu time. Quando todos estiverem prontos, inicie.</div>`+
   L.map(c=>{
     const g=ONL.on&&ONL.papel==='host'&&c.hum.uid?ONL.jog[c.hum.uid]:null,pr=g?(g.pronto&&ONL.merged[c.hum.uid]===ONL.ver):null;
     return`<div class="clube"><span>${escudo(c,20)} <b>${c.hum.nome}</b>${c.hum.uid?' 🌐':''}<br><small class="mu">${c.nome} · ${c.hum.uid?(pr?'<span class=g>✅ pronto</span>':'<span class=y>⏳ aguardando</span>'):humStatus(c)}</small></span>${c.hum.uid?'':`<button class="sm" onclick="fechaDlg();trocaTecnico(${c.id},true)">Ajustar</button>`}</div>`}).join('')+
   `<div class="row" style="margin-top:10px"><button class="s" onclick="fechaDlg()">Voltar</button><button onclick="humIniciar()">⚽ Iniciar rodada</button></div>`);
}
function humIniciar(){fechaDlg();S._humOk=true;ONL.forcar=true;comecaRodada()}
const _comecaRodada=comecaRodada;
comecaRodada=function(){
  if(!S)return;
  let liga=false;try{if(!S.agenda||S.dia==null)agendaMonta();const d=S.agenda&&S.agenda[S.dia];liga=!!(d&&d.comp==='liga')}catch(e){}
  if(!S.live&&ONL.on&&ONL.papel==='guest'){return onlGuestPronto()}
  if(!S.live&&liga&&!S._humOk){
    const precisa=humCount()>1||(ONL.on&&ONL.papel==='host'&&onlConvidados().length);
    if(precisa&&!(ONL.on&&ONL.papel==='host'&&onlTodosProntos()&&humCount()<=1+onlConvidados().length)){return humDlgRodada()}
  }
  const tinhaLive=!!S.live;
  try{
    if(!tinhaLive&&ONL.on&&ONL.papel==='host')onlAntesRodada();
    _comecaRodada.apply(this,arguments);
  }finally{S._humOk=false;ONL.forcar=false}
  if(!tinhaLive&&!S.live&&ONL.on&&ONL.papel==='host')onlPosRodada();
};
const _fimLive=fimLive;
fimLive=function(){_fimLive.apply(this,arguments);if(ONL.on&&ONL.papel==='host'&&!S.live)onlPosRodada()};
const _abaLive=abaLive;
abaLive=function(){
  let sw='';
  if(humCount()>1&&!S._clbak){sw=`<div class="row" style="flex-wrap:wrap;gap:6px;margin-bottom:8px">`+humLista().map(c=>`<button class="sm ${c.id===S.meu?'':'s'}" onclick="trocaTecnico(${c.id},false)">👤 ${c.hum.nome}</button>`).join('')+`</div>`}
  return sw+_abaLive.apply(this,arguments);
};

/* ---------- 3) ONLINE (Firebase Realtime Database) ----------------------
   Modelo: o anfitrião roda a simulação e guarda o savegame na sala.
   Cada amigo entra com o código, escolhe um clube livre e monta o time no
   próprio celular; ao tocar em "Jogar" manda a escalação (pronto). Quando
   todos estiverem prontos o anfitrião inicia a rodada e todos acompanham ao vivo. */
const ONL={on:false,papel:null,codigo:null,uid:null,nome:null,db:null,jog:{},ver:0,fase:'prep',live:null,forcar:false,offs:[],merged:{},msg:'',ocupado:false,timerLive:null,timerPatch:null};
const ONL_SDK='10.12.2';
const FIREBASE_CONFIG=null; // opcional: cole aqui o objeto firebaseConfig. Hospedando no Firebase Hosting isso não é necessário.
function onlConvidados(){return Object.keys(ONL.jog).filter(u=>u!==ONL.uid)}
function onlTodosProntos(){const c=onlConvidados();return c.every(u=>ONL.jog[u]&&ONL.jog[u].pronto&&ONL.merged[u]===ONL.ver)}
function onlScript(src){return new Promise((ok,er)=>{const s=document.createElement('script');s.src=src;s.onload=ok;s.onerror=()=>er(new Error('Não consegui carregar '+src.split('/').pop()+' (sem internet?)'));document.head.appendChild(s)})}
async function onlConfig(){
  try{const m=localStorage.getItem('fbcfg');if(m)return JSON.parse(m)}catch(e){}
  if(FIREBASE_CONFIG)return FIREBASE_CONFIG;
  try{const r=await fetch('/__/firebase/init.json');if(r.ok){const j=await r.json();if(j&&j.apiKey)return j}}catch(e){}
  return null;
}
async function onlInicia(){
  if(ONL.db&&ONL.uid)return;
  if(!(window.firebase&&firebase.database)){for(const n of['app','auth','database'])await onlScript('https://www.gstatic.com/firebasejs/'+ONL_SDK+'/firebase-'+n+'-compat.js')}
  const cfg=await onlConfig();
  if(!cfg)throw new Error('SEM_CONFIG');
  if(!cfg.databaseURL)throw new Error('Falta o "databaseURL" no config. Crie o Realtime Database no console do Firebase.');
  if(!firebase.apps.length)firebase.initializeApp(cfg);
  const cr=await firebase.auth().signInAnonymously();
  ONL.uid=(cr.user||firebase.auth().currentUser).uid;ONL.db=firebase.database();
}
function onlConfigDlg(){
  modal(`<b>🔧 Configurar Firebase</b><div class="mu" style="font-size:12px;margin:6px 0">Se o jogo estiver hospedado no Firebase Hosting isso é automático. Senão, cole aqui o objeto <i>firebaseConfig</i> (Console → Configurações do projeto → Seus apps → Config), incluindo o <b>databaseURL</b>.</div>
  <textarea id="fbcfg" style="width:100%;height:150px;background:var(--card2);color:var(--tx);border:1px solid var(--bd);border-radius:8px;padding:8px" placeholder='{"apiKey":"...","authDomain":"...","databaseURL":"https://SEU-PROJETO-default-rtdb.firebaseio.com","projectId":"..."}'></textarea>
  <div class="row" style="margin-top:10px"><button class="s" onclick="fechaDlg()">Cancelar</button><button onclick="onlSalvaConfig()">Salvar</button></div>`);
}
function onlSalvaConfig(){
  let t=document.getElementById('fbcfg').value.trim();
  try{t=t.replace(/^[^{]*/,'').replace(/;?\s*$/,'');let o;try{o=JSON.parse(t)}catch(e){o=(new Function('return('+t+')'))()}
    if(!o||!o.apiKey)throw 0;localStorage.setItem('fbcfg',JSON.stringify(o));fechaDlg();toast('Configuração salva');render()}catch(e){aviso('Não entendi esse texto. Cole o objeto firebaseConfig inteiro (começando em { e terminando em }).')}
}
function onlErro(e){
  if(e&&e.message==='SEM_CONFIG'){aviso('O Firebase ainda não foi configurado neste jogo.',()=>onlConfigDlg());return}
  const m=(e&&e.code||'')+' '+(e&&e.message||e);
  if(/admin-restricted|operation-not-allowed/.test(m))return aviso('Ative o login Anônimo no Firebase:\nConsole → Authentication → Método de login → Anônimo → Ativar.');
  if(/PERMISSION_DENIED|permission_denied/.test(m))return aviso('O Firebase recusou o acesso. Confira se as regras do Realtime Database foram publicadas (arquivo database.rules.json).');
  aviso('Erro online:\n'+m);
}
const ONL_CH=250000;
async function onlGz(txt){
  if(typeof CompressionStream==='undefined')return'P'+txt;
  const cs=new CompressionStream('gzip'),w=cs.writable.getWriter();w.write(new TextEncoder().encode(txt));w.close();
  const buf=new Uint8Array(await new Response(cs.readable).arrayBuffer());let bin='';
  for(let i=0;i<buf.length;i+=0x8000)bin+=String.fromCharCode.apply(null,buf.subarray(i,i+0x8000));
  return'G'+btoa(bin);
}
async function onlUngz(s){
  if(s[0]==='P')return s.slice(1);
  const bin=atob(s.slice(1)),u=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)u[i]=bin.charCodeAt(i);
  const ds=new DecompressionStream('gzip'),w=ds.writable.getWriter();w.write(u);w.close();return await new Response(ds.readable).text();
}
function onlRef(p){return ONL.db.ref('salas/'+ONL.codigo+(p?'/'+p:''))}
async function onlPut(path,txt,extra){ // grava texto comprimido em pedaços
  const g=await onlGz(txt),o=Object.assign({n:Math.ceil(g.length/ONL_CH)},extra||{});
  for(let i=0;i<o.n;i++)o['c'+i]=g.slice(i*ONL_CH,(i+1)*ONL_CH);
  await onlRef(path).set(o);return g.length;
}
async function onlGet(path){
  const s=await onlRef(path).get(),o=s.val();if(!o)return null;
  let g='';for(let i=0;i<o.n;i++)g+=o['c'+i]||'';return{txt:await onlUngz(g),meta:o};
}
function onlCodigo(){const a='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';let c='';for(let i=0;i<5;i++)c+=a[Math.floor(Math.random()*a.length)];return c}
function onlLimpaOuvintes(){ONL.offs.forEach(f=>{try{f()}catch(e){}});ONL.offs=[];clearInterval(ONL.timerLive);ONL.timerLive=null}
function onlOuve(path,cb){const r=onlRef(path),f=r.on('value',s=>{try{cb(s.val())}catch(e){console.log(e)}});ONL.offs.push(()=>r.off('value',f))}
function onlAtualizaTela(){try{if(S&&(S.aba==='onl'||document.getElementById('dlg')))render()}catch(e){}}

/* ---- anfitrião ---- */
async function onlCriarSala(retomar){
  if(!S||S.live)return aviso('Abra o jogo (e termine a partida em andamento) antes de criar a sala.');
  if(ONL.ocupado)return;ONL.ocupado=true;ONL.msg='Conectando…';render();
  try{
    await onlInicia();humInit();
    let cod=retomar&&S.sala?S.sala.codigo:null;
    if(!cod){for(let i=0;i<8;i++){const c=onlCodigo(),sn=await ONL.db.ref('salas/'+c+'/meta').get();if(!sn.exists()){cod=c;break}}}
    if(!cod)throw new Error('Não consegui gerar um código livre. Tente de novo.');
    ONL.codigo=cod;ONL.papel='host';ONL.on=true;ONL.merged={};
    const sn=await onlRef('meta').get();
    if(sn.exists()&&sn.val().host!==ONL.uid)throw new Error('Essa sala pertence a outro anfitrião.');
    ONL.ver=sn.exists()?(sn.val().ver||0):0;
    S.sala={codigo:cod};
    await onlRef('meta').update({host:ONL.uid,anfitriao:S.treinador,clube:S.clubes[S.meu].nome,criada:firebase.database.ServerValue.TIMESTAMP,fase:'prep'});
    await onlRef('jogadores/'+ONL.uid).set({nome:S.treinador,clube:S.clubes[S.meu].nome,pronto:true,host:true});
    await onlPushEstado();
    onlOuve('jogadores',onlJogadoresMudou);
    ONL.msg='';save();
  }catch(e){ONL.on=false;ONL.papel=null;ONL.msg='';onlErro(e)}
  ONL.ocupado=false;render();
}
async function onlPushEstado(){
  const ver=ONL.ver+1,txt=serializaJogo();
  const bytes=await onlPut('estado/v'+ver,txt,{rodada:S.rodada,temp:S.temp});
  await onlRef('meta').update({ver,fase:'prep',rodada:S.rodada,temp:S.temp,kb:Math.round(bytes/1024),t:firebase.database.ServerValue.TIMESTAMP});
  if(ver>2)onlRef('estado/v'+(ver-2)).remove().catch(()=>{});
  ONL.ver=ver;ONL.merged={};
  const u={};Object.keys(ONL.jog).forEach(k=>{if(k!==ONL.uid)u[k+'/pronto']=false});
  if(Object.keys(u).length)await onlRef('jogadores').update(u);
}
function onlJogadoresMudou(v){
  ONL.jog=v||{};
  if(ONL.papel==='host'&&S){
    let mudou=false;
    Object.keys(ONL.jog).forEach(u=>{
      const j=ONL.jog[u];if(u===ONL.uid||!j.clube)return;
      const c=S.clubes.find(x=>x.nome===j.clube);
      if(c&&!c.hum){c.hum={nome:j.nome,uid:u,tt:Object.assign({},TT_PAD,{form:c.form})};mudou=true;toast('🌐 '+j.nome+' entrou com o '+c.nome)}
      if(c&&c.hum&&!c.hum.uid&&c.id!==S.meu){c.hum.uid=u;c.hum.nome=j.nome;mudou=true}
      if(j.pronto&&ONL.merged[u]!==ONL.ver&&!S.live)onlMesclaPatch(u);
    });
    if(mudou)save();
  }
  onlAtualizaTela();
}
async function onlMesclaPatch(uid){
  if(ONL.merged[uid]==='...'+ONL.ver)return;ONL.merged[uid]='...'+ONL.ver;
  try{
    const r=await onlGet('patch/'+uid);if(!r){ONL.merged[uid]=null;return}
    if(r.meta.base!==ONL.ver){ONL.merged[uid]=null;return}
    const p=JSON.parse(r.txt),c=S.clubes.find(x=>x.nome===p.c.nome);if(!c||!c.hum||c.hum.uid!==uid){ONL.merged[uid]=null;return}
    const manter={};['id','pts','j','v','e','d','gp','gc'].forEach(k=>manter[k]=c[k]);
    const hum=Object.assign({},c.hum,{tt:p.c.hum&&p.c.hum.tt||c.hum.tt});
    Object.assign(c,p.c,manter);c.hum=hum;c.hum.uid=uid;
    ONL.merged[uid]=ONL.ver;save();onlAtualizaTela();
  }catch(e){ONL.merged[uid]=null;console.log('patch',e)}
}
function onlAntesRodada(){
  onlRef('meta').update({fase:'jogando'}).catch(()=>{});
  onlRef('ao_vivo').remove().catch(()=>{});
  clearInterval(ONL.timerLive);ONL.timerLive=setInterval(onlTransmite,1800);setTimeout(onlTransmite,300);
}
function onlSnapLive(){
  const L=S.live;if(!L)return null;
  const lance=g=>{const e=g.ev.filter(x=>x.t==='g'||x.t==='c').slice(-1)[0];if(!e)return'';let n='';try{n=(nj2(g,e)||e.n||'')}catch(x){n=e.n||''}return(e.t==='g'?'⚽':(e.verm?'🟥':'🟨'))+' '+n.split(' ').slice(-1)[0]+' '+e.m+"' - "+(e.m<=45?'1º':'2º')};
  const nomesH=new Set(humLista().map(c=>c.id));
  return{t:Date.now(),min:L.min,tit:(()=>{try{return tituloAoVivo()}catch(e){return''}})(),
    jogos:L.jogos.map(g=>{const A=S.clubes[g.a],B=S.clubes[g.b],h=nomesH.has(g.a)||nomesH.has(g.b);
      return{a:A.nome,b:B.nome,ca:A.cor,cb:B.cor,cc:A.cor2||'#fff',cd:B.cor2||'#fff',ga:g.ga,gb:g.gb,est:g.est||'',pub:g.pub||0,lance:lance(g),h:h?1:0,
        ev:h?g.ev.filter(x=>x.t==='g'||x.t==='c').slice(-10).map(e=>{let n='';try{n=nj2(g,e)||e.n||''}catch(x){n=e.n||''}return{m:e.m,k:e.t==='g'?'g':(e.verm?'v':'a'),n,l:e.lado}}):null}})};
}
function onlTransmite(){
  if(!ONL.on||ONL.papel!=='host')return;
  if(!S.live){clearInterval(ONL.timerLive);ONL.timerLive=null;return}
  try{onlRef('ao_vivo').set(onlSnapLive()).catch(()=>{})}catch(e){}
}
async function onlPosRodada(){
  clearInterval(ONL.timerLive);ONL.timerLive=null;
  try{await onlRef('ao_vivo').remove();await onlPushEstado();save()}catch(e){console.log('posRodada',e)}
  onlAtualizaTela();
}
async function onlEncerrar(){
  confirma(ONL.papel==='host'?'Encerrar a sala? Os amigos serão desconectados (o seu jogo continua salvo).':'Sair da sala?',async()=>{
    try{if(ONL.papel==='host'){await onlRef('').remove();delete S.sala}else{await onlRef('jogadores/'+ONL.uid+'/pronto').set(false)}}catch(e){}
    onlLimpaOuvintes();ONL.on=false;ONL.papel=null;ONL.codigo=null;ONL.jog={};ONL.live=null;
    if(S&&S._eraConvidado){S=null;telaTitulo=true}
    save();render();
  });
}

/* ---- convidado ---- */
function onlEntrarDlg(){
  modal(`<b>🌐 Entrar em sala online</b><div class="mu" style="font-size:12px;margin:6px 0 10px">Peça ao anfitrião o código da sala.</div>
  <label class="tag">Código da sala</label><input id="onlCod" maxlength="5" style="text-transform:uppercase" placeholder="ABCDE" value="${localStorage.getItem('onlCod')||''}">
  <label class="tag" style="display:block;margin-top:8px">Seu nome de técnico</label><input id="onlNome" maxlength="24" value="${localStorage.getItem('tn')||''}">
  <div class="row" style="margin-top:12px"><button class="s" onclick="fechaDlg()">Cancelar</button><button onclick="onlEntrar()">Entrar</button></div>`);
}
async function onlEntrar(){
  const cod=(document.getElementById('onlCod').value||'').trim().toUpperCase(),nome=(document.getElementById('onlNome').value||'').trim();
  if(cod.length<4||!nome)return aviso('Digite o código da sala e o seu nome.');
  fechaDlg();ONL.msg='Conectando…';modal('<div style="text-align:center">🌐 Entrando na sala…<br><small class="mu">baixando o jogo do anfitrião</small></div>');
  try{
    await onlInicia();ONL.codigo=cod;ONL.nome=nome;localStorage.setItem('onlCod',cod);localStorage.setItem('tn',nome);
    const m=(await onlRef('meta').get()).val();if(!m)throw new Error('Sala "'+cod+'" não encontrada.');
    const r=await onlGet('estado/v'+m.ver);if(!r)throw new Error('O anfitrião ainda não publicou o jogo.');
    onlAplicaSave(r.txt);ONL.ver=m.ver;ONL.papel='guest';S._eraConvidado=true;
    const eu=(await onlRef('jogadores/'+ONL.uid).get()).val();
    fechaDlg();
    if(eu&&eu.clube){const c=S.clubes.find(x=>x.nome===eu.clube);if(c)return onlAssume(c,eu.nome||nome)}
    onlEscolheClubeDlg();
  }catch(e){fechaDlg();ONL.papel=null;ONL.codigo=null;onlErro(e)}
}
function onlAplicaSave(txt){
  const d=JSON.parse(txt);S=d;SLOT_ATUAL=null;S._slot=null;S._mem={};
  const _vAntes=(S._v==null?1:S._v);
  try{ligasDoSave(S.ligas)}catch(e){}
  migraJogo();garante();try{if(typeof migraSaveVersao==='function')migraSaveVersao(_vAntes)}catch(e){}try{if(typeof dbMigraSave==='function')dbMigraSave()}catch(e){}S.live=null;S.extras=0;
  ['cl','lb','cn','el','sa'].forEach(k=>{if(S[k])S[k].jogouHoje=false});
  delete S._clbak;delete S.clAoVivo;if(S.aba==='live'||S.aba==='pos')S.aba='home';
  telaTitulo=false;NOVO={passo:0,nome:'',pais:null,div:null};
}
function onlEscolheClubeDlg(){
  const livres=S.clubes.filter(c=>!c.hum).sort((a,b)=>a.nome.localeCompare(b.nome));
  modal(`<b>Escolha o seu clube</b><div class="mu" style="font-size:12px;margin:4px 0 8px">Só aparecem os clubes livres.</div><div style="max-height:55vh;overflow:auto">`+
   (livres.length?livres.map(c=>`<div class="clube" onclick="onlReserva(${c.id})"><span>${escudo(c,22)} <b>${c.nome}</b></span><span class="tag">força ${Math.round(c.forca||0)}</span></div>`).join(''):'<div class="mu">Todos os clubes já têm técnico.</div>')+`</div><button class="s big" onclick="fechaDlg();onlSairLocal()">Cancelar</button>`);
}
function onlSairLocal(){onlLimpaOuvintes();ONL.on=false;ONL.papel=null;ONL.codigo=null;S=null;telaTitulo=true;render()}
async function onlReserva(ci){
  const c=S.clubes[ci];if(!c||c.hum)return;fechaDlg();
  try{
    const slug=escSlug(c.nome),tr=await onlRef('reservas/'+slug).transaction(cur=>cur?undefined:ONL.uid);
    if(!tr.committed){aviso('Esse clube acabou de ser escolhido por outra pessoa.',()=>onlEscolheClubeDlg());return}
    if(ONL.reservaAtual&&ONL.reservaAtual!==slug)onlRef('reservas/'+ONL.reservaAtual).remove().catch(()=>{});
    ONL.reservaAtual=slug;
    await onlRef('jogadores/'+ONL.uid).set({nome:ONL.nome,clube:c.nome,pronto:false});
    onlAssume(c,ONL.nome);
  }catch(e){onlErro(e)}
}
function onlAssume(c,nome){
  c.hum={nome,uid:ONL.uid,tt:Object.assign({},TT_PAD,{form:c.form})};
  S.meu=c.id;S.treinador=nome;carregaTT(c);S.aba='home';ONL.on=true;ONL.papel='guest';S._eraConvidado=true;
  onlOuve('jogadores',v=>{ONL.jog=v||{};onlAtualizaTela()});
  onlOuve('ao_vivo',v=>{ONL.live=v;if(v&&S&&S.aba!=='onl'&&!ONL._foiLive){ONL._foiLive=true;S.aba='onl'}if(!v)ONL._foiLive=false;try{render()}catch(e){}});
  onlOuve('meta',onlMetaMudou);
  render();toast('🌐 Você é o técnico do '+c.nome);
}
async function onlMetaMudou(m){
  if(!m){if(ONL.papel==='guest'){aviso('O anfitrião encerrou a sala.',()=>onlSairLocal())}return}
  ONL.fase=m.fase;
  if(ONL.papel==='guest'&&m.ver>ONL.ver&&!ONL._baixando){
    ONL._baixando=true;
    try{
      const r=await onlGet('estado/v'+m.ver);if(r){
        const uid=ONL.uid,nome=ONL.nome,cNome=(S.clubes[S.meu]||{}).nome,aba=S.aba;
        onlAplicaSave(r.txt);ONL.ver=m.ver;
        const c=S.clubes.find(x=>x.nome===cNome);S._eraConvidado=true;ONL.pronto=false;
        if(c){if(!c.hum)c.hum={nome,uid,tt:{}};c.hum.uid=uid;S.meu=c.id;carregaTT(c);S.aba=aba==='live'?'home':aba;render();toast('🔄 Jogo sincronizado — rodada '+(S.rodada+1))}
        else{render();aviso('Seu clube saiu desta divisão (subiu ou caiu). Escolha outro clube livre para continuar.',()=>onlEscolheClubeDlg())}
      }
    }catch(e){console.log('sync',e)}
    ONL._baixando=false;
  }
  onlAtualizaTela();
}
async function onlEnviaPatch(){
  if(!ONL.on||ONL.papel!=='guest'||!ONL.pronto)return;
  guardaTT();const c=S.clubes[S.meu];
  const txt=JSON.stringify({c},(k,v)=>k==='_clube'?undefined:v);
  await onlPut('patch/'+ONL.uid,txt,{base:ONL.ver,t:Date.now()});
  await onlRef('jogadores/'+ONL.uid+'/pronto').set(true);
}
async function onlGuestPronto(){
  const c=S.clubes[S.meu];
  try{const r=garante11(c,false);if(!r.ok)return}catch(e){}
  if(titularesAptos(c).length<11)return aviso('Faltam jogadores aptos em campo. Ajuste a escalação na Tática.');
  if(ONL.pronto){ONL.pronto=false;try{await onlRef('jogadores/'+ONL.uid+'/pronto').set(false)}catch(e){}toast('Você cancelou o "pronto"');render();return}
  ONL.pronto=true;
  try{await onlEnviaPatch();toast('✅ Pronto! Aguardando o anfitrião iniciar');}catch(e){ONL.pronto=false;onlErro(e)}
  render();
}
const _save=save;
save=function(){
  _save.apply(this,arguments);
  if(ONL.on&&ONL.papel==='guest'&&ONL.pronto){clearTimeout(ONL.timerPatch);ONL.timerPatch=setTimeout(()=>onlEnviaPatch().catch(()=>{}),1500)}
};
/* o mercado mexe em outros clubes: só no aparelho do anfitrião */
const _abaMer=abaMer;
abaMer=function(){
  if(ONL.on&&ONL.papel==='guest')return`<div class="card"><h3>💱 Mercado</h3><div class="mu" style="margin-top:6px">Nesta versão o mercado de transferências funciona só no aparelho do anfitrião (ele mexe em outros clubes). Peça para o anfitrião fechar a contratação.</div></div>`;
  return _abaMer.apply(this,arguments);
};

/* ---- tela 🌐 Online ---- */
function abaOnl(){
  let h='';
  if(!ONL.on){
    h+=`<div class="card"><h3>🌐 Jogar online com amigos</h3><small class="mu">O anfitrião (quem tem o jogo) cria uma sala e passa o código. Cada amigo entra pelo código na tela inicial, escolhe um clube livre e controla o próprio time no seu celular.</small>
    ${ONL.msg?`<div class="tag" style="margin-top:8px">${ONL.msg}</div>`:''}
    <button class="big" onclick="onlCriarSala(false)">➕ Criar sala (sou o anfitrião)</button>
    ${S&&S.sala?`<button class="s big" onclick="onlCriarSala(true)">↩ Retomar sala ${S.sala.codigo}</button>`:''}
    <button class="s big" onclick="onlEntrarDlg()">🔑 Entrar numa sala com código</button>
    <button class="s big" onclick="onlConfigDlg()">🔧 Configurar Firebase</button></div>`;
    return h;
  }
  h+=`<div class="card"><div class="row"><div><h3>🌐 Sala ${ONL.codigo}</h3><small class="mu">${ONL.papel==='host'?'Você é o anfitrião':'Você é convidado'} · versão ${ONL.ver} · ${ONL.fase==='jogando'?'🔴 rodada em andamento':'🟢 preparação'}</small></div><button class="s sm" onclick="onlEncerrar()">${ONL.papel==='host'?'Encerrar':'Sair'}</button></div></div>`;
  const ids=Object.keys(ONL.jog);
  h+=`<div class="card"><div class="tag" style="margin-bottom:6px">Técnicos na sala (${ids.length})</div>`+ids.map(u=>{
    const j=ONL.jog[u],pr=j.host?true:(j.pronto&&(ONL.papel!=='host'||ONL.merged[u]===ONL.ver));
    return`<div class="row" style="padding:6px 0;border-top:1px solid var(--bd)"><span><b>${j.nome}</b>${u===ONL.uid?' (você)':''}${j.host?' 👑':''}<br><small class="mu">${j.clube||'escolhendo clube…'}</small></span><span class="tag">${pr?'✅ pronto':'⏳ montando'}</span></div>`}).join('')+`</div>`;
  if(ONL.papel==='host'){
    h+=`<div class="card"><small class="mu">Compartilhe o código <b style="color:var(--ac);font-size:16px">${ONL.codigo}</b>. Quando todos estiverem ✅ toque em <b>Jogar</b> no Início para começar a rodada (ou inicie mesmo assim).</small><button class="big" onclick="ir('home')">🏠 Ir para o Início</button></div>`;
  }else{
    h+=`<div class="card"><small class="mu">Monte seu time na <b>Tática</b>. Quando estiver pronto, toque em <b>Jogar</b> — a escalação é enviada ao anfitrião, que inicia a rodada.</small>
    <button class="big" onclick="ir('tat')">📋 Tática</button><button class="${ONL.pronto?'s':''} big" onclick="onlGuestPronto()">${ONL.pronto?'✅ Pronto (toque para cancelar)':'⚽ Estou pronto'}</button></div>`;
  }
  const v=ONL.live;
  if(v){
    h+=`<div class="bfLista"><div class="bfDv">🔴 Ao vivo · ${v.min}' ${v.tit?'· '+v.tit:''}</div>`+(v.jogos||[]).map(g=>`<div class="bfJ ${g.h?'meu':''}"><span class="bfE">${g.est||''}${g.pub?' | '+Math.round(g.pub/1000)+'k':''}</span><div class="bfC" style="--c1:${g.ca};--c2:${g.cc}">${escudo({nome:g.a,cor:g.ca,cor2:g.cc},15)}<span>${g.a}</span></div><div class="bfS ${g.ga>g.gb?'w':''}">${g.ga}</div><div class="bfS ${g.gb>g.ga?'w':''}">${g.gb}</div><div class="bfC d" style="--c1:${g.cb};--c2:${g.cd}"><span>${g.b}</span>${escudo({nome:g.b,cor:g.cb,cor2:g.cd},15)}</div><span class="bfL">${g.lance||''}</span></div>`).join('')+`</div>`;
    const meus=(v.jogos||[]).filter(g=>g.ev&&g.ev.length);
    meus.forEach(g=>{h+=`<div class="card"><div class="tag">${g.a} ${g.ga} x ${g.gb} ${g.b}</div><div class="lv" style="max-height:120px">${g.ev.slice().reverse().map(e=>`<div>${e.k==='g'?'⚽':e.k==='v'?'🟥':'🟨'} ${e.m}' ${e.n}</div>`).join('')}</div></div>`});
  }
  return h;
}

/* ---------- 4) virada de temporada: técnicos cujo clube saiu da divisão ---------- */
const _reconstroiMinhaLiga=reconstroiMinhaLiga;
reconstroiMinhaLiga=function(){
  let antes=[];try{antes=humLista().map(c=>({n:c.nome,h:c.hum.nome}))}catch(e){}
  const r=_reconstroiMinhaLiga.apply(this,arguments);
  try{
    const nomes=new Set(S.clubes.map(c=>c.nome)),fora=antes.filter(x=>!nomes.has(x.n));
    if(fora.length){
      Object.values(S.ext||{}).forEach(x=>{if(x&&x.hum&&!nomes.has(x.nome))delete x.hum});
      setTimeout(()=>aviso('🔀 Subida/descida de divisão:\n'+fora.map(x=>x.h+' ('+x.n+')').join('\n')+'\n\nficou fora da sua divisão e o clube passa a ser controlado pelo computador. Para jogarem juntos de novo, adicione o técnico em um clube desta divisão (☰ → Técnicos).'),700);
    }
  }catch(e){}
  return r;
};

/* ---------- 5) saves antigos: descarta o envelope do multiplayer removido (S.mp) ---------- */
const _carregaSlot=carregaSlot;
carregaSlot=function(){const r=_carregaSlot.apply(this,arguments);try{if(S&&S.mp)delete S.mp}catch(e){}return r};

/* ---------- 6) EQUILÍBRIO: elencos reais na escala interna de cada liga ----------
   Os 9 elencos reais (JOG_REAL) usavam a nota crua (75–90) enquanto o resto do mundo
   usa a escala interna (Brasil ≈ 34–43, Inglaterra ≈ 49–57). Aqui a nota real é
   convertida: a média dos clubes reais de um país fica um pouco abaixo do pico da liga
   (PICO_LIGA) e a diferença entre eles e entre jogadores é preservada pela metade.      */
const BAL={esc:0.5,folga:2};
function balPais(nome){try{for(const p of Object.keys(LIGAS)){if(LIGAS[p][0].some(c=>c[0]===nome))return p}}catch(e){}return null}
function balTopMedia(arr){const f=arr.map(r=>r[4]).sort((a,b)=>b-a).slice(0,11);return f.reduce((a,b)=>a+b,0)/Math.max(1,f.length)}
function balRef(pais){const m=Object.keys(JOG_REAL).filter(n=>balPais(n)===pais).map(n=>balTopMedia(JOG_REAL[n]));return m.length?m.reduce((a,b)=>a+b,0)/m.length:null}
function balNota(f,pais){const ref=balRef(pais);if(ref==null)return f;const T=picoDe(pais,0)-BAL.folga;return Math.max(20,Math.min(95,Math.round((T+(f-ref)*BAL.esc)*10)/10))}
function balReescala(c,soSeCru){
  if(!c||!JOG_REAL[c.nome])return false;
  const pais=balPais(c.nome);if(!pais)return false;
  const reais=c.elenco.filter(j=>j.real);if(!reais.length)return false;
  const top=c.elenco.map(j=>j.f).sort((a,b)=>b-a).slice(0,11),M=top.reduce((a,b)=>a+b,0)/Math.max(1,top.length);
  if(soSeCru&&M<=picoDe(pais,0)+8)return false;           // já está na escala interna (save novo ou já migrado)
  const mk=mkDaChave((S?S.pais:'Brasil')+'|'+(S?S.div:0)+'|0');
  reais.forEach(j=>{const p0=j.pot==null?j.f:j.pot;j.f=balNota(j.f,pais);j.pot=Math.max(j.f,balNota(p0,pais));j.val=valorDe(j.f,j.idade,j.pot,mk);j.sal=salarioDe(j.f,mk)});
  c.forca=forcaMedia(c);return true;
}
const _realizaElenco=realizaElenco;
realizaElenco=function(c){const ok=_realizaElenco.apply(this,arguments);if(ok){try{balReescala(c,false)}catch(e){}}return ok};
/* saves antigos: converte uma vez os elencos reais que ainda estão na nota crua */
const _carregaSlot2=carregaSlot;
carregaSlot=function(){
  const r=_carregaSlot2.apply(this,arguments);
  try{if(S&&S.clubes){let n=0;S.clubes.forEach(c=>{if(balReescala(c,true))n++});if(n){save();render();toast('⚖️ Elencos reais ajustados à escala da liga ('+n+')')}}}catch(e){}
  return r;
};

/* ================================================================
   SELEÇÕES NACIONAIS — integradas ao modo carreira
   Tudo fica em S.sel (vai junto no save). Nada do motor foi removido:
   o módulo se encaixa por "ganchos" (calendário, disponibilidade, telas).
   ================================================================ */
function selFlagIso(iso){
  if(iso==='ENG')return String.fromCodePoint(0x1F3F4,0xE0067,0xE0062,0xE0065,0xE006E,0xE0067,0xE007F);
  if(iso==='SCT')return String.fromCodePoint(0x1F3F4,0xE0067,0xE0062,0xE0073,0xE0063,0xE0074,0xE007F);
  return String.fromCodePoint(...iso.split('').map(c=>127397+c.charCodeAt(0)));
}
// [nome, iso, confederação, nível-base (escala interna do jogo)]
const SEL_DEF=[
 ["Brasil","BR","CONMEBOL",58],["Argentina","AR","CONMEBOL",58],["Colômbia","CO","CONMEBOL",50],["Uruguai","UY","CONMEBOL",50],["Equador","EC","CONMEBOL",46],["Chile","CL","CONMEBOL",44],["Paraguai","PY","CONMEBOL",42],["Peru","PE","CONMEBOL",42],
 ["França","FR","UEFA",59],["Espanha","ES","UEFA",59],["Inglaterra","ENG","UEFA",58],["Alemanha","DE","UEFA",56],["Portugal","PT","UEFA",55],["Itália","IT","UEFA",54],["Holanda","NL","UEFA",54],["Bélgica","BE","UEFA",52],["Croácia","HR","UEFA",51],["Suíça","CH","UEFA",48],["Dinamarca","DK","UEFA",48],["Turquia","TR","UEFA",48],["Polônia","PL","UEFA",47],["Áustria","AT","UEFA",47],["Rússia","RU","UEFA",45],["Escócia","SCT","UEFA",44],
 ["México","MX","CONCACAF",48],["Estados Unidos","US","CONCACAF",48],["Canadá","CA","CONCACAF",43],["Costa Rica","CR","CONCACAF",40],["Panamá","PA","CONCACAF",38],["Jamaica","JM","CONCACAF",38],
 ["Marrocos","MA","CAF",49],["Senegal","SN","CAF",48],["Nigéria","NG","CAF",46],["Costa do Marfim","CI","CAF",46],["Egito","EG","CAF",45],["Argélia","DZ","CAF",45],["Gana","GH","CAF",44],["Camarões","CM","CAF",44],["Tunísia","TN","CAF",43],["África do Sul","ZA","CAF",40],
 ["Japão","JP","AFC",49],["Coreia do Sul","KR","AFC",47],["Irã","IR","AFC",45],["Austrália","AU","AFC",44],["Arábia Saudita","SA","AFC",42],["Catar","QA","AFC",40],["Uzbequistão","UZ","AFC",39],["Iraque","IQ","AFC",38]
];
const SEL_PAISES=SEL_DEF.map(d=>d[0]);
const SEL_INFO={};SEL_DEF.forEach(d=>SEL_INFO[d[0]]={nome:d[0],iso:d[1],flag:selFlagIso(d[1]),conf:d[2],base:d[3]});
function fl(p){return SEL_INFO[p]?SEL_INFO[p].flag:'🏳️'}
const SEL_CONFS=['UEFA','CONMEBOL','CONCACAF','CAF','AFC'];
const SEL_COMPS={
  copa:{n:'Copa do Mundo',ic:'🏆',max:26,premio:5e6},euro:{n:'Eurocopa',ic:'🇪🇺',max:26,premio:3e6},ca:{n:'Copa América',ic:'🌎',max:26,premio:3e6},
  can:{n:'Copa Africana de Nações',ic:'🌍',max:26,premio:2.5e6},asia:{n:'Copa da Ásia',ic:'🌏',max:26,premio:2.5e6},ouro:{n:'Copa Ouro',ic:'🥇',max:26,premio:2.5e6},
  nl:{n:'UEFA Nations League',ic:'🇪🇺',max:23,premio:2e6},elim:{n:'Eliminatórias da Copa',ic:'🎯',max:23,premio:0},ami:{n:'Amistoso internacional',ic:'🤝',max:23,premio:0}
};
const SEL_QUOTA26={GOL:3,ZAG:5,LD:2,LE:2,VOL:3,MEI:4,PE:3,ATA:4},SEL_QUOTA23={GOL:3,ZAG:4,LD:2,LE:2,VOL:3,MEI:3,PE:3,ATA:3};
const SEL_POS=[['GOL','Goleiros'],['LD','Laterais direitos'],['LE','Laterais esquerdos'],['ZAG','Zagueiros'],['VOL','Volantes'],['MEI','Meias'],['PE','Pontas'],['ATA','Atacantes']];
const SELV={pool:{},map:{}};          // cache só da sessão (não vai pro save)

function selRng(chave){return rngSeed(semente('sel|'+chave+'|'+(S&&S.seed!=null?S.seed:0)))}
function selIni(){
  if(!S)return null;
  if(S.sel&&S.sel.v)return S.sel;
  const s=S.sel={v:1,tec:{},meu:null,rank:{},conv:{},comps:{},hist:[],js:{},vp:{},ult:[],props:[],recusas:{},jan:0,
    tecst:{j:0,v:0,e:0,d:0,gp:0,gc:0,tit:0,inv:0,maxInv:0,rkMax:null,por:{}},propAval:0};
  SEL_PAISES.forEach(p=>{
    const rg=selRng('tec|'+p),info=SEL_INFO[p];
    s.tec[p]={nome:(nomeJog?pickRg(rg,SILABAS1)+pickRg(rg,SILABAS2)+' '+pickRg(rg,SOBRE):'Técnico'),rep:Math.round(info.base+rg()*10-3),desde:S.temp||1,user:false};
    s.rank[p]=Math.round(1200+(info.base-45)*30+rg()*20);
    selGeraVP(p);
  });
  return s;
}
function pickRg(rg,a){return a[Math.floor(rg()*a.length)]}
/* Legionários: o "pelotão" que joga fora do campeonato jogável (e as seleções sem liga) */
function selGeraVP(p,qtd){
  const s=S.sel,info=SEL_INFO[p],rg=selRng('vp|'+p+'|'+(S.temp||1)+'|'+(s.vp[p]?s.vp[p].length:0));
  const lista=s.vp[p]||(s.vp[p]=[]);
  const molde=['GOL','GOL','ZAG','ZAG','ZAG','ZAG','LD','LE','VOL','VOL','VOL','MEI','MEI','MEI','PE','PE','PE','ATA','ATA','ATA'];
  const n=qtd||molde.length;
  for(let i=0;i<n;i++){
    const pos=molde[i%molde.length],star=(i%molde.length)>=11||i%4===0;
    const alvo=info.base+(star?3:-2)+Math.floor(rg()*9)-4;
    const x=criaJogadorFixo(pos,alvo,rg,null,null,p);
    lista.push({id:x.id,nome:x.nome,pos:x.pos,f:x.f,pot:x.pot,idade:x.idade,vp:1});
  }
}
/* Pool de candidatos de um país = jogadores da liga do país + estrangeiros reais + legionários */
function selPoolDe(p){
  if(SELV.pool[p])return SELV.pool[p];
  const out=[],vistos={};
  const add=(j,c,dom)=>{if(!j||vistos[j.id])return;vistos[j.id]=1;out.push({id:j.id,j,c,pais:p,dom})};
  if(LIGAS[p]){
    for(let i=0;i<LIGAS[p][0].length;i++){let c;try{c=clubeMundo(p,0,i)}catch(e){continue}
      if(c)c.elenco.forEach(j=>{if((j.nac||p)===p)add(j,c,true)})}
  }
  // estrangeiros reais e jogadores de clubes do meu campeonato
  try{S.clubes.forEach(c=>c.elenco.forEach(j=>{if(j.nac===p)add(j,c,true)}))}catch(e){}
  (S.sel.vp[p]||[]).forEach(j=>add(j,null,false));
  // reaplica a marca de convocado (jogadores gerados na hora não guardam a marca)
  const cv=S.sel.conv[p];
  if(cv&&cv.conf&&cv.ids){const set=new Set(cv.ids);out.forEach(r=>{if(set.has(r.id)&&r.c&&!r.j.conv)selMarca(r.j,p,cv.w)})}
  SELV.pool[p]=out;SELV.map[p]={};out.forEach(r=>SELV.map[p][r.id]=r);
  return out;
}
function selLimpaCache(){SELV.pool={};SELV.map={}}
function selMarca(j,p,w){if(j.conv)return;j.conv={p,w,lo:j.lesao>0?j.lesao:0};j.lesao=Math.max(j.lesao||0,999)}
function selDesmarca(j){if(!j||!j.conv)return;const lo=j.conv.lo||0;delete j.conv;j.lesao=Math.max(0,lo-1);j.en=100}
function selClubeNome(r){return r.c?r.c.nome:'Exterior'}
/* Dá o "mínimo de pontos de preparo" que o jogador teria para ser lembrado */
function selScore(r){
  const j=r.j,minutos=(j.jogou?2:0)+(j.tit?3:0),forma=Math.min(4,(j.golsLiga||0)*.4+(j.assistLiga||0)*.25);
  const idadeAj=j.idade<=22?(Math.min(j.pot||j.f,j.f+8)-j.f)*.25:(j.idade>=34?-(j.idade-33)*.7:0);
  return j.f+forma+minutos*.4+idadeAj+((j.pot||j.f)-j.f)*.05;
}
function selDisponivel(r){const j=r.j;return !(j.lesao>0&&!j.conv)&&!(j.suspenso>0)&&!j.expulso&&!j.emprestadoFora}
function selQuota(max){return max>=26?SEL_QUOTA26:SEL_QUOTA23}
/* Convocação automática (IA e botão "Completar" do usuário) */
function selAutoLista(p,max,jaIds){
  const quota=Object.assign({},selQuota(max)),pool=selPoolDe(p).filter(r=>selDisponivel(r)||(S.sel.conv[p]&&S.sel.conv[p].ids&&S.sel.conv[p].ids.includes(r.id)));
  const lista=(jaIds||[]).slice(),porPos={};pool.forEach(r=>(porPos[r.j.pos]=porPos[r.j.pos]||[]).push(r));
  const have={};lista.forEach(id=>{const r=SELV.map[p][id];if(r)have[r.j.pos]=(have[r.j.pos]||0)+1});
  Object.keys(quota).forEach(pos=>{
    const c=(porPos[pos]||[]).filter(r=>!lista.includes(r.id)).sort((a,b)=>selScore(b)-selScore(a));
    while((have[pos]||0)<quota[pos]&&c.length&&lista.length<max){const r=c.shift();lista.push(r.id);have[pos]=(have[pos]||0)+1}
  });
  // sobras: melhores restantes
  const resto=pool.filter(r=>!lista.includes(r.id)).sort((a,b)=>selScore(b)-selScore(a));
  while(lista.length<max&&resto.length)lista.push(resto.shift().id);
  return lista;
}
/* Aplica a convocação: marca os jogadores dos clubes e guarda a lista */
function selConfirma(p,ids,w,comp){
  const s=S.sel;selLiberaPais(p);
  selPoolDe(p);
  const okIds=ids.filter(id=>SELV.map[p][id]);
  s.conv[p]={ids:okIds,conf:true,w:w,comp:comp};
  okIds.forEach(id=>{const r=SELV.map[p][id];if(r.c)selMarca(r.j,p,w);selStat(r.j,p,'c')});
  return okIds;
}
function selLiberaPais(p){
  const cv=S.sel.conv[p];if(!cv||!cv.ids)return;
  selPoolDe(p);cv.ids.forEach(id=>{const r=SELV.map[p]&&SELV.map[p][id];if(r)selDesmarca(r.j)});
  cv.conf=false;
}
function selLiberaTodas(){
  const s=S.sel;Object.keys(s.conv).forEach(p=>selLiberaPais(p));
  // também limpa marcas órfãs nos clubes do meu campeonato (segurança contra saves interrompidos)
  try{S.clubes.forEach(c=>c.elenco.forEach(j=>{if(j.conv&&!(s.conv[j.conv.p]&&s.conv[j.conv.p].conf))selDesmarca(j)}))}catch(e){}
  Object.keys(S.ext||{}).forEach(k=>{try{S.ext[k].elenco.forEach(j=>{if(j.conv&&!(s.conv[j.conv.p]&&s.conv[j.conv.p].conf))selDesmarca(j)})}catch(e){}});
  selLimpaCache();
}
/* estatísticas pela seleção, guardadas por id do jogador */
function selStat(j,p,k,v){
  const js=S.sel.js,o=js[j.id]||(js[j.id]={p:p});
  if(k==='tit'){(o.t=o.t||[]).push(v);return o}
  o[k]=(o[k]||0)+(v==null?1:v);
  if(k==='j'&&!o.e)o.e=S.temp+'/'+(v||'ami');
  return o;
}
/* XI da seleção: melhores dos convocados em um 4-3-3 */
function selXI(p){
  const cv=S.sel.conv[p];selPoolDe(p);
  let refs=(cv&&cv.ids?cv.ids:[]).map(id=>SELV.map[p][id]).filter(Boolean);
  if(refs.length<14){refs=selAutoLista(p,23,[]).map(id=>SELV.map[p][id]).filter(Boolean)}
  const slots=[['GOL',1],['ZAG',2],['LD',1],['LE',1],['VOL',1],['MEI',2],['PE',2],['ATA',1]],xi=[],usados=new Set();
  slots.forEach(([pos,n])=>{
    const c=refs.filter(r=>r.j.pos===pos&&!usados.has(r.id)).sort((a,b)=>b.j.f-a.j.f).slice(0,n);
    c.forEach(r=>{xi.push(r);usados.add(r.id)});
  });
  const resto=refs.filter(r=>!usados.has(r.id)&&r.j.pos!=='GOL').sort((a,b)=>b.j.f-a.j.f);
  while(xi.length<11&&resto.length){const r=resto.shift();xi.push(r);usados.add(r.id)}
  const f=xi.reduce((q,r)=>q+r.j.f,0)/Math.max(1,xi.length);
  return{xi,f,refs};
}
function selForcaRapida(p){ // força sem depender de convocação (para sorteio, ranking e IA de convites)
  const info=SEL_INFO[p];return info?info.base:40;
}


/* ---------- partidas entre seleções ---------- */
function selPoisson(l,rg){let L=Math.exp(-l),k=0,p=1;do{k++;p*=rg()}while(p>L&&k<12);return k-1}
function selEscolhe(xi,pesos,rg,exceto){
  const arr=xi.map(r=>({r,w:(pesos[r.j.pos]||0)*Math.pow(Math.max(1,r.j.f)/40,2)*(exceto&&exceto.id===r.id?0:1)})),t=arr.reduce((q,x)=>q+x.w,0);
  if(t<=0)return null;let x=rg()*t;for(const a of arr){x-=a.w;if(x<=0)return a.r}return arr[arr.length-1].r;
}
const SEL_PGOL={GOL:0,ZAG:.5,LD:.9,LE:.9,VOL:.8,MEI:2.4,PE:3,ATA:5},SEL_PAST={GOL:.1,ZAG:.3,LD:1.4,LE:1.4,VOL:1,MEI:3.2,PE:3,ATA:1.8};
let SEL_SEQ=0;
/* Joga uma partida. opts: {ko, comp, md, neutro}. Devolve o relatório. */
function selJoga(a,b,opts){
  opts=opts||{};const s=S.sel;
  if(s.espiao){ // modo espião: só descobre qual é o jogo do usuário, sem efeitos
    if(a===s.meu||b===s.meu)s.espiao.jogo={a,b,opts:{comp:opts.comp,fase:opts.fase,ko:opts.ko,neutro:opts.neutro,md:opts.md}};
    return{a,b,ga:0,gb:0,pen:opts.ko?[1,0]:null,ev:[],comp:opts.comp||'ami',md:opts.md,fase:opts.fase||'',temp:S.temp,melhor:''};
  }
  const pre=s.liveRes;
  if(pre&&pre.a===a&&pre.b===b){ // partida do usuário jogada ao vivo: usa o resultado real
    s.liveRes=null;const xiA={xi:pre._xiA},xiB={xi:pre._xiB};delete pre._xiA;delete pre._xiB;
    Object.assign(pre,{comp:opts.comp||'ami',md:opts.md,fase:opts.fase||'',temp:S.temp});
    selAplicaResultado(pre,xiA,xiB,opts);return pre;
  }
  const rg=selRng('jogo|'+(++SEL_SEQ)+'|'+(S.temp||1)+'|'+a+'|'+b+'|'+Math.random());
  const A=selXI(a),B=selXI(b),fa=A.f,fb=B.f,dif=(fa-fb)/12;
  const casa=opts.neutro?0:.12;
  const la=Math.max(.25,Math.min(4.2,1.28+dif+casa)),lb=Math.max(.2,Math.min(4.2,1.12-dif-casa));
  let ga=selPoisson(la,rg),gb=selPoisson(lb,rg),pen=null;
  const evs=[];
  const gera=(X,n,lado)=>{for(let i=0;i<n;i++){
      const m=1+Math.floor(rg()*90),art=selEscolhe(X.xi,SEL_PGOL,rg);if(!art)continue;
      const as=rg()<.72?selEscolhe(X.xi,SEL_PAST,rg,art):null;evs.push({t:'g',m,lado,r:art,as})}};
  gera(A,ga,'a');gera(B,gb,'b');
  const cart=(X,lado)=>{const n=selPoisson(1.5,rg);for(let i=0;i<n;i++){const r=X.xi[Math.floor(rg()*X.xi.length)];if(r)evs.push({t:'am',m:1+Math.floor(rg()*90),lado,r})}
    if(rg()<.07){const r=X.xi[1+Math.floor(rg()*(X.xi.length-1))];if(r)evs.push({t:'vm',m:1+Math.floor(rg()*90),lado,r})}};
  cart(A,'a');cart(B,'b');
  if(opts.ko&&ga===gb){ // prorrogação/pênaltis resumidos
    const pa=3+Math.floor(rg()*3)+(rg()<.5+dif*.2?1:0),pb=3+Math.floor(rg()*3)+(rg()<.5-dif*.2?1:0);
    pen=pa===pb?(rg()<.5?[pa+1,pb]:[pa,pb+1]):[pa,pb];
  }
  evs.sort((x,y)=>x.m-y.m);
  const rel={a,b,ga,gb,pen,comp:opts.comp||'ami',md:opts.md,fase:opts.fase||'',temp:S.temp,ev:evs.map(e=>({t:e.t,m:e.m,lado:e.lado,id:e.r.id,n:e.r.j.nome,as:e.as?e.as.j.nome:null,aid:e.as?e.as.id:null})),
    melhor:null};
  // melhor da partida: o autor com mais gols ou o maior f do vencedor
  const venc=ga>gb?A:gb>ga?B:(pen&&pen[0]>pen[1]?A:B),golsPor={};
  evs.filter(e=>e.t==='g').forEach(e=>{golsPor[e.r.id]=(golsPor[e.r.id]||0)+1});
  const top=Object.keys(golsPor).sort((x,y)=>golsPor[y]-golsPor[x])[0];
  rel.melhor=top?(A.xi.concat(B.xi).find(r=>r.id===top).j.nome):venc.xi.slice().sort((x,y)=>y.j.f-x.j.f)[0].j.nome;
  selAplicaResultado(rel,A,B,opts);
  return rel;
}
function selAplicaResultado(rel,A,B,opts){
  const s=S.sel,a=rel.a,b=rel.b;
  // jogadores
  [[A,a],[B,b]].forEach(([X,p])=>X.xi.forEach(r=>{selStat(r.j,p,'j',rel.comp)}));
  rel.ev.forEach(e=>{
    const p=e.lado==='a'?a:b;
    if(e.t==='g'){const o=selStat({id:e.id},p,'g');o.r=Math.max(o.r||0,rel.ev.filter(x=>x.t==='g'&&x.id===e.id).length);if(e.aid)selStat({id:e.aid},p,'a')}
    if(e.t==='am')selStat({id:e.id},p,'am');
    if(e.t==='vm')selStat({id:e.id},p,'vm');
  });
  // ranking (Elo) — mata-mata e torneios valem mais
  const k=rel.comp==='ami'?20:(rel.comp==='copa'?60:40),ra=s.rank[a],rb=s.rank[b];
  const esp=1/(1+Math.pow(10,(rb-ra)/400)),res=rel.ga>rel.gb?1:rel.ga<rel.gb?0:(rel.pen?(rel.pen[0]>rel.pen[1]?.75:.25):.5);
  const delta=Math.round(k*(res-esp));s.rank[a]=ra+delta;s.rank[b]=rb-delta;
  // técnico do usuário
  [[a,rel.ga,rel.gb,1],[b,rel.gb,rel.ga,0]].forEach(([p,gp,gc])=>{
    const t=s.tec[p];if(!t||!t.user)return;
    const ts=s.tecst;ts.j++;ts.gp+=gp;ts.gc+=gc;
    if(gp>gc){ts.v++;ts.inv++}else if(gp===gc){ts.e++;ts.inv++}else{ts.d++;ts.inv=0}
    ts.maxInv=Math.max(ts.maxInv,ts.inv);
  });
  s.ult.unshift(rel);if(s.ult.length>30)s.ult.length=30;
  // artilharia/assistências da competição
  const c=opts&&opts.compObj;
  if(c){rel.ev.forEach(e=>{if(e.t==='g'){const o=c.art[e.id]||(c.art[e.id]={n:e.n,p:e.lado==='a'?a:b,g:0,a:0});o.g++}
      if(e.t==='g'&&e.aid){const o=c.art[e.aid]||(c.art[e.aid]={n:e.as,p:e.lado==='a'?a:b,g:0,a:0});o.a++}})}
}
function selRankPos(p){const s=S.sel;return SEL_PAISES.slice().sort((x,y)=>s.rank[y]-s.rank[x]).indexOf(p)+1}
function selAtualizaRkMax(){const s=S.sel,m=s.meu;if(!m)return;const r=selRankPos(m);if(s.tecst.rkMax==null||r<s.tecst.rkMax)s.tecst.rkMax=r}

/* ---------- competições ---------- */
function selRR(times){ // método do círculo: devolve rodadas [[a,b],...]
  const t=times.slice();if(t.length%2)t.push(null);const n=t.length,rod=[];
  for(let r=0;r<n-1;r++){const ps=[];for(let i=0;i<n/2;i++){const x=t[i],y=t[n-1-i];if(x&&y)ps.push(r%2?[y,x]:[x,y])}rod.push(ps);t.splice(1,0,t.pop())}
  return rod;
}
function selTab0(times){const o={};times.forEach(p=>o[p]={pts:0,j:0,v:0,e:0,d:0,gp:0,gc:0});return o}
function selTabAplica(tab,r){
  const A=tab[r.a],B=tab[r.b];if(!A||!B)return;A.j++;B.j++;A.gp+=r.ga;A.gc+=r.gb;B.gp+=r.gb;B.gc+=r.ga;
  if(r.ga>r.gb){A.v++;A.pts+=3;B.d++}else if(r.ga<r.gb){B.v++;B.pts+=3;A.d++}else{A.e++;B.e++;A.pts++;B.pts++}
}
function selOrdena(tab,times){return times.slice().sort((x,y)=>tab[y].pts-tab[x].pts||(tab[y].gp-tab[y].gc)-(tab[x].gp-tab[x].gc)||tab[y].gp-tab[x].gp||S.sel.rank[y]-S.sel.rank[x])}
function selSnake(times,G){const ord=times.slice().sort((x,y)=>S.sel.rank[y]-S.sel.rank[x]),gs=Array.from({length:G},()=>[]);ord.forEach((p,i)=>{const r=Math.floor(i/G),g=r%2?G-1-(i%G):i%G;gs[g].push(p)});return gs}
function selNovaComp(tipo,times,cfg){
  const s=S.sel,id=tipo+'_'+S.temp,c=Object.assign({id,tipo,temp:S.temp,times:times.slice(),fase:'grupos',grupos:[],ko:[],art:{},camp:null,vice:null,stage:0,jogos:[]},cfg||{});
  c.tab=selTab0(times);s.comps[id]=c;return c;
}
function selMontaGrupos(c,G,duplo){
  c.grupos=selSnake(c.times,G).map((ts,i)=>({n:'Grupo '+String.fromCharCode(65+i),times:ts,rod:(function(){const r=selRR(ts);return duplo?r.concat(r.map(x=>x.map(([p,q])=>[q,p]))):r})()}));
}
function selJogaRodadaGrupos(c,k,md){
  const out=[];
  c.grupos.forEach(g=>{(g.rod[k]||[]).forEach(([a,b])=>{const r=selJoga(a,b,{comp:c.tipo,md,fase:g.n,compObj:c,neutro:c.neutro});selTabAplica(c.tab,r);out.push(r)})});
  return out;
}
function selClassifGrupo(c,g){return selOrdena(c.tab,g.times)}
function selFaseKO(c,n){ // n = times vivos; monta confrontos por semeadura (1×último)
  let vivos=c.vivos;const jogos=[];
  for(let i=0;i<vivos.length/2;i++)jogos.push([vivos[i],vivos[vivos.length-1-i]]);
  return jogos;
}
function selJogaKO(c,md){
  const nome={16:'Oitavas',8:'Quartas',4:'Semifinal',2:'Final'}[c.vivos.length]||('Fase de '+c.vivos.length);
  const jogos=selFaseKO(c),out=[],prox=[];
  jogos.forEach(([a,b])=>{
    const r=selJoga(a,b,{comp:c.tipo,md,fase:nome,ko:true,compObj:c,neutro:true});out.push(r);
    const venc=r.ga>r.gb?a:r.ga<r.gb?b:(r.pen[0]>r.pen[1]?a:b);prox.push(venc);
    if(c.vivos.length===2){c.camp=venc;c.vice=venc===a?b:a}
  });
  c.ko.push({n:nome,r:out});
  // vencedores na ordem do chaveamento: mantém a semeadura (melhor vs pior)
  c.vivos=prox.sort((x,y)=>c.seed[x]-c.seed[y]);
  if(c.vivos.length<=1){c.fase='fim'}
  return out;
}
/* inicia o mata-mata a partir dos grupos */
function selIniciaKO(c,quantos){
  const q=[];const porGrupo=c.grupos.map(g=>selClassifGrupo(c,g));
  const nPor=Math.floor(quantos/c.grupos.length);let extras=quantos-nPor*c.grupos.length;
  porGrupo.forEach(l=>l.slice(0,nPor).forEach((p,i)=>q.push({p,pos:i})));
  if(extras>0){const terc=porGrupo.map(l=>l[nPor]).filter(Boolean).sort((x,y)=>c.tab[y].pts-c.tab[x].pts||(c.tab[y].gp-c.tab[y].gc)-(c.tab[x].gp-c.tab[x].gc)||c.tab[y].gp-c.tab[x].gp);terc.slice(0,extras).forEach(p=>q.push({p,pos:nPor}))}
  q.sort((x,y)=>x.pos-y.pos||c.tab[y.p].pts-c.tab[x.p].pts||(c.tab[y.p].gp-c.tab[y.p].gc)-(c.tab[x.p].gp-c.tab[x.p].gc)||c.tab[y.p].gp-c.tab[x.p].gp);
  c.vivos=q.map(x=>x.p);c.seed={};c.vivos.forEach((p,i)=>c.seed[p]=i);c.fase='ko';
}
function selFinalizaComp(c){
  const s=S.sel;if(s.espiao)return;c.fase='fim';
  const info=SEL_COMPS[c.tipo];
  const art=Object.keys(c.art).map(k=>Object.assign({id:k},c.art[k])).sort((x,y)=>y.g-x.g||y.a-x.a)[0];
  const ass=Object.keys(c.art).map(k=>Object.assign({id:k},c.art[k])).sort((x,y)=>y.a-x.a||y.g-x.g)[0];
  s.hist.unshift({temp:c.temp,tipo:c.tipo,nome:info.n,ic:info.ic,camp:c.camp,vice:c.vice,art:art?{n:art.n,p:art.p,g:art.g}:null,ass:ass?{n:ass.n,p:ass.p,a:ass.a}:null});
  // títulos dos jogadores do campeão
  if(c.camp&&s.conv[c.camp]&&s.conv[c.camp].ids){s.conv[c.camp].ids.forEach(id=>{const o=s.js[id];if(o)(o.t=o.t||[]).push(info.n+' '+(2026+c.temp))})}
  // técnico do usuário
  const t=s.tec[c.camp];if(t&&t.user){s.tecst.tit++;s.tecst.por[info.n]=(s.tecst.por[info.n]||0)+1;
    try{if(info.premio){S.clubes[S.meu].caixa+=info.premio;if(typeof lancaPremio==='function')lancaPremio(info.premio,'🏅 Premiação da federação: '+info.n)}}catch(e){}}
  s.recentes=s.recentes||[];s.recentes.unshift({t:c.camp,n:info.n,temp:S.temp});if(s.recentes.length>6)s.recentes.length=6;
}
/* qualificados da Copa a partir das eliminatórias */
function selApuraCopa(){
  const s=S.sel,el=s.comps['elim_'+(S.temp-1)]||Object.values(s.comps).filter(c=>c.tipo==='elim').sort((x,y)=>y.temp-x.temp)[0];
  const cota={UEFA:10,CONMEBOL:5,CAF:6,AFC:4,CONCACAF:3},q=[],resto=[];
  SEL_CONFS.forEach(cf=>{
    const times=SEL_PAISES.filter(p=>SEL_INFO[p].conf===cf),tab=el&&el.tabs?el.tabs[cf]:null;
    const ord=tab?selOrdena(tab,times):times.slice().sort((x,y)=>s.rank[y]-s.rank[x]);
    ord.slice(0,cota[cf]).forEach(p=>q.push(p));ord.slice(cota[cf]).forEach(p=>resto.push({p,pts:tab?tab[p].pts/Math.max(1,tab[p].j):0,rk:s.rank[p]}));
  });
  resto.sort((x,y)=>y.pts-x.pts||y.rk-x.rk);
  while(q.length<32&&resto.length)q.push(resto.shift().p);
  return q;
}
/* ---------- planejamento da temporada ---------- */
function selCiclo(){return ((S.temp-1)%4)+1}
/* cria as competições de TEMPORADA (janelas) e de VERÃO (torneios) */
function selPlanejaTemporada(){
  const s=S.sel;selIni();
  const ciclo=selCiclo(),porConf=cf=>SEL_PAISES.filter(p=>SEL_INFO[p].conf===cf);
  s.plano={ciclo,md:[],verao:[],temp:S.temp};
  s.mdAtual=0;
  // 1) competições que ocupam as 8 datas da temporada
  if(ciclo===1){ // UEFA Nations League (fase de liga: 4 grupos duplos = 6 datas)
    const c=selNovaComp('nl',porConf('UEFA'),{});selMontaGrupos(c,4,true);c.mdBase=0;c.verao=false;
  }
  if(ciclo===2||ciclo===3){ // eliminatórias: 16 datas em 2 temporadas
    let el=Object.values(s.comps).find(c=>c.tipo==='elim'&&c.ciclo===(ciclo===2?2:2)&&!c.fim);
    if(ciclo===2){
      el=selNovaComp('elim',SEL_PAISES,{ciclo:2,tabs:{},sched:{},jogou:0});el.id='elim_'+S.temp;
      SEL_CONFS.forEach(cf=>{
        const ts=porConf(cf).sort((x,y)=>s.rank[y]-s.rank[x]);el.tabs[cf]=selTab0(ts);
        let rod=selRR(ts);const dup=rod.length*2<=16;if(dup)rod=rod.concat(selRR(ts).map(r=>r.map(([a,b])=>[b,a])));
        el.sched[cf]=rod;
      });
    }
    if(el)s.plano.elim=el.id;
  }
  // 2) torneios de VERÃO desta temporada
  const V=s.plano.verao;
  const mk=(tipo,times,G,quantosKO,nome,cfg)=>{const c=selNovaComp(tipo,times,Object.assign({verao:true},cfg||{}));selMontaGrupos(c,G,false);c.quantosKO=quantosKO;V.push(c.id);return c};
  if(ciclo===1){mk('ouro',porConf('CONCACAF'),2,4);mk('asia',porConf('AFC'),2,4);mk('can',porConf('CAF'),2,4)}
  if(ciclo===2){mk('euro',porConf('UEFA'),4,8);
    const conv=porConf('CONCACAF').sort((x,y)=>s.rank[y]-s.rank[x]).slice(0,4);mk('ca',porConf('CONMEBOL').concat(conv),3,8)}
  if(ciclo===3){mk('ouro',porConf('CONCACAF'),2,4);mk('can',porConf('CAF'),2,4)}
  if(ciclo===4){mk('copa',selApuraCopa(),8,16,'',{neutro:true})}
}


/* ---------- calendário: Datas FIFA dentro da temporada + torneios de verão ---------- */
COMP_INFO.sel={n:'Seleções',ic:'🌐'};
const SEL_MESES_JANELA=[8,9,10,2];           // set, out, nov, mar
function selNovaEntrada(ref,extra){return Object.assign({comp:'sel',idx:0,mes:ref.mes,dia:ref.dia,ano:ref.ano,dow:ref.dow,res:null,adv:null,casa:null},extra)}
function selInsereJanelas(){
  const s=S.sel,ag=S.agenda;if(!ag||s.janTemp===S.temp)return;
  if(ag.some(d=>d.comp==='sel'))return;
  const pos=[];
  SEL_MESES_JANELA.forEach(m=>{
    const i=ag.findIndex((d,k)=>k>S.dia&&d.comp==='liga'&&d.mes===m&&d.dia>=8);
    if(i>=0)pos.push(i);
  });
  let w=pos.length;
  pos.slice().sort((x,y)=>y-x).forEach(i=>{
    w--;const ref=ag[i];
    ag.splice(i+1,0,selNovaEntrada(ref,{win:w,md:w*2+1,last:true}));
    ag.splice(i,0,selNovaEntrada(ref,{win:w,md:w*2,first:true}));
  });
  s.janTemp=S.temp;
}
function selIdxSel(){let n=0;(S.agenda||[]).forEach(d=>{if(d.comp==='sel')d.idx=n++})}
function selPreparaVerao(){
  const s=S.sel,ag=S.agenda;if(!s.plano||s.plano.temp!==S.temp)selPlanejaTemporada();
  if(s.plano.veraoOk)return false;s.plano.veraoOk=true;
  let ids=s.plano.verao.slice();
  if(selCiclo()===1){const nl=Object.values(s.comps).find(c=>c.tipo==='nl'&&c.temp===S.temp);if(nl){nl.koSo=true;ids.push(nl.id)}}
  const comps=ids.map(i=>s.comps[i]).filter(Boolean);if(!comps.length)return false;
  const dias=Math.max(...comps.map(c=>c.koSo?2:Math.max(...c.grupos.map(g=>g.rod.length))+Math.log2(c.quantosKO||4)));
  const ult=ag[ag.length-1],base=new Date(ult.ano,ult.mes,ult.dia);
  for(let i=0;i<dias;i++){const dt=new Date(base.getFullYear(),base.getMonth(),base.getDate()+12+i*4);
    ag.push({comp:'sel',idx:0,mes:dt.getMonth(),dia:dt.getDate(),ano:dt.getFullYear(),dow:dt.getDay(),res:null,adv:null,casa:null,verao:true,vi:i,first:i===0,last:i===dias-1})}
  selIdxSel();s.plano.veraoIds=ids;return true;
}

/* ---------- execução de uma data de seleções ---------- */
function selTimesDaData(d){
  const s=S.sel;if(d.verao)return (s.plano.veraoIds||[]).map(i=>s.comps[i]).filter(Boolean).flatMap(c=>c.times);
  return SEL_PAISES;
}
function selPrecisaConvocar(d){ // true se o usuário ainda precisa confirmar a convocação desta janela
  const s=S.sel;if(!s.meu||!d.first)return false;
  const cv=s.conv[s.meu],id=d.verao?'v'+S.temp:'j'+S.temp+'_'+d.win;
  if(cv&&cv.conf&&cv.w===id)return false;
  if(d.verao&&!selTimesDaData(d).includes(s.meu))return false;
  return true;
}
function selJanelaId(d){return d.verao?'v'+S.temp:'j'+S.temp+'_'+d.win}
function selConvocaIA(d){
  const s=S.sel,w=selJanelaId(d),verao=!!d.verao;
  const times=selTimesDaData(d);selLimpaCache();
  times.forEach(p=>{
    if(p===s.meu)return;
    const c=verao?(s.plano.veraoIds||[]).map(i=>s.comps[i]).find(x=>x&&x.times.includes(p)):null;
    const max=c?SEL_COMPS[c.tipo].max:23;
    selConfirma(p,selAutoLista(p,max,[]),w,c?c.tipo:'janela');
  });
}
function selMdMeuJogo(rels){const m=S.sel.meu;return m?rels.filter(r=>r.a===m||r.b===m):[]}
function selJogaData(d){
  const s=S.sel,rels=[];
  if(!d.verao){
    const md=d.md,ocup=new Set(),mdIn=md;
    // Nations League (fase de liga)
    Object.values(s.comps).filter(c=>c.tipo==='nl'&&c.temp===S.temp&&c.mdBase!=null&&!c.koSo).forEach(c=>{
      if(mdIn<6){selJogaRodadaGrupos(c,mdIn,mdIn).forEach(r=>{rels.push(r);ocup.add(r.a);ocup.add(r.b)})}
    });
    // Eliminatórias
    const pl=s.plano,el=pl&&pl.elim?s.comps[pl.elim]:null;
    if(el){
      const k=(pl.ciclo===2?0:8)+mdIn;
      SEL_CONFS.forEach(cf=>{(el.sched[cf][k]||[]).forEach(([a,b])=>{
        const r=selJoga(a,b,{comp:'elim',md:mdIn,fase:cf});selTabAplica(el.tabs[cf],r);selTabAplica(el.tab,r);rels.push(r);ocup.add(a);ocup.add(b)})});
      if(pl.ciclo===3&&mdIn===7){el.fim=true;el.fase='fim'}
    }
    // amistosos para quem ficou livre
    const livres=SEL_PAISES.filter(p=>!ocup.has(p)),rg=selRng('ami|'+S.temp+'|'+d.md),ruido={};
    livres.forEach(p=>ruido[p]=rg());
    livres.sort((x,y)=>(s.rank[y]+ruido[y]*350)-(s.rank[x]+ruido[x]*350));   // pareia vizinhos do ranking (com ruído, sempre igual para a mesma data)
    for(let i=0;i+1<livres.length;i+=2){rels.push(selJoga(livres[i],livres[i+1],{comp:'ami',md:d.md,fase:'Amistoso'}))}
  }else{
    const vi=d.vi;
    (s.plano.veraoIds||[]).map(i=>s.comps[i]).filter(Boolean).forEach(c=>{
      if(c.fase==='fim')return;
      if(c.koSo){ // Nations League: final four
        if(vi===0&&c.fase==='grupos')selIniciaKO(c,4);
        if(c.fase==='ko')selJogaKO(c,vi).forEach(r=>rels.push(r));
        if(c.fase==='fim'||c.vivos.length<=1)selFinalizaComp(c);
        return;
      }
      const R=Math.max(...c.grupos.map(g=>g.rod.length));
      if(vi<R){selJogaRodadaGrupos(c,vi,vi).forEach(r=>rels.push(r))}
      else{if(c.fase==='grupos')selIniciaKO(c,c.quantosKO);selJogaKO(c,vi).forEach(r=>rels.push(r))}
      if(c.fase==='fim'||(c.vivos&&c.vivos.length<=1&&c.fase==='ko'))selFinalizaComp(c);
    });
  }
  rels.forEach(r=>{const t=S.sel.tstat||(S.sel.tstat={});[[r.a,r.ga,r.gb],[r.b,r.gb,r.ga]].forEach(([p,gp,gc])=>{const o=t[p]||(t[p]={j:0,v:0,e:0,d:0,gp:0,gc:0});o.j++;o.gp+=gp;o.gc+=gc;if(gp>gc)o.v++;else if(gp===gc)o.e++;else o.d++})});
  selAtualizaRkMax();
  return rels;
}
/* tela de resultado da seleção do usuário */
function selResultadoDlg(rels,d){
  const m=S.sel.meu,meus=selMdMeuJogo(rels);
  if(!meus.length&&!d.verao)return;
  let h=`<b>${fl(m)} ${m||''} · Data internacional</b>`;
  meus.forEach(r=>{
    const gols=r.ev.filter(e=>e.t==='g').map(e=>`⚽ ${e.n} ${e.m}'${e.as?' (ast. '+e.as+')':''}`).join('<br>'),
      cart=r.ev.filter(e=>e.t==='am'||e.t==='vm').map(e=>(e.t==='vm'?'🟥 ':'🟨 ')+e.n+' '+e.m+"'").join(', ');
    h+=`<div class="card" style="margin:8px 0"><div class="tag">${SEL_COMPS[r.comp]?SEL_COMPS[r.comp].n:''} ${r.fase?'· '+r.fase:''}</div>
      <div style="font-size:18px;text-align:center;margin:6px 0">${fl(r.a)} ${r.a} <b>${r.ga} x ${r.gb}</b> ${r.b} ${fl(r.b)}${r.pen?`<br><small class="mu">pênaltis ${r.pen[0]} x ${r.pen[1]}</small>`:''}</div>
      <small>${gols||'sem gols'}</small>${cart?`<br><small class="mu">${cart}</small>`:''}<br><small>⭐ Melhor em campo: <b>${r.melhor}</b></small></div>`;
  });
  if(!meus.length)h+=`<div class="mu" style="margin:8px 0">Sua seleção não jogou nesta data.</div>`;
  h+=`<button class="big" onclick="fechaDlg()">OK</button>`;
  modal(h);
}
function selAvancaAgenda(){try{agendaAvanca()}catch(e){S.dia++}}
function selRodadaData(d){
  const s=S.sel;
  if(d.first){
    if(selPrecisaConvocar(d)){s.pend={w:selJanelaId(d),verao:!!d.verao,win:d.win};S.aba='sel';s.sub='cvc';render();toast('🌐 Faça a convocação da sua seleção');return false}
    if(!s.convFeita||s.convFeita!==selJanelaId(d)){selConvocaIA(d);s.convFeita=selJanelaId(d)}
  }
  if(s.meu&&!s.liveRes){ // a partida da SUA seleção é jogada ao vivo, como as da liga
    const jg=selEspiaMeuJogo(d);
    if(jg){selComecaLive(jg,d);return false}
  }
  const rels=selJogaData(d);
  s.liveRes=null;
  if(d.last){selLiberaTodas();s.pend=null}
  d.res='sel';
  selAvancaAgenda();
  try{save()}catch(e){}
  render();
  try{selResultadoDlg(rels,d)}catch(e){console.log(e)}
  return true;
}


/* ---------- convites das federações ---------- */
const SEL_ADJ={Brasil:'Brasileira',Argentina:'Argentina',Colômbia:'Colombiana',Uruguai:'Uruguaia',Equador:'Equatoriana',Chile:'Chilena',Paraguai:'Paraguaia',Peru:'Peruana',França:'Francesa',Espanha:'Espanhola',Inglaterra:'Inglesa',Alemanha:'Alemã',Portugal:'Portuguesa',Itália:'Italiana',Holanda:'Holandesa',Bélgica:'Belga',Croácia:'Croata',Suíça:'Suíça',Dinamarca:'Dinamarquesa',Turquia:'Turca',Polônia:'Polonesa',Áustria:'Austríaca',Rússia:'Russa',Escócia:'Escocesa',México:'Mexicana','Estados Unidos':'Norte-Americana',Canadá:'Canadense','Costa Rica':'Costarriquenha',Panamá:'Panamenha',Jamaica:'Jamaicana',Marrocos:'Marroquina',Senegal:'Senegalesa',Nigéria:'Nigeriana','Costa do Marfim':'Marfinense',Egito:'Egípcia',Argélia:'Argelina',Gana:'Ganesa',Camarões:'Camaronesa',Tunísia:'Tunisiana','África do Sul':'Sul-Africana',Japão:'Japonesa','Coreia do Sul':'Sul-Coreana',Irã:'Iraniana',Austrália:'Australiana','Arábia Saudita':'Saudita',Catar:'Catariana',Uzbequistão:'Uzbeque',Iraque:'Iraquiana'};
function selReputacao(){
  const eu=S.clubes[S.meu],h=S.hist||[],tit=h.filter(x=>x.meu===1).length,top3=h.filter(x=>x.meu<=3).length;
  const aprov=eu&&eu.j>0?eu.pts/(3*eu.j):.45,cf=eu?forcaMedia(eu):35,ult=h.length?h[h.length-1].meu:null;
  let R=22+7*Math.min(5,tit)+2*Math.min(6,top3)+30*(aprov-.4)+(cf-35)*.55+(ult!=null?(ult<=3?6:ult>=15?-5:0):0);
  const ts=S.sel.tecst;R+=Math.min(15,ts.tit*6)+(ts.j>5?(ts.v/ts.j-.4)*20:0);
  return Math.max(5,Math.min(98,Math.round(R*10)/10));
}
function selExigencia(p){return (SEL_INFO[p].base-20)*2.2-(p===S.pais?8:0)}
function selAvaliaConvites(forca){
  const s=S.sel;if(s.meu||s.props.length)return;
  s.propAval++;if(!forca&&s.propAval%5)return;
  if(S.temp===1&&S.dia<12)return;
  const R=selReputacao(),ok=SEL_PAISES.filter(p=>!s.tec[p].user&&(!s.recusas[p]||S.temp-s.recusas[p]>=2)&&R>=selExigencia(p));
  if(!ok.length)return;
  if(!forca&&Math.random()>.35)return;
  ok.sort((x,y)=>SEL_INFO[y].base-SEL_INFO[x].base);
  const p=ok[Math.min(ok.length-1,Math.floor(Math.random()*Math.min(3,ok.length)))];
  s.props.push({p,temp:S.temp,R});
  setTimeout(()=>{try{selPropostaDlg(0)}catch(e){}},400);
}
function selPropostaDlg(i){
  const pr=S.sel.props[i];if(!pr)return;
  modal(`<div style="text-align:center"><div style="font-size:42px">${fl(pr.p)}</div><b>Convite da Federação</b>
   <p style="margin:10px 0">A Federação ${SEL_ADJ[pr.p]||'de Futebol'} deseja oferecer o cargo de treinador da Seleção ${SEL_ADJ[pr.p]?'':'de '}${pr.p}.</p>
   <small class="mu">Você continua no seu clube e passa a comandar também a seleção. Ranking FIFA: ${selRankPos(pr.p)}º</small></div>
   <div class="row" style="margin-top:12px"><button class="s" onclick="selRecusa(${i})">RECUSAR</button><button onclick="selAceita(${i})">ACEITAR</button></div>`);
}
function selAceita(i){
  const s=S.sel,pr=s.props[i];if(!pr)return;fechaDlg();
  s.meu=pr.p;s.tec[pr.p]={nome:S.treinador,rep:pr.R,desde:S.temp,user:true};s.props=[];
  s.tecst.desde=s.tecst.desde||S.temp;s.tecst.rkIni=selRankPos(pr.p);selAtualizaRkMax();
  save();render();toast(fl(pr.p)+' Você é o novo treinador da seleção!');
}
function selRecusa(i){const s=S.sel,pr=s.props[i];if(!pr)return;fechaDlg();s.recusas[pr.p]=S.temp;s.props=[];save();render();toast('Convite recusado. Outras seleções podem procurar você.')}
function selDeixa(){
  const s=S.sel,p=s.meu;if(!p)return;
  confirma('Deixar o comando da seleção '+p+'?',()=>{
    const rg=selRng('novo|'+p+'|'+S.temp);s.tec[p]={nome:pickRg(rg,SILABAS1)+pickRg(rg,SILABAS2)+' '+pickRg(rg,SOBRE),rep:SEL_INFO[p].base,desde:S.temp,user:false};
    s.meu=null;s.recusas[p]=S.temp;save();render();
  });
}

/* ---------- virada de temporada ---------- */
function selFimTemporada(){
  const s=S.sel;selIni();selLiberaTodas();
  SEL_PAISES.forEach(p=>{
    const rg=selRng('env|'+p+'|'+S.temp),lista=s.vp[p]||[],info=SEL_INFO[p];
    lista.forEach(j=>{j.idade++;if(j.idade<25)j.f=Math.min(j.pot||j.f,j.f+Math.floor(rg()*3));else if(j.idade>31)j.f=Math.max(15,j.f-Math.floor(rg()*3))});
    s.vp[p]=lista.filter(j=>j.idade<37);
    const falta=20-s.vp[p].length;
    if(falta>0){const molde=['GOL','ZAG','ZAG','LD','LE','VOL','MEI','MEI','PE','ATA','ATA','ZAG','VOL','PE','GOL','MEI','ATA','LD','LE','ZAG'];
      for(let i=0;i<falta;i++){const x=criaJogadorFixo(molde[i%molde.length],info.base+Math.floor(rg()*7)-3,rg,18+Math.floor(rg()*3),null,p);s.vp[p].push({id:x.id,nome:x.nome,pos:x.pos,f:x.f,pot:x.pot,idade:x.idade,vp:1})}}
    // técnico da IA: troca se o ranking ficou muito abaixo do esperado
    const t=s.tec[p];if(t&&!t.user){const esp=SEL_PAISES.slice().sort((x,y)=>SEL_INFO[y].base-SEL_INFO[x].base).indexOf(p),real=selRankPos(p);
      if(real-esp>10&&rg()<.45||S.temp-t.desde>=8&&rg()<.3){t.nome=pickRg(rg,SILABAS1)+pickRg(rg,SILABAS2)+' '+pickRg(rg,SOBRE);t.desde=S.temp;t.rep=Math.round(info.base+rg()*8)}}
  });
  s.tstat=s.tstat||{};
  // poda estatísticas de jogadores que já saíram de cena (mantém quem tem história)
  try{const vivos=new Set();SEL_PAISES.forEach(p=>selPoolDe(p).forEach(r=>vivos.add(r.id)));
    Object.keys(s.js).forEach(id=>{const o=s.js[id];if(!vivos.has(id)&&(o.j||0)<10&&!o.g&&!o.t)delete s.js[id]})}catch(e){}
  s.edit=null;s.verCmp=null;
}

/* ---------- ganchos do motor ---------- */
const _agendaMonta=agendaMonta;
agendaMonta=function(){
  _agendaMonta.apply(this,arguments);
  try{selIni();if(!S.sel.plano||S.sel.plano.temp!==S.temp)selPlanejaTemporada();selInsereJanelas();selIdxSel()}catch(e){console.log('sel agenda',e)}
};
const _comecaRodada3=comecaRodada;
comecaRodada=function(){
  if(!S||S.live)return _comecaRodada3.apply(this,arguments);
  try{
    selIni();
    if(!S.agenda||S.dia==null)agendaMonta();
    const pl=S.sel.plano;
    if(S.agenda&&S.dia<S.agenda.length&&(!pl||pl.temp!==S.temp)){selPlanejaTemporada();selInsereJanelas();selIdxSel()}
    else if(S.agenda&&!S.agenda.some(d=>d.comp==='sel')&&S.sel.janTemp!==S.temp&&S.dia<S.agenda.length){selInsereJanelas();selIdxSel()}
    const d=agendaAtual();
    if(d&&d.comp==='sel'){selRodadaData(d);return}
    if(S.agenda&&S.dia>=S.agenda.length&&S.sel.plano&&!S.sel.plano.veraoOk){
      if(selPreparaVerao()&&S.dia<S.agenda.length){return comecaRodada()}
    }
    if(d&&d.comp==='liga')selAvaliaConvites(false);
  }catch(e){console.log('sel comecaRodada',e)}
  return _comecaRodada3.apply(this,arguments);
};
const _fimTemporada=fimTemporada;
fimTemporada=function(){const r=_fimTemporada.apply(this,arguments);try{selFimTemporada()}catch(e){console.log('sel fim',e)}return r};
const _agendaTexto=agendaTexto;
agendaTexto=function(){
  try{const d=agendaAtual();if(d&&d.comp==='sel'){const c=d.verao?'Torneio de seleções':'Data FIFA';return `${d.dia} ${MESES[d.mes].slice(0,3)} · 🌐 ${c}`}}catch(e){}
  return _agendaTexto.apply(this,arguments);
};
/* disponibilidade / exibição do convocado nos clubes */
const _lesaoSelo=lesaoSelo;
lesaoSelo=function(j){if(j&&j.conv)return`<i class="mk" title="Em serviço da Seleção ${j.conv.p}" style="background:#14532d;color:#fff;border-radius:6px;padding:0 4px;font-style:normal;font-size:11px">${fl(j.conv.p)} Convocado</i>`;return _lesaoSelo.apply(this,arguments)};
const _lesaoTexto=lesaoTexto;
lesaoTexto=function(j){if(j&&j.conv)return`${fl(j.conv.p)} Convocado — em serviço da Seleção ${j.conv.p}`;return _lesaoTexto.apply(this,arguments)};
const _motivoInapto=motivoInapto;
motivoInapto=function(j){if(j&&j.conv)return'convocado pela Seleção ('+j.conv.p+')';return _motivoInapto.apply(this,arguments)};
['vender','emprestaMeu','confirmaEmprestaMeu','renova'].forEach(nome=>{
  const f=window[nome];if(typeof f!=='function')return;
  window[nome]=function(arg){
    try{const eu=S.clubes[S.meu];const j=eu.elenco.find(x=>x.id===arg);if(j&&j.conv)return aviso(j.nome+' está em serviço da Seleção '+j.conv.p+'. Só pode ser negociado depois que voltar ao clube.')}catch(e){}
    return f.apply(this,arguments);
  };
});
const _geraPropostas=geraPropostas;
geraPropostas=function(){const r=_geraPropostas.apply(this,arguments);try{const eu=S.clubes[S.meu];if(S.props)S.props=S.props.filter(p=>{const j=eu.elenco.find(x=>x.id===p.jid);return !(j&&j.conv)})}catch(e){}return r};
/* saves: ao carregar, reaplica as marcas de convocado e cria S.sel se faltar */
const _carregaSlot3=carregaSlot;
carregaSlot=function(){const r=_carregaSlot3.apply(this,arguments);try{if(S){selIni();selLimpaCache();const s=S.sel;Object.keys(s.conv).forEach(p=>{if(s.conv[p].conf)selPoolDe(p)})}}catch(e){console.log('sel load',e)}return r};

/* ---------- ficha do jogador ---------- */
function selFichaHTML(j){
  try{
    const o=S.sel&&S.sel.js[j.id];
    if(!o&&!j.conv)return'';
    const tag=j.conv?`<div class="hint" style="margin:6px 0;background:#14532d">${fl(j.conv.p)} <b>Convocado</b> — em serviço da Seleção ${j.conv.p}. Volta ao clube quando a Data FIFA terminar.</div>`:'';
    if(!o)return tag;
    const t=o.t||[],est=o.e?(function(){const [tp,c]=o.e.split('/');return 'temp. '+tp+' · '+(SEL_COMPS[c]?SEL_COMPS[c].n:c)})():'—';
    return tag+`<div class="card" style="margin:6px 0"><div class="tag">${fl(o.p)} Pela seleção — ${o.p}</div>
     <div class="fcGrid"><div><small>Jogos</small><b>${o.j||0}</b></div><div><small>Gols</small><b>${o.g||0}</b></div><div><small>Assistências</small><b>${o.a||0}</b></div><div><small>🟨 / 🟥</small><b>${o.am||0} / ${o.vm||0}</b></div>
     <div><small>Convocações</small><b>${o.c||0}</b></div><div><small>Títulos</small><b>${t.length}</b></div><div><small>Estreia</small><b style="font-size:11px">${est}</b></div><div><small>Recorde</small><b>${o.r?o.r+' gol(s) em 1 jogo':'—'}</b></div></div>
     ${t.length?`<small class="mu">🏆 ${t.join(' · ')}</small>`:''}</div>`;
  }catch(e){return''}
}

/* ---------- telas ---------- */
const SEL_SUBS=[['conv','📨','Convites'],['cvc','📝','Convocação'],['lst','📋','Convocados'],['agd','📅','Agenda'],['rkg','📊','Ranking FIFA'],['cmp','🏆','Competições'],['hst','📜','Histórico'],['tec','👔','Meu histórico']];
function selSub(k){S.sel.sub=k;render()}
function abaSel(){
  const s=selIni();if(!s)return'';
  const sub=s.sub||(s.meu?'cvc':'conv');
  let h=`<div class="card"><div class="row"><div><h3>🌐 Seleções nacionais</h3><small class="mu">${s.meu?`Você comanda: ${fl(s.meu)} <b>${s.meu}</b> · ranking ${selRankPos(s.meu)}º`:'Você ainda não comanda uma seleção'}</small></div></div>
    <div class="row" style="flex-wrap:wrap;gap:6px;margin-top:8px">${SEL_SUBS.map(([k,i,n])=>`<button class="sm ${sub===k?'':'s'}" onclick="selSub('${k}')">${i} ${n}</button>`).join('')}</div></div>`;
  h+=({conv:selTelaConv,cvc:selTelaCvc,lst:selTelaLst,agd:selTelaAgd,rkg:selTelaRkg,cmp:selTelaCmp,hst:selTelaHst,tec:selTelaTec}[sub]||selTelaConv)();
  return h;
}
function selTelaConv(){
  const s=S.sel;let h='';
  if(s.props.length){h+=s.props.map((pr,i)=>`<div class="card"><div class="tag">📨 Convite pendente</div><p style="margin:8px 0">${fl(pr.p)} A Federação ${SEL_ADJ[pr.p]||''} deseja oferecer o cargo de treinador da Seleção ${pr.p}.</p><div class="row"><button class="s" onclick="selRecusa(${i})">RECUSAR</button><button onclick="selAceita(${i})">ACEITAR</button></div></div>`).join('')}
  else h+=`<div class="card"><small class="mu">${s.meu?'Você já comanda uma seleção.':'As federações avaliam periodicamente os técnicos: reputação, títulos, aproveitamento, desempenho recente, nível do clube e nacionalidade. Se você recusar, outras podem fazer propostas depois.'}</small></div>`;
  h+=`<div class="card"><div class="tag">Sua reputação como treinador</div><div style="font-size:22px;margin:6px 0"><b>${selReputacao()}</b> <small class="mu">/ 100</small></div>
   <small class="mu">Títulos de liga: ${(S.hist||[]).filter(x=>x.meu===1).length} · Nacionalidade preferida: ${fl(S.pais)} ${S.pais}</small></div>`;
  h+=`<div class="card"><div class="tag">Técnicos das seleções</div>${SEL_PAISES.slice().sort((x,y)=>selRankPos(x)-selRankPos(y)).slice(0,12).map(p=>`<div class="row" style="padding:3px 0"><span>${fl(p)} ${p}</span><small class="mu">${s.tec[p].nome}${s.tec[p].user?' (você)':''}</small></div>`).join('')}<small class="mu">Os 12 primeiros do ranking</small></div>`;
  return h;
}
function selMaxAtual(){
  const s=S.sel,pd=s.pend;if(!pd)return 23;
  if(!pd.verao)return 23;
  const cs=(s.plano.veraoIds||[]).map(i=>s.comps[i]).filter(c=>c&&c.times.includes(s.meu));
  return cs.length?Math.max(...cs.map(c=>SEL_COMPS[c.tipo].max)):26;
}
function selEditIni(){
  const s=S.sel,p=s.meu;selPoolDe(p);
  const w=s.pend?s.pend.w:'x',max=selMaxAtual();
  if(!s.edit||s.edit.w!==w||s.edit.p!==p){
    const ja=s.conv[p]&&s.conv[p].conf?s.conv[p].ids.slice():[];
    s.edit={p,w,max,ids:ja.length?ja:selAutoLista(p,max,[])};
  }
  s.edit.max=max;return s.edit;
}
function selTogConv(id){
  const e=selEditIni(),i=e.ids.indexOf(id);
  if(i>=0)e.ids.splice(i,1);else{if(e.ids.length>=e.max)return toast('Limite de '+e.max+' convocados');e.ids.push(id)}
  render();
}
function selAuto(){const e=selEditIni();e.ids=selAutoLista(e.p,e.max,e.ids.slice(0,e.max));render()}
function selLimpaConv(){const e=selEditIni();e.ids=[];render()}
function selConfOk(){
  const s=S.sel,e=selEditIni(),min=s.pend&&s.pend.verao?23:18;
  const gk=e.ids.filter(id=>SELV.map[e.p][id]&&SELV.map[e.p][id].j.pos==='GOL').length;
  if(e.ids.length<16)return aviso('Convoque pelo menos 16 jogadores (o regulamento permite até '+e.max+').');
  if(gk<2)return aviso('Convoque pelo menos 2 goleiros.');
  if(s.pend){selConfirma(e.p,e.ids,s.pend.w,s.pend.verao?'verao':'janela');s.pend=null;s.convFeita=null}
  else selConfirma(e.p,e.ids,s.conv[e.p]?s.conv[e.p].w:'manual',s.conv[e.p]?s.conv[e.p].comp:'manual');
  s.edit=null;save();render();toast('✅ Convocação confirmada. Toque em Jogar para seguir.');
}
function selTelaCvc(){
  const s=S.sel;if(!s.meu)return`<div class="card"><small class="mu">Você precisa comandar uma seleção para convocar.</small></div>`;
  const e=selEditIni(),pool=selPoolDe(s.meu),set=new Set(e.ids);
  const pend=s.pend,fonte=pend?(pend.verao?'torneio de verão':'Data FIFA'):'convocação atual';
  let h=`<div class="card"><h3>CONVOCAÇÃO DA SELEÇÃO</h3><small class="mu">${fl(s.meu)} ${s.meu} · ${fonte} · <b>${e.ids.length}/${e.max}</b> convocados${pend?' · <span class="y">pendente</span>':''}</small>
   <div class="row" style="flex-wrap:wrap;gap:6px;margin-top:8px"><button class="sm s" onclick="selAuto()">⚙️ Completar</button><button class="sm s" onclick="selLimpaConv()">🗑 Remover todos</button><button class="sm" onclick="selConfOk()">✅ Confirmar convocação</button></div></div>`;
  SEL_POS.forEach(([pos,nome])=>{
    const l=pool.filter(r=>r.j.pos===pos).sort((a,b)=>selScore(b)-selScore(a)).slice(0,18);
    const marc=l.filter(r=>set.has(r.id)).length;
    h+=`<div class="card"><div class="tag">${nome} <span class="mu">(${e.ids.filter(id=>SELV.map[s.meu][id]&&SELV.map[s.meu][id].j.pos===pos).length} convocados)</span></div>`+
     l.map(r=>{const j=r.j,ok=selDisponivel(r),on=set.has(r.id);
       return`<div class="clube" onclick="selTogConv('${r.id}')" style="${on?'outline:1px solid #34d98b':''}${ok?'':';opacity:.55'}"><span>${on?'☑':'☐'} <b>${j.nome}</b> <small class="mu">${j.idade}a · ${selClubeNome(r)}</small></span><span><span class="y">${Math.round(j.f)}</span>${j.lesao>0&&!j.conv?' 🤕':''}${j.suspenso>0?' ⛔':''}${j.conv?' '+fl(j.conv.p):''}</span></div>`}).join('')+`</div>`;
  });
  return h;
}
function selTelaLst(){
  const s=S.sel,p=s.verLst||s.meu||S.pais;
  let h=`<div class="card"><div class="tag">Seleção</div><select onchange="S.sel.verLst=this.value;render()" style="width:100%">${SEL_PAISES.map(x=>`<option ${x===p?'selected':''}>${x}</option>`).join('')}</select></div>`;
  const cv=s.conv[p];
  if(!cv||!cv.ids||!cv.conf)return h+`<div class="card"><small class="mu">${fl(p)} ${p} não tem convocação ativa agora. As listas saem a cada Data FIFA e torneio.</small></div>`;
  selPoolDe(p);
  const refs=cv.ids.map(id=>SELV.map[p][id]).filter(Boolean);
  h+=`<div class="card"><h3>${fl(p)} Convocados — ${p}</h3><small class="mu">Técnico: ${s.tec[p].nome} · ${refs.length} jogadores</small></div>`;
  SEL_POS.forEach(([pos,nome])=>{const l=refs.filter(r=>r.j.pos===pos);if(!l.length)return;
    h+=`<div class="card"><div class="tag">${nome}</div>`+l.map(r=>`<div class="row" style="padding:3px 0"><span>${r.j.nome} <small class="mu">${selClubeNome(r)}</small></span><span class="y">${Math.round(r.j.f)}</span></div>`).join('')+`</div>`});
  return h;
}
function selTelaAgd(){
  const s=S.sel,ag=(S.agenda||[]).map((d,i)=>({d,i})).filter(x=>x.d.comp==='sel'&&x.i>=S.dia);
  const ciclo=selCiclo();
  let h=`<div class="card"><h3>📅 Agenda internacional</h3><small class="mu">Ciclo ${ciclo}/4 · temporada ${S.temp} · ${ciclo===1?'Nations League + Copa Ouro, Copa da Ásia e Copa Africana':ciclo===2?'Eliminatórias (1ª metade) + Eurocopa e Copa América':ciclo===3?'Eliminatórias (2ª metade) + Copa Ouro e Copa Africana':'Amistosos + Copa do Mundo'}</small></div>`;
  h+=`<div class="card"><div class="tag">Próximas datas</div>`+(ag.length?ag.slice(0,12).map(({d})=>`<div class="row" style="padding:3px 0"><span>${d.dia} ${MESES[d.mes].slice(0,3)} ${d.ano}</span><small class="mu">${d.verao?'Torneios de verão (dia '+(d.vi+1)+')':'Data FIFA — '+(d.first?'convocação + jogo 1':'jogo 2 + retorno dos convocados')}</small></div>`).join(''):'<small class="mu">Nenhuma data restante nesta temporada.</small>')+`</div>`;
  const comps=Object.values(s.comps).filter(c=>c.temp===S.temp&&c.fase!=='fim');
  if(comps.length)h+=`<div class="card"><div class="tag">Competições desta temporada</div>${comps.map(c=>`<div class="row" style="padding:3px 0"><span>${SEL_COMPS[c.tipo].ic} ${SEL_COMPS[c.tipo].n}</span><small class="mu">${c.verao?'verão':'durante a temporada'}</small></div>`).join('')}</div>`;
  h+=`<div class="card"><div class="tag">Últimos resultados</div>`+(s.ult.slice(0,14).map(r=>`<div style="padding:2px 0;font-size:13px">${fl(r.a)} ${r.a} <b>${r.ga}x${r.gb}</b> ${r.b} ${fl(r.b)} <small class="mu">${SEL_COMPS[r.comp]?SEL_COMPS[r.comp].n:''}${r.fase?' · '+r.fase:''}</small></div>`).join('')||'<small class="mu">Sem jogos ainda.</small>')+`</div>`;
  return h;
}
function selTelaRkg(){
  const s=S.sel,t=s.tstat||{};
  const ord=SEL_PAISES.slice().sort((x,y)=>s.rank[y]-s.rank[x]);
  return`<div class="card"><h3>📊 Ranking FIFA e estatísticas</h3><div style="overflow-x:auto"><table style="width:100%;font-size:12px"><tr><th>#</th><th style="text-align:left">Seleção</th><th>Pts</th><th>J</th><th>V</th><th>E</th><th>D</th><th>GP</th><th>GC</th></tr>`+
   ord.map((p,i)=>{const o=t[p]||{j:0,v:0,e:0,d:0,gp:0,gc:0};return`<tr style="${p===s.meu?'background:#14532d55':''}"><td>${i+1}</td><td style="text-align:left">${fl(p)} ${p}</td><td class="y">${s.rank[p]}</td><td>${o.j}</td><td>${o.v}</td><td>${o.e}</td><td>${o.d}</td><td>${o.gp}</td><td>${o.gc}</td></tr>`}).join('')+`</table></div></div>`;
}
function selTelaCmp(){
  const s=S.sel,lista=Object.values(s.comps).filter(c=>c.tipo!=='elim'||true).sort((x,y)=>y.temp-x.temp);
  if(!lista.length)return`<div class="card"><small class="mu">Nenhuma competição criada ainda.</small></div>`;
  const id=s.verCmp&&s.comps[s.verCmp]?s.verCmp:lista[0].id,c=s.comps[id];
  let h=`<div class="card"><div class="tag">Competição</div><select onchange="S.sel.verCmp=this.value;render()" style="width:100%">${lista.map(x=>`<option value="${x.id}" ${x.id===id?'selected':''}>${SEL_COMPS[x.tipo].ic} ${SEL_COMPS[x.tipo].n} — temp. ${x.temp}</option>`).join('')}</select></div>`;
  h+=`<div class="card"><h3>${SEL_COMPS[c.tipo].ic} ${SEL_COMPS[c.tipo].n}</h3><small class="mu">${c.camp?'🏆 Campeã: '+fl(c.camp)+' '+c.camp+' · Vice: '+fl(c.vice)+' '+c.vice:c.fase==='fim'?'Encerrada':'Em andamento'}${SEL_COMPS[c.tipo].premio?' · premiação R$ '+(SEL_COMPS[c.tipo].premio/1e6)+' mi':''}</small></div>`;
  if(c.tipo==='elim'){
    SEL_CONFS.forEach(cf=>{const tab=c.tabs[cf],ts=Object.keys(tab);h+=`<div class="card"><div class="tag">${cf}</div>${selTabHTML(tab,ts)}</div>`});
  }else{
    c.grupos.forEach(g=>{h+=`<div class="card"><div class="tag">${g.n}</div>${selTabHTML(c.tab,g.times)}</div>`});
    (c.ko||[]).forEach(f=>{h+=`<div class="card"><div class="tag">${f.n}</div>${f.r.map(r=>`<div style="font-size:13px;padding:2px 0">${fl(r.a)} ${r.a} <b>${r.ga}x${r.gb}</b> ${r.b} ${fl(r.b)}${r.pen?` <small class="mu">(pên. ${r.pen[0]}x${r.pen[1]})</small>`:''}</div>`).join('')}</div>`});
  }
  const arr=Object.keys(c.art).map(k=>c.art[k]);
  const art=arr.slice().sort((x,y)=>y.g-x.g||y.a-x.a).filter(x=>x.g>0).slice(0,8),ass=arr.slice().sort((x,y)=>y.a-x.a||y.g-x.g).filter(x=>x.a>0).slice(0,8);
  h+=`<div class="card"><div class="tag">⚽ Artilharia</div>${art.map((x,i)=>`<div class="row" style="padding:2px 0"><span>${i+1}. ${x.n} ${fl(x.p)}</span><b>${x.g}</b></div>`).join('')||'<small class="mu">—</small>'}</div>`;
  h+=`<div class="card"><div class="tag">🎯 Assistências</div>${ass.map((x,i)=>`<div class="row" style="padding:2px 0"><span>${i+1}. ${x.n} ${fl(x.p)}</span><b>${x.a}</b></div>`).join('')||'<small class="mu">—</small>'}</div>`;
  return h;
}
function selTabHTML(tab,times){
  const ord=selOrdena(tab,times),s=S.sel;
  return`<table style="width:100%;font-size:12px"><tr><th></th><th style="text-align:left">Seleção</th><th>P</th><th>J</th><th>V</th><th>E</th><th>D</th><th>SG</th></tr>`+ord.map((p,i)=>{const o=tab[p];return`<tr style="${p===s.meu?'background:#14532d55':''}"><td>${i+1}</td><td style="text-align:left">${fl(p)} ${p}</td><td class="y">${o.pts}</td><td>${o.j}</td><td>${o.v}</td><td>${o.e}</td><td>${o.d}</td><td>${o.gp-o.gc}</td></tr>`}).join('')+`</table>`;
}
function selTelaHst(){
  const s=S.sel;
  return`<div class="card"><h3>📜 Histórico das seleções</h3>`+(s.hist.length?s.hist.map(h=>`<div style="padding:6px 0;border-top:1px solid var(--bd)"><b>${h.ic} ${h.nome}</b> <small class="mu">temp. ${h.temp}</small><br>🏆 ${fl(h.camp)} ${h.camp} · 🥈 ${fl(h.vice)} ${h.vice}${h.art?`<br><small class="mu">⚽ Artilheiro: ${h.art.n} ${fl(h.art.p)} (${h.art.g})${h.ass?' · 🎯 '+h.ass.n+' ('+h.ass.a+')':''}</small>`:''}</div>`).join(''):'<small class="mu">Os campeões aparecem aqui conforme os torneios terminam.</small>')+`</div>`;
}
function selTelaTec(){
  const s=S.sel,t=s.tecst,ap=t.j?Math.round((t.v*3+t.e)/(t.j*3)*100):0;
  let h=`<div class="card"><h3>👔 Meu histórico em seleções</h3>${s.meu?`<small class="mu">Atual: ${fl(s.meu)} ${s.meu} desde a temp. ${s.tec[s.meu].desde}</small>`:'<small class="mu">Você não comanda uma seleção no momento.</small>'}
   <div class="fcGrid" style="margin-top:8px"><div><small>Jogos</small><b>${t.j}</b></div><div><small>Vitórias</small><b>${t.v}</b></div><div><small>Empates</small><b>${t.e}</b></div><div><small>Derrotas</small><b>${t.d}</b></div>
   <div><small>Aproveitamento</small><b>${ap}%</b></div><div><small>Gols pró</small><b>${t.gp}</b></div><div><small>Gols contra</small><b>${t.gc}</b></div><div><small>Títulos</small><b>${t.tit}</b></div>
   <div><small>Melhor ranking FIFA</small><b>${t.rkMax?t.rkMax+'º':'—'}</b></div><div><small>Maior invencibilidade</small><b>${t.maxInv}</b></div></div>
   ${Object.keys(t.por).length?`<small class="mu">🏆 ${Object.keys(t.por).map(k=>k+' ×'+t.por[k]).join(' · ')}</small>`:''}</div>`;
  if(s.meu)h+=`<button class="s big" onclick="selDeixa()">Deixar a seleção</button>`;
  return h;
}

const _proximoJogoInfo=proximoJogoInfo;
proximoJogoInfo=function(){const r=_proximoJogoInfo.apply(this,arguments);try{if(r&&r.comp==='sel'){const d=agendaAtual();r.titulo=d&&d.verao?'🌐 Torneios de seleções':'🌐 Data FIFA — seleções em campo';if(S.sel&&S.sel.meu)r.titulo+=' · você comanda '+S.sel.meu}}catch(e){}return r};


/* ---------- PARTIDA DA SUA SELEÇÃO AO VIVO (mesmo esquema das copas do jogo) ---------- */
const SEL_COR={Brasil:['#f7d117','#0a7d33'],Argentina:['#75aadb','#ffffff'],Colômbia:['#fcd116','#003893'],Uruguai:['#6cb4ee','#111111'],Equador:['#ffd100','#034ea2'],Chile:['#d52b1e','#0039a6'],Paraguai:['#d52b1e','#ffffff'],Peru:['#ffffff','#d91023'],
 França:['#0055a4','#ffffff'],Espanha:['#c60b1e','#f1bf00'],Inglaterra:['#ffffff','#1c2c5b'],Alemanha:['#ffffff','#111111'],Portugal:['#006600','#ff0000'],Itália:['#0b5fb4','#ffffff'],Holanda:['#f36c21','#ffffff'],Bélgica:['#e30613','#111111'],Croácia:['#ff0000','#ffffff'],Suíça:['#e30613','#ffffff'],Dinamarca:['#c8102e','#ffffff'],Turquia:['#e30a17','#ffffff'],Polônia:['#ffffff','#dc143c'],Áustria:['#ed2939','#ffffff'],Rússia:['#d52b1e','#ffffff'],Escócia:['#0a2a66','#ffffff'],
 México:['#006847','#ce1126'],'Estados Unidos':['#1f2a5a','#ffffff'],Canadá:['#d80621','#ffffff'],'Costa Rica':['#d6001c','#002b7f'],Panamá:['#d21034','#ffffff'],Jamaica:['#fed100','#009b3a'],
 Marrocos:['#c1272d','#006233'],Senegal:['#ffffff','#00853f'],Nigéria:['#008751','#ffffff'],'Costa do Marfim':['#f77f00','#009e60'],Egito:['#ce1126','#111111'],Argélia:['#ffffff','#006233'],Gana:['#ffffff','#fcd116'],Camarões:['#007a5e','#ce1126'],Tunísia:['#e70013','#ffffff'],'África do Sul':['#ffb612','#007a4d'],
 Japão:['#1f3a93','#ffffff'],'Coreia do Sul':['#c60c30','#ffffff'],Irã:['#ffffff','#239f40'],Austrália:['#fcd116','#00843d'],'Arábia Saudita':['#006c35','#ffffff'],Catar:['#8d1b3d','#ffffff'],Uzbequistão:['#ffffff','#1eb53a'],Iraque:['#ffffff','#007a3d']};
function selEspiaMeuJogo(d){
  const snap=JSON.stringify(S.sel);S.sel.espiao={};
  let jg=null;try{selJogaData(d);jg=S.sel.espiao.jogo||null}catch(e){console.log('espia',e)}
  S.sel=JSON.parse(snap);return jg;
}
function selClubeLive(p,formUsuario){
  const x=selXI(p);
  const elenco=x.refs.map(r=>{const c=Object.assign({},r.j);['conv','suspenso','expulso','emprestadoFora','lesionadoJogo','lesAoVivo','jogou'].forEach(k=>delete c[k]);
    c.lesao=0;c.tit=false;c.en=100;c.nac=p;c.amarelos=0;c.hum=c.hum||50;return c});
  const cor=SEL_COR[p]||['#334155','#ffffff'];
  const c={id:0,nome:p,sig:p.slice(0,3).toUpperCase(),cor:cor[0],cor2:cor[1],forca:0,elenco,form:formUsuario||'4-3-3',caixa:0,pts:0,j:0,v:0,e:0,d:0,gp:0,gc:0,selecao:true,ext:true};
  c.forca=forcaMedia(c);
  try{auto(c)}catch(e){console.log('auto sel',e)}
  return c;
}
function selComecaLive(jg,d){
  const s=S.sel,meu=s.meu,A=jg.a,B=jg.b,meuEhA=A===meu;
  const CA=selClubeLive(A,meuEhA?S.form:null),CB=selClubeLive(B,meuEhA?null:S.form);
  S._clbak={clubes:S.clubes,meu:S.meu,fixt:S.fixt,rodada:S.rodada,ids:S.clubes.map(c=>c.id)};
  S.clubes=[CA,CB];CA.id=0;CB.id=1;S.meu=meuEhA?0:1;S.fixt=[[[0,1]]];S.rodada=0;
  S.clAoVivo={meuEhA,sel:true,A,B,opts:jg.opts,xiA:CA.elenco.filter(x=>x.tit).map(x=>x.id),xiB:CB.elenco.filter(x=>x.tit).map(x=>x.id)};
  try{est(CA);est(CB)}catch(e){}
  let ok=true;try{ok=criaLive()!==false}catch(e){console.log('criaLive sel',e);ok=false}
  if(!ok){selRestauraClubes();s.liveRes=null;return false}
  S.live.outras=[];S.live.emCL=true;S.live.tela='lista';
  S.aba='live';render();try{somApito();playLive()}catch(e){}
  return true;
}
function selRestauraClubes(){
  const bak=S._clbak;if(!bak)return;
  S.clubes=bak.clubes;S.meu=bak.meu;S.fixt=bak.fixt;S.rodada=bak.rodada;S._clbak=null;if(bak.ids)S.clubes.forEach((c,i)=>{c.id=bak.ids[i]});S.clAoVivo=null;
}
function selFimLive(){
  const L=S.live,j=L.jogos[0],ai=S.clAoVivo,s=S.sel,CA=S.clubes[0],CB=S.clubes[1];
  const evs=[];
  j.ev.forEach(e=>{
    if(e.t==='g')evs.push({t:'g',m:e.m,lado:e.lado,id:e.jid,n:e.n,as:e.ass||null,aid:e.assId||null});
    else if(e.t==='c')evs.push({t:e.verm?'vm':'am',m:e.m,lado:e.lado,id:e.jid,n:e.n});
  });
  const ga=j.ga,gb=j.gb;let pen=null;
  if(ai.opts&&ai.opts.ko&&ga===gb){
    const dif=(CA.forca-CB.forca)/40,rg=selRng('penlive|'+S.temp+'|'+ai.A+ai.B+Math.random());
    const pa=3+Math.floor(rg()*3)+(rg()<.5+dif?1:0),pb=3+Math.floor(rg()*3)+(rg()<.5-dif?1:0);
    pen=pa===pb?(rg()<.5?[pa+1,pb]:[pa,pb+1]):[pa,pb];
  }
  const xi=(C,ids)=>{const set=new Set(ids.concat(C.elenco.filter(x=>x.tit).map(x=>x.id)));return[...set].map(id=>({id,j:C.elenco.find(x=>x.id===id)})).filter(r=>r.j)};
  const xiA=xi(CA,ai.xiA),xiB=xi(CB,ai.xiB);
  const golsPor={};evs.filter(e=>e.t==='g').forEach(e=>{golsPor[e.id]=(golsPor[e.id]||0)+1});
  const top=Object.keys(golsPor).sort((x,y)=>golsPor[y]-golsPor[x])[0];
  const vencXI=ga>gb?xiA:gb>ga?xiB:(pen&&pen[0]>pen[1]?xiA:xiB);
  const melhor=top?(xiA.concat(xiB).find(r=>r.id===top).j.nome):vencXI.slice().sort((x,y)=>y.j.f-x.j.f)[0].j.nome;
  const rel={a:ai.A,b:ai.B,ga,gb,pen,ev:evs,melhor,_xiA:xiA,_xiB:xiB};
  selRestauraClubes();
  try{limpaPartidaEstado()}catch(e){}
  S.live=null;S.subs=0;S.pos=null;S.aba='home';
  s.liveRes=rel;
  const d=agendaAtual();
  if(d&&d.comp==='sel')selRodadaData(d);else{s.liveRes=null;render()}
}
const _fimLive4=fimLive;
fimLive=function(){if(S.live&&S.live.emCL&&S.clAoVivo&&S.clAoVivo.sel)return selFimLive();return _fimLive4.apply(this,arguments)};
const _tituloAoVivo=tituloAoVivo;
tituloAoVivo=function(){
  try{const ai=S.clAoVivo;if(S.live&&S.live.emCL&&ai&&ai.sel){const o=ai.opts||{},c=SEL_COMPS[o.comp];return`🌐 ${c?c.n:'Seleções'}${o.fase?' · '+o.fase:''}`}}catch(e){}
  return _tituloAoVivo.apply(this,arguments);
};

